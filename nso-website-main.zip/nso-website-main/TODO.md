== WEBSITE ==

MENU
-[x] Create a mobile menu for the site
-[ ] Site mega menu does not close on clicking outside the menu when on home page
-[ ] Site menu misbehaves at some point when page is scrolled
-[x] Site logo not available on mobile on pages other than the homepage

 PUBLICATIONS/REPORTS
-[x] Create a latest publication page linked to the one on home page
-[x] Report should be able to handle more than one file
-[x] Report should be available only in its own super category (bug fix)
-[ ] Categories should be an extra filter when clicked within a Super category
-[x] Reports should be listed by latest published first in all appearances.
-[x] Report view breaks because there is no category. Also applies to recent releases.

 MAP
-[ ] We should try to use the DISTRICT/CITY map - restructure how districts and cities relate

 CENSUS
-[x] Finalise Census page with files/resources and regional/district data provided by single endpoint

 CPI
-[ ] Add CPI map - select a map that spans a reasonable height showing CPI trend
-[ ] CPI data endpoint by Year and Month

 SEARCH
-[x] Site Search to be revisited

 MISCELLANEOUS
-[x] Former commissioners should be featured on the website
-[ ] Add picture and video gallery under about us
-[x] Add a page-loading component for all pages waiting for data
-[ ] All pages that have paged data should have a LOAD MORE button.
-[ ] Page should have titles in web browser for SEO.

 == CMS == 
-[x] Email subscription to be mapped to models subscribed for notifications
-[x] Finalise Census page with files/resources and regional/district data provided by single endpoint
-[x] Report should be able to handle more than one file
-[x] Create a latest publication page linked to the one on home page [endpoint]
-[x] Site Search to be revisited
-[x] All listings in CMS should be ordered by latest created first
-[x] Private downloads, management of users and permissions [PPPC site specific feature]
-[x] Logo in CMS disappears when you are not on dashboard
