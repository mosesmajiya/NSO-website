<template>
  <nuxt-link :to="`${ link }`" class="md:w-1/2 pb-10 flex items-center group">
    <div class="mr-4">
      <div class="bg-primary-400 group-hover:bg-red-500 text-white lg:w-20 lg:h-20 w-16 h-16 flex items-center justify-center rounded-full transition duration-500 ease-in-out">
        <slot/>
      </div>
    </div>
    <div>
      <div class="font-display font-bold text-sm text-gray-600 lg:text-gray-400 w-full group-hover:text-red-500">{{ label }}</div>
      <div class="font-display font-medium text-2xl xl:text-4xl leading-tight text-gray-700 lg:text-white group-hover:text-red-500">
        {{ value | numeral }}<span v-if="isPercentage">%</span>
      </div>
    </div>
  </nuxt-link>
</template>

<script>
export default {
  name: "QuickStat",
  props: {
    label: String,
    value: String,
    link: String,
    type: String
  },
  computed: {
    isPercentage(){
      return this.type=== 'percentage'
    }
  }
}
</script>

<style scoped>

</style>
