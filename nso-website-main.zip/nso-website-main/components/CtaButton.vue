<template>
  <div class="pb-4 md:w-1/2 lg:flex-1">
    <button
      :class="`bg-${accent}-400 hover:bg-${accent}-600`"
      class="flex lg:hidden xl:flex x w-full py-4 px-6 focus:outline-none rounded justify-center">
      <svg class="w-6 h-6 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
           xmlns="http://www.w3.org/2000/svg">
        <path d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"></path>
      </svg>
      <slot/>
    </button>
  </div>
</template>

<script>
export default {
  name: "CtaButton",
  props: {
    accent: {
      default: 'green'
    }
  }
}
</script>

<style scoped>

</style>
