<template>
  <footer>
    <div class="bg-gradient-to-b from-black to-gray-600 text-gray-300">
      <div class="container mx-auto md:flex pt-16 pb-5 px-4">

        <div class="lg:w-1/4 px-5 md:mr-8 mb-5 lg:mb-0">
          <h1 class="tracking-widest mb-8 font-display font-semibold">About</h1>
          <div class="">
            <nuxt-link class="block pb-2 mb-2 text-sm" to="/about">National Statistical Office</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="/news">News</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="/events">Events</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="/vacancies">Job Opportunities</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="/contact">Contact</nuxt-link>
          </div>
        </div>

        <div class="lg:w-1/4 px-5 md:mr-8 mb-5 lg:mb-0">
          <h1 class="tracking-widest mb-8 font-display font-semibold">Quick Statistics</h1>
          <div class="">
            <nuxt-link class="block pb-2 mb-2 text-sm" to="#">Latest Census</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="#">Gross Domestic Product</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="#">Consumer Price Index</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="#">NADA</nuxt-link>
            <nuxt-link class="block pb-2 mb-2 text-sm " to="#">MASEDA</nuxt-link>
          </div>
        </div>

        <div class="lg:w-1/4 px-5 md:mr-8 mb-5 lg:mb-0">
          <h1 class="tracking-widest mb-8 font-display font-semibold">Government Resources</h1>
          <a v-for="link in localLinks" v-bind:key="link.id" :href="link.url"
             class="block pb-2 mb-2 text-sm "
             target="_blank">{{ link.name }}</a>
        </div>

        <div class="lg:w-1/4 px-5 md:mr-8 mb-5 lg:mb-0">
          <h1 class="tracking-widest mb-8 font-display font-semibold">External Resources</h1>
          <a v-for="link in foreignLinks" v-bind:key="link.id" :href="link.url"
             class="block pb-2 mb-2 text-sm "
             target="_blank">{{ link.name }}</a>
        </div>

      </div>

      <div class="bg-gray-700 pt-10 lg:mt-5">
        <div class="container mx-auto mx-10">
          <div class="flex flex-wrap justify-center">
            <nuxt-link class="flex items-center mx-4" to="$store.state.settings.facebook" target="_blank">
              <svg class="h-5 w-5 fill-current text-gray-300 hover:text-blue-700" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <title>Facebook</title>
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
            </nuxt-link>
            <nuxt-link class="flex items-center mx-4" to="$store.state.settings.linkedin" target="_blank">
              <svg class="h-5 w-5 fill-current text-gray-300 hover:text-blue-300" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                <title>Linkedin</title>
                <path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"/>
              </svg>
            </nuxt-link>
            <nuxt-link class="flex items-center mx-4" to="$store.state.settings.instagram" target="_blank">
              <svg class="h-5 w-5 fill-current text-gray-300 hover:text-yellow-600" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                <title>Instagram</title>
                <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/>
              </svg>
            </nuxt-link>
            <nuxt-link class="flex items-center mx-4" to="$store.state.settings.youtube" target="_blank">
              <svg class="h-5 w-5 fill-current text-gray-300 hover:text-red-600" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                <title>Youtube</title>
                <path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/>
              </svg>
            </nuxt-link>
          </div>
        </div>
        <div class="container mx-auto text-center text-gray-300 text-sm p-5 font-display">
          Copyright &copy; {{ new Date() | date('YYYY') }} National Statistical Office of Malawi. All Rights Reserved
        </div>
      </div>
    </div>

  </footer>
</template>

<script>
import BrandIcon from "~/components/BrandIcon";
import MIcon from "~/components/MIcon";

export default {
  name: "SiteFooter",
  components: {MIcon, BrandIcon},
  props: ['articles', 'links'],

  mounted() {
    this.scrollToTop()
  },
  computed: {
    settings() {
      return this.$store.state.settings
    },
    localLinks() {
      return this.links.filter(link => link.type === 'local')
    },
    foreignLinks() {
      return this.links.filter(link => link.type === 'foreign')
    }
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  }
}
</script>
