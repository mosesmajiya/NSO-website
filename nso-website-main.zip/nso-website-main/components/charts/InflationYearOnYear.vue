<template>
  <div class="">
    <line-chart :chart-data="dataCollection" :options="options"></line-chart>
  </div>
</template>

<script>
import LineChart from '../../charts/LineChart.js'
import moment from "moment";

export default {
  name: "InflationYearOnYear",
  components: {
    LineChart
  },
  data () {
    return {
      dataCollection: null,
      inflation: []
    }
  },
  mounted () {
    this.$axios.get('cpi/graph').then(res => {
      this.inflation = res.data.data
      this.fillData()
    })
  },
  methods: {
    fillData () {
      this.dataCollection = {
        labels: this.labels,
        datasets: [
          {
            label: 'National Inflation',
            fill: false,
            pointRadius:4,
            pointHoverRadius:6,
            pointHoverBackgroundColor: '#c51d1d',
            pointBackgroundColor: '#c51d1d',
            borderColor: '#c51d1d',
            data: this.inflationRate
          },
          {
            label: 'Food Inflation',
            fill: false,
            pointRadius:4,
            pointHoverRadius:6,
            pointHoverBackgroundColor: '#fd9c02',
            pointBackgroundColor: '#fd9c02',
            borderColor: '#fd9c02',
            data: this.foodInflation
          },
          {
            label: 'Non-Food Inflation',
            fill: false,
            pointRadius:4,
            pointHoverRadius:6,
            pointHoverBackgroundColor: '#428263',
            pointBackgroundColor: '#428263',
            borderColor: '#428263',
            data: this.nonFoodInflation
          }
        ],
      }
    },
  },
  computed: {
    foodInflation(){
      return this.inflation.map(i => i.food)
    },
    nonFoodInflation(){
      return this.inflation.map(i => i.non_food_inflation)
    },
    inflationRate(){
      return this.inflation.map(i => i.inflation_rate)
    },
    labels(){
      return this.inflation.map(i => moment(i.date).format('MMM YY'))
    },
    options(){
      return {
        responsive: true,
        maintainAspectRatio: false,
      }
    }
  }

}
</script>

<style>
.small {
}
</style>
