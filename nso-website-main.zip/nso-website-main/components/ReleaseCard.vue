<template>
  <nuxt-link v-bind:to="`/publications/${release.super_categories[0].slug}/${release.slug}`"
    class="md:w-1/3 hover:shadow-xl hover:bg-white group border-transparent border-b-4 hover:border-red-400 p-6 rounded-lg">
    <h1 class="font-display text-xl py-2 font-bold group-hover:text-gray-700">{{ release.title }}</h1>
    <p class="text-gray-700 group-hover:text-gray-600">{{ release.abstract | str_limit(100) }}</p>
    <p class="text-sm pt-2 text-gray-600 group-hover:text-gray-500">{{ release.created_at | from_now }}</p>
  </nuxt-link>
</template>

<script lang="ts">

type ReleaseInterface = {
  title: string,
  created_at: Date,
  abstract: string,
  slug: string
}

export default {
  name: "ReleaseCard",
  props: {
    release: {
      type: Object as () => ReleaseInterface
    }
  }
}
</script>
