<template>
  <div v-if="posts.length" class="pb-8">
    <h1 class="uppercase font-display text-sm font-bold">Recent News</h1>
    <div class="my-4">
      <div class="" v-for="post in posts">
        <nuxt-link v-bind:to="`/news/${post.slug}`" v-bind:key="post.id"
                   class="hover:text-gray-700 flex items-start py-2 text-gray-600">
          <span>{{ post.title}}</span>
        </nuxt-link>
        <div class="w-6 border-b-2 border-red-500 mb-4"></div>
      </div>
    </div>
  </div>
</template>

<script>
  import MIcon from "../MIcon";

  export default {
    name: "RecentNews",
    components: {MIcon},
    props: ['posts']
  }
</script>

<style scoped>

</style>
