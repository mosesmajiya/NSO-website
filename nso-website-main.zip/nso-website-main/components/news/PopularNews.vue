<template>
  <div v-if="posts.length" class="pb-8">
    <h1 class="uppercase font-display text-sm font-bold">Popular News</h1>
    <div class="my-4 mx-1">
      <nuxt-link v-bind:to="`/news/${post.slug}`" v-for="post in posts" v-bind:key="post.id"
                 class="hover:text-gray-700 flex items-start py-2 my-1 text-gray-600">
        <div class="rounded-lg overflow-hidden mr-4">
          <img :src="post.image_url" class="h-16 w-16 object-cover" v-if="hasMedia(post)"/>
          <img src="~assets/images/no-image.png" class="h-16 w-16 object-cover" v-else/>
        </div>
        <div class="flex-1">
          <div>{{ post.title}}</div>
          <p class="text-xs flex items-center mt-1">
            {{ post.published_at | from_now }}
          </p>
        </div>
      </nuxt-link>
    </div>
  </div>
</template>

<script>
import MIcon from "../MIcon";

export default {
  name: "PopularNews",
  components: {MIcon},
  props: ['posts'],
  methods: {
    hasMedia(post) {
      return post.media.length
    },
  }
}
</script>

<style scoped>

</style>
