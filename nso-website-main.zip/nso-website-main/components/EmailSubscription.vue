<template>
  <div class="pt-5 font-menu">
    <div class="w-full border border-b border-dashed border-gray-300"></div>
    <div class="flex py-10">
      <div class="w-1/4">
        <button @click="dropDownClick('/subscribe')" class="focus:outline-none w-full px-5 py-3 rounded-lg
          bg-primary-400 text-white text-center hover:bg-primary-500 duration-500 ease-in-out">
          Get Started Now
        </button>
      </div>
      <div class="flex-1 pl-10">
        <h1 class="text-2xl font-semibold font-menu text-gray-700">Subscribe to Email Notifications</h1>
        <div class="pt-2 text-gray-600">
          Don't miss a thing. Get notified by email of our latest publications in any category of your choice.
          Terms and conditions apply.
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "EmailSubscription",

  methods: {
    dropDownClick(link){
      this.closeMegaMenu()
      this.$router.push(link)
    },
    getAllMegaMenu() {
      return Array.from(document.querySelectorAll('.mega-menu'));
    },
    getActiveMegaMenu() {
      return this.getAllMegaMenu().filter(mega => !mega.classList.contains('hidden'))
    },
    hide(element) {
      element.classList.add('hidden')
    },
    makeActive(element) {
      if (element.classList.contains('active')) return
      element.classList.add('active')
    },
    makeInactive(element) {
      if (element.classList.contains('active')) element.classList.remove('active')
    },
    show(element) {
      element.classList.remove('hidden')
    },
    showMenu(menu) {
      this.getActiveMegaMenu().forEach(mega => {
        this.hide(mega)
        let btn = document.getElementById(mega.id.replace('menu-', 'btn-'))
        this.makeInactive(btn.parentNode)
      })
      this.show(menu)
      if (process.browser) {
        this.show(document.getElementById('backdrop'))
        let btn = document.getElementById(menu.id.replace('menu-', 'btn-'))
        this.makeActive(btn.parentNode)
      }
      this.colorNavbar = true;
    },
    closeMenu(menu) {
      this.hide(menu)
      this.closeBackdrop()
      this.colorNavbar = false
      if (process.browser) {
        let btn = document.getElementById(menu.id.replace('menu-', 'btn-'))
        this.makeInactive(btn.parentNode)
      }
    },
    closeBackdrop() {
      if (process.browser) this.hide(document.getElementById('backdrop'))
    },
    isHidden(element) {
      return element.classList.contains('hidden')
    },
    onScroll() {
      const currentScrollPosition = window.pageXOffset || document.documentElement.scrollTop
      this.scrolledDown = currentScrollPosition >= 98;
    },
    closeMegaMenu() {
      this.getActiveMegaMenu().forEach(mega => {
        if (process.browser) {
          let btn = document.getElementById(mega.id.replace('menu-', 'btn-'))
          this.makeInactive(btn.parentNode)
        }
        this.hide(mega)
      })
      this.closeBackdrop()
      this.colorNavbar = false
    },
  }
}
</script>

