<template>
  <div class="fixed w-full z-0">
    <MobileNav/>
    <div id="backdrop" class="absolute inset-0 bg-transparent hidden" @click="closeMegaMenu"></div>
    <div :class="{'shadow': scrolledDown, 'fixed': onLandingPage, 'bg-white border-transparent border-b border-gray-200': !onLandingPage,
    'bg-white border-0': !onLandingPage && scrolledDown}" class="fixed inset-x-0 w-full">
      <div :class="{'bg-white': scrolledDown, 'bg-green-100': colorNavbar && !scrolledDown || !onLandingPage && !scrolledDown}"
        class="navbar font-display w-full">
        <div :class="scrolledDown ? 'pt-3 pb-5': 'pt-8 pb-10'"
             class="container mx-auto flex justify-between relative px-10 lg:items-baseline items-center">
          <div class="">
            <nuxt-link to="/">
              <img alt="National Statistical Office" class="h-10 -mb-3 hidden"
                   :class="{'xl:block': !scrolledDown && !colorMainMenu && onLandingPage, 'hidden': scrolledDown || colorMainMenu }"
                   src="~assets/images/nso-logo.png">
              <img alt="National Statistical Office" class="h-10 -mb-3 hidden"
                   :class="{'xl:block': scrolledDown || colorMainMenu || !onLandingPage, 'hidden': !scrolledDown}"
                   src="~assets/images/nso-logo-color.png">
              <img alt="National Statistical Office" class="h-6 -mb-1 xl:hidden"
                   :class="{'block': scrolledDown, 'hidden': !scrolledDown}" src="~assets/images/nso-logo-sm.png">
              <img alt="National Statistical Office" class="h-10 pt-3 md:h-12 lg:-mt-10 lg:pt-4 -mt-6 ml-2 absolute hidden"
                   :class="{'md:block': !scrolledDown}"
                   src="~/assets/images/malawi-government-logo-small.png">
            </nuxt-link>
          </div>
          <nav id="main-nav" :class="{'text-gray-700': scrolledDown || colorMainMenu, 'text-gray-300':onLandingPage}"
               class="font-semibold hidden lg:block">
            <ul class="flex">
              <li class="mx-4 relative">
                <button id="btn-statistics" class="font-semibold focus:outline-none" @click="toggleMegaMenu">
                  Statistics
                </button>
              </li>
              <li class="mx-4 relative">
                <button id="btn-census" class="font-semibold focus:outline-none" @click="toggleMegaMenu">Census</button>
              </li>
              <li class="mx-4 relative">
                <button id="btn-publications" class="font-semibold focus:outline-none" @click="toggleMegaMenu">
                  Publications
                </button>
              </li>
              <li class="mx-4 relative">
                <button id="btn-activities" class="font-semibold focus:outline-none" @click="toggleMegaMenu">NSS
                  Activities
                </button>
              </li>
              <li class="mx-4 relative">
                <button id="btn-archives" class="font-semibold focus:outline-none" @click="toggleMegaMenu">Data
                  Archives
                </button>
              </li>
              <li class="mx-4 relative">
                <button id="btn-about" class="font-semibold focus:outline-none" @click="toggleMegaMenu">About Us
                </button>
              </li>
            </ul>
          </nav>
          <div
            :class="{'text-gray-700': scrolledDown || !onLandingPage, 'lg:text-gray-700': scrolledDown || !onLandingPage }"
            class="flex text-red-600 lg:text-gray-100">
            <button class="" @click="openSearch">
              <ic-icon class="mr-4" path="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </button>
            <button @click="openMobileNav">
              <ic-icon class="lg:hidden" path="M4 6h16M4 12h16m-7 6h7"/>
            </button>
          </div>
        </div>

        <!-- Statistics mega menu -->
        <div id="menu-statistics"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10">
            <div class="flex font-menu flex-wrap">
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">What's New?</p>
                <button class="mb-5 group text-left focus:outline-none" @click="dropDownClick('/recent-releases')">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Recent Releases</h1>
                  <p class="text-gray-500 text-sm">
                    Get our most recently published reports. Don't miss a thing.
                  </p>
                </button>
                <button @click="dropDownClick('/page/census-guidelines')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Guidelines</h1>
                  <p class="text-gray-500 text-sm">
                    Population Census guidelines
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Economy</p>
                <button @click="dropDownClick('/')" class="pb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Gross Domestic Product</h1>
                  <p class="text-gray-500 text-sm">
                    The total monetary or market value of all the finished goods and services produced
                  </p>
                </button>
                <button @click="dropDownClick('/consumer-price-index')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Consumer Price Index</h1>
                  <p class="text-gray-500 text-sm">
                    The average change in prices that consumers pay for a basket of goods and services
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-white pb-6">N</p>
                <button @click="dropDownClick('/')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Labour Market</h1>
                  <p class="text-gray-500 text-sm">
                    The supply of and demand for labor in the country
                  </p>
                </button>
                <button @click="dropDownClick('/')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Unemployment Rate</h1>
                  <p class="text-gray-500 text-sm">
                    The unemployment rate is the percent of the labor force that is jobless
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Environment</p>
                <button @click="dropDownClick('/')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Agriculture</h1>
                  <p class="text-gray-500 text-sm">
                    Statistical analysis of agricultural impact on environment.
                  </p>
                </button>
                <button @click="dropDownClick('/')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Energy</h1>
                  <p class="text-gray-500 text-sm">
                    Information on the environment and energy relations
                  </p>
                </button>
              </div>
            </div>
            <EmailSubscription/>
          </div>
        </div>

        <!-- Census mega menu -->
        <div id="menu-census"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10">
            <div class="flex font-menu flex-wrap">
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Population and Housing Census</p>
                <button @click="dropDownClick('/census/2018')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">2018</h1>
                  <p class="text-gray-500 text-sm">
                    Sixth Population and Housing Census since Malawi got its independence in 1964
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-white pb-6">1</p>
                <button @click="dropDownClick('/census/2008')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">2008</h1>
                  <p class="text-gray-500 text-sm">
                    Fifth Population and Housing Census since Malawi got its independence in 1964
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-white pb-6">2</p>
                <button @click="dropDownClick('/census/1998')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">1998</h1>
                  <p class="text-gray-500 text-sm">
                    Fourth Population and Housing Census since Malawi got its independence in 1964
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-white pb-6">3</p>
                <button @click="dropDownClick('/census/1987')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">1987</h1>
                  <p class="text-gray-500 text-sm">
                    Third Population and Housing Census since Malawi got its independence in 1964
                  </p>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Publications mega menu -->
        <div id="menu-publications"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10 font-menu">
            <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Categories</h1>
            <p class="text-sm text-gray-500 pb-6">Our publications are grouped into so many different categories by
              sector.</p>
            <div class="flex flex-wrap items-center text-sm">
              <button @click="dropDownClick(`/publications/${publication.slug}`)" v-for="publication in publications"
                      :key="publication.id" class="mb-3 cursor-pointer w-1/5 pr-4 focus:outline-none">
                <span class="pb-2 text-gray-600 hover:text-red-500 flex items-center">
                  <svg class="w-4 h-4 mr-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                  </svg>
                  {{ publication.name }}
                </span>
              </button>
            </div>
            <EmailSubscription/>
          </div>
        </div>

        <!-- Activities mega menu -->
        <div id="menu-activities"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10">
            <div class="flex font-menu flex-wrap">
              <div class="w-1/2 pr-6">
                <p class="text-sm text-gray-500 pb-6">The National Statistical System (NSS)</p>
                <div class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Strategic Plan 2013 - 2017</h1>
                  <p class="text-gray-500 text-sm">
                    A guide to data suppliers, producers and users of statistics to achieve coordinated, harmonized,
                    relevant and timely official statistics
                  </p>
                </div>
              </div>
              <div class="w-1/2 pr-6">
                <p class="text-sm text-white pb-6">N</p>
                <div class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Strategic Plan 2008 - 2012</h1>
                  <p class="text-gray-500 text-sm">
                    A guide to data suppliers, producers and users of statistics to achieve coordinated, harmonized,
                    relevant and timely official statistics
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Archives mega menu -->
        <div id="menu-archives"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10">
            <div class="flex font-menu flex-wrap">
              <div class="w-1/3 pr-6">
                <div class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">NADA</h1>
                  <p class="text-gray-500 text-sm">
                    National Data Archive
                  </p>
                </div>
              </div>
              <div class="w-1/3 pr-6">
                <div class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">MASEDA</h1>
                  <p class="text-gray-500 text-sm">
                    The Malawi Socio-Economic Database
                  </p>
                </div>
              </div>
              <div class="w-1/3 pr-6">
                <div class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Malawi Data Portal</h1>
                  <p class="text-gray-500 text-sm">
                    Malawi Data At-a-Glance
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- About mega menu -->
        <div id="menu-about"
             :class="{'border-green-200': !scrolledDown}"
             class="hidden absolute inset-x-0 bg-white border-t py-10 z-10 mega-menu">
          <div class="container mx-auto px-10">
            <div class="flex font-menu flex-wrap">
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Who we are</p>
                <button class="mb-5 group text-left focus:outline-none" @click="dropDownClick('/about')">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">About NSO</h1>
                  <p class="text-gray-500 text-sm">
                    The story of the National Statistical Office in brief
                  </p>
                </button>
                <button @click="dropDownClick('/vacancies')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Vacancies</h1>
                  <p class="text-gray-500 text-sm">
                    Work with us by grabbing available job opportunities
                  </p>
                </button>
                <button @click="dropDownClick('/faq')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">FAQ</h1>
                  <p class="text-gray-500 text-sm">
                    Your frequently asked questions with quick responses
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Within and around us</p>
                <button @click="dropDownClick('/news')" class="pb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">News</h1>
                  <p class="text-gray-500 text-sm">
                    Get latest news happening within and around us
                  </p>
                </button>
                <button @click="dropDownClick('/events')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Events</h1>
                  <p class="text-gray-500 text-sm">
                    A calendar of activities planned or happening within the NSO
                  </p>
                </button>
                <button @click="dropDownClick('/galleries')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Gallery</h1>
                  <p class="text-gray-500 text-sm">
                    See our picture and video galleries
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-white pb-6">N</p>
                <button @click="dropDownClick('/projects')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Projects</h1>
                  <p class="text-gray-500 text-sm">
                    A comprehensive list of projects currently running within the NSO
                  </p>
                </button>
                <button @click="dropDownClick('/newsletters')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Newsletters</h1>
                  <p class="text-gray-500 text-sm">
                    Downloadable compilations of our news and events within a defined time period
                  </p>
                </button>
                <button @click="dropDownClick('/downloads')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Downloads</h1>
                  <p class="text-gray-500 text-sm">
                    Administrative public documents for download
                  </p>
                </button>
              </div>
              <div class="w-1/4 pr-6">
                <p class="text-sm text-gray-500 pb-6">Administration</p>
                <button @click="dropDownClick(`/departments/${ceo.department.slug}/${ceo.slug}`)"
                        class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">The Commissioner</h1>
                  <p class="text-gray-500 text-sm">
                    Meet our top leadership and past officers who once led the NSO
                  </p>
                </button>
                <button @click="dropDownClick('/departments')" class="mb-5 group text-left focus:outline-none">
                  <h1 class="text-xl font-medium pb-2 group-hover:text-red-500">Departments</h1>
                  <p class="text-gray-500 text-sm">
                    Administrative sections and members of staff within the NSO
                  </p>
                </button>
              </div>
            </div>
            <div class="pt-5 font-menu">
              <div class="w-full border border-b border-dashed border-gray-300"></div>
              <div class="flex py-10">
                <div class="w-1/4">
                  <button @click="dropDownClick('/about/contact')" class="focus:outline-none w-full w-full px-5 py-3 rounded-lg
          bg-primary-400 text-white text-center hover:bg-primary-500 duration-500 ease-in-out">
                    Contact us
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- Search modal -->
    <div class="inset-0 w-full h-full bg-black z-40 opacity-75 fixed hidden" @click="closeMobileNav"
         id="mobile-nav-backdrop"></div>

    <div id="search" class="text-white px-10 inset-0 z-50 flex flex-col justify-center fixed hidden container mx-auto"
         @click.exact="closeSearch">
      <form class="container flex items-center border-b-2 border-white text-3xl md:text-5xl" @click.stop=""
            @submit.prevent="doSearch">
        <input v-model="searchQuery"
               class="w-full md:py-3 text-white focus:outline-none px-4 py-2 bg-black bg-opacity-0 flex-1"
               placeholder="What are you looking for?" autofocus>
        <button class="flex px-2" @click.capture="" type="submit">
          <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"
               xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
          </svg>
        </button>
      </form>
      <div class="text-gray-400 mt-10 font-menu text-lg mx-5">
        This is a site-wide search. For best results use short but precise searches with keywords are recommended.
      </div>
    </div>

    <div id="searchBackDrop" class="inset-0 w-full h-full bg-primary-700 z-40 opacity-90 fixed hidden"
         @click="closeSearch"></div>

  </div>

</template>

<script>
import IcIcon from "./icons/ic-icon";
import PublicationLink from './nav/PublicationLink'
import EmailSubscription from "./EmailSubscription";
import MobileNav from "./nav/MobileNav";

export default {
  name: "navbar",
  components: {MobileNav, EmailSubscription, IcIcon, PublicationLink},
  mounted() {
    if (!process.browser) return
    window.addEventListener("scroll", this.onScroll)
  },
  beforeDestroy() {
    if (!process.browser) return
    window.removeEventListener("scroll", this.onScroll)
  },
  data() {
    return {
      scrolledDown: false,
      colorNavbar: false,
      megaIsOpen: false,
      searchQuery: '',
    }
  },
  computed: {
    onLandingPage() {
      return this.$route.path === '/'
    },
    publications() {
      return this.$store.state.publications
    },
    ceo() {
      return this.$store.state.ceo
    },
    colorMainMenu() {
      return this.megaIsOpen || this.scrolledDown || this.colorNavbar
    }
  },
  methods: {
    dropDownClick(link){
      this.closeMegaMenu()
      this.$router.push(link)
    },
    getAllMegaMenu() {
      return Array.from(document.querySelectorAll('.mega-menu'));
    },
    getActiveMegaMenu() {
      return this.getAllMegaMenu().filter(mega => !mega.classList.contains('hidden'))
    },
    hide(element) {
      element.classList.add('hidden')
    },
    makeActive(element) {
      if (element.classList.contains('active')) return
      element.classList.add('active')
    },
    makeInactive(element) {
      if (element.classList.contains('active')) element.classList.remove('active')
    },
    show(element) {
      element.classList.remove('hidden')
    },
    showMenu(menu) {
      this.getActiveMegaMenu().forEach(mega => {
        this.hide(mega)
        let btn = document.getElementById(mega.id.replace('menu-', 'btn-'))
        this.makeInactive(btn.parentNode)
      })
      this.show(menu)
      if (process.browser) {
        this.show(document.getElementById('backdrop'))
        let btn = document.getElementById(menu.id.replace('menu-', 'btn-'))
        this.makeActive(btn.parentNode)
      }
      this.colorNavbar = true;
    },
    closeMenu(menu) {
      this.hide(menu)
      this.closeBackdrop()
      this.colorNavbar = false
      if (process.browser) {
        let btn = document.getElementById(menu.id.replace('menu-', 'btn-'))
        this.makeInactive(btn.parentNode)
      }
    },
    closeBackdrop() {
      if (process.browser) this.hide(document.getElementById('backdrop'))
    },
    isHidden(element) {
      return element.classList.contains('hidden')
    },
    onScroll() {
      const currentScrollPosition = window.pageXOffset || document.documentElement.scrollTop
      this.scrolledDown = currentScrollPosition >= 98;
    },
    closeMegaMenu() {
      this.getActiveMegaMenu().forEach(mega => {
        if (process.browser) {
          let btn = document.getElementById(mega.id.replace('menu-', 'btn-'))
          this.makeInactive(btn.parentNode)
        }
        this.hide(mega)
      })
      this.closeBackdrop()
      this.colorNavbar = false
    },
    toggleMegaMenu(e) {
      let menu = document.getElementById(e.target.id.replace('btn-', 'menu-'))

      if (!this.isHidden(menu)) return this.closeMenu(menu)

      this.showMenu(menu)
    },
    doSearch() {
      this.closeSearch()
      let query = this.searchQuery
      this.searchQuery = ''
      this.$router.push(`/search/${query}`)
    },
    openSearch() {
      document.querySelector('#search').classList.remove('hidden')
      document.querySelector('#searchBackDrop').classList.remove('hidden')
    },
    closeSearch() {
      document.querySelector('#search').classList.add('hidden')
      document.querySelector('#searchBackDrop').classList.add('hidden')
    },
    closeMobileNav() {
      this.closeMobileSubMenu()
      document.querySelector('#mobile-nav').classList.add('hidden')
      document.querySelector('#mobile-nav-backdrop').classList.add('hidden')
    },
    openMobileNav() {
      document.querySelector('#mobile-nav').classList.remove('hidden')
      document.querySelector('#mobile-nav-backdrop').classList.remove('hidden')
    },
    closeMobileSubMenu() {
      document.querySelectorAll('.mobile-dropdown').forEach(function (i) {
        if (!i.classList.contains('hidden')) {
          i.classList.add('hidden')
        }
      })
    },
  }
}
</script>

<style scoped>
.normal {

}

.scrolled {
  @apply bg-green-100 shadow;
}

.mega-menu {
  /* offset-x | offset-y | blur-radius | spread-radius | color */
  box-shadow: 0 1.8rem 1.8rem 0 rgba(0, 0, 0, 0.2);
}

nav#main-nav > ul > li {
  cursor: pointer;
}

nav#main-nav > ul > li::after {
  position: absolute;
  z-index: 10000;
  @apply inset-x-0 border border-b border-red-500 text-center;
  top: 2.2rem;
  opacity: 0;
  content: "";
}

nav#main-nav > ul > li:hover::after, nav#main-nav > ul > li.active::after, nav#main-nav > ul > li.open::after {
  opacity: 1;
}

</style>
