<template>
  <action-button @click="$emit('click')" v-bind:busy="busy" class="flex items-center">
    <span v-if="!busy"><slot/></span>
    <span v-else>Loading</span>
    <fa-icon type="fas" size="lg" icon="circle-notch" :spin="busy" v-if="busy" class="ml-2"></fa-icon>
  </action-button>
</template>

<script>
import ActionButton from "./ActionButton";
import FaIcon from "./FaIcon";

export default {
  name: "LoaderButton",
  components: {FaIcon, ActionButton},
  props: {
    busy: {default: false},
  }
}
</script>

<style scoped>

</style>
