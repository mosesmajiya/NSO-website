<template>
    <nuxt-link :to="`/news/${slug}`" class="flex space-x-3 md:mb-4 xl:h-24 h-24">
      <div class="rounded-2xl overflow-hidden hidden md:block">
        <img :alt="title" :src="image" class="object-cover xl:w-24 xl:h-24 w-24 h-24"/>
      </div>
      <div class="text-gray-700 lg:text-gray-200 md:py-3 xl:pt-1">
        <h1 class="font-display text-lg xl:text-2xl leading-tight">{{ title | strip | str_limit(52) }}</h1>
        <div class="py-1 text-sm hidden xl:block">{{ snippet | strip | str_limit(100) }}</div>
        <div class="py-1 hidden text-sm md:block xl:hidden">{{ snippet | strip | str_limit(70) }}</div>
        <p class="font-display text-sm text-gray-500 lg:text-gray-400">{{ created_at | from_now }}</p>
      </div>
    </nuxt-link>
</template>

<script>
export default {
  name: "AlertSlide",
  props: ['title', 'snippet', 'created_at', 'image', 'slug'],
}
</script>

<style scoped>

</style>
