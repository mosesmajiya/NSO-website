<template>
  <font-awesome-icon :icon="['fab', brand]"/>
</template>

<script>
  export default {
    name: "BrandIcon",
    props: ['brand']
  }
</script>
