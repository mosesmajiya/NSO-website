<template>
  <font-awesome-icon :icon="[type, icon]" fixed-width :size="size" :spin="spin"/>
</template>

<script>
export default {
  name: "FaIcon",
  props: {
    type: {default: 'far'},
    icon: {type: String},
    size: {default: 'sm'},
    spin: {default: false}
  }
}
</script>
