<template>
  <div class="flex items-center justify-center mx-auto w-4/5 md:w-2/5 pb-5">
    <div class="flex-1 border-t-2 border-red-400"/>
    <h1 class="font-menu text-center tracking-widest uppercase py-2 px-8">
      <slot/>
    </h1>
    <div class="flex-1 border-t-2 border-red-400"/>
  </div>
</template>

<script>
export default {
  name: "SectionHeader"
}
</script>

<style scoped>

</style>
