<template>
  <a :href="href" class="px-2 text-lg hover:text-gray-600" target="_blank">
    <brand-icon :brand="brand"/>
  </a>
</template>

<script>
  import BrandIcon from "./BrandIcon";

  export default {
    name: "ContactSocialLink",
    components: {BrandIcon},
    props: ['brand', 'href']
  }
</script>

<style scoped>

</style>
