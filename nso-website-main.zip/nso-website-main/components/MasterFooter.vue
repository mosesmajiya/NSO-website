<template>
  <div>
    <site-footer :articles="popularArticles" :links="links" />
  </div>

</template>

<script>
import SiteFooter from "./SiteFooter";
export default {
  name: "MasterFooter",
  components: {SiteFooter},
  async asyncData({store}) {
    await store.dispatch('fetchSettings')
  },
  computed: {
    settings() {
      return this.$store.state.settings
    },
    popularArticles() {
      return this.$store.state.popularArticles
    },
    links() {
      return this.$store.state.links
    },
  },
}
</script>
