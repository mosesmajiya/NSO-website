<template>
  <transition
    mode="out-in"
    name="fade"
    v-on:enter="enter"
    v-on:leave="leave"
    v-on:before-enter="beforeEnter"
    v-on:before-leave="beforeLeave"
  >
    <slot></slot>
  </transition>
</template>
<script>

export default {
  props: {
    duration: {
      default: false
    }
  },
  methods: {
    beforeEnter(el) {
      el.style.opacity = 0
    },
    enter(el, done) {
      let vm = this
      this.$velocity(el,
        {opacity: 1},
        {
          duration: vm.duration ? vm.duration : 500,
          easing: [0.39, 0.67, 0.04, 0.98],
          complete: function () {
            done()
          }
        }
      )
    },
    beforeLeave(el) {
      el.style.opacity = 1
    },
    leave(el, done) {
      let vm = this
      this.$velocity(el,
        {opacity: 0},
        {
          duration: vm.duration ? vm.duration : 500,
          easing: [0.39, 0.67, 0.04, 0.98],
          complete: function () {
            done()
          }
        }
      )
    }
  }
}
</script>
