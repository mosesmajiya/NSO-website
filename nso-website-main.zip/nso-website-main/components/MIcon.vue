<template>
  <i class="material-icons"><slot/></i>
</template>

<script>

export default {
  name: "MIcon",
  props: {
    solid: {
      default: false
    }
  }
}
</script>
