<template>
  <div>
    <div v-show="modalOn" class="py-5 inset-0 bg-black bg-opacity-75 fixed flex justify-center h-screen"
         @click="hideModal">
      <div id="modal"
           class="flex flex-col justify-between bg-white h-full shadow  relative rounded overflow-hidden container"
           @click.stop>
        <div class="right-0 absolute text-xs text-white uppercase p-2 cursor-pointer" @click="hideModal">[ Close ]</div>
        <div v-if="selectedDistrict.district" class="p-10 flex-0 bg-primary-600 text-white">
          <div class="font-display font-semibold text-3xl">
            {{ selectedDistrict.district.name }} District
          </div>
          <div class="mt-5" v-html="selectedDistrict.district.description"></div>
          <div class="border-t border-dashed border-gray-500 mt-8 pt-5 flex flex-auto">
            <div class="w-1/5">
              <div class="font-display font-semibold text-3xl">{{ selectedDistrict.population | numeral('0,0') }}</div>
              <div class="text-xs uppercase">Population</div>
            </div>
            <div class="w-1/5">
              <div class="font-display font-semibold text-3xl flex items-center">
                <div>{{ selectedDistrict.population_density }}</div>
                <div class="ml-2 text-xs">persons/sq. km</div>
              </div>
              <div class="text-xs uppercase">Population Density</div>
            </div>
            <div class="w-1/5">
              <div class="font-display font-semibold text-3xl flex items-center">
                <div> {{ selectedDistrict.poverty }}</div>
                <div class="text-sm">%</div>
              </div>
              <div class="text-xs uppercase">Poverty</div>
            </div>
            <div class="w-1/5">
              <div class="font-display font-semibold text-3xl flex items-center">
                <div class="mr-2 text-xs">M</div>
                <div>{{ national.life_expectancy_male }}</div>
                <div class="mx-2 text-gray-500 text-xs font-light">|</div>
                <div>{{ national.life_expectancy_female }}</div>
                <div class="ml-2 text-xs">F</div>
              </div>
              <div class="text-xs uppercase">Life Expectancy</div>
            </div>
            <div class="w-1/5">
              <div class="font-display font-semibold text-3xl flex items-center">
                <div>{{ selectedDistrict.fertility_rate }}</div>
                <div class="text-sm">%</div>
              </div>
              <div class="text-xs uppercase">Fertility Rate</div>
            </div>
          </div>
        </div>
        <div class="flex-1 relative bg-red-100 ">
          <div v-if="selectedDistrict.district && selectedDistrict.district.image_url"
               :style="{ backgroundImage: `url(${selectedDistrict.district.image_url})` }"
               class="h-full bg-center bg-cover"></div>
          <div v-else
               :style="{backgroundImage: `url(` + require(`~/assets/images/district-default.jpg`) + `)`}"
               class="h-full bg-center bg-cover"></div>
          <img class="h-96 absolute top-0 mt-16 ml-32" src="~assets/images/malawi-map-static.png"/>
        </div>
        <div class="flex-0 bg-gray-300 text-right py-2 px-4">
          <span class="text-xs text-gray-700 font-display uppercase">{{ selectedDistrict.year }} Census Data</span>
        </div>
      </div>
    </div>
    <client-only>
      <div id="map"></div>
    </client-only>
    <div id="popper" class="rounded-lg shadow text-white bg-red-700 p-2">
      <div id="popperName" class="text-xs font-bold"></div>
      <div id="popperValue"></div>
    </div>
  </div>
</template>

<script>
import {SVG} from "@svgdotjs/svg.js";
import {createPopper} from "@popperjs/core";
import numeral from 'numeral'

export default {
  name: "MalawiMap",
  props: {
    year: {default: 2018},
    height: {default: 550}
  },
  data() {
    return {
      selectedDistrict: {},
      modalOn: false,
      national: {},
      districts: []
    }
  },
  methods: {
    getHex(value) {
      return value.toString(16).padStart(2, '0')
    },
    getColor(ratio) {
      const color1 = '228b22'
      const color2 = 'ffffff'

      if (!isFinite(ratio)) {
        return '#' + color1
      }

      const r = Math.ceil(parseInt(color1.substring(0, 2), 16) * ratio + parseInt(color2.substring(0, 2), 16) * (1 - ratio))
      const g = Math.ceil(parseInt(color1.substring(2, 4), 16) * ratio + parseInt(color2.substring(2, 4), 16) * (1 - ratio))
      const b = Math.ceil(parseInt(color1.substring(4, 6), 16) * ratio + parseInt(color2.substring(4, 6), 16) * (1 - ratio))

      return '#' + this.getHex(r) + this.getHex(g) + this.getHex(b)
    },
    async fetchData() {
      let stats = (await this.$axios.get(`census/${this.year}`)).data.data
      this.national = stats.national
      this.districts = stats.districts

      let population = {}
      stats.districts.forEach(i => population[i.district.code] = i.population)
      return population
    },
    showModal() {
      this.modalOn = true
    },
    hideModal() {
      this.modalOn = false
    },
    formatNumber(value) {
      return numeral(value, '0,0')
    }
  },
  async mounted() {
    if (!process.browser) return
    const popperEl = document.getElementById('popper')
    const popperName = document.getElementById('popperName')
    const popperValue = document.getElementById('popperValue')
    let popperInstance

    const data = await this.fetchData()

    fetch(process.env.publicURL)
      .then(response => response.text())
      .then(image => {
        let startOfSvg = image.indexOf('<svg')
        startOfSvg = startOfSvg >= 0 ? startOfSvg : 0

        const draw = SVG(image.slice(startOfSvg))
          .addTo('#map')
          .size('100%', this.height)
        // .panZoom()

        // get maximum value among the supplied data
        const max = Math.max(...Object.values(data))

        for (const region of draw.find('path')) {
          const regionValue = data[region.id()]

          if (isFinite(regionValue)) {
            // color the region based on it's value with respect to the maximum
            region.fill(this.getColor(regionValue / max))

          }

          // show region data when clicking on it
          region.on('click', () => {
            // alert(`${region.attr('name')} (${region.id()}): ${regionValue}`)
            // this.selectedDistrict = `${region.attr('name')} (${region.id()}): ${regionValue}`
            this.selectedDistrict = this.districts.find(i => i.district.code === region.id())
            this.showModal()
          })

          region.on('mouseover', () => {
            // popperEl.innerText = `${region.attr('name')} (${region.id()}): ${regionValue}`
            region.fill('#333')
            popperName.innerText = region.attr('name')
            popperValue.innerText = regionValue

            popperEl.style.visibility = 'visible'
            popperInstance = createPopper(region.node, popperEl, {placement: 'bottom'})
          })

          region.on('mouseleave', () => {
            popperEl.style.visibility = 'hidden'
            region.fill(this.getColor(regionValue / max))
          })
        }
      })
  }

}
</script>

<style scoped>
body {
  font-family: sans-serif;
  background: #008cc6;
}

small {
  color: #ccc;
}

path {
}

path:hover {
  fill: rebeccapurple;
  @apply cursor-pointer;
}

#popper {
  @apply invisible;
}
</style>
