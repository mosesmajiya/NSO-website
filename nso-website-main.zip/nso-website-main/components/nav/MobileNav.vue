<template>
  <div class="fixed ml-10 right-0 h-screen z-50 w-72 md:w-108 lg:w-120 hidden transition duration-500 ease-in-out" id="mobile-nav">
    <nav class="bg-white h-full">
      <div class="h-16 flex items-center justify-between">
        <logo/>
        <button class="p-4 mr-4 focus:outline-none" @click="closeMobileNav">
          <m-icon>clear</m-icon>
        </button>
      </div>
      <div class="pt-4">
        <MobileNavLink @click="goMobile('/')">Home</MobileNavLink>
        <MobileNavLink @click="goMobile('/recent-releases')">Recent Releases</MobileNavLink>
        <div>
          <button
            @click="openMobileSubMenu($event)"
            class="block py-3 px-8 font-menu flex items-center focus:outline-none mobile-dropdown-link">
            Quick Statistics
            <m-icon>keyboard_arrow_right</m-icon>
          </button>
          <div class="bg-white z-60 inset-0 absolute mobile-dropdown hidden">
            <nav class="">
              <div class="h-16 flex items-center justify-between">
                <div class="ml-8 flex items-center" @click="closeMobileSubMenu">
                  <m-icon class="text-lg mr-2">keyboard_backspace</m-icon>
                  Back
                </div>
                <button class="p-4 mr-4 focus:outline-none" @click="closeMobileNav">
                  <m-icon>clear</m-icon>
                </button>
              </div>
              <div class="pt-4 ml-6">
                <h1 class="text-2xl ml-2 font-bold">Quick Statistics</h1>
                <MobileNavLink @click="goMobile('/')" to="/">2018 Census</MobileNavLink>
                <MobileNavLink @click="goMobile('/')" to="/">Gross Domestic Product</MobileNavLink>
                <MobileNavLink @click="goMobile('/')" to="/">Consumer Price Index</MobileNavLink>
                <MobileNavLink @click="goMobile('/')" to="/">Labour Market</MobileNavLink>
                <MobileNavLink @click="goMobile('/')" to="/">Unemployment Rate</MobileNavLink>
              </div>
            </nav>
          </div>
        </div>
        <div>
          <button
            @click="openMobileSubMenu($event)"
            class="block py-3 px-8 font-menu flex items-center focus:outline-none mobile-dropdown-link">
            Publications
            <m-icon>keyboard_arrow_right</m-icon>
          </button>
          <div class="bg-white z-60 inset-0 absolute mobile-dropdown hidden">
            <nav class="">
              <div class="h-16 flex items-center justify-between">
                <div class="ml-8 flex items-center" @click="closeMobileSubMenu">
                  <m-icon class="text-lg mr-2">keyboard_backspace</m-icon>
                  Back
                </div>
                <button class="p-4 mr-4 focus:outline-none" @click="closeMobileNav">
                  <m-icon>clear</m-icon>
                </button>
              </div>
              <div class="pt-4 ml-6">
                <h1 class="text-2xl ml-2 font-bold">Publications</h1>
                <MobileNavLink v-for="publication in publications" :key="publication.id"
                               @click="goMobile(`/publications/${publication.slug}`)">
                  {{ publication.name }}
                </MobileNavLink>
              </div>
            </nav>
          </div>
        </div>
        <div>
          <button
            @click="openMobileSubMenu($event)"
            class="block py-3 px-8 font-menu flex items-center focus:outline-none mobile-dropdown-link">
            Census
            <m-icon>keyboard_arrow_right</m-icon>
          </button>
          <div class="bg-white z-60 inset-0 absolute mobile-dropdown hidden">
            <nav class="">
              <div class="h-16 flex items-center justify-between">
                <div class="ml-8 flex items-center" @click="closeMobileSubMenu">
                  <m-icon class="text-lg mr-2">keyboard_backspace</m-icon>
                  Back
                </div>
                <button class="p-4 mr-4 focus:outline-none" @click="closeMobileNav">
                  <m-icon>clear</m-icon>
                </button>
              </div>
              <div class="pt-4 ml-6">
                <h1 class="text-2xl ml-2 font-bold">Population and Housing Census</h1>
                <MobileNavLink @click="goMobile('/census/2018')" to="/census/2018">2018 Census</MobileNavLink>
                <MobileNavLink @click="goMobile('/census/2008')" to="/census/2008">2008 Census</MobileNavLink>
                <MobileNavLink @click="goMobile('/census/1987')" to="/census/1987">1987 Census</MobileNavLink>
                <MobileNavLink @click="goMobile('/census/1977')" to="/census/1977">1977 Census</MobileNavLink>
                <MobileNavLink @click="goMobile('/census/1966')" to="/census/1966">1966 Census</MobileNavLink>
              </div>
            </nav>
          </div>
        </div>
        <MobileNavLink @click="goMobile('/news')" to="/news">News</MobileNavLink>
        <MobileNavLink @click="goMobile('/events')">Events</MobileNavLink>
        <MobileNavLink @click="goMobile('/vacancies')">Vacancies</MobileNavLink>
        <MobileNavLink @click="goMobile('/downloads')">Downloads</MobileNavLink>
        <div>
          <button
            @click="openMobileSubMenu($event)"
            class="block py-3 px-8 font-menu flex items-center focus:outline-none mobile-dropdown-link">
            About Us
            <m-icon>keyboard_arrow_right</m-icon>
          </button>
          <div class="bg-white z-60 inset-0 absolute mobile-dropdown hidden">
            <nav class="">
              <div class="h-16 flex items-center justify-between">
                <div class="ml-8 flex items-center" @click="closeMobileSubMenu">
                  <m-icon class="text-lg mr-2">keyboard_backspace</m-icon>
                  Back
                </div>
                <button class="p-4 mr-4 focus:outline-none" @click="closeMobileNav">
                  <m-icon>clear</m-icon>
                </button>
              </div>
              <div class="pt-4 ml-6">
                <h1 class="text-2xl ml-2 font-bold">About Us</h1>
                <MobileNavLink @click="goMobile('/about')">Who we are</MobileNavLink>
                <MobileNavLink @click="goMobile(`/departments/${ceo.department.slug}/${ceo.slug}`)">The Commissioner</MobileNavLink>
                <MobileNavLink @click="goMobile('/departments')">Staff Departments</MobileNavLink>
                <MobileNavLink @click="goMobile('/news')" to="/news">News</MobileNavLink>
                <MobileNavLink @click="goMobile('/news')" to="/newsletters">Newsletters</MobileNavLink>
                <MobileNavLink @click="goMobile('/events')">Events</MobileNavLink>
                <MobileNavLink @click="goMobile('/vacancies')">Vacancies</MobileNavLink>
                <MobileNavLink @click="goMobile('/galleries')">Galleries</MobileNavLink>
                <MobileNavLink @click="goMobile('/faq')">FAQ</MobileNavLink>
                <MobileNavLink @click="goMobile('/about/contact')">Contact Us</MobileNavLink>
              </div>
            </nav>
          </div>
        </div>
        <div class="border-b pb-2 mb-2"></div>
        <MobileNavLink @click="goMobile('/subscribe')" class="font-bold">Subscribe Now</MobileNavLink>
      </div>
    </nav>
  </div>
</template>

<script>
import MobileNavLink from "./MobileNavLink";
import MIcon from "../MIcon";
export default {
  name: "MobileNav",
  components: {MIcon, MobileNavLink},
  methods: {
    openMobileSubMenu(event) {
      let target = event.target.parentNode.querySelector('.mobile-dropdown');
      if (!target) return
      target.classList.remove('hidden')
    },
    closeMobileSubMenu() {
      document.querySelectorAll('.mobile-dropdown').forEach(function (i) {
        if (!i.classList.contains('hidden')) {
          i.classList.add('hidden')
        }
      })
    },
    closeMobileNav() {
      this.closeMobileSubMenu()
      document.querySelector('#mobile-nav').classList.add('hidden')
      document.querySelector('#mobile-nav-backdrop').classList.add('hidden')
    },
    openMobileNav() {
      document.querySelector('#mobile-nav').classList.remove('hidden')
      document.querySelector('#mobile-nav-backdrop').classList.remove('hidden')
    },
    goMobile(event) {
      this.closeMobileNav()
      this.$router.push(event)
    },
  },
  computed: {
    publications() {
      return this.$store.state.publications
    },
    ceo() {
      return this.$store.state.ceo
    },
  }
}
</script>

<style scoped>

</style>
