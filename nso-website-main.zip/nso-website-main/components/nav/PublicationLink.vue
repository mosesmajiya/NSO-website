<template>
<button @click="closeMegaMenu()" class="mb-3 cursor-pointer focus:outline-none" >
  <h1 class="pb-2 text-gray-600 hover:text-red-500 flex items-center">
    <svg class="w-4 h-4 mr-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
    </svg>
    <slot/>
  </h1>
</button>
</template>

<script>
export default {
  name: 'publication-link',
  props: {
    to: {
      default: '#'
    }
  },

  methods: {
    dropDownClick() {
      this.closeMegaMenu()
      this.$router.push(this.to)
    },
    closeMegaMenu() {
      this.getActiveMegaMenu().forEach(mega => {
        if (process.browser) {
          let btn = document.getElementById(mega.id.replace('menu-', 'btn-'))
          this.makeInactive(btn.parentNode)
        }
        this.hide(mega)
      })
      this.closeBackdrop()
      this.colorNavbar = false
    },
    getActiveMegaMenu() {
      return this.getAllMegaMenu().filter(mega => !mega.classList.contains('hidden'))
    },
    makeActive(element) {
      if (element.classList.contains('active')) return
      element.classList.add('active')
    },
    getAllMegaMenu() {
      return Array.from(document.querySelectorAll('.mega-menu'));
    },
  }
}
</script>
