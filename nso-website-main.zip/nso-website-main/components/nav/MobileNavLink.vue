<template>
  <div @click="$emit('click')" class="block py-3 px-8 font-menu">
    <slot/>
  </div>
</template>

<script>
export default {
  name: "MobileNavLink",
  props: ['to']
}
</script>
