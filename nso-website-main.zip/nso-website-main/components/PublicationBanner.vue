<template>
  <div v-if="category.name"
       class="p-10 pt-32 lg:pt-40 pb-12 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
    <div class="container mx-auto xl:px-12">
      <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">
        <svg class="w-8 h-8 mr-2 hidden lg:block" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        {{ category.name }}
      </h1>
      <div class="mb-10">{{ category.description }}</div>
      <form @submit.prevent="search" class="p-8 rounded-lg bg-green-200 flex-col flex md:flex-row">
        <input v-model="query"
          class="md:flex-1 rounded font-display text-green-700 px-5 py-3 bg-gray-100 focus:outline-none focus:shadow-lg"
          :placeholder="`Search in ${category.name}`"/>
        <button class="px-5 py-2 text-white bg-green-700 rounded md:ml-4 mt-2 md:mt-0" type="submit">
          <svg class="w-6 h-6 hidden md:block" fill="none" stroke="currentColor" viewBox="0 0 24 24"
               xmlns="http://www.w3.org/2000/svg">
            <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" stroke-linecap="round" stroke-linejoin="round"
                  stroke-width="2"></path>
          </svg>
          <span class="md:hidden font-semibold">Search</span>
        </button>
      </form>

      <div class="pt-8 pb-2 text-sm text-gray-300">In this category:</div>
      <div class="mb-2" v-if="isFiltered">
        <nuxt-link  :to="`/publications/${slug}`" class="clear text-white uppercase text-sm mb-2 px-2 py-1 rounded bg-primary-100 text-primary-600 hover:bg-primary-200">
          Clear Filter
        </nuxt-link>
      </div>
      <div class="font-semibold text-primary-100 flex flex-wrap">
        <nuxt-link v-for="filter in filters" :to="`/publications/${slug}/filter/${filter.slug}`" class="mr-4 mb-1 hover:underline hover:text-white">{{ filter.name }}</nuxt-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "PublicationBanner",
  props: {
    slug: {
      type: String,
      required: true,
    },
  },
  created() {
    if (!process.browser) return;
    this.$axios.get(`publications/super-categories/${this.slug}`)
      .then(res => this.category = res.data.category)
    this.$axios.get(`publications/filters/${this.slug}`)
      .then(res => this.filters = res.data.categories)
  },
  data() {
    return {
      category: {},
      'query': '',
      'loading': false,
      results: [],
      filters: [],
    }
  },
  methods: {
    search() {
      this.loading = true
      this.$axios.get(`/report-search/${this.query}/${this.slug}`)
        .then(res => {
          this.results = res.data.data
          this.$emit('loadeddata', this.results)
          this.loading = false
        })
    }
  },
  computed: {
    isFiltered(){
      return !!this.$route.params.filter
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
.nuxt-link-exact-active:not(.clear), .nuxt-link-active:not(.clear){
  @apply font-bold text-white
}
</style>
