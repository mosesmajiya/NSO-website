<template>
  <a :href="href" :target="target"
     class="inline-block bg-primary-500 hover:bg-primary-600 shadow-lg text-sm font-bold text-white rounded px-8 py-4">
    <slot/>
  </a>
</template>

<script>
export default {
  name: "LinkButton",
  props: {
    href: String,
    target: {
      default: '_self'
    }
  }
}
</script>

<style scoped>

</style>
