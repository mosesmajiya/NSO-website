<template>
  <div class="accordion">
    <div
      class="flex flex-wrap px-5 py-5 lg:py-3 rounded border border-gray-300 border-dashed bg-gray-200 text-gray-700 my-1 lg:text-center
        font-semibold cursor-pointer hover:bg-gray-300"
      @click="toggle()">
      <div class="w-2/12 hidden lg:flex items-center">
        <svg v-if="show" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mx-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
        </svg>
        <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mx-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
        <div class="px-6">{{ year.date | date('Y')}}</div>
      </div>
      <div class="w-1/12 hidden lg:block">{{ year.food }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.beverage_and_tobacco }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.clothing_and_footwear }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.housing }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.household_operation }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.transport }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.miscellaneous }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.all_items }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.inflation_rate }}</div>
      <div class="w-1/12 hidden lg:block">{{ year.non_food_inflation}}</div>
      <div class="w-full lg:hidden">
        <div class="font-bold text-lg mb-1">{{ year.date | date('Y')}}</div>
        <div class="flex flex-wrap">
          <div class="mr-4 my-1"> Food: <span class="italic font-bold"> {{ year.food }}</span> </div>
          <div class="mr-4 my-1"> Beverage &amp; Tobacco: <span class="italic font-bold"> {{ year.beverage_and_tobacco }}</span> </div>
          <div class="mr-4 my-1"> Clothing &amp; Footwear: <span class="italic font-bold"> {{ year.clothing_and_footwear }}</span> </div>
          <div class="mr-4 my-1"> Housing: <span class="italic font-bold"> {{ year.housing }}</span> </div>
          <div class="mr-4 my-1"> Household Operation: <span class="italic font-bold"> {{ year.household_operation }}</span> </div>
          <div class="mr-4 my-1"> Transport: <span class="italic font-bold"> {{ year.transport }}</span> </div>
          <div class="mr-4 my-1"> Miscellaneous: <span class="italic font-bold"> {{ year.miscellaneous }}</span> </div>
          <div class="mr-4 my-1"> All Items: <span class="italic font-bold"> {{ year.all_items }}</span> </div>
          <div class="mr-4 my-1"> Inflation Rate: <span class="italic font-bold"> {{ year.inflation_rate }}</span> </div>
          <div class="mr-4 my-1"> Non-food Inflation: <span class="italic font-bold"> {{ year.non_food_inflation }}</span> </div>
        </div>
      </div>
      <div class="mt-2 text-sm lg:hidden text-primary-400 flex">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
          <path d="M5 12a1 1 0 102 0V6.414l1.293 1.293a1 1 0 001.414-1.414l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L5 6.414V12zM15 8a1 1 0 10-2 0v5.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L15 13.586V8z" />
        </svg> <span v-if="show">See less</span><span v-else>See more</span>
      </div>
    </div>
    <loader :show="apiBusy"/>
    <div v-if="show">
      <div class="flex-col border border-gray-300 text-gray-700 border-dashed rounded overflow-hidden pt-5 even:bg-gray-100">
        <div class="flex flex-wrap px-5 pb-8 lg:pb-0 rounded lg:text-center" v-for="month in months">
          <div class="hidden lg:block flex-1 -ml-5 -mt-8 py-8 bg-gray-200">
            <div class="font-semibold">{{ month.date | date('MMMM')}}</div>
          </div>
          <div class="w-1/12 hidden lg:block">{{ month.food }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.beverage_and_tobacco }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.clothing_and_footwear }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.housing }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.household_operation }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.transport }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.miscellaneous }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.all_items }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.inflation_rate }}</div>
          <div class="w-1/12 hidden lg:block">{{ month.non_food_inflation}}</div>
          <div class="w-full lg:hidden">
            <div class="font-bold mb-2">{{ month.date | date('YYYY MMMM')}}<hr class="border-dashed border-gray-300 mt-2"></div>
            <div class="flex flex-wrap">
              <div class="mr-4 my-1"> Food: <span class="italic font-semibold"> {{ month.food }}</span> </div>
              <div class="mr-4 my-1"> Beverage &amp; Tobacco: <span class="italic font-bold"> {{ month.beverage_and_tobacco }}</span> </div>
              <div class="mr-4 my-1"> Clothing &amp; Footwear: <span class="italic font-bold"> {{ month.clothing_and_footwear }}</span> </div>
              <div class="mr-4 my-1"> Housing: <span class="italic font-bold"> {{ month.housing }}</span> </div>
              <div class="mr-4 my-1"> Household Operation: <span class="italic font-bold"> {{ month.household_operation }}</span> </div>
              <div class="mr-4 my-1"> Transport: <span class="italic font-bold"> {{ month.transport }}</span> </div>
              <div class="mr-4 my-1"> Miscellaneous: <span class="italic font-bold"> {{ month.miscellaneous }}</span> </div>
              <div class="mr-4 my-1"> All Items: <span class="italic font-bold"> {{ month.all_items }}</span> </div>
              <div class="mr-4 my-1"> Inflation Rate: <span class="italic font-bold"> {{ month.inflation_rate }}</span> </div>
              <div class="mr-4 my-1"> Non-food Inflation: <span class="italic font-bold"> {{ month.non_food_inflation }}</span> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MIcon from "@/components/MIcon";
import moment from "moment";
import Loader from "./Loader";

export default {
  name: "Accordion",
  components: {Loader, MIcon},
  props: ['year'],
  async created(){
    await this.fetchData()
  },
  data() {
    return {
      show: false,
      months:{},
      apiBusy: false
    }
  },
  computed: {
    selectedYear(){
      return moment(this.year.date).format('YYYY')
    }
  },
  methods: {
    toggle() {
      this.show = !this.show
    },
    async fetchData() {
      this.apiBusy = true
      this.months = (await this.$axios.get(`cpi/monthly/${this.selectedYear}`)).data.data
      this.apiBusy = false
    }
  }
}
</script>

<style scoped>

.accordion .body {
  overflow: hidden;
  transition: 150ms ease-out;
}

.accordion .body-inner {
  padding: 8px;
  overflow-wrap: break-word;
}

</style>
