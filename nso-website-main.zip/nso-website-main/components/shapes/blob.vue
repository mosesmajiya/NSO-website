<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
    <path fill="#0099ff" fill-opacity="0.06" :d="path"></path>
  </svg>
</template>

<script>
export default {
  name: "blob",
  props: {
    path: String
  }
}
</script>

<style scoped>

</style>
