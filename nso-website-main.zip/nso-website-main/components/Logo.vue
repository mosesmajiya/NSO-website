<template>
  <img src="~/assets/images/malawi-government-logo-small.png" class="h-12 p-1 ml-6" alt="NSO"/>
</template>

<script>
export default {
  name: "Logo"
}
</script>

<style scoped>

</style>

