<template>
  <a :href="href" class="px-2 text-3xl mr-4 hover:text-gray-400" target="_blank">
    <brand-icon :brand="brand"/>
  </a>
</template>

<script>
  import BrandIcon from "./BrandIcon";

  export default {
    name: "FooterSocialLink",
    components: {BrandIcon},
    props: ['brand', 'href']
  }
</script>

<style scoped>

</style>
