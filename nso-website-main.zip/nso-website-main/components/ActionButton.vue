<template>
  <button @click="$emit('click')"
          class="bg-primary-500 hover:bg-primary-600 shadow-lg text-sm font-bold text-white rounded px-8 py-4"
          :disabled="busy"
          :class="{'cursor-wait':busy}"
  >
    <slot/>
  </button>
</template>

<script>
export default {
  name: "ActionButton",
  props: {
    busy: {type: Boolean},
  }
}
</script>
