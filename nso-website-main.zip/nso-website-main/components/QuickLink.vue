<template>
  <div class="md:w-1/3 mb-5 text-center font-display shadow-xl border-b-4 md:odd:shadow-none md:odd:border-transparent md:even:shadow-xl md:even:border-b-4 border-red-400 p-5 py-16 rounded-lg">
    <div class="flex justify-center">
      <div
        class="lg:hidden xl:flex bg-red-100 text-red-500 w-20 h-20 flex items-center justify-center rounded-full">
        <slot/>
      </div>
    </div>
    <h1 class="text-xl py-5 font-bold">{{ title }}</h1>
    <p class="px-5 text-gray-600">{{ subTitle }}</p>
  </div>
</template>

<script>
export default {
  name: "QuickLink",
  props: {
    title: String,
    subTitle: String
  }
}
</script>

<style scoped>

</style>
