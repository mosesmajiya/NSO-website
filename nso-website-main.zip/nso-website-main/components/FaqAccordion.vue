<template>
  <div class="accordion">
    <div class="flex text-gray-700 font-bold pb-2 question cursor-pointer" @click="toggle()">
      <m-icon class="mr-2">play_circle_outline</m-icon>
      <div>{{ faq.question }}</div>
    </div>
    <div v-if="show" class="answer md:mx-8 text-gray-600 p-5 rounded-lg border-gray-300 shadow hover:shadow-xl
      hover:bg-white group border-transparent border-b-4 hover:border-red-400 p-6 rounded-lg" v-html="faq.response"></div>
  </div>
</template>

<script>
import MIcon from "@/components/MIcon";

export default {
  name: "FaqAccordion",
  components: {MIcon},
  props: ['faq'],
  data() {
    return {
      show: false
    }
  },
  methods: {
    toggle() {
      this.show = !this.show
    },
    beforeEnter: function (el) {
      el.style.height = '0';
    },
    enter: function (el) {
      el.style.height = el.scrollHeight + 'px';
    },
    beforeLeave: function (el) {
      el.style.height = el.scrollHeight + 'px';
    },
    leave: function (el) {
      el.style.height = '0';
    },
  }
}
</script>

<style scoped>

.accordion .body {
  overflow: hidden;
  transition: 150ms ease-out;
}

.accordion .body-inner {
  padding: 8px;
  overflow-wrap: break-word;
}

</style>
