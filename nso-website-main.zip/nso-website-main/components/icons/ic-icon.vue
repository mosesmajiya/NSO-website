<template>
  <svg :class="`w-${size} h-${size}`" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="path"></path>
  </svg>
</template>

<script>
export default {
  name: "ic-icon",
  props: {
    path: String,
    size: {
      default: 5
    }
  }
}
</script>

<style scoped>

</style>
