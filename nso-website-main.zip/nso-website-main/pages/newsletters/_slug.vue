<template>
  <div class="font-display">
    <div v-if="newsletter" class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">{{ newsletter.name }}</h1>
        <div class="mb-5 font-semibold">Editor: {{ newsletter.editor }}</div>
        <article class="py-2 content" v-html="newsletter.content"></article>
      </div>
    </div>

    <div class="container mx-auto p-10 xl:flex">
      <div class="mb-20">
        <div v-for="release in newsletter.releases"
             class="mb-8 bg-gray-100 rounded p-8 hover:bg-gray-200">
          <div class="flex flex-wrap">
            <div class="w-1/2">
                <span class="px-5 py-3 rounded bg-gray-200 uppercase text-sm font-bold">
                  Volume {{ release.volume }}, Issue {{ release.issue }}
                </span>
            </div>
            <div class="w-1/2 text-right text-gray-600 text-sm">{{ release.published_on | from_now }}</div>
          </div>
          <div class="pt-6" v-html="release.content"></div>
          <div v-if="hasDownload(release)" class="flex items-center">
            <a :href="getDownload(release).download"
               class="px-5 py-2 bg-primary-500 hover:bg-primary-600 text-white mt-8 rounded-l">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" />
              </svg>
            </a>
            <div class="px-5 py-2 bg-gray-500 text-white mt-8 rounded-r">{{ getDownload(release).size }}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-gray-100 lg:px-20 hidden md:block">

      <h1 class="text-2xl font-bold pl-5 pt-10 font-display">Popular News</h1>
      <div class="md:flex py-10 flex-wrap">
        <nuxt-link :to="`/news/${article.slug}`" class="group pt-8 px-5 lg:px-0 lg:pt-0 lg:mx-5 md:w-1/2 lg:flex-1 lg:bg-white lg:hover:shadow-xl rounded-lg overflow-hidden group"
                   v-for="article in posts" v-bind:key="article.id">
          <article class="text-gray-600 border-b-4 group-hover:border-red-400 border-transparent">
            <div class="mb-6 relative">
              <img :src="article.image_url" class="h-56 object-cover w-full" v-if="article.image_url"/>
              <img src="~/assets/images/no-image.png" class="h-56 object-cover w-full" v-else/>
            </div>
            <div class="px-8 lg:pb-5 flex-col h-full">
              <h1 class="font-display font-semibold text-xl text-gray-800">{{ article.title | str_limit(44) }}</h1>
              <div class="text-xs mt-1">
                {{ article.published_at | from_now }}
              </div>
            </div>
          </article>
        </nuxt-link>

      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "_slug",
  layout: 'secondary',
  head() {
    return {
      title: this.newsletter.name + ' - Newsletters - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  async asyncData({$axios, params}) {
    let popular = (await $axios.get('news/popular')).data.data
    return {popular}
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
    posts() {
      return this.popular.slice(0, 3)
    }
  },
  created() {
    this.$axios.get(`/newsletters/${this.$route.params.slug}`)
      .then(res => this.newsletter = res.data.data)
  },
  data() {
    return {
      newsletter: {},
      popular: {}
    }
  },
  methods: {
    hasAttachments(post) {
      return post.attachments && post.attachments.length
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    getDownload(release) {
      return release.attachments[0]
    },
    hasDownload(release) {
      return release.attachments && release.attachments.length
    },
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
