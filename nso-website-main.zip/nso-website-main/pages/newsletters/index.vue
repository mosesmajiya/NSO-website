<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Newsletters</h1>
        <div class="mb-10">Our compilation of news and events in printable form.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-8">
      <div class="flex flex-wrap md:space-x-4 md:px-5">
        <div class="md:w-1/2 mb-5 group md:odd:-ml-2 md:even:-mr-2" v-for="post in posts" v-bind:key="post.id">
          <div class="shadow-xl group-hover:border-red-400 border-b-4 px-8 rounded-lg border-transparent">
            <div class="py-12">
              <h1 class="font-display font-bold py-2 text-lg">{{ post.name }}</h1>
              <div class="pb-2 text-xs text-gray-500">
                {{ post.releases_count }} Releases &middot;
                <span v-if="post.editor">{{ post.editor }}</span>
              </div>
              <div class="text-gray-600 mb-4">{{ post.content | strip | str_limit(120) }}</div>
              <nuxt-link :to="`/newsletters/${post.slug}`"
                         class="flex items-center text-sm text-primary-500 mt-3">
                <span>Read more</span>
                <m-icon class="ml-2">trending_flat</m-icon>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
      <loader-button :busy="loading" @click="loadMore" class="ml-5" v-if="posts.next_page_url">Load more</loader-button>
    </div>


  </div>
</template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  head() {
    return {
      title: 'Newsletters - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  created() {
    this.$axios.get('newsletters')
      .then(res => this.posts = res.data.data)
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.posts.next_page_url)
        .then(res => {
          this.loading = false
          this.posts.data = this.posts.data.concat(res.data.data.data)
          this.posts.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      posts: {},
      loading: false,
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.scrollToTop()
    }
  },
  computed:{
    settings() {
      return this.$store.state.settings;
    },
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
