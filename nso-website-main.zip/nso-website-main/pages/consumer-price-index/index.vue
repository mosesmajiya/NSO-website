<template>
  <div class="">
    <div class="p-10 pt-40 banner bg-green-700 border-transparent border-b border-gray-200">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl text-white pb-2 flex items-center">Malawi Consumer Price Indices</h1>
        <div class="mb-4 text-white">
          {{ thisYear }}
        </div>
        <div class="mb-4 text-white font-light">
          A consumer price index measures changes in the price level of a weighted average market basket of consumer goods and services purchased by households.
        </div>
        <div class="mb-5 text-gray-300 py-3 px-5 bg-green-900 rounded font-light flex">
          <svg class="hidden md:block lg:w-6 lg:h-6 w-12 h-12 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          Annual figures are calculated using the average of the monthly indices for the year compared to the average for the previous year
        </div>
      </div>
    </div>
    <div class="container mx-auto px-10 my-10">

      <InflationYearOnYear class="mb-10"/>

      <div class="pb-10 font-display">
        <div class="hidden lg:flex flex-wrap px-5 py-3 rounded-t border border-b-0 border-primary-300 border-dashed
          bg-primary-400 text-white mb-0 lg:text-center font-semibold text-sm">
          <div class="w-2/12 hidden lg:block"></div>
          <div class="w-1/12 hidden lg:block">Food</div>
          <div class="w-1/12 hidden lg:block">Beverage & Tobacco</div>
          <div class="w-1/12 hidden lg:block">Clothing & Footwear</div>
          <div class="w-1/12 hidden lg:block">Housing</div>
          <div class="w-1/12 hidden lg:block">Household Operation</div>
          <div class="w-1/12 hidden lg:block">Transport</div>
          <div class="w-1/12 hidden lg:block">Miscellaneous</div>
          <div class="w-1/12 hidden lg:block">All Items</div>
          <div class="w-1/12 hidden lg:block">Inflation Rate</div>
          <div class="w-1/12 hidden lg:block">Non-food Inflation</div>
        </div>
        <div
          class="flex flex-wrap px-5 py-3 rounded lg:rounded-b lg:rounded-t-none border border-primary-300 border-dashed
            bg-primary-300 text-white mb-2 lg:text-center font-bold">
          <div class="w-2/12 hidden lg:block">Weight</div>
          <div class="w-1/12 hidden lg:block">{{ weights.food }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.beverage_and_tobacco }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.clothing_and_footwear }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.housing }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.household_operation }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.transport }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.miscellaneous }}</div>
          <div class="w-1/12 hidden lg:block">{{ weights.all_items }}</div>
          <div class="w-1/12 hidden lg:block"></div>
          <div class="w-1/12 hidden lg:block"></div>
          <div class="w-full py-5 lg:hidden">
            <div class="font-bold text-lg mb-2">Weight</div>
            <div class="flex flex-wrap">
              <div class="mr-4 my-1"> Food: <span class="italic font-bold"> {{ weights.food }}</span> </div>
              <div class="mr-4 my-1"> Beverage &amp; Tobacco: <span class="italic font-bold"> {{ weights.beverage_and_tobacco }}</span> </div>
              <div class="mr-4 my-1"> Clothing &amp; Footwear: <span class="italic font-bold"> {{ weights.clothing_and_footwear }}</span> </div>
              <div class="mr-4 my-1"> Housing: <span class="italic font-bold"> {{ weights.housing }}</span> </div>
              <div class="mr-4 my-1"> Household Operation: <span class="italic font-bold"> {{ weights.household_operation }}</span> </div>
              <div class="mr-4 my-1"> Transport: <span class="italic font-bold"> {{ weights.transport }}</span> </div>
              <div class="mr-4 my-1"> Miscellaneous: <span class="italic font-bold"> {{ weights.miscellaneous }}</span> </div>
              <div class="mr-4 my-1"> All Items: <span class="italic font-bold"> {{ weights.all_items }}</span> </div>
            </div>
          </div>
        </div>
        <div class="" v-for="year in annual">
          <accordion :year="year"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import InflationYearOnYear from "../../components/charts/InflationYearOnYear";
import Accordion from "../../components/Accordion";
export default {
  name: "reports",
  components: {Accordion, InflationYearOnYear},
  layout: 'secondary',
  created() {
    this.$axios.get('cpi/weights')
      .then(res => this.weights = res.data.data)
    this.$axios.get('cpi/annual')
      .then(res => this.annual = res.data.data)
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  computed: {
    thisYear() {
      return new Date().getFullYear()
    }
  },

  data() {
    return {
      weights: {},
      annual: {},
    }
  },
  mounted() {
    this.scrollToTop()
  },
  }
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
