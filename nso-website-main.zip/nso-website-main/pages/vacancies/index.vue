<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Vacancies</h1>
        <div class="mb-10">The National Statistical Office provides job opportunities for all. Here is our list of current and past job opportunities.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-8">
      <div class="flex flex-wrap md:space-x-4 md:px-5">
        <div class="md:w-1/2 mb-5 group md:odd:-ml-2 md:even:-mr-2" v-for="post in posts.data">
          <div class="shadow-xl group-hover:border-red-400 border-b-4 px-8 rounded-lg border-transparent">
            <div class="py-12">
              <h1 class="font-display font-bold pt-2 pb-6 text-lg">{{ post.position }} &middot; <span
                class="capitalize">{{ post.job_type }}</span></h1>
              <div class="text-gray-600 mb-4">{{ post.content | strip | str_limit(120) }}</div>
              <span class="text-sm border-l-4 border-primary-300 pl-5">{{ post.deadline | date('Do MMMM, YYYY') }}</span>
              <div class="text-xs text-gray-500 mt-2 pt-2">
                {{ post.published_at | from_now }}
                <span v-if="post.attachments.length">&middot; {{ post.attachments.length }} files</span>
              </div>
              <nuxt-link :to="`/vacancies/${post.slug}`"
                         class="flex items-center text-sm text-primary-500 mt-3">
                <span>Read more</span>
                <m-icon class="ml-2">trending_flat</m-icon>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
      <loader-button :busy="loading" @click="loadMore" class="ml-5" v-if="posts.next_page_url">Load more</loader-button>
    </div>


  </div>
</template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.$axios.get('vacancies')
      .then(res => this.posts = res.data.data)
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.posts.next_page_url)
        .then(res => {
          this.loading = false
          this.posts.data = this.posts.data.concat(res.data.data.data)
          this.posts.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      posts: {},
      loading: false,
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.scrollToTop()
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
