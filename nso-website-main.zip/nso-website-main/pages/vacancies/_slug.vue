<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Vacancies</h1>
        <div class="mb-10">The National Statistical Office provides job opportunities for all. Here is our list of current and past job opportunities.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10 xl:flex">
      <article class="">
        <h1 class="font-display text-xl lg:text-2xl font-semibold leading-none">{{ post.position }}</h1>
        <div class="mt-4 mb-2 font-display text-sm">Type: <span class="capitalize pr-4">{{ post.job_type }}</span> Deadline:
          {{ post.deadline | date('Do MMMM YYYY') }}
        </div>
        <div class="pt-2 pb-4 text-xs text-gray-500">
          {{ post.created_at | from_now }}
        </div>
        <div class="text-gray-600 pt-4 content" v-html="post.content"></div>

        <div class="flex pt-12 text-sm font-bold font-display items-center uppercase" v-if="hasAttachments(post)">
          <h1>Downloads</h1>
          <div class="border-b ml-2 text-black flex-1"></div>
        </div>
        <div class="flex flex-wrap pt-8" v-if="hasAttachments(post)">
          <div class="w-full md:w-1/2" v-bind:key="attachment.id" v-for="attachment in post.attachments">
            <a :href="attachment.download" class="flex justify-between mr-4 mb-4 shadow-xs rounded overflow-hidden">
              <div class="text-gray-500 py-2 px-1 flex-shrink bg-gray-100">
                <fa-icon icon="file-pdf" size="3x" type="fas"/>
              </div>
              <div class="flex-1 bg-gray-200 py-2 px-3">
                <p class="text-gray-700">{{ attachment.caption }}</p>
                <span class="block text-xs text-gray-600">{{ attachment.size }}</span>
              </div>
            </a>
          </div>
        </div>
      </article>
    </div>


  </div>
</template>

<script>
export default {
  name: "_slug",
  layout: 'secondary',
  head() {
    return {
      title: this.post.position + ' - Vacancies - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
  },
  created() {
    this.$axios.get(`/vacancies/${this.$route.params.slug}`)
      .then(res => this.post = res.data.data)
  },
  data() {
    return {
      post: {}
    }
  },
  methods: {
    hasAttachments(post) {
      return post.attachments && post.attachments.length
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`vacancies/${this.$route.params.slug}`)
        .then(res => this.post = res.data.data)
    },
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
