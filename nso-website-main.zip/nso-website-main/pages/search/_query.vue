<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">
          <span v-if="loading">Searching...</span>
          <span v-else>Search for "<span class="text-primary-200">{{ $route.params.query }}</span>"</span>
        </h1>
        <div class="mb-10" v-if="!loading">{{ results.length }} results</div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="lg:flex">
        <section class="w-full">
          <nuxt-link v-for="(result, index) in results" :key="index" :to="`/${result.url}`" class="mb-10 block">
            <div class="font-display font-bold text-xl text-primary-500 my-2 flex inline-block align-middle">
              {{ result.title }}
            </div>
            <div>
              <span class="text-gray-600 font-light">
                {{ result.published_at | date('D MMM YYYY') }}, {{ result.type }}
              </span> -
              {{ result.description | strip | str_limit(200) }}
            </div>
            <div class="text-sm text-gray-600 mt-1">
             statistics.gov.mw > {{ result.type | lowercase }} > {{ result.slug }}
            </div>
          </nuxt-link>
        </section>
      </div>
    </div>

  </div>
</template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "_query",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.loading = true
    this.$axios.get(`/search/${this.$route.params.query}`)
      .then(res => {
        this.results = res.data.data
        this.loading = false
      })
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.downloads.next_page_url)
        .then(res => {
          this.loading = false
          this.downloads.data = this.downloads.data.concat(res.data.data.data)
          this.downloads.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      results: [],
      loading: false,
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
