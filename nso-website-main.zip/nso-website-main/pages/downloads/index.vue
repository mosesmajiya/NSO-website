<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Downloads</h1>
        <div class="mb-10">Administrative public documents for download.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="lg:flex">
        <section class="lg:w-2/3">
          <div v-for="(download, index) in downloads" :key="index" class="pb-10">
            <h1 class="font-display text-xl lg:text-2xl font-bold pb-8">{{ download.name }}</h1>
            <div class="lg:flex flex-wrap">
              <div v-for="(file, index) in download.attachments" v-bind:key="index" class="w-full md:w-1/2">
                <a class="flex justify-between mr-4 mb-4 shadow-xs rounded overflow-hidden group"
                   target="_blank" v-bind:href=file.url>
                  <div class="text-gray-500 py-2 px-1 bg-gray-100 group-hover:text-red-500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div class="flex-1 bg-gray-200 py-2 px-3">
                    <p class="text-gray-700">{{ file.caption | str_limit(30) }}</p>
                    <span class="block text-xs text-gray-600">{{ file.size }}</span>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>
        <section class="lg:w-1/3 lg:ml-12 text-sm">
          <popular-news v-bind:posts="popular"/>
          <recent-news v-bind:posts="recent"/>
        </section>
      </div>
    </div>

  </div>
  </template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";
import PopularNews from "../../components/news/PopularNews";
import RecentNews from "../../components/news/RecentNews";

export default {
  name: "index",
  components: {LoaderButton, MIcon, PopularNews, RecentNews},
  layout: 'secondary',
  created() {
    this.$axios.get('downloads')
      .then(res => this.downloads = res.data.data.data)
    this.$axios.get('news/popular')
      .then(res => this.popular = res.data.data)
    this.$axios.get('news/recent')
      .then(res => this.recent = res.data.data)
  },
  mounted() {
    this.scrollToTop()
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.downloads.next_page_url)
        .then(res => {
          this.loading = false
          this.downloads.data = this.downloads.data.concat(res.data.data.data)
          this.downloads.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      downloads: {},
      popular: [],
      recent:[],
      loading: false,
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
