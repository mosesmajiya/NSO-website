<template>
  <div class="font-display">
    <div class="h-132 p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner bg-center"
         :style="{'background-image': 'url(' + image + ')'}" v-if="page">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">{{ page.title }}</h1>
        <div class="mb-10">{{ page.updated_at | date('Do MMMM YYYY') }}</div>
      </div>
    </div>

    <div class="container mx-auto p-10 xl:flex">
      <article class="content" v-html="page.content"></article>
      <div class="pt-10">
        <div v-for="attachment in page.attachments">
          <div>{{ attachment.download }}</div>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";

export default {
  name: "page",
  components: {SectionHeader},
  layout: 'secondary',
  async created() {
    this.page = (await this.$axios.get(`pages/${this.$route.params.slug}`)).data.data
  },
  data() {
    return {
      page: {}
    }
  },
  head() {
    return {
      title: this.page.title + ' - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
    image() {
      return this.page && this.page.image_url ? this.page.image_url : '~/assets/images/banner.jpg'
    },
  }
}
</script>

<style scoped>
.banner {
  background-blend-mode: multiply;
  @apply bg-cover;
}
</style>
