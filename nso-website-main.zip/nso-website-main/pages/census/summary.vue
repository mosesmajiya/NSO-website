<template>
  <div class="">
    <div class="p-10 pt-40 banner bg-green-700 border-transparent border-b border-gray-200">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl text-white pb-2 flex items-center">2018 Population and Housing
          Census</h1>
        <div class="mb-10 text-white">
          {{ national.description }}
          <div class="flex flex-wrap mt-12">
            <div class="flex flex-col p-2 items-center justify-center flex-1 mb-5 md:mb-0 group">
              <div class="rounded-full h-24 w-24 flex items-center justify-center border-white border-2">
                <div
                  class="rounded-full h-20 w-20 flex items-center justify-center text-red-600 bg-white group-hover:text-white group-hover:bg-red-500">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      stroke-linecap="round" stroke-linejoin="round"
                      stroke-width="2"></path>
                  </svg>
                </div>
              </div>
              <h2 class="mt-2 font-display font-semibold">Population</h2>
              <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-500">
                {{ national.population | numeral('0,0') }}
              </div>
            </div>
            <div class="flex flex-col p-2 items-center justify-center flex-1 mb-5 md:mb-0 group">
              <div class="rounded-full h-24 w-24 flex items-center justify-center border-white border-2">
                <div
                  class="rounded-full h-20 w-20 flex items-center justify-center text-red-600 bg-white group-hover:text-white group-hover:bg-red-500">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2"
                      stroke-linecap="round" stroke-linejoin="round"
                      stroke-width="2"></path>
                  </svg>
                </div>
              </div>
              <h2 class="mt-2 font-display font-semibold">Density</h2>
              <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-500 flex items-center">
                <div>{{ national.population_density }}</div>
                <div class="ml-2 text-xs">p/sq. km</div>
              </div>
            </div>
            <div class="flex flex-col p-2 items-center justify-center flex-1 mb-5 md:mb-0 group">
              <div class="rounded-full h-24 w-24 flex items-center justify-center border-white border-2">
                <div
                  class="rounded-full h-20 w-20 flex items-center justify-center text-red-600 bg-white group-hover:text-white group-hover:bg-red-500">
                  <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path clip-rule="evenodd"
                          d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"
                          fill-rule="evenodd">
                    </path>
                  </svg>
                </div>
              </div>
              <h2 class="mt-2 font-display font-semibold">Life Expectancy</h2>
              <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-500 flex items-center">
                <div class="mr-2 text-xs">M</div>
                <div>{{ national.life_expectancy_male }}</div>
                <div class="mx-2 text-gray-500 text-xs font-light">|</div>
                <div>{{ national.life_expectancy_female }}</div>
                <div class="ml-2 text-xs">F</div>
              </div>
            </div>
            <div class="flex flex-col p-2 items-center justify-center flex-1 mb-5 md:mb-0 group">
              <div class="rounded-full h-24 w-24 flex items-center justify-center border-white border-2">
                <div
                  class="rounded-full h-20 w-20 flex items-center justify-center text-red-600 bg-white group-hover:text-white group-hover:bg-red-500">
                  <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z"></path>
                    <path clip-rule="evenodd"
                          d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"
                          fill-rule="evenodd"></path>
                  </svg>
                </div>
              </div>
              <h2 class="mt-2 font-display font-semibold">Literacy</h2>
              <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-500 flex items-center">
                <div>{{ national.literacy }}</div>
                <div class="text-xs">%</div>
              </div>
            </div>
            <div class="flex flex-col p-2 items-center justify-center flex-1 mb-5 md:mb-0 group">
              <div class="rounded-full h-24 w-24 flex items-center justify-center border-white border-2">
                <div
                  class="rounded-full h-20 w-20 flex items-center justify-center text-red-600 bg-white group-hover:text-white group-hover:bg-red-500">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                          stroke-linecap="round" stroke-linejoin="round"
                          stroke-width="2"></path>
                  </svg>
                </div>
              </div>
              <h2 class="mt-2 font-display font-semibold">Fertility Rate</h2>
              <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-500 flex items-center">
                <div>{{ national.fertility_rate }}</div>
                <div class="text-xs">%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container mx-auto px-10 my-10">
      <div class="pb-10 font-display" >
        <div class="flex items-center mb-5">
          <div class="font-display text-xl font-bold hidden md:block">Summary of Regional and District Indicators</div>
          <nuxt-link to="/census/2018" class="md:text-right font-light uppercase text-xs flex-1">[ Close table view ]</nuxt-link>
        </div>
        <div
          class="flex flex-wrap px-5 py-3 rounded border border-green-500 border-dashed bg-green-700 text-white text-bold mb-5 lg:text-center">
          <div class="w-1/3 lg:w-2/12">Area</div>
          <div class="w-2/12 hidden lg:block">Population</div>
          <div class="w-1/12 hidden lg:block">Density</div>
          <div class="w-1/12 hidden lg:block">Poverty</div>
          <div class="w-2/12 hidden lg:block">Life Expectancy</div>
          <div class="w-2/12 hidden lg:block">Fertility Rate</div>
          <div class="w-2/12 hidden lg:block">Literacy Rate</div>
          <div class="w-2/3 lg:hidden">Statistics</div>
        </div>
        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-700 border-dashed mb-4 lg:text-center bg-gray-100 font-bold">
          <div class="w-1/3 lg:w-2/12">Northern Region</div>
          <div class="w-2/12 hidden lg:block">7,845,67</div>
          <div class="w-1/12 hidden lg:block">26</div>
          <div class="w-1/12 hidden lg:block">47%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">22%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>
        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-600 border-dashed mb-4 lg:text-center">
          <div class="w-1/3 lg:w-2/12">Machinga</div>
          <div class="w-2/12 hidden lg:block">5,005,67</div>
          <div class="w-1/12 hidden lg:block">24</div>
          <div class="w-1/12 hidden lg:block">67%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">12%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>
        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-600 border-dashed mb-4 lg:text-center">
          <div class="w-1/3 lg:w-2/12">Machinga</div>
          <div class="w-2/12 hidden lg:block">5,005,67</div>
          <div class="w-1/12 hidden lg:block">24</div>
          <div class="w-1/12 hidden lg:block">67%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">12%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>

        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-700 border-dashed mb-4 lg:text-center bg-gray-100 font-bold">
          <div class="w-1/3 lg:w-2/12">Northern Region</div>
          <div class="w-2/12 hidden lg:block">7,845,67</div>
          <div class="w-1/12 hidden lg:block">26</div>
          <div class="w-1/12 hidden lg:block">47%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">22%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>
        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-600 border-dashed mb-4 lg:text-center">
          <div class="w-1/3 lg:w-2/12">Machinga</div>
          <div class="w-2/12 hidden lg:block">5,005,67</div>
          <div class="w-1/12 hidden lg:block">24</div>
          <div class="w-1/12 hidden lg:block">67%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">12%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>
        <div class="flex flex-wrap px-5 py-3 rounded border border-gray-400 text-gray-600 border-dashed mb-4 lg:text-center">
          <div class="w-1/3 lg:w-2/12">Machinga</div>
          <div class="w-2/12 hidden lg:block">5,005,67</div>
          <div class="w-1/12 hidden lg:block">24</div>
          <div class="w-1/12 hidden lg:block">67%</div>
          <div class="w-2/12 hidden lg:block">45</div>
          <div class="w-2/12 hidden lg:block">34%</div>
          <div class="w-2/12 hidden lg:block">12%</div>
          <div class="w-2/3 lg:hidden">
            Population: 5252 <br> Density: 46 <br> Poverty: 87 <br> Life Expectancy: 56 <br> Fertility Rate: 34 <br> Literacy rate: 12
          </div>
        </div>
      </div>
    </div>
    <div class="container mx-auto flex px-5 mb-20">
      <div class="flex-1 px-5 rounded-lg overflow-hidden">
        <img src="https://source.unsplash.com/CG6Gd__QIOY/500x600/" class="object-cover rounded-lg h-72 w-full">
      </div>
      <div class="flex-1 px-5 rounded-lg overflow-hidden">
        <img src="https://source.unsplash.com/cVEOh_JJmEE/500x600/" class="object-cover rounded-lg h-72 w-full">
      </div>
      <div class="flex-1 px-5 rounded-lg overflow-hidden">
        <img src="https://source.unsplash.com/GaLzDCnA5EI/500x600/" class="object-cover rounded-lg h-72 w-full">
      </div>
    </div>
    <div class="container mx-auto px-10">
      <div class="flex items-center justify-center mx-auto pb-5">
        <div class="border-t-2 border-red-400 w-4/12 md:w-1/3 xl:w-1/12"/>
        <h1 class="font-menu lg:text-center tracking-widest uppercase py-2 px-8 w-6/12 md:w-1/3 xl:w-3/12">
          Resources
        </h1>
        <div class="border-t-2 border-red-400 w-4/12 md:w-1/3 xl:w-8/12"/>
      </div>

      <div class="mb-10">
        <div class="text-sm font-display text-left pr-5 mb-5">District Tables</div>
        <div class="flex flex-wrap mt-2">
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Zomba District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Chikwawa District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Zomba District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Chikwawa District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mb-10">
        <div class="text-sm font-display text-left pr-5 mb-5">District Tables</div>
        <div class="flex flex-wrap mt-2">
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Zomba District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Chikwawa District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Zomba District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Chikwawa District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
          <div class="cursor-pointer group">
            <div
              class="flex items-center shadow rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-gray-500 group-hover:text-white">
              <div class="px-4 py-3 bg-green-600 group-hover:bg-gray-600 text-white">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
              <div class="px-3 text-gray-700 group-hover:text-gray-200 font-semibold font-display">Mulanje District
                <div class="text-gray-500 group-hover:text-gray-200 uppercase text-xs">123KB</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import Malawi from "../../components/Malawi";
import SectionHeader from "../../components/SectionHeader";
import MalawiMap from "../../components/MalawiMap";

export default {
  name: "reports",
  components: {MalawiMap, SectionHeader, Malawi},
  layout: 'secondary',
  async created() {
    this.national = (await this.$axios.get(`census/2018`)).data.data.national
  },
  data() {
    return {
      national: {}
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
