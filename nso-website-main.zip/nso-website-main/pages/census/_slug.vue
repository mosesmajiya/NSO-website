<template>
  <div class="">
    <loader :show="apiBusy"/>
    <div :class="{'hidden': apiBusy}" v-if="national">
      <div class="p-10 pt-40 banner bg-green-700 border-transparent border-b border-gray-200 font-display">
        <div class="container mx-auto px-2 xl:px-12">
          <h1 class="font-display font-semibold text-3xl text-white pb-2"><span
            class="text-red-600 mr-1">{{ national.year }}</span> Population and Housing
            Census</h1>
          <div class="mb-10 text-white">
            {{ national.description }}
            <div class="flex flex-wrap mt-12">
              <div class="flex flex-col p-4 items-center justify-center flex-1 mb-5 md:mb-0 group">
                <ic-population class="text-gray-500"/>
                <h2 class="mt-2 font-display font-semibold group-hover:text-gray-400 text-center">Population</h2>
                <div class="mt-2 font-display text-xl md:text-2xl font-semibold group-hover:text-yellow-400">
                  {{ national.population | numeral('0,0') }}
                </div>
              </div>
              <div class="flex flex-col p-4 items-center justify-center flex-1 mb-5 md:mb-0 group">
                <ic-density class="text-gray-500"/>
                <h2 class="mt-2 font-display font-semibold group-hover:text-gray-400 text-center">Density</h2>
                <div
                  class="mt-2 font-display text-xl md:text-2xl font-semibold flex items-center group-hover:text-yellow-400">
                  <div>{{ national.population_density }}</div>
                  <div class="ml-2 text-xs">p/sq. km</div>
                </div>
              </div>
              <div class="flex flex-col p-4 items-center justify-center flex-1 mb-5 md:mb-0 group">
                <ic-life class="text-gray-500"/>
                <h2 class="mt-2 font-display font-semibold group-hover:text-gray-400 text-center">Life Expectancy</h2>
                <div
                  class="mt-2 font-display text-xl md:text-2xl font-semibold flex items-center group-hover:text-yellow-400">
                  <div class="mr-2 text-xs">M</div>
                  <div>{{ national.life_expectancy_male }}</div>
                  <div class="mx-2 text-gray-500 text-xs font-light">|</div>
                  <div>{{ national.life_expectancy_female }}</div>
                  <div class="ml-2 text-xs">F</div>
                </div>
              </div>
              <div class="flex flex-col p-4 items-center justify-center flex-1 mb-5 md:mb-0 group">
                <ic-literacy class="text-gray-500"/>
                <h2 class="mt-2 font-display font-semibold group-hover:text-gray-400 text-center">Literacy Rate</h2>
                <div
                  class="mt-2 font-display text-xl md:text-2xl font-semibold flex items-center group-hover:text-yellow-400">
                  <div>{{ national.literacy }}</div>
                  <div class="text-xs">%</div>
                </div>
              </div>
              <div class="flex flex-col p-4 items-center justify-center flex-1 mb-5 md:mb-0 group">
                <ic-fertility class="text-gray-500"/>
                <h2 class="mt-2 font-display font-semibold group-hover:text-gray-400 text-center">Fertility Rate</h2>
                <div
                  class="mt-2 font-display text-xl md:text-2xl font-semibold flex items-center group-hover:text-yellow-400">
                  <div>{{ national.fertility_rate }}</div>
                  <div class="text-xs">%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container mx-auto px-10">
        <div class="container mx-auto flex my-12" v-if="media.length">
          <div class="flex-1 even:px-5 rounded-lg overflow-hidden" v-for="image in media">
            <img :src="image.url" class="object-cover rounded-lg h-72 w-full">
          </div>
        </div>
        <div class="my-10 text-gray-600 font-display" v-html="national.abstract"></div>
        <div class="hidden mt-10 px-5 py-3 bg-gray-200 rounded xl:flex items-center">
          <div class="rounded-full bg-gray-100 border w-16 h-16 p-3 text-green-600">
            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"></path>
            </svg>
          </div>
          <div class="text-sm font-light ml-5">
            <span class="font-bold text-gray-700">Interactive Map: Malawi</span><br>
            Mouse-over or click on a district on the map to get more {{ national.year }} district census information.
          </div>
        </div>
        <div class="mt-5 xl:py-10 flex rounded-lg">
          <div class="xl:w-1/4 hidden xl:block">
            <client-only>
              <malawi-map/>
            </client-only>
          </div>
          <div class="w-full xl:w-3/4 xl:pl-8 hidden xl:block">
            <div class="pb-5" v-if="capital">
              <div class="font-display font-semibold uppercase mb-3">{{ capital.district.name }} - The Capital of Malawi</div>
              <div class="text-gray-600 font-display">
                {{ capital.district.description | strip }}
              </div>
              <div class="border-t border-dashed border-gray-500 mt-8 pt-5 px-2 flex flex-auto">
                <div class="w-1/5 flex flex-col items-start">
                  <div class="font-display font-semibold text-3xl">{{ capital.population | numeral('0,0') }}</div>
                  <div class="text-xs uppercase">Population</div>
                </div>
                <div class="w-1/5 flex flex-col items-center">
                  <div class="font-display font-semibold text-3xl flex items-center">
                    <div>{{ capital.population_density }}</div>
                    <div class="ml-2 text-xs">persons/sq. km</div>
                  </div>
                  <div class="text-xs uppercase">Population Density</div>
                </div>
                <div class="w-1/5 flex flex-col items-center">
                  <div class="font-display font-semibold text-3xl flex items-center">
                    <div> {{ capital.poverty }}</div>
                    <div class="text-sm">%</div>
                  </div>
                  <div class="text-xs uppercase">Poverty</div>
                </div>
                <div class="w-1/5 flex flex-col items-center">
                  <div class="font-display font-semibold text-3xl flex items-center">
                    <div class="mr-2 text-xs">M</div>
                    <div>{{ capital.life_expectancy_male }}</div>
                    <div class="mx-2 text-gray-500 text-xs font-light">|</div>
                    <div>{{ capital.life_expectancy_female }}</div>
                    <div class="ml-2 text-xs">F</div>
                  </div>
                  <div class="text-xs uppercase">Life Expectancy</div>
                </div>
                <div class="w-1/5 flex flex-col items-end">
                  <div class="font-display font-semibold text-3xl flex items-center">
                    <div>{{ capital.fertility_rate }}</div>
                    <div class="text-sm">%</div>
                  </div>
                  <div class="text-xs uppercase">Fertility Rate</div>
                </div>
              </div>
              <div class="mt-8 rounded overflow-hidden">
                <img class="object-cover object-center w-full h-72" :src="capital.district.image_url"/>
              </div>
            </div>
          </div>
        </div>
        <div class="py-10 font-display">
          <div
            class="flex flex-wrap px-5 py-4 rounded bg-primary-300 text-white font-semibold mb-5 lg:text-center">
            <div class="w-1/3 lg:w-2/12">Area</div>
            <div class="w-2/12 hidden lg:block">Population</div>
            <div class="w-1/12 hidden lg:block">Density</div>
            <div class="w-1/12 hidden lg:block">Poverty</div>
            <div class="w-2/12 hidden lg:block">Life Expectancy</div>
            <div class="w-2/12 hidden lg:block">Fertility Rate</div>
            <div class="w-2/12 hidden lg:block">Literacy Rate</div>
            <div class="w-2/3 lg:hidden">Statistics</div>
          </div>
          <div v-for="(region, i) in regions" :key="i" class="mb-10 border border-gray-200 rounded overflow-hidden">
            <div class="flex flex-wrap px-5 py-4 text-gray-700 lg:text-center bg-gray-200 font-bold">
              <div class="w-1/3 lg:w-2/12">{{ region.name }}</div>
              <div class="w-2/12 hidden lg:block"><span
                v-if="region.census">{{ region.census.population | numeral('0,0') }}</span></div>
              <div class="w-1/12 hidden lg:block"><span v-if="region.census">{{
                  region.census.population_density
                }}</span></div>
              <div class="w-1/12 hidden lg:block"><span v-if="region.census">{{ region.census.poverty }}</span></div>
              <div class="w-2/12 hidden lg:block">
              <span v-if="region.census">
                {{ region.census.life_expectancy_female }}
                {{ region.census.life_expectancy_male }}
              </span>
              </div>
              <div class="w-2/12 hidden lg:block"><span v-if="region.census">{{ region.census.fertility_rate }}</span>
              </div>
              <div class="w-2/12 hidden lg:block"><span v-if="region.census">{{ region.census.literacy }}</span></div>
              <div class="w-2/3 lg:hidden">
                Population: <span v-if="region.census">{{ region.census.population | numeral('0,0') }}</span><br>
                Density: <span v-if="region.census">{{ region.census.population_density }}</span> <br>
                Poverty: <span v-if="region.census">{{ region.census.poverty }}</span> <br>
                Life Expectancy: <span v-if="region.census">
                {{ region.census.life_expectancy_female }}
                {{ region.census.life_expectancy_male }}
              </span> <br>
                Fertility Rate: <span v-if="region.census">{{ region.census.fertility_rate }}</span> <br>
                Literacy rate: <span v-if="region.census">{{ region.census.literacy }}</span>
              </div>
            </div>
            <div
              class="flex flex-wrap px-5 py-4 text-gray-600 lg:text-center odd:bg-gray-100"
              v-for="(district, j) in region.districts" :key="j" v-if="region.districts">
              <div class="w-1/3 lg:w-2/12">{{ district.name }}</div>
              <div class="w-2/12 hidden lg:block"><span
                v-if="district.census">{{ district.census.population | numeral('0,0') }}</span></div>
              <div class="w-1/12 hidden lg:block"><span v-if="district.census">{{
                  district.census.population_density
                }}</span></div>
              <div class="w-1/12 hidden lg:block"><span v-if="district.census">{{ district.census.poverty }}</span>
              </div>
              <div class="w-2/12 hidden lg:block">
                <span v-if="district.census">
                {{ district.census.life_expectancy_female }}
                {{ district.census.life_expectancy_male }}
              </span></div>
              <div class="w-2/12 hidden lg:block"><span v-if="district.census">{{
                  district.census.fertility_rate
                }}</span></div>
              <div class="w-2/12 hidden lg:block"><span v-if="district.census">{{ district.census.literacy }}</span>
              </div>
              <div class="w-2/3 lg:hidden">
                Population: <span v-if="district.census">{{ district.census.population | numeral('0,0') }}</span><br>
                Density: <span v-if="district.census">{{ district.census.population_density }}</span> <br>
                Poverty: <span v-if="district.census">{{ district.census.poverty }}</span> <br>
                Life Expectancy: <span v-if="district.census">
                {{ district.census.life_expectancy_female }}
                {{ district.census.life_expectancy_male }}
                </span> <br>
                Fertility Rate: <span v-if="district.census">{{ district.census.fertility_rate }}</span> <br>
                Literacy rate: <span v-if="district.census">{{ district.census.literacy }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container mx-auto px-10 mt-5">

        <div class="flex items-center justify-center mx-auto pb-5">
          <div class="border-t-2 border-red-400 w-4/12 md:w-1/3 xl:w-1/12"/>
          <h1 class="font-menu text-center tracking-widest uppercase py-2 px-8 w-6/12 md:w-1/3 xl:w-3/12">
            Resources
          </h1>
          <div class="border-t-2 border-red-400 w-4/12 md:w-1/3 xl:w-8/12"/>
        </div>

        <div class="mb-10">
          <div class="" v-for="(resource, i) in resources" :key="i">
            <div class="text-sm font-display text-left pr-5 mb-5">{{ resource.name }}</div>
            <div class="flex flex-wrap mt-2">
              <div v-for="(media, j) in resource.media" :key="j" v-if="resource.media.length">
                <a :href="media.url" :alt="media.name" target="_blank" class="cursor-pointer group">
                  <div
                    class="flex items-center bg-gray-200 rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-primary-500 group-hover:text-white">
                    <div class="px-4 py-3 bg-green-400 group-hover:bg-primary-600 text-white">
                      <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                           xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"></path>
                      </svg>
                    </div>
                    <div class="px-3 group-hover:text-gray-200 font-menu text-gray-700 text-sm">{{
                        media.name
                      }}
                      <div class="group-hover:text-gray-200 uppercase text-xs">{{ media.size }}</div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Malawi from "../../components/Malawi";
import SectionHeader from "../../components/SectionHeader";
import MalawiMap from "../../components/MalawiMap";
import IcLiteracy from "../../components/icons/ic-literacy";
import IcLife from "../../components/icons/ic-life";
import IcDensity from "../../components/icons/ic-density";
import IcPopulation from "../../components/icons/ic-population";
import IcFertility from "../../components/icons/ic-fertility";
import Loader from "../../components/Loader";

export default {
  name: "census",
  components: {Loader, IcFertility, IcPopulation, IcDensity, IcLife, IcLiteracy, MalawiMap, SectionHeader, Malawi},
  layout: 'secondary',
  async created() {
    await this.getAll()
  },
  data() {
    return {
      national: null,
      regions: [],
      media: [],
      resources: [],
      districts: [],
      apiBusy: false
    }
  },
  methods: {
    async getAll() {
      this.apiBusy = true
      let response = (await this.$axios.get(`census/${this.$route.params.slug}`)).data.data
      if (response) {
        this.national = response.national
        this.regions = response.regions
        this.resources = response.resources
        this.districts = response.districts
        this.media = response.media
        this.apiBusy = false
      }
    }
  },
  computed: {
    capital() {
      return this.districts.find(c => c.district.name === 'Lilongwe')
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
