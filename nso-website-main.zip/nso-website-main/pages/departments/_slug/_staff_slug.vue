<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <div class="md:float-right overflow-hidden object-cover rounded-lg border-b-4 border-red-600">
          <img v-if="hasMedia(staff)" :src="staff.image_url" class="object-cover md:w-64 md:h-72 xl:w-72 xl:h-84">
          <img v-else src="~/assets/images/no-image.png" class="object-cover md:w-64 md:h-72 xl:w-72 xl:h-84"/>
        </div>
        <div class="mt-5 md:mt-0">
          <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">{{ staff.name }}</h1>
          <div class="mb-5 text-lg"><span v-if="former(staff)">Former </span> {{ staff.position }}</div>
          <div class="pb-5 font-light md:flex items-center" v-if="hasContacts(staff)">
            {{ staff.phone_number }} <span class="text-3xl text-red-600 mx-2 hidden md:block">/</span>
            <br class="md:hidden"> <div class="border border-b my-2 border-red-600 w-1/4 md:hidden"></div> {{ staff.email }}
          </div>
          <nuxt-link to="/speeches" v-if="isCeo()">
            <button class="px-8 py-2 rounded bg-primary-600 hover:bg-primary-500 flex items-center duration-500 ease-in-out">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
              </svg>
              <span class="flex-1">Download Speeches</span>
            </button>
          </nuxt-link>
        </div>
      </div>
    </div>

    <div class="lg:mt-0 bg-primary-600 text-gray-100 hidden md:block">
      <div class="pt-10 px-10 container mx-auto"></div>
    </div>

    <div>
      <div class="mx-auto container mb-10 lg:mt-0 flex">
        <div class="lg:w-3/4 text-gray-700 lg:mb-10 mt-5 px-10 lg:mt-0 xl:-mt-10 lg:pr-20 content" v-html="this.staff.profile"></div>
        <div class="lg:w-1/4 text-gray-700 my-10  hidden lg:block md:-ml-12 xl:-ml-8 mr-8" v-if="isCeo()">
          <h1 class="font-display font-semibold text-xl pb-2 text-center" v-if="formerStaff.length">Former Commissioners</h1>
          <div class="py-5 flex flex-col px-5">
            <div class="flex mb-5" v-for="retired in formerStaff">
              <nuxt-link v-bind:to="`/departments/${retired.department.slug}/${retired.slug}`" class="flex items-center mb-5">
                <div class="w-16 h-16 mr-2 xl:mr-5">
                  <img :src="retired.image_url" class="rounded-full object-cover w-16 h-16" :alt="retired.name" v-if="hasMedia(retired)"/>
                  <img src="~assets/images/no-image.png" class="rounded-full object-cover w-16 h-16" :alt="retired.name" v-else/>
                </div>
                <div class="font-light flex-1">{{ retired.name }}</div>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
      <div class="lg:hidden" v-if="isCeo()">
        <h1 class="font-display font-semibold text-3xl pb-5 px-10" v-if="formerStaff.length">Former Commissioners</h1>
        <div class="py-5 flex flex-wrap px-10">
          <div class="flex mb-5" v-for="retired in formerStaff">
            <nuxt-link v-bind:to="`/departments/${retired.department.slug}/${retired.slug}`" class="flex items-center mb-5 mr-5">
              <div class="w-16 h-16 mr-2 xl:mr-5">
                <img :src="retired.image_url" class="rounded-full object-cover w-16 h-16" :alt="retired.name" v-if="hasMedia(retired)"/>
                <img src="~assets/images/no-image.png" class="rounded-full object-cover w-16 h-16" :alt="retired.name" v-else/>
              </div>
              <div class="font-light flex-1">{{ retired.name }}</div>
            </nuxt-link>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import LinkButton from "../../../components/LinkButton";
import MIcon from "../../../components/MIcon.vue";

export default {
  name: "_staff_slug",
  components: {LinkButton, MIcon},
  created() {
    this.fetchData()
  },
  mounted() {
    this.scrollToTop()
  },
  data() {
    return {
      staff: {},
      formerStaff: {},
      namespace: 'staff'
    }
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`${this.namespace}/${this.$route.params.staff_slug}`)
        .then(res => this.staff = res.data.data)
      this.$axios.get('/about/former-ceo')
        .then(res => this.formerStaff = res.data.data)
    },
    hasMedia(staff) {
      return staff.media && staff.media.length
    },
    hasContacts(staff) {
      return staff.phone_number && staff.email
    },
    former(staff){
      return staff.current===0
    },
    isCeo(){
      return `${this.$route.params.staff_slug}` === `${this.ceo.slug}`
    }
  },
  head() {
    return {
      title: this.staff.name + ' - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.staff.profile}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
    ceo() {
      return this.$store.state.ceo
    },
  }
}
</script>
<style>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
