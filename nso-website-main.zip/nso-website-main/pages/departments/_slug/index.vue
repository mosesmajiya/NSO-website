<template>
  <div class="font-display">
    <div v-if="loaded">

      <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
        <div class="container mx-auto px-2 xl:px-12">
          <h1 class="font-display font-semibold text-3xl pb-2"><span class="text-red-600 mr-1 inline-block">{{ department.name }}</span>Department</h1>
          <div class="mb-10">{{ department.description | strip }}</div>
        </div>
      </div>

      <div class="bg-gray-100">
        <div class="container mx-auto p-10 pb-5">

          <div class="md:flex md:flex-wrap xl:py-10">
            <div v-for="(member, index) in staff" :data-aos-delay="index * 200" class="md:w-1/2 lg:w-1/3 md:pr-10 pb-24 aos-fix"
                 data-aos="zoom-in-up">
              <nuxt-link v-bind:to="`/departments/${department.slug}/${member.slug}`" class="h-full">
                <div class="rounded-lg overflow-hidden">
                  <img :src="member.image_url" class="md:h-84 w-full object-cover" v-if="hasMedia(member)">
                  <img class="md:h-84 w-full object-cover" src="~assets/images/no-image.png" v-else>
                </div>
                <h1 class="font-bold font-display text-xl lg:text-2xl pt-6">{{ member.name }}</h1>
                <div class="w-6 border-b-2 border-red-500 my-1"></div>
                <div class="pb-4 text-gray-700">
                  {{ member.position }}
                </div>
                <div class="text-gray-600 content font-light" v-if="member.profile">
                  {{ member.profile | strip | str_limit(160) }}
                </div>
              </nuxt-link>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div v-else class="container mx-auto p-10 pt-40 items-stretch h-screen flex text-lg">
      LOADING...
    </div>
  </div>
</template>

<script>
import SectionHeader from "../../../components/SectionHeader";
import LinkButton from "../../../components/LinkButton";
import MIcon from "../../../components/MIcon";

export default {
  name: "_slug",
  components: {LinkButton, MIcon, SectionHeader},
  layout: 'secondary',

  created() {
    this.fetchData()
  },
  mounted() {
    this.scrollToTop()
  },
  data() {
    return {
      staff: [],
      positions: [],
      department: {},
      namespace: 'departments',
      loaded: false
    }
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  methods: {
    hasMedia(member) {
      return member.image_url !== ''
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`${this.namespace}/${this.$route.params.slug}`)
        .then(res => {
          let data = res.data.data
          this.positions = data.positions
          this.department = data
          this.staff = this.department.staff
          this.loaded = true
        })
    },
  },
  head() {
    return {
      title: 'Division - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}

.pr-10:nth-child(3n) {
  padding-right: unset;
  padding-left: 40px;
}

.pr-10:nth-child(2n) {
  padding: 0 20px;
}
</style>
