<template>
  <nuxt></nuxt>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";
import LinkButton from "../../components/LinkButton";
import MIcon from "../../components/MIcon";
export default {
  name: "_slug",
  components: {MIcon, SectionHeader, LinkButton},
  layout: 'secondary',
}
</script>
<style scoped>

</style>
