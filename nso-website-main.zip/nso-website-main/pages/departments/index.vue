<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center"><span class="text-red-600 mr-2">About</span>Departments</h1>
        <div class="mb-10">The NSO also has regional offices in the major urban centres of Lilongwe, Mzuzu, and Blantyre. Many of the NSO's
          statistical products may be obtained at these offices as well as the headquarters in Zomba.
        </div>
      </div>
    </div>
    <div class="bg-gray-300">

      <div class="container mx-auto">

        <div class="md:flex md:flex-wrap py-5">
          <div class="md:w-1/2" v-bind:key="department.id" v-for="department in departments">
            <div class="p-10">
              <h1 class="font-display text-gray-800 text-2xl font-bold capitalize">{{ department.name }}</h1>
              <div class="pt-2 text-gray-700">{{ department.description | strip | str_limit(180) }}</div>
              <nuxt-link :to="`/departments/${department.slug}`"
                         class="text-primary-500 text-sm flex items-center inline-block pt-4">
                <span>Read More</span>
              </nuxt-link>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.$axios.get('departments')
      .then(res => this.departments = res.data.data.data)
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.posts.next_page_url)
        .then(res => {
          this.loading = false
          this.departments.data = this.departments.data.concat(res.data.data.data)
          this.departments.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      departments: {},
      loading: false,
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.scrollToTop()
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}

</style>
