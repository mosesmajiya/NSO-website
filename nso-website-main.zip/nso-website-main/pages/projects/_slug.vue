<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Projects</h1>
        <div class="mb-10">Follow a series of projects the NSO is undertaking
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="lg:flex">
        <section class="lg:w-2/3">
          <article class="pb-5 group aos-fix" data-aos="zoom-in-up">
            <div class="mb-4">
              <h1 class="font-display text-xl lg:text-3xl font-bold leading-none">{{ project.name }}</h1>
              <div class="pt-2 pb-4 text-xs text-gray-500">
                <span v-if="project.author">{{ project.author }} &middot; </span>
                {{ project.published_at | from_now }}
              </div>
            </div>
            <div class="rounded-lg overflow-hidden">
              <img :src="project.image_url" v-if="hasMedia(project)" class="w-full object-cover">
              <img src="~assets/images/no-image.png" v-else class="w-full object-cover">
            </div>
            <div class="mt-4 px-2" v-if="hasMedia(project)">
              <div class="w-8 border-t-2 border-red-500 my-2"></div>
              <div class="text-gray-600 italic">{{ project.type }} | {{ project.advisor }} | {{ project.ministry }}</div>
            </div>
            <div class="text-gray-600 pt-8 content" v-html="project.content"></div>

            <div class="flex pt-12 text-sm font-bold font-display items-center uppercase" v-if="hasAttachments(project)">
              <h1>Downloads</h1>
              <div class="border-b ml-2 text-black flex-1"></div>
            </div>
            <div v-if="hasAttachments(project)" class="flex flex-wrap pt-8">
              <div v-for="attachment in project.attachments" v-bind:key="attachment.id" class="w-full md:w-1/2">
                <a :href="attachment.download" class="flex justify-between mr-4 mb-4 shadow-xs rounded overflow-hidden">
                  <div class="text-gray-500 py-2 px-1 flex-shrink bg-gray-100">
                    <fa-icon icon="file-pdf" type="fas" size="3x"/>
                  </div>
                  <div class="flex-1 bg-gray-200 py-2 px-3">
                    <p class="text-gray-700">{{ attachment.caption }}</p>
                    <span class="block text-xs text-gray-600">{{ attachment.size }}</span>
                  </div>
                </a>
              </div>
            </div>
          </article>
        </section>
        <section class="mt-10 lg:mt-0 lg:w-1/3 lg:ml-12 text-sm">
          <popular-news v-bind:posts="popular"/>
          <recent-news v-bind:posts="recent"/>
        </section>
      </div>
    </div>

  </div>
</template>

<script>
import FaIcon from "../../components/FaIcon";
import RecentNews from "../../components/news/RecentNews";
import PopularNews from "../../components/news/PopularNews";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "_slug",
  components: {LoaderButton, PopularNews, RecentNews, FaIcon},
  layout: 'secondary',
  async asyncData({$axios, params}) {
    let project = (await $axios.get(`projects/${params.slug}`)).data.data
    let popular = (await $axios.get('news/popular')).data.data

    return {project, popular}
  },
  mounted() {
    this.scrollToTop()
  },
  created() {
    this.$axios.get('news/recent')
      .then(res => this.recent = res.data.data)
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.fetchRelated()
      this.scrollToTop()
    }
  },
  methods: {
    hasMedia(project) {
      return project.media && project.media.length
    },
    hasAttachments(project) {
      return project.attachments && project.attachments.length
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`projects/${this.$route.params.slug}`)
        .then(res => this.project = res.data.data)
    },
    fetchRelated() {
      this.$axios.get('news/popular')
        .then(res => this.popular = res.data.data)
    }
  },
  head() {
    return {
      title: this.pageTitle + this.settings.organization_name || '',
    }
  },
  computed: {
    pageTitle() {
      return this.project.title ? this.project.title + ' - Projects - ' : ''
    },
    metaDescription() {
      return ''
    },
    settings() {
      return this.$store.state.settings;
    },
    posts() {
      return this.popular.slice(0, 3)
    }
  },
  data() {
    return {
      project: {},
      popular: [],
      recent: [],
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
