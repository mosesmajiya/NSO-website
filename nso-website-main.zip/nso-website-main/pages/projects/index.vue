<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Projects</h1>
        <div class="mb-10">Follow a series of projects the NSO is undertaking.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="lg:flex">
        <section class="lg:w-2/3">
          <article v-for="project in projects.data" v-bind:key="project.id" class="pb-20 group aos-fix" data-aos="zoom-in-up">
              <div class="bg-gray-100 border-b-4 group-hover:border-red-400 rounded-lg border-transparent">
                <div class="rounded-t overflow-hidden">
                  <img :src="project.image_url" v-if="hasMedia(project)" class="md:h-84 w-full object-cover">
                  <img src="~assets/images/no-image.png" v-else class="md:h-84 w-full object-cover">
                </div>
                <div class="px-8 py-8">
                  <h1 class="font-display font-semibold text-2xl">{{ project.name }}</h1>
                  <div class="py-2 text-xs text-gray-500">
                    <span v-if="project.type">{{ project.type }} &middot; </span>
                    {{ project.created_at | from_now }}
                  </div>
                  <p class="text-gray-600">{{ project.content | strip | str_limit(120) }}</p>
                  <nuxt-link v-bind:to="`/projects/${project.slug}`" class="flex items-center text-sm mt-4 text-primary-500">
                    <span>Read more</span>
                    <m-icon class="ml-2">trending_flat</m-icon>
                  </nuxt-link>
                </div>
              </div>
            </article>
          <div class="flex justify-center">
            <loader-button :busy="loading" @click="loadMore" v-if="projects.next_page_url">Load more news</loader-button>
          </div>
        </section>
        <section class="lg:w-1/3 lg:ml-12 text-sm">
          <popular-news v-bind:posts="popular"/>
          <recent-news v-bind:posts="recent"/>
        </section>
      </div>
    </div>


  </div>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";
import MIcon from "../../components/MIcon";
import PopularNews from "../../components/news/PopularNews";
import RecentNews from "../../components/news/RecentNews";
import LoaderButton from "../../components/LoaderButton";
export default {
  name: "reports",
  components: {LoaderButton, RecentNews, PopularNews, MIcon, SectionHeader},
  layout: 'secondary',

  async asyncData({$axios}) {
    let response = (await $axios.get('projects/category/normal')).data.data;
    return {projects: response}
  },
  created() {
    this.$axios.get('projects/category/normal')
      .then(res => this.projects = res.data.data)

    this.$axios.get('news/popular')
      .then(res => this.popular = res.data.data)

    this.$axios.get('news/recent')
      .then(res => this.recent = res.data.data)
  },
  methods: {
    hasMedia(post) {
      return post.media.length
    },
    loadMore() {
      this.loading = true
      this.$axios.get(this.posts.next_page_url)
        .then(res => {
          this.loading = false
          this.posts.data = this.posts.data.concat(res.data.data.data)
          this.posts.next_page_url = res.data.data.next_page_url
        })
    }
  },
  data() {
    return {
      projects: {},
      loading: false,
      popular: [],
      recent: [],
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
