<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Unsubscribe from Email Notifications</h1>
        <div class="mb-10">
          We are sad to see you go but we are hoping you shall come back!
        </div>
      </div>
    </div>

    <div class="bg-gray-200">
      <div class="text-gray-800 py-16 px-10">
          <form @submit.prevent="onSubmit">
            <div v-show="!subscribed" class="mx-auto flex lg:max-w-6xl">
              <div class="flex-1 lg:px-20">
                <div style="min-height: 12rem">
                  <div v-show="!subscribed">
                    <p class="text-lg text-center sm:text-left">
                      You are currently subscribed for the following email alerts.
                      Please select the alerts category that you are not interested in anymore.</p>
                    <div class="pt-8">
                      <div data-aos="zoom-in" :data-aos-delay="_slug * 100" v-for="(service, index) in subscriptions"
                           v-bind:key="service.id" class="pb-2 pl-8 aos-fix">
                        <label class="inline-flex items-center">
                          <input type="checkbox" class="form-checkbox h-4 w-4" v-bind:id="service.id"
                                 @change="errors = null"
                                 v-bind:value="service.id" checked v-model="form.subscriptions">
                          <span class="ml-2">{{ service.name }}</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="subscribed lg:flex max-w-4xl mx-auto justify-center text-3xl text-center"
                 v-if="subscribed">
              <svg class="hidden lg:block md:w-10 md:h-10 mb-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"></path></svg>
              <span class="font-display">Successfully unsubscribed!</span>
            </div>
            <div class="lg:max-w-6xl mx-auto lg:px-20" v-else>
              <ul class="errors bg-white mb-2 px-8 py-2 rounded text-red-500 text-sm" v-if="errors">
                <li v-for="error in errors" class="py-1">{{ error }}</li>
              </ul>
              <div class="flex hidden md:flex">
                <button
                  v-bind:disabled="busy"
                  :class="{'cursor-wait bg-primary-200': this.busy}"
                  class="bg-primary-500 hover:bg-primary-600 px-10 py-2 text-white rounded-lg focus:outline-none
                flex items-center hover:text-gray-300 transition duration-500 ease-out font-semibold"
                  type="submit">
                  Unsubscribe
                </button>
              </div>

            </div>
          </form>

        </div>
    </div>


  </div>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";
import MIcon from "../../components/MIcon";
export default {
  name: "unsubscribe",
  components: {MIcon, SectionHeader},
  layout: 'secondary',
  props: ['subscriptions'],
  methods: {
    onSubmit() {
      this.busy = true
      this.$axios.post(`unsubscribe/${this.$route.params.slug}`, this.form)
        .then(() => {
          this.subscribed = true
          this.busy = false
        })
        .catch(err => {
          this.busy = false
          this.errors = err.response.data.status.errors
        })
    }
  },
  created() {
    this.$axios.get(`unsubscribe/${this.$route.params.slug}`)
      .then(res => this.subscriptions = res.data.subscriptions)
  },
  data() {
    return {
      subscriptions: {},
      subscribed: false,
      errors: null,
      busy: false,
      form: {
        subscriptions: [],
      }
    }
  },
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
