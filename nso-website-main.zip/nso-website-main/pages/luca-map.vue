<template>
  <div>
    <malawi-map/>
  </div>
</template>

<script>

import MalawiMap from "../components/MalawiMap";

export default {
  name: "luca-map",
  components: {MalawiMap},
}
</script>
