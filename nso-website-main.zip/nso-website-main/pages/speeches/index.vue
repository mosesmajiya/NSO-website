<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Commissioner of Statistics Speeches</h1>
        <div class="mb-10">Download speeches made by the Commissioner of Statistics
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10 pb-5">
      <section class="w-full">
        <div v-for="download in downloads" class="pb-10 rounded p-10 mb-10 bg-gray-100">
          <h1 class="font-display text-xl lg:text-2xl font-bold">{{ download.name }}</h1>
          <div class="mt-0 mb-8" v-html="download.description "></div>
          <div class="flex flex-wrap">
            <div v-for="file in download.attachments" v-bind:key="download.id" class="w-full md:w-1/2">
              <a :href="file.url" :alt="file.name" target="_blank" class="cursor-pointer group">
                <div
                  class="flex items-center bg-gray-200 rounded overflow-hidden mb-4 mr-3 xl:w-72 group-hover:bg-primary-500 group-hover:text-white">
                  <div class="px-4 py-3 bg-green-400 group-hover:bg-primary-600 text-white">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                         xmlns="http://www.w3.org/2000/svg">
                      <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"></path>
                    </svg>
                  </div>
                  <div class="px-3 group-hover:text-gray-200 font-menu text-gray-700 text-sm">{{ file.name }}
                    <div class="group-hover:text-gray-200 uppercase text-xs">{{ file.size }}</div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>


  </div>
</template>

<script>
import MIcon from "@/components/MIcon";
import LoaderButton from "@/components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.$axios.get('downloads/speech')
      .then(res => this.downloads = res.data.data.data)
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.downloads.next_page_url)
        .then(res => {
          this.loading = false
          this.downloads.data = this.downloads.data.concat(res.data.data.data)
          this.downloads.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      downloads: {},
      loading: false,
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
