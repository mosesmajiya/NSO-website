<template>
  <div class="hero bg-gradient-to-b from-green-600 to-green-400">
    <navbar class="relative"/>
    <div class="">
      <img src="~assets/images/malawi-government-logo-small.png" class="mx-auto md:hidden w-16 mt-20 -mb-20">
      <div class="pt-24 md:pt-32 px-10 font-display font-semibold text-2xl md:text-4xl lg:text-3xl xl:text-4xl pb-2 text-center lg:hidden">
        The National Statistical <br class="lg:hidden"><span class="text-green-400">Office of Malawi</span>
      </div>
      <section-header class="-mb-20 mt-10 lg:hidden text-xs">Malawi at a Glance</section-header>
      <div class="container bg-top bg-no-repeat md:flex pt-10 xl:pt-56 xl:pb-10 lg:pt-32 mx-auto p-0 lg:pl-10">
        <div class="hidden md:w-1/3 lg:w-1/4 lg:flex flex-col w-auto items-center xl:pt-24">
          <client-only>
            <malawi-map class=" xl:-mt-10" height="600"/>
          </client-only>
        </div>
        <div class="flex-grow md:w-2/3 lg:3/4 px-10 lg:px-5 flex self-center">
          <div class="flex-1">
            <div class="md:flex flex-wrap rounded-lg mt-5 pt-10 lg:pt-0 px-5 md:px-10">
              <quick-stat label="Population (mid-year)" :value="quickStats.population" link="/census/2018" type="normal">
                <svg class="lg:w-10 lg:h-10 w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="1"></path>
                </svg>
              </quick-stat>
              <quick-stat label="Headline Inflation" :value="quickStats.inflation_rate" link="/consumer-price-index" type="percentage">
                <svg class="lg:w-10 lg:h-10 w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                    stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="1"></path>
                </svg>
              </quick-stat>
              <quick-stat label="Gross Domestic Product" :value="quickStats.gross_domestic_product" link="/census/2018" type="percentage">
                <svg class="lg:w-10 lg:h-10 w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"
                    stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="1"></path>
                </svg>
              </quick-stat>
              <quick-stat label="Unemployment Rate" :value="quickStats.unemployment_rate" link="/census/2018" type="percentage">
                <svg class="lg:w-10 lg:h-10 w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="1"></path>
                </svg>
              </quick-stat>
            </div>

            <div class="lg:px-10">
              <div>
                <div class="font-display mt-2 md:px-5 md:px-10 lg:p-0 lg:mb-16 xl:mb-0 rounded-lg
                  px-5 mt-5 pt-5 md:mt-0 md:p-5 lg:border-0 shadow-lg lg:shadow-none">
                  <div v-for="article in latestArticles" v-bind:key="article.id">
                    <alert-slide
                      :created_at="article.created_at"
                      :image="article.image"foo
                      :snippet="article.content"
                      :title="article.title"
                      :slug="article.slug"
                    >
                    </alert-slide>
                  </div>
                </div>
                <div class="rounded-2xl bg-gray-600 bg-opacity-50 py-2 px-5 mt-5 shadow-lg items-center hidden xl:flex">
                  <div class="w-10 text-gray-400">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div class="font-display font-semibold text-xl leading-tight text-white pl-5">
                    <div>Interactive Population Census Map of Malawi</div>
                    <div class="text-sm text-gray-100 mt-1 font-light">Hover or select a district on the map to get more census information about a district.</div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>

    <div class="font-display p-10 mt-10 lg:-mt-16 bg-gradient-to-b from-green-600 to-green-400 text-white xl:hidden">
      <div class="container mx-auto lg:p-10 p-3">
        <div class="font-semibold text-4xl lg:text-3xl xl:text-4xl pb-2 text-center hidden lg:block">
          The National Statistical <br class="lg:hidden"><span class="text-yellow-400">Office of Malawi</span>
        </div>
        <div class="pb-8 lg:pt-4 text-center lg:px-32">
          The NSO is the main government department responsible for the collection
          and dissemination of official statistics operating under the 2013 Statistics Act.
        </div>
        <div class="text-center flex flex-col">
          <div class="flex">
            <nuxt-link to="/about" class="flex-1 rounded px-5 mb-5 bg-green-600 hover:bg-green-600 duration-500 ease-in-out py-2 mx-4 uppercase text-white font-menu text-sm
            hover:border-green-400 hover:text-gray-200 block mb-2 sm:inline">About Us</nuxt-link>
            <nuxt-link to="/news" class="flex-1 rounded px-5 mb-5 bg-green-600 hover:bg-green-600 duration-500 ease-in-out py-2 mx-4 uppercase text-white font-menu text-sm
            hover:border-green-400 hover:text-gray-200 block mb-2 sm:inline">News</nuxt-link>
          </div>
          <div class="flex">
            <nuxt-link to="/events" class="flex-1 rounded px-5 mb-5 bg-green-600 hover:bg-green-600 duration-500 ease-in-out py-2 mx-4 uppercase text-white font-menu text-sm
            hover:border-green-400 hover:text-gray-200 block mb-2 sm:inline">Events</nuxt-link>
            <nuxt-link to="/vacancies" class="flex-1 rounded px-5 mb-5 bg-green-600 hover:bg-green-600 duration-500 ease-in-out py-2 mx-4 uppercase text-white font-menu text-sm
            hover:border-green-400 hover:text-gray-200 block mb-2 sm:inline">Vacancies</nuxt-link>
          </div>
        </div>
      </div>
    </div>

    <div class="text-white font-display font-semibold text-3xl overflow-hidden p-5 mt-8 hidden xl:flex bg-white">
      <nuxt-link to="/about" class="bg-about bg-cover bg-center h-72 flex-1 flex items-center justify-center mx-1 border-b-4
        border-red-600 hover:bg-gray-800 rounded-lg">
        <div class="px-5 py-3 bg-black bg-opacity-25 w-full text-center">About NSO</div>
      </nuxt-link>
      <nuxt-link to="/news" class="bg-news bg-cover bg-center h-72 flex-1 flex items-center justify-center mx-1 border-b-4
        border-red-600 hover:bg-gray-800 rounded-lg">
        <span class="px-5 py-3 bg-black bg-opacity-25 w-full text-center">News</span>
      </nuxt-link>
      <nuxt-link to="/events" class="bg-events bg-cover bg-center h-72 flex-1 flex items-center justify-center mx-1 border-b-4
        border-red-600 hover:bg-gray-800 rounded-lg">
        <span class="px-5 py-3 bg-black bg-opacity-25 w-full text-center">Events</span>
      </nuxt-link>
      <nuxt-link to="/vacancies" class="bg-vacancies bg-cover bg-center h-72 flex-1 flex items-center justify-center mx-1 border-b-4
        border-red-600 hover:bg-gray-800 rounded-lg">
        <span class="px-5 py-3 bg-black bg-opacity-25 w-full text-center">Job Opportunities</span>
      </nuxt-link>
    </div>

    <div :style="`background-image: url(${ require('~/assets/images/circle-bg-flip.png')})`"
         class="shadow-2xl shadow-inner bg-gray-100 bg-no-repeat bg-fixed">
      <div :style="`box-shadow: inset 0 -2px 4px 0 rgba(0, 0, 0, 0.06);`">
        <div class="container mx-auto py-16 lg:py-24">
          <section-header>Latest Releases</section-header>
          <h2 class="font-display text-center font-semibold text-2xl md:text-4xl max-w-4xl mx-auto px-4">
            Our Most Recent Releases</h2>
          <div v-if="releases" class="md:flex flex-wrap pt-4 md:pt-16 px-8 font-display">
            <release-card v-for="(release, index) in releases" :key="index" :release="release"/>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-white">
      <div class="container mx-auto py-10 lg:py-24">
        <h2 class="font-display text-center font-semibold text-2xl md:text-4xl max-w-4xl mx-auto px-4 hidden">
          General Statistics For You</h2>
        <div class="md:flex flex-wrap pt-4 md:pt-16 px-8">
          <quick-link
            sub-title="Business statistics are about the activity and performance of businesses and the economy in general in Malawi."
            title="Business">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path
                d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2">
              </path>
            </svg>
          </quick-link>
          <quick-link
            sub-title="Population and Housing Censuses (PHC) conducted over several decades by the National Statistical Office (NSO)."
            title="Population"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path
                d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
            </svg>
          </quick-link>
          <quick-link
            sub-title="Statistics about the goods and services Malawi consumes and produces, and its economic relationship with the rest of the world."
            title="Economy"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path
                d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2">
              </path>
            </svg>
          </quick-link>
        </div>

        <div class="hidden md:block border-b border-gray-400 my-20 max-w-3xl mx-auto"></div>

        <div class="hidden md:flex md:flex-wrap px-8 pb-5">
          <div v-for="(topCategory, index) in topCategories" :key="index" class="md:w-1/3">
            <sec-quick-link :to="`/publications/${topCategory.slug}`">{{ topCategory.name }}</sec-quick-link>
          </div>
        </div>

      </div>
    </div>

    <div class="bg-white w-full bg-gray-100" v-if="featuredPublications.length">
      <div class="py-10 md:py-24 mx-auto">
        <section-header>Featured Publications</section-header>
        <h2 class="font-display text-center font-semibold text-2xl md:text-4xl max-w-4xl mx-auto px-4">
          Must See Publications</h2>
        <div class="md:flex flex-wrap pt-16 px-8">

          <div class="mb-5 xl:flex-1 sm:w-1/3" v-for="publication in featuredPublications">
            <div class="md:mr-4 px-2 pb-10 lg:pb-0">
              <nuxt-link v-bind:to="`/publications/${publication.super_category_slug}/${publication.slug}`">
                <img class="rounded object-cover object-top w-full h-48 lg:h-84"
                     :src="publication.cover" :alt="publication.title"/>
                <div class="mt-2 text-gray-700 text-xs font-light hidden xl:flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 inline mr-1 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                  </svg>
                  Featured {{ publication.featured_on | from_now }}  &middot; Published on {{ publication.published_at | date_format }}
                </div>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="w-full bg-gradient-to-r from-gray-300 to-gray-200 text-center">
      <div class="py-16 px-10 md:py-24 mx-auto">
        <h1 class="font-display font-semibold text-2xl md:text-4xl max-w-4xl mx-auto px-4">Subscribe to Email Notifications</h1>
        <div class="pt-2 mb-10 text-gray-700">
          Don't miss a thing. Get notified by email of our latest publications in any category of your choice.
          Terms and conditions apply.
        </div>
        <nuxt-link to="/subscribe" class="mt-8 px-5 py-3 rounded-lg bg-secondary-400 text-white text-center hover:bg-secondary-500 duration-500 ease-in-out border-0">
          Let's Get Started
        </nuxt-link>
      </div>
    </div>

  </div>
</template>

<script>
import IcIcon from "~/components/icons/ic-icon.vue";
import HomeFooter from "~/components/SiteFooter.vue";
import Navbar from "~/components/navbar.vue";
import SectionHeader from "~/components/SectionHeader.vue";
import CtaButton from "~/components/CtaButton.vue";
import QuickStat from "~/components/QuickStat.vue";
import QuickLink from "~/components/QuickLink.vue";
import SecQuickLink from "~/components/SecQuickLink.vue";
import AlertSlide from "~/components/AlertSlide.vue";
import ReleaseCard from "~/components/ReleaseCard.vue";
import faker from 'faker';
import Malawi from "~/components/Malawi.vue";
import MalawiMap from "~/components/MalawiMap.vue";

export default {
  components: {
    MalawiMap,
    Malawi,
    ReleaseCard,
    AlertSlide, SecQuickLink, QuickLink, QuickStat, CtaButton, SectionHeader, Navbar, HomeFooter, IcIcon
  },
  head() {
    return {
      title: 'Home - ' + this.$store.state.settings.organization_name
    }
  },
  created() {
    this.$axios.get('reports/recent')
      .then(res => this.releases = res.data.data)
    this.$axios.get('top-categories')
      .then(res => this.topCategories = res.data.data)
    this.$axios.get('featured-publications')
      .then(res => this.featuredPublications = res.data.data)
    this.$axios.get('quick-stats')
      .then(res => this.quickStats = res.data.quick_stats)
  },
  data() {
    return {
      topCategories: {},
      releases: {},
      alerts: [],
      latestArticles: [],
      featuredPublications: [],
      quickStats:{}
    }
  },
  async asyncData({$axios}) {
    let events = (await $axios.get('events/soon')).data.data
    let latestArticles = (await $axios.get('articles/latest-two')).data.data
    return {events, latestArticles}
  },
  mounted() {
    this.$axios.get(`/`, {
      headers: {
        'x-user-agent': this.getUserAgent()
      }
    })
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },

  },
  methods: {
    getUserAgent() {
      if (process.server) return ''
      let userAgent = navigator.userAgent
      if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(userAgent)) {
        return "tablet";
      }
      if (
        /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(
          userAgent
        )
      ) {
        return "mobile";
      }
      return "desktop";
    }
  }
}
</script>

<style scoped>
.hero {
  @apply bg-wave-line;
  background-repeat: no-repeat;
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: "";
  position: absolute;
  left: -65px;
  width: 110%;
  height: 384px;
  z-index: -1;
  @apply bg-wave;
  background-repeat: no-repeat;
  background-size: 100% auto;
}



@screen lg {
  .hero::after {
    content: "";
    position: absolute;
    @apply inset-0 bg-home bg-cover;
    z-index: -2;
    background-repeat: no-repeat;
    background-size: 100% auto;
  }
}

@media only screen and (max-width: 768px) {
  .alert-slide {

  }
}


@media only screen and (min-width: 1024px) {
  .hero {
    background-size: auto 320px;
  }
}

@media only screen and (min-width: 1440px) {
  .hero {
    background-size: auto 420px;
  }
}

@media only screen and (min-width: 2560px) {
  .hero {
    background-size: auto 520px;
  }
}
</style>
