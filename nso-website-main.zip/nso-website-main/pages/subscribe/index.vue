<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Subscribe to Email Notifications</h1>
        <div class="mb-10">
          Don't miss a thing. Get notified by email of our latest publications in any category of your choice.
          Terms and conditions apply.
        </div>
      </div>
    </div>

    <div class="bg-gray-200">
      <div class="text-gray-800 py-16 px-10">
          <form @submit.prevent="onSubmit">
            <div v-show="!subscribed" class="mx-auto flex lg:max-w-6xl">
              <div class="flex-1 lg:px-20">
                <div style="min-height: 12rem">
                  <div v-show="!subscribed">
                    <p class="text-lg text-center sm:text-left">Please select the publications you want to subscribe to</p>
                    <div class="pt-8">
                      <div data-aos="zoom-in" :data-aos-delay="index * 100" v-for="(service, index) in subscriptions"
                           v-bind:key="service.id" class="pb-2 pl-8 aos-fix">
                        <label class="inline-flex items-center">
                          <input type="checkbox" class="form-checkbox h-4 w-4" v-bind:id="service.id"
                                 @change="errors = null"
                                 v-bind:value="service.id" checked v-model="form.publications">
                          <span class="ml-2">{{ service.name }}</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="subscribed lg:flex max-w-4xl mx-auto justify-center text-3xl text-center"
                 v-if="subscribed">
              <svg class="hidden lg:block md:w-10 md:h-10 mb-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"></path></svg>
              <span class="font-display">Thank you for subscribing to our publications!</span>
            </div>
            <div class="mt-8 lg:max-w-6xl mx-auto lg:px-20" v-else>
              <ul class="errors bg-white mb-2 px-8 py-2 rounded text-red-500 text-sm" v-if="errors">
                <li v-for="error in errors" class="py-1">{{ error }}</li>
              </ul>
              <div class="flex hidden md:flex">
                <input type="email" class="flex-1 font-display text-green-700 px-8 py-4 focus:outline-none text-lg rounded-l-lg"
                       v-model="form.email"
                       @keydown="errors = null"
                       placeholder="Email address">
                <button
                  v-bind:disabled="busy"
                  :class="{'cursor-wait bg-primary-200': this.busy}"
                  class="bg-primary-500 hover:bg-primary-600 px-10 py-2 text-white rounded-r-lg focus:outline-none
                flex items-center hover:text-gray-300 transition duration-500 ease-out font-semibold"
                  type="submit">
                  Subscribe
                </button>
              </div>

              <div class="md:hidden">
                <input type="email" class="flex-1 py-2 focus:outline-none px-4 text-xl w-full rounded"
                       v-model="form.email"
                       @keydown="errors = null"
                       placeholder="Email address">
                <button
                  v-bind:disabled="busy"
                  :class="{'cursor-wait bg-primary-200': this.busy}"
                  class="rounded bg-primary-500 font-semibold w-full justify-center hover:bg-primary-600 px-10 mt-5 py-2 text-white focus:outline-none
                flex items-center hover:text-gray-300 transition duration-500 ease-out"
                  type="submit">
                  Subscribe
                </button>
              </div>

            </div>
          </form>

        </div>
    </div>


  </div>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";
import MIcon from "../../components/MIcon";
export default {
  name: "subscribe",
  components: {MIcon, SectionHeader},
  layout: 'secondary',
  props: ['subscriptions'],
  methods: {
    onSubmit() {
      this.busy = true
      this.$axios.post('subscribe', this.form)
        .then(() => {
          this.subscribed = true
          this.busy = false
        })
        .catch(err => {
          this.busy = false
          this.errors = err.response.data.status.errors
        })
    }
  },
  created() {
    this.$axios.get('subscriptions')
      .then(res => this.subscriptions = res.data.data)
  },
  data() {
    return {
      subscriptions: {},
      subscribed: false,
      errors: null,
      busy: false,
      form: {
        publications: [],
        email: ''
      }
    }
  },
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
