<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">About NSO</h1>
        <div class="mb-10">The National Statistical Office is Malawi Government's department responsible for the collection
          and dissemination of official statistics.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10 xl:flex">
      <div class="xl:w-8/12 pr-5">
        <div class="py-3 mb-5 text-gray-800" v-for="about in abouts">
          <h1 class="text-2xl font-bold font-display">{{ about.category }}</h1>
          <div class="w-6 border-b-2 border-red-500 mt-1"></div>
          <div class="mt-4 text-gray-700" v-html="about.content"></div>
        </div>

      </div>

      <div class="xl:w-4/12 p-10 hidden xl:block">
        <img class="rounded object-cover mb-4 h-108" v-bind:src="ceo.image_url" v-if="ceo.image_url"/>
        <img class="rounded object-cover mb-4" src="~assets/images/no-image.png" v-else/>
        <h1 class="text-2xl font-display font-bold text-gray-800">{{ ceo.name }}</h1>
        <div class="font-light">{{ ceo.position.name }}</div>
        <div class="mt-2 text-sm font-light">
          {{ ceo.profile | strip | str_limit(300)}}
          <nuxt-link class="block mt-2 text-green-700"
                     :to="`/departments/${ceo.department.slug}/${ceo.slug}`">Read More</nuxt-link>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
import SectionHeader from "../../components/SectionHeader";
import MIcon from "../../components/MIcon";
export default {
  name: "about",
  components: {MIcon, SectionHeader},
  layout: 'secondary',

  data() {
    return {
      abouts:{},
    }
  },
  async asyncData({$axios}) {
    let abouts = (await $axios.get('abouts')).data.data
    return {abouts}
  },
  computed: {
    ceo() {
      return this.$store.state.ceo
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
