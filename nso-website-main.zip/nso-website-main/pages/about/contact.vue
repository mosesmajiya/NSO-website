<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Contact Us</h1>
        <div class="mb-10">Get in touch with us. We're here to help and answer any questions you might have. We look forward to hearing from you!</div>
      </div>
    </div>

    <div class="container mx-auto py-16 px-10 xl:flex">
      <form @submit.prevent="onSubmit" class="xl:w-2/3" v-if="!submitted">
        <div v-if="error" class="text-red-500 py-2">{{ error }}</div>
        <div class="flex">
          <label class="w-1/2 mr-4">
            <input
              class="w-full py-2 px-4 bg-gray-200 border border-transparent focus:outline-none focus:bg-gray-100 rounded focus:border-primary-300 mb-5"
              placeholder="Name*" v-model="form.name" autocomplete="off"/>
          </label>
          <label class="w-1/2">
            <input type="email"
                   v-model="form.email"
                   class="w-full py-2 px-4 bg-gray-200 border border-transparent focus:outline-none focus:bg-gray-100 rounded focus:border-primary-300 mb-5"
                   autocomplete="off" placeholder="Email*"/>
          </label>
        </div>
        <label class="py-5">
          <input
            v-model="form.subject"
            class="w-full px-4 py-2 bg-gray-200 focus:outline-none focus:border-primary-300 focus:bg-gray-100 border border-transparent rounded mb-5"
            placeholder="Subject*"/>
        </label>
        <label>
          <textarea
            v-model="form.message"
            class="w-full bg-gray-200 rounded focus:bg-gray-100 focus:outline-none px-4 py-2 border border-transparent focus:border-primary-300"
            rows="5" placeholder="Message*"></textarea>
        </label>
        <button class="bg-primary-500 w-full lg:w-auto px-5 py-3 rounded text-white mt-5" :class="{'cursor-wait': busy}"
                :disabled="busy">
          <span v-if="busy">Sending...</span>
          <span v-else>Send Message</span>
          <fa-icon :spin="true" icon="circle-notch" type="fas" v-if="busy"/>
        </button>
      </form>
      <div class="subscribed flex mt-8 max-w-4xl py-3 mx-auto justify-center text-3xl rounded-full"
           v-else>
        <svg fill="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
             class="stroke-current text-white inline-block h-12 w-12 mr-8">
          <path
            d="M 12 2 C 6.486 2 2 6.486 2 12 C 2 17.514 6.486 22 12 22 C 17.514 22 22 17.514 22 12 C 22 10.874 21.803984 9.7942031 21.458984 8.7832031 L 19.839844 10.402344 C 19.944844 10.918344 20 11.453 20 12 C 20 16.411 16.411 20 12 20 C 7.589 20 4 16.411 4 12 C 4 7.589 7.589 4 12 4 C 13.633 4 15.151922 4.4938906 16.419922 5.3378906 L 17.851562 3.90625 C 16.203562 2.71225 14.185 2 12 2 z M 21.292969 3.2929688 L 11 13.585938 L 7.7070312 10.292969 L 6.2929688 11.707031 L 11 16.414062 L 22.707031 4.7070312 L 21.292969 3.2929688 z"/>
        </svg>
        <span class="font-display">Thank you for getting in touch!</span>
      </div>
      <div class="flex-1 xl:ml-5 mt-10 xl:mt-0 xl:shadow-none xl:border-0 xl:p-0 shadow-xl border-b-4 border-red-400 rounded-xl p-10">
        <div class="text-gray-600">
          <div class="py-2 flex">
            <m-icon class="mr-4">location_on</m-icon>
            <div>
              <p>{{ $store.state.settings.postal_address }}</p>
              <p>{{ $store.state.settings.physical_address }}</p>
            </div>
          </div>
          <div class="py-2 flex">
            <m-icon class="mr-4">phone</m-icon>
            <div>{{ $store.state.settings.phone }}</div>
          </div>
          <div class="py-2 flex">
            <m-icon class="mr-4">email</m-icon>
            <div>{{ $store.state.settings.email }}</div>
          </div>
        </div>
      </div>

    </div>
    <div>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3846.9780285603742!2d35.32178921537863!3d-15.377676216940998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x18d904b7c29b9235%3A0xa5d7e716afa969c1!2sNational%20Statistics%20Office%20(NSO)%3A%20Headquarters%20and%20Administration!5e0!3m2!1sen!2smw!4v1610881364849!5m2!1sen!2smw"
        width="100%" height="550" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false"
        tabindex="0"></iframe>
    </div>

  </div>
</template>

<script>
import MIcon from "@/components/MIcon";
import FooterSocialLink from "@/components/FooterSocialLink";
import ContactSocialLink from "@/components/ContactSocialLink";
import BrandIcon from "@/components/BrandIcon";
import FaIcon from "@/components/FaIcon";

export default {
  name: "contact",
  components: {FaIcon, BrandIcon, ContactSocialLink, FooterSocialLink, MIcon},
  layout: "secondary",
  head() {
    return {
      title: 'Contact Us - ' + this.$store.state.settings.organization_name
    }
  },
  data() {
    return {
      submitted: false,
      busy: false,
      error: null,
      form: {
        email: '',
        name: '',
        subject: '',
        message: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.busy = true
      this.$axios.post('contact', this.form)
        .then(() => {
          this.submitted = true
          this.busy = false
          this.error = null
        })
        .catch(err => {
          if (err.response.status === 422) this.error = 'Please fill in all fields'
          this.busy = false
        })
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
