<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Gallery</h1>
        <div class="mb-10">Viewing picture album</div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="md:flex md:flex-wrap pb-20 pt-10">
        <div v-if="lightBoxIsActive" class="inset-0 bg-black fixed opacity-75"></div>
        <div v-if="lightBoxIsActive" class="fixed flex inset-0 justify-center items-center p-12 h-full w-full"
             @click="closeLightBox">
          <img :src="lightBoxImage" class="object-contain max-h-full" @click.stop>
        </div>
        <div class="container mx-auto px-10 xl:px-0">
          <div class="md:flex md:flex-wrap pb-20 pt-10">
            <div v-for="photo in photos" class="md:w-1/2 md:odd:pr-5 md:even:pl-5 mb-10 aos-fix" data-aos="zoom-in-up">
              <div class="bg-white h-full">
                <div class="cursor-pointer" @click="showLightBox(photo.url)">
                  <img :alt="photo.caption" :src="photo.url" class="w-full object-cover h-96 object-center">
                </div>
                <div class="py-2 text-gray-600 text-sm">{{ photo.caption }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  </template>
<script>
import LinkButton from "@/components/LinkButton";

export default {
  name: "_slug",
  layout: "secondary",
  components: {LinkButton},
  created() {
    this.fetchData()
  },
  mounted() {
    this.scrollToTop()
  },
  data() {
    return {
      gallery: {},
      photos: {},
      lightBoxIsActive: false,
      lightBoxImage: '',
      namespace: 'pictures'
    }
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    showLightBox(url) {
      this.lightBoxIsActive = true
      this.lightBoxImage = url
    },
    closeLightBox() {
      this.lightBoxIsActive = false
      this.lightBoxImage = ''
    },
    fetchData() {
      this.$axios.get(`${this.namespace}/${this.$route.params.slug}`)
        .then(res => {
          let data = res.data.data
          this.photos = data.photos
          this.gallery = data
        })
    },
  },
  head() {
    return {
      title: 'Galleries - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
