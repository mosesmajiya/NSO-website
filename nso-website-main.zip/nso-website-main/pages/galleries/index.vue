<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Our Galleries</h1>
        <div class="mb-10">Our Pictures and Videos
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div v-if="videos.length" id="videos">
        <h1 class="font-display text-2xl lg:pt-10 font-bold">Video Galleries</h1>
      </div>

      <div class="md:flex md:flex-wrap lg:pb-5 pt-5">
        <div v-for="video in videos" v-bind:key="video.id" class="md:w-1/2 mb-10 md:odd:pr-2 md:even:pl-2 aos-fix"
             data-aos="zoom-in-up">
          <div class="bg-white h-full">
            <div class="">
              <img class="w-full h-84 object-cover" v-bind:src="video.image_url" v-if="video.image_url"/>
              <img class="w-full h-84 object-cover" src="~assets/images/no-image.png" v-else/>
            </div>
            <div class="py-4">
              <h1 class="font-display text-xl font-bold capitalize">{{ video.name }}</h1>
              <nuxt-link :to="`/galleries/videos/${video.slug}`"
                         class="flex items-center inline-block pt-4">
                <span>View Album</span>
                <div class="text-red-400 ml-2">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"></path>
                  </svg>
                </div>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>

      <div v-if="pictures.length" id="pictures">
        <h1 class="font-display text-2xl font-bold">Picture Galleries</h1>
      </div>

      <div class="md:flex md:flex-wrap pb-5 pt-5">
        <div v-for="picture in pictures" v-bind:key="picture.id" class="md:w-1/2 mb-10 md:odd:pr-2 md:even:pl-2 aos-fix"
             data-aos="zoom-in-up">
          <div class="bg-white h-full">
            <div class="">
              <img class="w-full h-84 object-cover" v-bind:src="picture.image_url" v-if="picture.image_url"/>
              <img class="w-full h-84 object-cover" src="~assets/images/no-image.png" v-else/>
            </div>
            <div class="p-8">
              <h1 class="font-display text-2xl font-bold capitalize inline-block">{{ picture.name }}</h1>
              <span class="inline-block bg-primary-600 rounded-full text-white py-1 px-3">{{
                  picture.total_photos
                }}</span>
              <nuxt-link :to="`/galleries/pictures/${picture.slug}`"
                         class="flex items-center inline-block pt-4">
                  <span>View Album</span>
                  <div class="text-red-400 ml-2">
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"></path>
                  </svg>
                </div>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  </template>

<script>
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton},
  layout: 'secondary',
  created() {
    this.$axios.get('videos')
      .then(res => this.videos = res.data.data.data)
    this.$axios.get('pictures')
      .then(res => this.pictures = res.data.data.data)
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.posts.next_page_url)
        .then(res => {
          this.loading = false
          this.videos.data = this.videos.data.concat(res.data.data.data)
          this.videos.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
  },
  data() {
    return {
      videos: {},
      pictures: {},
      loading: false,
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.scrollToTop()
    }
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
