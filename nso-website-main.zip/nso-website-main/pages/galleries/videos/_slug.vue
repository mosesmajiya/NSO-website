<template>
  <div class="font-display">

    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Gallery</h1>
        <div class="mb-10">Viewing video album</div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="md:flex md:flex-wrap pb-20 pt-10">
        <div v-for="video in videos" class="md:w-1/2 md:odd:pr-5 md:even:pl-5 mb-10 aos-fix" data-aos="zoom-in-up">
          <div class="bg-white h-full">
            <iframe :src="`https://www.youtube.com/embed/${video.video_id}`"
                    allow="encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen class="w-full"
                    frameborder="0" height="350"></iframe>
          </div>
        </div>
      </div>
    </div>

  </div>
  </template>
<script>
import LinkButton from "@/components/LinkButton";
import LoaderButton from "../../../components/LoaderButton";

export default {
  name: "_slug",
  layout: 'secondary',
  components: {LoaderButton, LinkButton},
  created() {
    this.fetchData()
  },
  mounted() {
    this.scrollToTop()
  },
  data() {
    return {
      videos: [],
      gallery: {},
      namespace: 'videos'
    }
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.scrollToTop()
    }
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`${this.namespace}/${this.$route.params.slug}`)
        .then(res => {
          let data = res.data.data
          this.videos = data.videos
          this.gallery = data
        })
    },
  },
  head() {
    return {
      title: 'Galleries - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings;
    },
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
