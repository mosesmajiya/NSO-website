<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">FAQ</h1>
        <div class="mb-10">Frequently Asked Questions
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div v-for="category in categories" class="mb-10">
        <div class="font-display text-2xl font-bold mb-3">{{ category.name }}</div>
        <faq-accordion v-for="(faq, index) in category.questions" :key="index" :faq="faq" class="py-2"/>
      </div>
    </div>

  </div>
  </template>

<script>
import MIcon from "@/components/MIcon";
import LoaderButton from "@/components/LoaderButton";
import Fade from "~/components/Fade";
import Accordion from "~/components/Accordion";
import FaqAccordion from "../../components/FaqAccordion";

export default {
  name: "index",
  components: {FaqAccordion, Accordion, Fade, LoaderButton, MIcon},
  layout: 'secondary',
  mounted() {
    this.scrollToTop()
    this.getAll()
  },
  data() {
    return {
      categories: [],
    }
  },
  methods: {
    collapseOthers(event) {

      let answers = Array.from(document.getElementsByClassName('answer'))
      answers
        .filter(answer => !answer.classList.contains('hidden'))
        .forEach(answer => answer.classList.add('hidden'))

      // let answer = Array.from(event.target.parentNode.getElementsByClassName('answer')).shift()
      // if (answer.classList.contains('hidden')) answer.classList.remove('hidden')
    },

    expand(event) {
      // if (!process.browser) return;
      // let answers = Array.from(document.getElementsByClassName('answer'))
      //
      // answers
      //   .filter(answer => !answer.classList.contains('hidden'))
      //   .forEach(answer => answer.classList.add('hidden'))
      //
      // let answer = Array.from(event.target.parentNode.getElementsByClassName('answer')).shift()
      // if (answer.classList.contains('hidden')) answer.classList.remove('hidden')
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    getAll() {
      this.$axios.get('faq').then(res => this.categories = res.data.data)
    },
  }
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
