<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">News</h1>
        <div class="mb-10">Get in touch with us by following news happening within and around us.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <div class="lg:flex">
        <section class="lg:w-2/3">
          <article class="pb-5 group aos-fix" data-aos="zoom-in-up">
            <div class="mb-4">
              <h1 class="font-display text-xl lg:text-3xl font-bold leading-none">{{ post.title }}</h1>
              <div class="pt-2 pb-4 text-xs text-gray-500">
                <span v-if="post.author">{{ post.author }} &middot; </span>
                {{ post.published_at | from_now }}
              </div>
            </div>
            <div class="rounded-lg overflow-hidden">
              <img :src="post.image_url" v-if="hasMedia(post)" class="w-full object-cover">
              <img src="~assets/images/no-image.png" v-else class="w-full object-cover">
            </div>
            <div class="mt-4 px-2" v-if="hasMedia(post)">
              <div class="w-8 border-t-2 border-red-500 my-2"></div>
              <div class="text-gray-600 italic">{{ post.caption }}</div>
            </div>
            <div class="text-gray-600 pt-8 content" v-html="post.content"></div>

            <div class="flex pt-12 text-sm font-bold font-display items-center uppercase" v-if="hasAttachments(post)">
              <h1>Downloads</h1>
              <div class="border-b ml-2 text-black flex-1"></div>
            </div>
            <div v-if="hasAttachments(post)" class="flex flex-wrap pt-8">
              <div v-for="attachment in post.attachments" v-bind:key="attachment.id" class="w-full md:w-1/2">
                <a :href="attachment.download" class="flex justify-between mr-4 mb-4 shadow-xs rounded overflow-hidden">
                  <div class="text-gray-500 py-2 px-1 flex-shrink bg-gray-100">
                    <fa-icon icon="file-pdf" type="fas" size="3x"/>
                  </div>
                  <div class="flex-1 bg-gray-200 py-2 px-3">
                    <p class="text-gray-700">{{ attachment.caption }}</p>
                    <span class="block text-xs text-gray-600">{{ attachment.size }}</span>
                  </div>
                </a>
              </div>
            </div>
          </article>
          <div class="flex justify-center">
            <loader-button :busy="loading" @click="loadMore" v-if="posts.next_page_url">Load more news</loader-button>
          </div>
        </section>
        <section class="mt-10 lg:mt-0 lg:w-1/3 lg:ml-12 text-sm">
          <popular-news v-bind:posts="popular"/>
          <recent-news v-bind:posts="recent"/>
        </section>
      </div>
    </div>

    <div class="bg-gray-100 lg:px-20 hidden md:block">

      <h1 class="text-2xl font-bold pl-5 pt-10 font-display">Popular News</h1>
      <div class="md:flex py-10 flex-wrap">
        <nuxt-link :to="`/news/${article.slug}`" class="border-transparent border-b-4 hover:border-red-400 pt-8 px-5 lg:px-0 lg:pt-0 lg:mx-5 md:w-1/2 lg:flex-1 lg:bg-white lg:hover:shadow-xl rounded-lg overflow-hidden group"
                   v-for="article in posts" v-bind:key="article.id">
          <article class="text-gray-600">
            <div class="mb-6">
              <img :src="article.image_url" class="h-56 object-cover w-full" v-if="article.image_url"/>
              <img src="~/assets/images/no-image.png" class="h-56 object-cover w-full" v-else/>
            </div>
            <div class="px-8 lg:pb-5 flex-col h-full">
              <h1 class="font-display font-semibold text-xl text-gray-800">{{ article.title | str_limit(44) }}</h1>
              <div class="text-xs mt-1">
                {{ article.published_at | from_now }}
              </div>
            </div>
          </article>
        </nuxt-link>

      </div>
    </div>

  </div>
</template>

<script>
import FaIcon from "../../components/FaIcon";
import RecentNews from "../../components/news/RecentNews";
import PopularNews from "../../components/news/PopularNews";
import LoaderButton from "../../components/LoaderButton";

export default {
  name: "_slug",
  components: {LoaderButton, PopularNews, RecentNews, FaIcon},
  layout: 'secondary',
  async asyncData({$axios, params}) {
    let post = (await $axios.get(`news/${params.slug}`)).data.data
    let popular = (await $axios.get('news/popular')).data.data

    return {post, popular}
  },
  mounted() {
    this.scrollToTop()
  },
  created() {
    this.$axios.get('news/recent')
      .then(res => this.recent = res.data.data)
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.fetchRelated()
      this.scrollToTop()
    }
  },
  methods: {
    hasMedia(post) {
      return post.media && post.media.length
    },
    hasAttachments(post) {
      return post.attachments && post.attachments.length
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`news/${this.$route.params.slug}`)
        .then(res => this.post = res.data.data)
    },
    fetchRelated() {
      this.$axios.get('news/popular')
        .then(res => this.popular = res.data.data)
    }
  },
  head() {
    return {
      title: this.pageTitle + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.pageTitle},
        {hid: 'og:title', name: 'og:title', content: this.pageTitle + this.settings.organization_name},
        {hid: 'og:description', name: 'og:description', content: this.pageTitle},
        {hid: 'og:image', name: 'og:image', content: this.post.image_url},
        {hid: 'og:url', name: 'og:url', content: this.$route.fullPath},
        {hid: 'twitter:card', name: 'twitter:card', content: 'summary_large_image'},
      ]
    }
  },
  computed: {
    pageTitle() {
      return this.post.title ? this.post.title + ' - News - ' : ''
    },
    metaDescription() {
      return ''
    },
    settings() {
      return this.$store.state.settings;
    },
    posts() {
      return this.popular.slice(0, 3)
    }
  },
  data() {
    return {
      post: {},
      popular: [],
      recent: [],
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
