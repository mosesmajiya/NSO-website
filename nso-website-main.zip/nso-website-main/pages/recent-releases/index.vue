<template>
  <div class="font-display">
    <div class="p-10 pt-40 bg-gray-100 border-transparent border-b border-gray-200 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Recent Releases</h1>
        <div class="mb-10">
          Don't miss a thing. Here is the list of our recently published reports.
          Remember to <nuxt-link to="subscribe" class="font-semibold text-primary-150 hover:text-primary-300">subscribe</nuxt-link> to get notified
          on all new reports as they are published.
        </div>
      </div>
    </div>

    <div class="container mx-auto px-8">
      <loader :show="apiBusy" class="text-center"/>
      <div class="py-10 flex flex-wrap -mr-4">
        <nuxt-link v-for="report in reports"
                   v-if="reports.length" :key="report.id"
                   :to="`/publications/${report.super_categories[0].slug}/${report.slug}`"
                   class="md:w-1/2 lg:w-1/3 mb-5 group cursor-pointer aos-fix" data-aos="zoom-in-up">
          <div
            class="h-full rounded-lg p-8 shadow bg-white border-transparent border-b-4 hover:border-red-400 mr-4 flex flex-col justify-between">
            <div class="">
              <div class="mb-3 text-xl font-bold group-hover:text-gray-700">{{ report.title | str_limit(55) }}</div>
              <div class="mb-3 text-gray-700 text-sm">{{ report.abstract | str_limit(130) }}</div>
            </div>

            <div class="flex justify-between items-center text-xs text-gray-500">
              <div>{{ report.published_at | from_now }}</div>
              <div class="group-hover:text-green-400">
                <div class="flex items-center">
                  <span class="p-2 text-xs">{{ report.filesize }}</span>
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </nuxt-link>
      </div>
      <loader-button :busy="loading" @click="loadMore" class="ml-5" v-if="reports.next_page_url">Load more</loader-button>
    </div>

  </div>
</template>

<script>
import MIcon from "../../components/MIcon";
import LoaderButton from "../../components/LoaderButton";
import Loader from "../../components/Loader";

export default {
  name: "index",
  components: {Loader, LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.getAll()
  },
  methods: {
    loadMore() {
      this.loading = true
      this.$axios.get(this.reports.next_page_url)
        .then(res => {
          this.loading = false
          this.reports.data = this.reports.data.concat(res.data.data.data)
          this.reports.next_page_url = res.data.data.next_page_url
        })
    },
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    getAll() {
      this.apiBusy = true
      this.$axios.get('reports/recent-full')
        .then(res => {
          this.reports = res.data.data
          this.apiBusy = false
        })
      }
  },
  data() {
    return {
      reports: {},
      apiBusy: true,
      loading: false,
    }
  },
  mounted() {
    this.scrollToTop()
  },
  watch: {
    '$route'(to, from) {
      this.scrollToTop()
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
