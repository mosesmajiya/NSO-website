<template>
  <div class="font-display">
    <publication-banner :slug="$route.params.category"/>
    <div class="container mx-auto px-4">
      <loader :show="apiBusy" class="pt-32"/>
      <div class="pt-5 pb-10">
        <div v-if="publication.title" class="rounded-lg p-6 bg-white">
          <div class="mb-3 font-display text-xl font-bold group-hover:text-gray-700">{{ publication.title }}</div>
          <div class="mb-5 text-gray-600 text-sm font-display">by {{ publication.source }}</div>
          <div class="text-gray-700 border-gray-200 pb-5">
            <div v-html="publication.abstract"></div>
            <div v-if="publication.indicators && publication.indicators.length"
                 class="bg-gray-100 mt-8 text-gray-600 rounded">
              <div class="text-base text-gray-700 font-bold bg-gray-200 py-3 px-8 m-0 rounded-t w-full">
                Research Indicators
              </div>
              <div class="py-6 px-8">
                <ul class="mt-3">
                  <li v-for="(i, index) in publication.indicators" :key="index" class="mb-3 flex md:items-center">
                    <svg class="w-4 h-4 mr-4 hidden md:block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    {{ i.indicator }}
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div v-if="publication.media && publication.media.length">
            <div class="flex flex-wrap text-gray-500 mt-2">
              <div v-for="(attachment, j) in publication.attachments" :key="j" v-if="publication.attachments.length">
                <a :href="attachment.url" :alt="attachment.name" target="_blank" class="cursor-pointer group">
                  <div
                    class="flex items-center bg-gray-200 rounded overflow-hidden mb-4 mr-3 group-hover:bg-primary-500 group-hover:text-white">
                    <div class="px-4 py-3 bg-green-400 group-hover:bg-primary-600 text-white">
                      <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                           xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"></path>
                      </svg>
                    </div>
                    <div class="px-3 group-hover:text-gray-200 font-menu text-gray-700 text-sm">
                      <span class="hidden md:block">{{ attachment.name | str_limit(50) }}</span>
                      <span class="md:hidden">{{ attachment.name | str_limit(40) }}</span>
                      <div class="group-hover:text-gray-200 uppercase text-xs">{{ attachment.filesize }}</div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
            <div class="font-light text-sm mt-5 text-gray-600">Published on {{ publication.published_at | date_format }}</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import PublicationBanner from "../../../components/PublicationBanner";
import Loader from "../../../components/Loader";

export default {
  name: "reports",
  components: {Loader, PublicationBanner},
  layout: 'secondary',
  created() {
    if (!process.browser) return;
    this.getAll()
  },
  data() {
    return {
      publication: {},
      apiBusy: true,
    }
  },
  methods: {
    getAll() {
      this.apiBusy = true
      this.$axios.get(`publications/${this.$route.params.slug}`)
        .then(res => {
          this.publication = res.data.publication
          this.apiBusy = false
        })
    }
  }
}
</script>

