<template>
  <div class="font-display">
    <publication-banner :slug="$route.params.category" @loadeddata="result = $event"/>
    <div class="container mx-auto px-8">
      <loader :show="apiBusy"/>
      <div class="py-10 flex flex-wrap -mr-4">
        <nuxt-link v-for="publication in publications"
                   v-if="publications.length" :key="publication.id"
                   :to="`/publications/${$route.params.category}/${publication.slug}`"
                   class="md:w-1/2 lg:w-1/3 w-full mb-5 group cursor-pointer aos-fix" data-aos="zoom-in-up">
          <div
            class="h-full rounded-lg p-8 shadow bg-white border-transparent border-b-4 hover:border-red-400 mr-4 flex flex-col justify-between">
            <div class="">
              <div class="mb-3 text-xl font-bold group-hover:text-gray-700">{{ publication.title | str_limit(55) }}</div>
              <div class="mb-3 text-gray-700 text-sm">{{ publication.abstract | str_limit(130) }}</div>
            </div>
            <div class="flex justify-between items-center text-xs text-gray-500">
              <div>{{ publication.published_at | date_format }}</div>
              <div class="group-hover:text-green-400">
                <div class="flex items-center">
                  <span class="p-2 text-xs">{{ publication.filesize }}</span>
                  <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                       xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </nuxt-link>
      </div>
    </div>
  </div>
</template>

<script>
import PublicationBanner from "../../../../components/PublicationBanner";
import Loader from "../../../../components/Loader";

export default {
  name: "_filter",
  components: {Loader, PublicationBanner},
  layout: 'secondary',
  created() {
    if (!process.browser) return;
    this.getAll()
  },
  data() {
    return {
      result: [],
      apiBusy: true,
    }
  },
  methods: {
    getAll() {
      this.apiBusy = true
      this.$axios.get(`publications/category/${this.$route.params.filter}`)
        .then(res => {
          this.result = res.data.reports
          this.apiBusy = false
        })
    }
  },
  computed: {
    publications(){
      return this.result.map(i => {
        return { ...i, ...i.abstract ? {} : { abstract: i.description } }
      })
    },
    categories(){
      return this.result.map(i => {
        return i.category
      })
    }
  }
}
</script>
