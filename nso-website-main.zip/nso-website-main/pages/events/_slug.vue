<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner" :style="{'background-image': 'url(' + image + ')'}" v-if="event">
      <div class="container mx-auto px-2 xl:px-12">
        <div class="">
          <h3 class="text-lg">Event</h3>
          <h1 class="font-display font-semibold text-3xl pb-2 flex items-center pb-6 leading-tight">
            {{ event.name }}
          </h1>
          <p class="pb-5">
            {{ event.start_date | date_format }}, {{ event.start_date | date('hh:mm a') }}
            <span v-if="event.end_date"> - <span v-if="differentDay">{{
                event.end_date | date_format
              }},</span>  {{ event.end_date | date('hh:mm a') }}</span></p>
          <p class="pb-4 font-display text-2xl">{{ event.venue }}</p>
          <p class="pt-2 flex">
            <button class="px-3 py-1 uppercase bg-primary-500 rounded text-xs text-white flex items-center"
                    v-if="event.type">
              {{ event.type.name }}
            </button>
            <button :class="event.past ? 'flex' : 'hidden'"
                    class="px-3 py-1 ml-2 uppercase bg-gray-500 rounded text-xs text-white items-center">
              Past Event
            </button>
            <button :class="event.in_progress ? 'flex' : 'hidden'"
                    class="px-3 py-1 ml-2 uppercase bg-red-500 rounded text-xs text-white items-center">
              In Progress
            </button>
            <a :href="event.link" v-if="!event.past">
              <button class="px-3 py-1 ml-2 flex uppercase bg-primary-500 rounded text-xs text-white items-center"
                      v-if="event.link">
                <m-icon class="text-sm mr-2">public</m-icon>
                <span>Join Online Now</span>
              </button>
            </a>
          </p>
          <div class="flex flex-wrap">
          </div>
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10">
      <article class="content text-gray-600" v-html="event.content"></article>
    </div>
    <div class="bg-gray-100 lg:px-20 hidden md:block">

      <h1 class="text-2xl font-bold pl-5 pt-10 font-display">Popular Events</h1>
      <div class="md:flex py-10 flex-wrap">
        <nuxt-link :to="`/events/${event.slug}`" class="group pt-8 px-5 lg:px-0 lg:pt-0 lg:mx-5 md:w-1/2 lg:flex-1 lg:bg-white lg:hover:shadow-xl rounded-lg overflow-hidden group"
                   v-for="event in events" v-bind:key="event.id">
          <article class="text-gray-600 border-b-4 group-hover:border-red-400 border-transparent">
            <div class="mb-6 relative">
              <img :src="event.image" class="h-56 object-top object-cover w-full" v-if="event.image"/>
              <img src="~/assets/images/no-image.png" class="h-56 object-cover w-full" v-else/>
            </div>
            <div class="px-8 lg:pb-5 flex-col h-full">
              <h1 class="font-display font-semibold text-xl text-gray-800">{{ event.name }}</h1>
              <div class="text-xs mt-1">
                {{ event.start_date | from_now }}
              </div>
            </div>
          </article>
        </nuxt-link>

      </div>
    </div>

  </div>
</template>

<script>
import LinkButton from "@/components/LinkButton";
import moment from "moment";
import MIcon from "@/components/MIcon";

export default {
  name: "_slug",
  components: {MIcon, LinkButton},
  layout: 'secondary',
  mounted() {
    this.scrollToTop()
  },
  data() {
    return {
      event: {},
      events: [],
      namespace: 'events'
    }
  },
  watch: {
    '$route'(to, from) {
      this.fetchData()
      this.fetchRelated()
      this.scrollToTop()
    }
  },
  async fetch() {
    this.event = (await this.$axios.get(`${this.namespace}/${this.$route.params.slug}`)).data.data
    this.events = (await this.$axios.get(`${this.namespace}/popular`)).data.data.data
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    fetchData() {
      this.$axios.get(`${this.namespace}/${this.$route.params.slug}`)
        .then(res => this.event = res.data.data)
    },
    fetchRelated() {
      this.$axios.get(`${this.namespace}/popular`)
        .then(res => this.events = res.data.data.data)
    }
  },
  head() {
    return {
      title: this.event.name + ' - Events - ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.pageTitle},
        {hid: 'og:title', name: 'og:title', content: this.pageTitle + this.settings.organization_name},
        {hid: 'og:description', name: 'og:description', content: this.pageTitle},
        {hid: 'og:image', name: 'og:image', content: this.event.image},
        {hid: 'og:url', name: 'og:url', content: this.$route.fullPath},
        {hid: 'twitter:card', name: 'twitter:card', content: 'summary_large_image'},
      ]
    }
  },
  computed: {
    pageTitle() {
      return this.event.name ? this.event.name + ' - Events - ' : ''
    },
    settings() {
      return this.$store.state.settings;
    },
    image() {
      return this.event && this.event.image ? this.event.image : '~assets/images/projects-banner.jpg'
    },
    differentDay() {
      return !moment(this.event.start_date).isSame(moment(this.event.end_date), 'day');
    }
  }
}
</script>
<style scoped>
.banner {
  background-color: rgba(0, 0, 0, 0.5);
  background-blend-mode: multiply;
  @apply bg-center bg-cover;
}
</style>
