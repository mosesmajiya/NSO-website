<template>
  <div class="font-display">
    <div class="p-10 pt-40 text-white banner">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl pb-2 flex items-center">Events</h1>
        <div class="mb-10">Follow our events and mark a day to attend one as they come.
        </div>
      </div>
    </div>

    <div class="container mx-auto p-10 pb-5">
      <div class="md:flex md:flex-wrap xl:py-10" v-if="events.data && events.data.length">
        <div v-for="event in events.data" v-bind:key="event.id"
             class="group md:w-1/2 mb-10 md:odd:pr-4 md:even:pl-4 xl:px-0 aos-fix" data-aos="zoom-in-up">
          <div class="bg-white h-full shadow-xl border-b-4 border-red-400 group-hover:border-primary-400 rounded-lg overflow-hidden">
            <div class="">
              <img class="w-full h-84 object-cover" v-bind:src="event.image" v-if="event.image"/>
              <img class="w-full h-84 object-cover" src="~assets/images/no-image.png" v-else/>
            </div>
            <div class="p-8">
              <p class="text-xs text-gray-500">
                {{ event.start_date | date_format }}
                <span v-if="event.end_date">- {{ event.end_date | date_format }}</span>
              </p>
              <h1 class="font-display text-2xl font-bold capitalize">{{ event.name }}</h1>
              <nuxt-link :to="`/events/${event.slug}`"
                         class="text-primary-500 text-sm flex items-center inline-block pt-4">
                <span>Read more</span>
                <m-icon class="ml-2">arrow_right_alt</m-icon>
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
      <div class="flex justify-center">
        <loader-button :busy="loading" @click="loadMore" v-if="events.next_page_url">Load more</loader-button>
      </div>
    </div>


  </div>
</template>

<script>
import MIcon from "@/components/MIcon";
import LoaderButton from "@/components/LoaderButton";

export default {
  name: "index",
  components: {LoaderButton, MIcon},
  layout: 'secondary',
  created() {
    this.getAll()
  },
  data() {
    return {
      events: [],
      loading: false,
      filters: [],
    }
  },
  methods: {
    getAll() {
      this.$axios.get('events').then(res => this.events = res.data.data)
    },
    loadMore() {
      this.loading = true
      this.$axios.get(this.events.next_page_url)
        .then(res => {
          this.loading = false
          this.events.data = this.events.data.concat(res.data.data.data)
          this.events.next_page_url = res.data.data.next_page_url
        })
    }
  }
}
</script>
<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
