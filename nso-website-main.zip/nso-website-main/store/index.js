export const state = () => ({
  settings: {},
  ceo: {},
  links: [],
  popularArticles: [],
  publications: []
})

export const actions = {
  async nuxtServerInit({state, commit}, {$axios}) {
    let settings = (await $axios.get('/settings')).data.data;
    let popularArticles = (await $axios.get('articles/popular')).data.data;
    let links = (await $axios.get('links')).data.data;
    let ceo = (await $axios.get('about/ceo')).data.data;
    let publications = (await $axios.get('publications/super-categories')).data.categories;

    commit('saveSettings', settings)
    commit('saveArticles', popularArticles)
    commit('saveLinks', links)
    commit('saveCeo', ceo)
    commit('savePublications', publications)
  },

  async fetchSettings({commit}) {
    let settings = (await this.$axios.get('settings')).data.data;
    let popularArticles = (await this.$axios.get('articles/popular')).data.data
    let links = (await this.$axios.get('links')).data.data
    let ceo = (await this.$axios.get('about/ceo')).data.data
    let publications = (await this.$axios.get('publications/super-categories')).data.categories

    commit('saveSettings', settings)
    commit('saveArticles', popularArticles)
    commit('saveLinks', links)
    commit('saveCeo', ceo)
    commit('savePublications', publications)
  }
}

export const mutations = {
  saveSettings(state, settings) {
    state.settings = settings
  },
  saveLinks(state, links) {
    state.links = links
  },
  saveArticles(state, articles) {
    state.popularArticles = articles
  },
  saveCeo(state, ceo) {
    state.ceo = ceo
  },
  savePublications(state, publications) {
    state.publications = publications
  }
}


