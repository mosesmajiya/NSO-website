/*
** TailwindCSS Configuration File
**
** Docs: https://tailwindcss.com/docs/configuration
** Default: https://github.com/tailwindcss/tailwindcss/blob/master/stubs/defaultConfig.stub.js
*/
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Rubik', 'Sans-serif'],
        'menu': ['Jost', 'Sans-serif'],
        'display': ['Quicksand', 'Oswald']
      },
      spacing: {
        '72': '18rem',
        '84': '21rem',
        '96': '24rem',
        '108': '27rem',
        '120': '30rem',
        '132': '33rem',
        '144': '36rem',
        '156': '39rem',
        '168': '42rem',
        '180': '45rem',
        '192': '48rem',
        '204': '51rem'
      },
      colors: {
        primary: {
          900: 'hsl(152,45%,04%)',
          800: 'hsl(152,45%,08%)',
          700: 'hsl(152,45%,18%)',
          600: 'hsl(152,45%,28%)',
          500: 'hsl(152,45%,38%)',
          400: 'hsl(152,45%,48%)',
          300: 'hsl(152,45%,58%)',
          200: 'hsl(152,45%,68%)',
          150: 'hsl(152,45%,73%)',
          100: 'hsl(152,45%,78%)'
        },
        secondary: {
          900: 'hsl(358,84%,01%)',
          800: 'hsl(358,84%,07%)',
          700: 'hsl(358,84%,13%)',
          600: 'hsl(358,84%,23%)',
          500: 'hsl(358,84%,33%)',
          400: 'hsl(358,84%,43%)',
          300: 'hsl(358,84%,53%)',
          200: 'hsl(358,84%,63%)',
          100: 'hsl(358,84%,73%)'
        }
      },
      backgroundImage: theme => ({
        'wave': "url('~assets/images/nav-wave-main.svg')",
        'wave-line': "url('~assets/images/nav-wave-line.svg')",
        'home': "url('~assets/images/home-bg.png')",
        'about': "url('~assets/images/bg-about.jpg')",
        'news': "url('~assets/images/bg-news.jpg')",
        'events': "url('~assets/images/bg-event.jpg')",
        'vacancies': "url('~assets/images/bg-vacancies.jpg')",
      })
    }
  },
  variants: {
    margin: ['responsive', 'hover', 'focus', 'last', 'odd', 'even', 'group-hover'],
    display: ['responsive', 'odd'],
    padding: ['responsive', 'odd', 'even', 'group-hover'],
    textColor: ['responsive', 'hover', 'focus', 'group-hover'],
    boxShadow: ['responsive', 'hover', 'focus', 'odd', 'even'],
    borderWidth: ['responsive', 'even', 'odd', 'hover'],
    borderColor: ['responsive', 'even', 'odd', 'hover', 'group-hover'],
    backgroundColor: ['responsive', 'group-hover', 'hover', 'odd', 'even'],
  },
  plugins: [],
  purge: false,
  future: {
    removeDeprecatedGapUtilities: true,
    purgeLayersByDefault: true,
  },
}
