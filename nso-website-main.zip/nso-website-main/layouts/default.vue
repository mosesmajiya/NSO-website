<template>
  <div class="font-sans antialiased text-gray-800">
    <Nuxt />
    <master-footer />
  </div>
</template>


<script>
import MasterFooter from "../components/MasterFooter";

export default {
  components: {MasterFooter}
}
</script>

