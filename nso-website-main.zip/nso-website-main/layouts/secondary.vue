<template>
  <div class="font-sans antialiased text-gray-800">
    <navbar/>
    <div class="">
      <Nuxt/>
    </div>
    <master-footer/>
  </div>
</template>

<script>
import HomeFooter from "../components/SiteFooter";
import Navbar from "../components/navbar";
import MasterFooter from "../components/MasterFooter";

export default {
  name: "secondary",
  components: {MasterFooter, Navbar, HomeFooter}
}
</script>

<style scoped>
.bg-image-circles {
  @apply bg-home;
  background-repeat: no-repeat;
}
</style>
