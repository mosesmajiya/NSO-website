<template>
  <div class="">
    <div class="p-10 pt-40 banner bg-green-700 border-transparent border-b border-gray-200">
      <div class="container mx-auto px-2 xl:px-12">
        <h1 class="font-display font-semibold text-3xl text-white pb-2">Oops!</h1>
        <div class="mb-10 text-white">
          The page you are looking for is not available!
        </div>
      </div>
    </div>
    <div class="container mx-auto px-10 my-10 flex-row">
      <div class="mx-auto">
        <img src="~assets/images/404.png" class="w-96 py-20 mx-auto">
      </div>
      <div class="text-center py-10">
        <nuxt-link to="/about" class="rounded px-5 mb-5 bg-green-600 py-2 mx-4 uppercase border border-green-600 text-white font-menu text-sm
            hover:border-red-600 hover:bg-red-600 hover:text-gray-200 block mb-2 sm:inline">About Us
        </nuxt-link>
        <nuxt-link to="/news" class="rounded px-5 mb-5 bg-green-600 py-2 mx-4 uppercase border border-green-600 text-white font-menu text-sm
            hover:border-red-600 hover:bg-red-600 hover:text-gray-200 block mb-2 sm:inline">News
        </nuxt-link>
        <nuxt-link to="/events" class="rounded px-5 mb-5 bg-green-600 py-2 mx-4 uppercase border border-green-600 text-white font-menu text-sm
            hover:border-red-600 hover:bg-red-600 hover:text-gray-200 block mb-2 sm:inline">Events
        </nuxt-link>
        <nuxt-link to="/vacancies" class="rounded px-5 mb-5 bg-green-600 py-2 mx-4 uppercase border border-green-600 text-white font-menu text-sm
            hover:border-red-600 hover:bg-red-600 hover:text-gray-200 block mb-2 sm:inline">Vacancies
        </nuxt-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "error",
  layout: 'secondary',
}
</script>

<style scoped>
.banner {
  background: url("~assets/images/banner.jpg") rgba(0, 0, 0, 0.2);
  background-blend-mode: multiply;
  @apply bg-cover
}
</style>
