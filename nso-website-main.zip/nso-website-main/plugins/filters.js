import Vue from 'vue';
import moment from 'moment'
import numeral from 'numeral'

Vue.filter('str_limit', function (value, limit, delimiter = '...') {

  if (!value) return '';

  value = value.toString();

  if (value.length <= limit) return value;

  return value.substr(0, limit) + delimiter;
})

Vue.filter('from_now', function (value) {
  return moment(value).fromNow()
})

Vue.filter('date', function (value, format) {
  return moment(value).format(format)
})

Vue.filter('date_format', function (value) {
  return moment(value).format('Do MMMM YYYY')
})

Vue.filter('numeral', function (value, format = '0,0') {
  return numeral(value).format(format)
})

Vue.filter('lowercase', value => value.toString().toLowerCase())

Vue.filter('strip', function (string) {
  return string.toString().replace(/<\/?[^>]+>/ig, " ").replace('&nbsp;', '');
})
