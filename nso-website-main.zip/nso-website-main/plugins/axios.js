export default function ({$axios, redirect}) {

  $axios.onError(error => {
    if (error.response) {
      if (error.response.status === 401) redirect('/login')
    }
  })

  $axios.onRequest(config => {
    if (process.browser && localStorage.getItem('token'))
      config.headers['Authorization'] = 'Bearer ' + localStorage.getItem('token')
  })
}
