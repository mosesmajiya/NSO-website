<?php

return [
    'optional' => env('OPTIONAL_MODULES', '')
];
