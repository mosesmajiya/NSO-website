# CMS
* [x] Adding newsletter release is failing to save
* [x] Adding media to Public Downloads is not working
* [x] Deleting a newspaper release deletes FAQs - it jumps from one section to the other
* [x] Editing Event should not make URL a required field - should be optional as it in on create
* [x] Photo Galleries - when you delete a gallery, it brings a breaking page (as if the deletion has failed)

# Website
* [x] Menu breaking on caret click
