<?php

use App\Models\User;
use Carbon\Carbon;

if (!function_exists('generate_number_code')) {
    function generate_number_code(int $length = 6): string
    {
        $chars = '0123456789';

        $charLength = strlen($chars);
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[rand(0, $charLength - 1)];
        }
        return $code;
    }
}

if (!function_exists('carbonise')) {
    function carbonise(string $datetime = null): Carbon
    {
        return Carbon::parse($datetime);
    }
}

if (!function_exists('generate_key')) {
    function generate_key(int $length = 10, bool $numeric = false): string
    {
        $characters = $numeric ? '0123456789' : '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}
if (!function_exists('user')) {
    function user(): User
    {
        return auth()->user();
    }
}

if (!function_exists('permute')){
    function permute($arr, $temp_string, &$collect) {
        if ($temp_string != "")
            $collect []= $temp_string;

        for ($i=0, $iMax = sizeof($arr); $i < $iMax; $i++) {
            $arrayCopy = $arr;
            $elem = array_splice($arrayCopy, $i, 1); // removes and returns the i'th element
            if (sizeof($arrayCopy) > 0) {
                permute($arrayCopy, $temp_string ." " . $elem[0], $collect);
            } else {
                $collect []= $temp_string. " " . $elem[0];
            }
        }
    }
}

