<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;

class SubscriptionPublished extends Mailable
{
    use Queueable, SerializesModels;

    public Collection $stories;
    public string $unsubscribe_link;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Collection $stories, string $unsubscribe_link)
    {
        $this->stories = $stories;
        $this->unsubscribe_link = $unsubscribe_link;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build(): SubscriptionPublished
    {
        return $this->markdown('emails.subscriptions.published')->subject('New Publication');
    }
}
