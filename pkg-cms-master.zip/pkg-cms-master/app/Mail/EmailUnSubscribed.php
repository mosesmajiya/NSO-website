<?php

namespace App\Mail;

use App\Models\Subscriber;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class EmailUnSubscribed extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @var Subscriber
     */
    public $subscriber;

    /**
     * Create a new message instance.
     *
     * @param Subscriber $subscriber
     */
    public function __construct(Subscriber $subscriber)
    {
        $this->subscriber = $subscriber;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->to($this->subscriber->email)
            ->markdown('emails.email-unsubscribed')
            ->subject('Successfully updated subscription');
    }
}
