<?php

namespace App\Mail;

use App\Http\Requests\UserFeedbackRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UserFeedback extends Mailable
{
    use Queueable, SerializesModels;

    public $sender_name;
    public $sender_email;
    public $title;
    public $inquiry;

    /**
     * Create a new message instance.
     *
     * @param UserFeedbackRequest $request
     */
    public function __construct(UserFeedbackRequest $request)
    {
        $this->sender_name = $request->{'name'};
        $this->sender_email = $request->{'email'};
        $this->title = $request->{'subject'};
        $this->inquiry = $request->{'message'};
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->to(config('app.admin_email'))
            ->from($this->sender_email)
            ->markdown('emails.feedback')
            ->subject('Online Inquiry: '.$this->title);
    }
}
