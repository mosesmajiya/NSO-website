<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ClearOldTrafficDataService
{
    public function service() : void
    {
        DB::table('traffic')->where('created_at','<',Carbon::now()->subMonths(6))->delete();
        DB::table('traffic')->whereNull('user_agent')->delete();
    }
}
