<?php


namespace App\Services\Subscriptions;


use Carbon\Carbon;

class Story
{
    private string $title;
    private string $content;
    private string $url;
    private ?Carbon $published_at;

    public function __construct(string $title, string $url, string $content, Carbon $published_at = null)
    {
        $this->title = $title;
        $this->content = $content;
        $this->url = $url;
        $this->published_at = $published_at;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function getContent(): string
    {
        return substr(strip_tags($this->content),0,200) . '...';
    }

    public function getUrl(): string
    {
        return $this->url;
    }

    /**
     * @return Carbon
     */
    public function getPublishedAt(): Carbon
    {
        return $this->published_at;
    }
}
