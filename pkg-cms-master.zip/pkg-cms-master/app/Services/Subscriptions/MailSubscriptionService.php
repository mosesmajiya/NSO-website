<?php


namespace App\Services\Subscriptions;


use App\Models\Subscriber;
use App\Services\BaseScript;

class MailSubscriptionService extends BaseScript
{
    protected function process(): void
    {
        Subscriber::whereHas('alertQueueItems')->with('alertQueueItems')->get()
            ->each(function (Subscriber $subscriber) {
                $subscriber->sendStories();
            });
    }
}
