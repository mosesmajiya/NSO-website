<?php


namespace App\Services\Subscriptions;


interface Subscribable
{
    public function getStory(): Story;

    public function getFullUrl(): string;
}
