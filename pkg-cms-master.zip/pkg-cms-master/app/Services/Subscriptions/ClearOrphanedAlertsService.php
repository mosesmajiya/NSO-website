<?php


namespace App\Services\Subscriptions;


use App\Models\AlertQueueItem;
use App\Models\Event;
use App\Models\NewsletterRelease;
use App\Models\Post;
use App\Models\Project;
use App\Models\Report;
use App\Models\Vacancy;
use App\Services\BaseScript;

class ClearOrphanedAlertsService extends BaseScript
{

    public function process(): void
    {
        $alerts = AlertQueueItem::whereNull('sent_at')
            ->whereHasMorph('subscribable',
                [Post::class, Event::class, NewsletterRelease::class, Vacancy::class, Project::class, Report::class])
            ->get()->map->{'id'}->toArray();
       AlertQueueItem::whereNotIn('id', $alerts)->whereNull('sent_at')->delete();
    }
}
