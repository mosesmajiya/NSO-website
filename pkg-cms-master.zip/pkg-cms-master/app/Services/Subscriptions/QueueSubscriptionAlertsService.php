<?php


namespace App\Services\Subscriptions;


use App\Models\Alert;
use App\Services\BaseScript;

class QueueSubscriptionAlertsService extends BaseScript
{
    protected function process(): void
    {
        Alert::whereNull('queued_at')->get()->each(function (Alert $alert) {
            $alert->queue();
        });
    }
}
