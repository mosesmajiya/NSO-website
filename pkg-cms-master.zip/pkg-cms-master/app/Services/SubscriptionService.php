<?php


namespace App\Services;


use App\Mail\EmailSubscribed;
use App\Mail\EmailUnSubscribed;
use App\Models\Subscriber;
use Illuminate\Support\Facades\Mail;

class SubscriptionService
{

    private string $email;

    public function __construct(string $email)
    {
        $this->email = $email;
    }

    public function subscribe(array $services): Subscriber
    {
        $subscriber = Subscriber::findByEmail($this->email);

        if (!$subscriber) return $this->createNewSubscriber($services);

        return $this->updateSubscription($services);
    }

    private function updateSubscription(array $services): Subscriber
    {
        $subscriber = Subscriber::findByEmail($this->email);
        $subscriber->subscriptions()->sync($services);
        Mail::queue(new EmailUnSubscribed($subscriber));
        return $subscriber;
    }

    private function createNewSubscriber(array $services): Subscriber
    {
        $subscriber = Subscriber::create(['email' => $this->email]);
        $subscriber->subscriptions()->sync($services);
        Mail::queue(new EmailSubscribed($subscriber));
        return $subscriber;
    }
}
