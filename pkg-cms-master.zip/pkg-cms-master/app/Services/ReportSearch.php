<?php


namespace App\Services;


use App\Models\Report;
use App\Models\ReportSuperCategory;
use Illuminate\Database\Eloquent\Builder;

class ReportSearch
{
    private ReportSuperCategory $category;
    private string $query;

    public function __construct(ReportSuperCategory $category, string $query)
    {
        $this->category = $category;
        $this->query = $query;
    }

    public function search(): array
    {
        return array_map(function ($result) {
            $result = json_decode(json_encode($result), true);
            return [
                'title' => $result[$this->fields()['title']],
                'description' => $result[$this->fields()['description']],
                'published_at' => $result['published_at'],
                'slug' => $result['slug'],
                'type' => class_basename(static::class),
                'url' => $this->getUrl($result['slug'])
            ];
        }, $this->buildResult());
    }

    private function buildResult(): array
    {
        $searchableFields = ['title', 'abstract', 'source'];
        $terms = explode(' ', $this->query);
        $permuted = array();
        permute($terms, "",$permuted);
        if (sizeof($terms) != 1) $terms = $permuted;

        $builder = Report::whereNotNull('published_at')
            ->whereHas('superCategories', function (Builder $relation){
                return $relation->where('id', $this->category->getKey());
            })
            ->where($searchableFields[0], 'LIKE', '%' . $this->query . '%');
        foreach ($searchableFields as $field) {
            foreach ($terms as $term) {
                $builder->orWhere($field, 'LIKE', '%' . $term . '%');
            }
        }
        return $builder
            ->get([$searchableFields[0], $searchableFields[1], 'published_at', 'slug'])->toArray();
    }

    private function getUrl(string $slug): string
    {
        return sprintf('publications/%s/%s', $this->category->{'slug'}, $slug);
    }

    private function fields(): array
    {
        return [
            'title' => 'title',
            'description' => 'abstract'
        ];
    }
}
