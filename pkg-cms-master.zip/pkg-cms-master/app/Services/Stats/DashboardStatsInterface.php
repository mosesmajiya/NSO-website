<?php


namespace App\Services\Stats;


interface DashboardStatsInterface
{
    public function get();
}
