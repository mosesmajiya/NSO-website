<?php


namespace App\Services\Stats\VisitorsByDevice;


class VisitorsByDeviceClient
{
    /**
     * @var VisitorsByDeviceServiceInterface
     */
    private $service;

    public function __construct()
    {
        $this->service = resolve(VisitorsByDeviceServiceInterface::class);
    }

    public function get()
    {
        return $this->service->get();
    }
}
