<?php


namespace App\Services\Stats\VisitorsByDevice;


use Faker\Factory;

class FakeVisitorsByDeviceService implements VisitorsByDeviceServiceInterface
{
    public function get()
    {
        $faker = Factory::create();
        return array_map(function (string $userAgent) use ($faker) {
            return [
                'device' => $userAgent,
                'value' => $faker->numberBetween(10, 400)
            ];
        }, ['desktop', 'mobile', 'tablet']);
    }
}
