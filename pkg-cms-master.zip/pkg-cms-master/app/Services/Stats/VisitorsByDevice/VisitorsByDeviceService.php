<?php


namespace App\Services\Stats\VisitorsByDevice;


use DB;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;

class VisitorsByDeviceService implements VisitorsByDeviceServiceInterface
{
    /**
     * @var Builder
     */
    private $builder;
    /**
     * @var Collection
     */
    private $report;

    public function __construct()
    {
        $this->builder = DB::table('traffic');
        $this->report = new Collection();
    }

    public function get()
    {
        return $this->fetchReport()->groupByUserAgent()->format();
    }

    private function fetchReport(): self
    {
        $this->report = $this->builder->where('created_at', '>', now()->subMonths(6))->get();
        return $this;
    }

    private function groupByUserAgent(): self
    {
        $this->report = $this->report->groupBy('user_agent')->map(function (Collection $collection) {
            return $collection->count();
        });
        return $this;
    }

    private function format(): array
    {
        return $this->report->map(function ($value, $key) {
            return [
                'device' => $key,
                'value' => $value
            ];
        })->values()->toArray();
    }
}
