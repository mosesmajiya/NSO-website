<?php


namespace App\Services\Stats\VisitorsByDevice;


use App\Services\Stats\DashboardStatsInterface;

interface VisitorsByDeviceServiceInterface extends DashboardStatsInterface
{

}
