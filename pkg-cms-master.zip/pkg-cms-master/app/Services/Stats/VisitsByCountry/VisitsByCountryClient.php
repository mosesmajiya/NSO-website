<?php


namespace App\Services\Stats\VisitsByCountry;


class VisitsByCountryClient
{
    /**
     * @var VisitsByCountryServiceInterface
     */
    private $service;

    public function __construct()
    {
        $this->service = resolve(VisitsByCountryServiceInterface::class);
    }

    public function get()
    {
        return $this->service->get();
    }
}
