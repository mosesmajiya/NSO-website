<?php


namespace App\Services\Stats\VisitsByCountry;


use DB;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;

class VisitsByCountryService implements VisitsByCountryServiceInterface
{
    /**
     * @var Builder
     */
    private $builder;
    /**
     * @var Collection
     */
    private $report;

    public function __construct()
    {
        $this->builder = DB::table('traffic');
        $this->report = new Collection();
    }

    public function get()
    {
        return $this->fetchReport()->groupByCountry()->format();
    }

    private function fetchReport(): self
    {
        $this->report = $this->builder->where('created_at', '>', now()->subMonths(6))->get();
        return $this;
    }

    private function groupByCountry(): self
    {
        $this->report = $this->report->groupBy('country')->map(function (Collection $country) {
            return $country->count();
        })->sortDesc()->take(4);
        return $this;
    }

    private function format(): array
    {
        return $this->report->map(function ($value, $key) {
            return [
                'country' => $key,
                'value' => $value
            ];
        })->values()->toArray();
    }
}
