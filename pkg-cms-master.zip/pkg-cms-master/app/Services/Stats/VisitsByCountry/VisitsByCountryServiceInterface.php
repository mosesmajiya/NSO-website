<?php


namespace App\Services\Stats\VisitsByCountry;


use App\Services\Stats\DashboardStatsInterface;

interface VisitsByCountryServiceInterface extends DashboardStatsInterface
{

}
