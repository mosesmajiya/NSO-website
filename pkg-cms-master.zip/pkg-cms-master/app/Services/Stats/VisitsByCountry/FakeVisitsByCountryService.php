<?php


namespace App\Services\Stats\VisitsByCountry;


use Faker\Factory;

class FakeVisitsByCountryService implements VisitsByCountryServiceInterface
{

    public function get()
    {
        $faker = Factory::create();

        return array_map(function () use ($faker) {
            return [
                'country' => $faker->country,
                'value' => $faker->numberBetween(200, 7900)
            ];
        }, range(0, 5));
    }
}
