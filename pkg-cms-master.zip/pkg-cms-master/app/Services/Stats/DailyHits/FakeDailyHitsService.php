<?php


namespace App\Services\Stats\DailyHits;


use Faker\Factory;

class FakeDailyHitsService implements DailyHitsServiceInterface
{
    public function get()
    {
        $faker = Factory::create();
        return array_reverse(array_map(function (int $day) use ($faker) {
            return [
                'date' => today()->subDays($day)->format('j-M'),
                'value' => $faker->numberBetween(10, 500)
            ];
        }, range(0, 29)));
    }
}
