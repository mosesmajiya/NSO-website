<?php


namespace App\Services\Stats\DailyHits;


class DailyHitsClient
{
    /**
     * @var DailyHitsServiceInterface
     */
    private $service;

    public function __construct()
    {
        $this->service = resolve(DailyHitsServiceInterface::class);
    }

    public function get()
    {
        return $this->service->get();
    }
}
