<?php


namespace App\Services\Stats\DailyHits;


use Carbon\Carbon;
use DB;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;

class DailyHitsService implements DailyHitsServiceInterface
{
    const DATE_FORMAT = 'j-M';
    /**
     * @var Builder
     */
    private $builder;
    /**
     * @var Collection
     */
    private $report;

    public function __construct()
    {
        $this->builder = DB::table('traffic');
        $this->report = new Collection();
    }

    public function get()
    {
        return $this->fetchReport()->addDate()->groupByDate()->format();
    }

    private function fetchReport(): self
    {
        $this->report = $this->builder->where('created_at', '>', today()->subDays(30))->get();
        return $this;
    }

    private function addDate(): self
    {
        $this->report = $this->report->map(function ($record) {
            $record->date = Carbon::parse($record->created_at)->toDateString();
            return $record;
        });
        return $this;
    }

    private function groupByDate(): self
    {
        $this->report = $this->report->groupBy('date')->map(function (Collection $date) {
            return $date->count();
        });
        return $this;
    }

    private function format(): array
    {
        return $this->getMonthlyRange()->map(function (Carbon $carbon) {
            if ($this->dateHasData($carbon)) {
                return $this->getAvailableReports()->first(function ($record) use ($carbon) {
                    return $record['date'] == $carbon->format(static::DATE_FORMAT);
                });
            } else {
                return $this->getNullHits($carbon);
            }
        })->toArray();
    }

    private function getMonthlyRange(): Collection
    {
        return collect(range(29, 0))->map(function (int $nthDay) {
            return today()->subDays($nthDay);
        });
    }

    private function getAvailableReports(): Collection
    {
        return $this->report->map(function ($value, $key) {
            return [
                'date' => Carbon::parse($key)->format(static::DATE_FORMAT),
                'value' => $value
            ];
        })->values();
    }

    private function dateHasData(Carbon $carbon): bool
    {
        return $this->getAvailableReports()->contains(function ($record) use ($carbon) {
            return $record['date'] == $carbon->format(static::DATE_FORMAT);
        });
    }

    private function getNullHits(Carbon $carbon): array
    {
        return [
            'date' => $carbon->format(static::DATE_FORMAT),
            'value' => 0
        ];
    }
}
