<?php


namespace App\Services\Stats\DailyHits;


use App\Services\Stats\DashboardStatsInterface;

interface DailyHitsServiceInterface extends DashboardStatsInterface
{
}
