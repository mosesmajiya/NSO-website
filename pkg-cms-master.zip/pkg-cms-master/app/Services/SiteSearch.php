<?php


namespace App\Services;


use App\Models\About;
use App\Models\Department;
use App\Models\Event;
use App\Models\Faq;
use App\Models\Indicator;
use App\Models\Newsletter;
use App\Models\Page;
use App\Models\PhotoGallery;
use App\Models\Post;
use App\Models\Project;
use App\Models\Report;
use App\Models\Searchable;
use App\Models\Staff;
use App\Models\Vacancy;
use App\Models\YoutubeAlbum;
use Illuminate\Support\Collection;

class SiteSearch
{
    protected array $result = [];

    public function search(string $query): array
    {
        if (strlen($query) < 3) return $this->result;

        $this->getSearchableModels()->each(function (string $model) use ($query) {
            /** @var Searchable $searchable */
            $searchable = new $model;

            if (in_array(Searchable::class, class_uses($searchable)))
                $this->result = array_merge($this->result, $searchable->search($query));
        });

        $result = array_values(collect($this->result)->sortBy('published_at')->reverse()->toArray());
        return array_map("unserialize", array_unique(array_map("serialize", $result)));
    }

    protected function getSearchableModels(): Collection
    {
        return new Collection([
            About::class,
            Department::class,
            Event::class,
            Faq::class,
            PhotoGallery::class,
            Newsletter::class,
            Page::class,
            Post::class,
            Project::class,
            Staff::class,
            Vacancy::class,
            YoutubeAlbum::class,
            Report::class,
            Indicator::class,
        ]);
    }
}
