<?php


namespace App\Services\Projects;


use DB;
use Illuminate\Database\Query\Builder;

class ProjectSummary
{
    private Builder $builder;

    public function __construct()
    {
        $this->builder = DB::table('projects');
    }

    public function get()
    {
        return $this->builder->select(DB::raw('project_stages.name, count(*) as count'))
            ->join('project_stages', 'project_stages.id', '=', 'project_stage_id')
            ->groupBy('project_stages.name')
            ->get();
    }
}
