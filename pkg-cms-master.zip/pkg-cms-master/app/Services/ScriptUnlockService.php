<?php


namespace App\Services;


use App\Models\ScriptLock;

class ScriptUnlockService
{
    public function run(): int
    {
        ScriptLock::where('locked_at', '<=',now()->subHour())->update(['locked_at' => null]);
        return 0;

    }
}
