<?php


namespace App\Services;


use App\Models\CensusResource;
use App\Models\NationalCensus;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CensusResourcesService
{
    private NationalCensus $census;
    private array $result;

    public function __construct(NationalCensus $census)
    {
        $this->census = $census;
        $this->result = $census->toArray();
    }

    public function run(): array
    {
        $resourceTypes = CensusResource::orderBy('priority')->get()->map->{'name'};
        if ($this->census->districts()->exists()) {
            $this->census->load('districts.district');
            $this->result['districts'] = $this->census->{'districts'};

        }

        $resourceTypes->each(function (string $type) {
            if ($this->census->hasMedia($type)) {
                $this->result['resources'][] = [
                    'name' => $type,
                    'files' => $this->census->getMedia($type)->map(function (Media $media) {
                        return [
                            'name' => $media->{'name'},
                            'size' => $media->getHumanReadableSizeAttribute(),
                            'link' => $media->getFullUrl()
                        ];
                    })
                ];
            }
        });

        return $this->result;
    }
}
