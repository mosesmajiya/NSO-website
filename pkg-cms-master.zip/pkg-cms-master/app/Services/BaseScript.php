<?php


namespace App\Services;


use App\Models\ScriptLock;

abstract class BaseScript
{
    protected ?ScriptLock $script;

    public final function run(): int
    {
        if (!$this->lock()) return 1;

        $this->process();

        $this->script->unlock();
        return 0;
    }

    protected function lock(): ?ScriptLock
    {
        $this->script = ScriptLock::lock(static::class);
        return $this->script;
    }

    abstract protected function process(): void;
}
