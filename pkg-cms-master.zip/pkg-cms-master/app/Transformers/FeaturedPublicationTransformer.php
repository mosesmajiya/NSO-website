<?php

namespace App\Transformers;

use App\Models\Report;

class FeaturedPublicationTransformer
{
    private Report $report;

    public function __construct(Report $report)
    {
        $this->report = $report;
    }

    public function transform():array
    {
        return [
            'cover' => $this->report->getFirstMedia('feature')->getFullUrl(),
            'super_category_slug' => $this->report->{'superCategories'}->first()->{'slug'},
            'title' => $this->report->{'title'},
            'published_at' => $this->report->{'published_at'},
            'featured_on' => $this->report->{'featured_on'},
            'slug' => $this->report->{'slug'},
        ];
    }
}
