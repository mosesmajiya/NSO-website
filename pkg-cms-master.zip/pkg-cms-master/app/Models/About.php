<?php

namespace App\Models;

use Spatie\Sluggable\SlugOptions;

class About extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function getSlugOptions($column = 'category'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    protected function getLogColumn()
    {
        return $this->{'category'};
    }

    public function searchable(): array
    {
        return ['category', 'content'];
    }

    public function fields(): array
    {
        return [
            'title' => 'category',
            'description' => 'content'
        ];
    }

    public function getUrl(string $slug) : string
    {
      return 'about/#'.$slug;
    }
}
