<?php

namespace App\Models;

class Slider extends SluggableModel
{
    use HasMetadata;
    protected $guarded = [];

    public function photos()
    {
        return $this->getMedia('cover');
    }
}
