<?php

namespace App\Models;

use Spatie\Sluggable\SlugOptions;

class Faq extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function category()
    {
        return $this->belongsTo(FaqCategory::class);
    }

    public function getSlugOptions($column = 'question'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function searchable(): array
    {
        return ['question', 'response'];
    }

    public function fields(): array
    {
        return [
            'title' => 'question',
            'description' => 'response'
        ];
    }

    public function getUrl(string $slug) : string
    {
      return 'faq/#'.$slug;
    }
}
