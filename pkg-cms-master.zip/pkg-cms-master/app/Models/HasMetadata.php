<?php


namespace App\Models;


use Illuminate\Database\Eloquent\Relations\MorphOne;

trait HasMetadata
{
    public function metadata(): MorphOne
    {
        return $this->morphOne(Metadata::class, 'metadatable');
    }

    public function addMetadata(string $description, string $keywords)
    {
        $values = [
            'description' => $description,
            'keywords' => $keywords
        ];
        if ($this->metadata()->exists()) return $this->metadata()->update($values);

        return $this->metadata()->create($values);
    }
}
