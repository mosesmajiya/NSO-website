<?php

namespace App\Models;

use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class AlertQueueItem extends Model
{
    protected $guarded = [];

    public function subscribable(): MorphTo
    {
        return $this->morphTo();
    }

    public function getModel(): Subscribable
    {
        return $this->{'subscribable'};
    }
}
