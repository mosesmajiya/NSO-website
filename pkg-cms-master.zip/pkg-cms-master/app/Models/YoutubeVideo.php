<?php

namespace App\Models;

class YoutubeVideo extends SluggableModel
{
    public function album()
    {
        return $this->belongsTo(YoutubeAlbum::class, 'youtube_album_id');
    }
}
