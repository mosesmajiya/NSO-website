<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Metadata extends Model
{
    protected $guarded = [];

    public function metadatable()
    {
        return $this->morphTo();
    }
}
