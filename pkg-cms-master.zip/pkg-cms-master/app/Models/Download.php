<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\Sluggable\SlugOptions;

class Download extends Post
{
    protected $guarded = [];

    public function getSlugOptions($column = 'name'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class);
    }

    public function scopeLocked(Builder $query, User $user): Builder
    {
        $roleIds = $user->{'roles'}->map->{'id'};

        return $query->where('type', 'private')
            ->whereHas('roles', function (Builder $builder) use ($roleIds) {
                return $builder->whereIn('roles.id', $roleIds);
            });
    }

    public function scopePublic($query)
    {
        return $query->whereType('public');
    }

    public function scopeReport($query)
    {
        return $query->whereType('report');
    }

    public function scopeSpeech($query)
    {
        return $query->whereType('speech');
    }
}
