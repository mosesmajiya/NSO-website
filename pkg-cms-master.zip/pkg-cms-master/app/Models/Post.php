<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Builder;
use Spatie\Sluggable\SlugOptions;

/**
 * @method static newsAnnouncement()
 */
class Post extends SluggableModel implements FuzzySearch, Subscribable
{
    use HasMetadata, Searchable;

    public function getSlugOptions($column = 'title'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class)->withTimestamps();
    }

    public function type()
    {
        return $this->belongsTo(PostType::class, 'post_type_id');
    }

    public function scopeType(Builder $builder, string $type)
    {
        return $builder->whereHas('type', function (Builder $builder) use ($type) {
            return $builder->where('name', $type);
        });
    }

    public function scopeTypes(Builder  $builder, array $types): Builder
    {
        $firstType = $types[0];
        $builder->whereHas('type', function (Builder $builder) use ($firstType) {
            return $builder->where('name', $firstType);
        });

        array_shift($types);

        foreach ($types as $type){
            $builder->orWhereHas('type', function (Builder $builder) use ($type) {
                return $builder->where('name', $type);
            });
        }

        return $builder;

    }

    public function scopeNewsAnnouncement(Builder $builder): Builder
    {
        return $builder->whereHas('type', function (Builder $builder) {
            return $builder->where('slug', 'news')->orWhere('slug', 'announcement');
        });
    }

    public function scopeNews(Builder $builder)
    {
        return $builder->type('News');
    }

    public function scopeProcurement(Builder $builder)
    {
        return $builder->types(['Procurement Advertisement', 'Procurement Notice', 'Procurement Report']);
    }

    public function scopeEvents(Builder $builder)
    {
        return $builder->type('Event');
    }

    public function scopeAdvertisement(Builder $builder)
    {
        return $builder->type('Procurement Advertisement');
    }

    public function scopeNotice(Builder $builder)
    {
        return $builder->types(['Procurement Notice', 'Procurement Report']);
    }

    public function searchable(): array
    {
        return ['title', 'content'];
    }

    public function fields(): array
    {
        return [
            'title' => 'title',
            'description' => 'content',
        ];
    }

    public function getUrl(string $slug) : string
    {
      return 'news/'.$slug;
    }

    public function getStory(): Story
    {
        return new Story($this->{'title'}, $this->getFullUrl(), $this->{'content'}, carbonise($this->{'published_at'}));
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/news/%s', config('app.site_url'), $this->{'slug'});
    }
}
