<?php

namespace App\Models;

class Position extends SluggableModel
{
    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function staff()
    {
        return $this->hasMany(Staff::class);
    }
}
