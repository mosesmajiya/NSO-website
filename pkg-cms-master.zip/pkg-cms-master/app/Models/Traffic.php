<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Traffic extends Model
{
    protected $guarded = [];

    public static function getForToday(): int
    {
        return static::whereDate('created_at', today())->count();
    }

    public static function getForThisMonth(): int
    {
        return static::whereDate('created_at', '>=', today()->startOfMonth())->count();
    }
}
