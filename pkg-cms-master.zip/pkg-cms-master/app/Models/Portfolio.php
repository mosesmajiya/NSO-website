<?php

namespace App\Models;

class Portfolio extends SluggableModel
{
    public function items()
    {
        return $this->hasMany(PortfolioItem::class);
    }
}
