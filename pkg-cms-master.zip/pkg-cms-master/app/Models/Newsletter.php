<?php

namespace App\Models;

class Newsletter extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function releases()
    {
        return $this->hasMany(NewsletterRelease::class);
    }

    public function registerMediaCollections(): void
    {
        $this
            ->addMediaCollection('attachment')
            ->singleFile();
    }

    public function getUrl(string $slug) : string
    {
      return 'newsletters/'.$slug;
    }
}
