<?php

namespace App\Models;

class SocialMedia extends SluggableModel
{
    public function handles()
    {
        return $this->hasMany(SocialMediaHandle::class);
    }
}
