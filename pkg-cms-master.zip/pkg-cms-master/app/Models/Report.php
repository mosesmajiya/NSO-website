<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\Builder;
use Spatie\Sluggable\SlugOptions;

class Report extends SluggableModel implements Subscribable
{
    use Searchable;

    protected $appends = ['filesize', 'document'];
    /**
     * @var Builder|mixed
     */
    private $builder;

    public function getDocumentAttribute(): string
    {
        if (!$this->hasMedia()) return '';
        return $this->getFirstMedia()->getFullUrl();
    }

    public function getFilesizeAttribute($value): string
    {
        if (!$this->hasMedia()) return '0 KB';
        return $this->getFirstMedia()->getHumanReadableSizeAttribute();
    }

    public function indicators(): HasMany
    {
        return $this->hasMany(Indicator::class);
    }

    public function superCategories(): BelongsToMany
    {
        return $this->belongsToMany(ReportSuperCategory::class);
    }

    public function getSlugOptions($column = 'title'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(ReportCategory::class, 'report_category_id');
    }

    public function getUrl(string $slug): string
    {
        $report = self::findBySlug($slug);
        return sprintf('publications/%s/%s', $report->{'super_category_slug'}, $slug);
    }

    public function searchable(): array
    {
        return ['title', 'abstract', 'source'];
    }

    public function fields(): array
    {
        return [
            'title' => 'title',
            'description' => 'abstract'
        ];
    }

    public function getSuperCategorySlugAttribute(){
        return $this->{'superCategories'}->first()->slug ? $this->{'superCategories'}->first()->slug : 'default-category';
    }

    public function getStory(): Story
    {
        return new Story($this->{'title'}, $this->getFullUrl(), $this->{'abstract'}, carbonise($this->{'published_at'}));
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/publications/report/%s', config('app.site_url'), $this->{'slug'});
    }

    public function scopeFeatured($builder)
    {
        return $builder->where('featured_on', '<>', null);
    }
}
