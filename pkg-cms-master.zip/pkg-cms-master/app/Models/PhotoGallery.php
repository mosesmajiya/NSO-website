<?php

namespace App\Models;

class PhotoGallery extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function photos()
    {
        return $this->getMedia('banner');
    }

    public function getUrl(string $slug) : string
    {
      return 'galleries/pictures/'.$slug;
    }
}
