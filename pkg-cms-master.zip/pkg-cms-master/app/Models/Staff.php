<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Staff extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    public function handles()
    {
        return $this->hasMany(SocialMediaHandle::class);
    }

    public function position(): BelongsTo
    {
        return $this->belongsTo(Position::class);
    }

    public function searchable(): array
    {
        return ['name', 'profile'];
    }

    public function fields(): array
    {
        return [
            'title' => 'name',
            'description' => 'profile'
        ];
    }

    public function getUrl(string $slug) : string
    {
        $staff = self::findBySlug($slug);
        return sprintf('departments/%s/%s', $staff->{'department'}->{'slug'}, $slug);
    }

    public function scopeCurrent($query)
    {
        return $query->where('current', 1);
    }

    public function scopeFormer($query)
    {
        return $query->where('current', 0);
    }
}
