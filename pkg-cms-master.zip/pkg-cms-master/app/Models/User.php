<?php

namespace App\Models;

use App\Exceptions\AccessDeniedException;
use App\Http\Controllers\Cms\CreatesLogs;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\HasApiTokens;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class User extends Authenticatable implements HasMedia
{
    use Notifiable, InteractsWithMedia, HasApiTokens, CreatesLogs;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public static function add(array $params): self
    {
        return static::create([
            'name' => $params['name'],
            'email' => $params['email'],
            'password' => Hash::make($params['password']),
        ]);
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('avatar')->singleFile();
    }

    /**
     * @param string $email
     * @return static
     * @throws AccessDeniedException
     */
    public static function findByEmail(string $email): self
    {
        return static::where('email', $email)->firstOr(function () {
            throw new AccessDeniedException();
        });
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class)->withTimestamps();
    }

    public function isAdmin(): bool
    {
        return $this->roles()->get()->contains(function (Role $role) {
            return $role->{'type'} === 'admin';
        });
    }

    public function isMember(): bool
    {
        return $this->roles()->get()->contains(function (Role $role) {
            return $role->{'type'} === 'portal';
        });
    }

    public function isNotAdmin(): bool
    {
        return !$this->isAdmin();
    }

    public function invalidPassword(string $password): bool
    {
        return !\Hash::check($password, $this->{'password'});
    }

    public function createResetCode(): string
    {
        return PasswordReset::generateCode($this->{'email'})->{'token'};
    }

    public function updatePassword(string $password): bool
    {
        return $this->update(['password' => bcrypt($password)]);
    }
}
