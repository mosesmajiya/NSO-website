<?php

namespace App\Models;

use Spatie\Sluggable\SlugOptions;

class Page extends SluggableModel implements FuzzySearch
{
    use HasMetadata, Searchable;

    public function getSlugOptions($column = 'title'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function searchable(): array
    {
        return ['title', 'content'];
    }

    public function fields(): array
    {
        return [
            'title' => 'title',
            'description' => 'content'
        ];
    }

    public function getUrl(string $slug) : string
    {
      return 'pages/'.$slug;
    }
}
