<?php

namespace App\Models;

use App\Exceptions\InvalidCredentialsException;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class PasswordReset extends Model
{
    const EXPIRY_MINUTES = 60;
    protected $guarded = [];
    public $timestamps = false;
    protected $dates = ['created_at', 'verified_at'];

    public static function generateCode(string $email): self
    {
        return static::updateOrCreate(['email' => $email],
            ['email' => $email, 'token' => generate_number_code(), 'created_at' => now()->toDateTimeString()]
        );
    }

    public function verify(): bool
    {
        if ($this->expired()) throw new InvalidCredentialsException('The code is expired', 400);
        return $this->update(['verified_at' => now()]);
    }

    public static function findByEmailAndCode(string $email, string $code): ?self
    {
        return static::where('email', $email)->where('token', $code)->first();
    }

    private function expired(): bool
    {
        return Carbon::parse($this->{'created_at'})->isBefore(now()->subMinutes(static::EXPIRY_MINUTES));
    }
}
