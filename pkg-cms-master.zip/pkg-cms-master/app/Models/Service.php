<?php

namespace App\Models;

class Service extends SluggableModel
{
    use HasMetadata;
}
