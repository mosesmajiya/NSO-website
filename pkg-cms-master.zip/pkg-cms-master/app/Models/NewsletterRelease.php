<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Spatie\Sluggable\SlugOptions;

class NewsletterRelease extends SluggableModel implements Subscribable
{
    use HasMetadata;

    public function getSlugOptions($column = 'volume'): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom($column)
            ->saveSlugsTo('slug');
    }

    protected $guarded = [];

    public function newsletter()
    {
        return $this->belongsTo(Newsletter::class);
    }

    public function getStory(): Story
    {
        return new Story(
            $this->newsletter->name . " Volume " . $this->{'volume'} . ", Issue " . $this->{'issue'},
            $this->getFullUrl(),
            $this->{'content'},
            carbonise($this->{'published_at'})
        );
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/newsletters/%s', config('app.site_url'), $this->newsletter->slug);
    }
}
