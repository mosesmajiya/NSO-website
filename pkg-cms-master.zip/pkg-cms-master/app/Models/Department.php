<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends SluggableModel implements FuzzySearch
{
    use Searchable;

    public function positions()
    {
        return $this->hasMany(Position::class);
    }

    public function staff(): HasMany
    {
        return $this->hasMany(Staff::class);
    }

    public function searchable(): array
    {
        return ['name', 'description'];
    }

    public function fields(): array
    {
        return [
            'title' => 'name',
            'description' => 'description'
        ];
    }

    public function getUrl(string $slug) : string
    {
        return 'departments/' . $slug;
    }
}
