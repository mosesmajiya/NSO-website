<?php

namespace App\Models;

class ReportSuperCategory extends SluggableModel
{
    protected $guarded = [];

    public function reports()
    {
        return $this->belongsToMany(Report::class);
    }
}
