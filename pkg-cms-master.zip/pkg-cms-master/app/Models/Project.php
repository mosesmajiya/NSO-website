<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class Project extends SluggableModel implements FuzzySearch, Subscribable
{
    use HasMetadata, Searchable;

    public function stage()
    {
        return $this->belongsTo(ProjectStage::class, 'project_stage_id');
    }

    public function scopeByStage(Builder $builder, array $filters)
    {
        return $builder->whereIn('project_stage_id', $filters);
    }

    public function scopeCategory(Builder $builder, string $category)
    {
        return $builder->where('category',$category);
    }

    public function getUrl(string $slug): string
    {
        return 'projects/' . $slug;
    }

    public function getPhase(int $stages): string
    {
        switch ($this->{'stage'}->{'rank'}) {
            case 1:
                return 'Upcoming';
            case $stages:
                return 'Closed';
            case $stages - 1:
                return 'Monitoring';
            default:
                return 'Underway';
        }
    }

    public function getProgress($stages): int
    {
        return (int)ceil(($this->{'stage'}->{'rank'} - 1) / ($stages - 1) * 100);
    }

    public static function getWithPhase(): Collection
    {
        $stages = ProjectStage::count();

        return Project::published()->category('normal')->with('stage')->get()->map(function (Project $project) use ($stages) {
            return array_merge($project->toArray(), [
                'stage' => $project->{'stage'}->{'name'},
                'progress' => $project->getProgress($stages),
                'phase' => $project->getPhase($stages)
            ]);
        });
    }

    public function getStory(): Story
    {
        return new Story($this->{'name'}, $this->getFullUrl(), $this->{'content'}, carbonise($this->{'published_at'}));
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/projects/%s', config('app.site_url'), $this->{'slug'});
    }
}
