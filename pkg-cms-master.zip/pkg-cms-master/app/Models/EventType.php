<?php

namespace App\Models;

class EventType extends SluggableModel
{
    public function events()
    {
        return $this->hasMany(Event::class);
    }
}
