<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Collection;

class Indicator extends Model implements FuzzySearch
{
    use Searchable;

    protected $guarded = [];

    public function report(): BelongsTo
    {
        return $this->belongsTo(Report::class);
    }

    public function getUrl(string $slug): string
    {
        return $this->{'report'}->getUrl($slug);
    }

    public function searchable(): array
    {
        return ['indicator'];
    }

    public function search(string $query): array
    {
        return $this->buildResult($query)->map(function (Indicator $indicator) {
            /** @var Report $report */
            $report = $indicator->{'report'};
            return [
                'title' => $report->{'title'},
                'description' => $report->{'abstract'},
                'published_at' => $report->{'published_at'},
                'slug' => $report->{'slug'},
                'type' => class_basename(Report::class),
                'url' => $report->getUrl($report->{'slug'}),
            ];
        })->toArray();
    }

    protected function buildResult(string $query): Collection
    {
        $terms = explode(' ', $query);
        $builder = static::query()->where($this->searchable()[0], 'LIKE', '%' . $query . '%');
        foreach ($this->searchable() as $field) {
            foreach ($terms as $term) {
                $builder->orWhere($field, 'LIKE', '%' . $term . '%');
            }
        }
        return $builder->get();
    }
}
