<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MonthlyConsumerPriceIndex extends Model
{
    protected $guarded = [];
}
