<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;

class ReportCategory extends SluggableModel
{
    public function reports(): HasMany
    {
        return $this->hasMany(Report::class);
    }
}
