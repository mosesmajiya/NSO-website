<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuSetting extends Model
{
    public function toggle(): self
    {
        $this->update(['enabled' => !$this->{'enabled'}]);
        return $this->fresh();
    }
}
