<?php

namespace App\Models;

use App\Events\SubscribablePublished;
use App\Http\Controllers\Cms\CreatesLogs;
use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

abstract class SluggableModel extends Model implements HasMedia
{
    use HasSlug, InteractsWithMedia, CreatesLogs;

    protected $guarded = [];

    public function getSlugOptions($column = 'name'): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom($column)
            ->saveSlugsTo('slug');
    }

    public static function recent(int $take = 5): Collection
    {
        return static::latest()->take($take)->get();
    }

    public function scopePopular(Builder $builder)
    {
        return $builder->orderBy('views', 'desc')
            ->where('created_at', '>', today()->subMonths(12))
            ->published();
    }

    public function publish(): self
    {
        $this->update(['published_at' => now()]);
        if ($this instanceof Subscribable) event(new SubscribablePublished($this));
        return $this;
    }

    public function unpublish(): self
    {
        if ($this->getAttribute("published_at")) {
            $this->update(['published_at' => null]);
        }
        return $this;
    }

    public function isNotPublished(): bool
    {
        return $this->{'published_at'} === null;
    }

    public function scopePublished(Builder $builder): Builder
    {
        return $builder->where('published_at', '<>', null);
    }

    public function scopeDraft(Builder $builder): Builder
    {
        return $builder->whereNull('published_at');
    }


    public static function findBySlug(string $slug): self
    {
        return static::where('slug', $slug)->firstOrFail();
    }

    public static function findByPublishedSlug(string $slug): self
    {
        return static::where('slug', $slug)->where('published_at', '<>', null)->firstOrFail();
    }

    public function countView(): self
    {
        $this->increment('views');
        return $this;
    }
}
