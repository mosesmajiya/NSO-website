<?php


namespace App\Models;


trait Searchable
{
    abstract public function getUrl(string $slug): string;

    public function searchable(): array
    {
        return ['name', 'content'];
    }

    public function fields(): array
    {
        return [
            'title' => 'name',
            'description' => 'content'
        ];
    }

    public function search(string $query): array
    {
        return array_map(function ($result) {
            $result = json_decode(json_encode($result), true);
            return [
                'title' => $result[$this->fields()['title']],
                'description' => $result[$this->fields()['description']],
                'published_at' => $result['published_at'],
                'slug' => $result['slug'],
                'type' => class_basename(static::class),
                'url' => $this->getUrl($result['slug'])
            ];
        }, $this->buildResult($query));
    }

    protected function buildResult(string $query): array
    {
        $terms = explode(' ', $query);
        $permuted = array();
        permute($terms, "",$permuted);

        if (sizeof($terms) != 1) $terms = $permuted;
        $this->builder = static::query()
            ->whereNotNull('published_at')
            ->where($this->searchable()[0], 'LIKE', '%' . $query . '%');
        foreach ($this->searchable() as $field) {
            foreach ($terms as $term) {
                $this->builder->orWhere($field, 'LIKE', '%' . $term . '%');
            }
        }
        return $this->builder
            ->get([$this->searchable()[0], $this->searchable()[1], 'published_at', 'slug'])->toArray();
    }

}
