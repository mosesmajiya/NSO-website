<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SocialMediaHandle extends Model
{
    protected $guarded = [];

    public function socialMedia()
    {
        return $this->belongsTo(SocialMedia::class);
    }
}
