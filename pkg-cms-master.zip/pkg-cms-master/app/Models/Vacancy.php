<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Spatie\Sluggable\SlugOptions;

class Vacancy extends SluggableModel implements FuzzySearch, Subscribable
{
    use HasMetadata, Searchable;

    public function getSlugOptions($column = 'position'): SlugOptions
    {
        return parent::getSlugOptions($column);
    }

    public function searchable(): array
    {
        return ['position', 'content'];
    }

    public function fields(): array
    {
        return [
            'title' => 'position',
            'description' => 'content'
        ];
    }

    public function getUrl(string $slug): string
    {
        return 'vacancies/' . $slug;
    }

    public function getStory(): Story
    {
        return new Story($this->{'position'}, $this->getFullUrl(), $this->{'content'}, carbonise($this->{'published_at'}));
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/%s/%s', config('app.site_url'), $this->getTable(), $this->{'slug'});
    }
}
