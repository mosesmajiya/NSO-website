<?php


namespace App\Models;


interface FuzzySearch
{
    public function searchable(): array;

    public function fields(): array;
}
