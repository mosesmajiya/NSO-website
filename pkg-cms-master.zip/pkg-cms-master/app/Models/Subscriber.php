<?php

namespace App\Models;

use App\Mail\SubscriptionPublished;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;

class Subscriber extends Model
{
    protected $guarded = [];

    public function subscriptions(): BelongsToMany
    {
        return $this->belongsToMany(Subscription::class)->withTimestamps();
    }

    public function alertQueueItems(): HasMany
    {
        return $this->hasMany(AlertQueueItem::class)->whereNull('sent_at')
            ->whereHasMorph('subscribable',
                [Post::class, Event::class, NewsletterRelease::class, Vacancy::class, Project::class, Report::class]);
    }


    /**
     * @param string $email
     * @return static
     */
    public static function findByEmail(string $email): ?self
    {
        return static::where(['email' => $email])->with('subscriptions')->first();
    }

    public function subscribe(Subscription $subscribable)
    {
        $this->subscriptions()->attach($subscribable);
    }

    public function sendStories()
    {
        $items = $this->{'alertQueueItems'};

        try{
            $stories = $this->getAlertCategories()->map(function (string $name) use ($items) {
                return [
                    'name' => $name,
                    'stories' => $items->filter(function (AlertQueueItem $item) use ($name) {
                        return $item->{'name'} == $name;
                    })->values()->map(function (AlertQueueItem $item) {
                        return $item->getModel()->getStory();
                    })->toArray()
                ];
            });
        }catch (Exception $exception){
            dd($exception->getMessage());
        }

        Mail::to($this->{'email'})->send(new SubscriptionPublished($stories,  $this->getUnsubscribeLink()));

        $this->complete();
    }

    private function getAlertCategories(): Collection
    {
        return $this->{'alertQueueItems'}->map(function (AlertQueueItem $item) {
            return $item->{'name'};
        })->unique()->values();
    }

    private function complete(): void
    {
        $this->{'alertQueueItems'}->each(function (AlertQueueItem $item) {
            $item->update(['sent_at' => now()]);
        });
    }

    private function getUnsubscribeLink(): string
    {
        return sprintf('%s/unsubscribe/%s', config('app.site_url'), Crypt::encryptString($this->{'email'}));
    }

    public function unsubscribe(array $subscriptions)
    {
        $this->subscriptions()->detach($subscriptions);
    }

}
