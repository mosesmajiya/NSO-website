<?php

namespace App\Models;

use App\Services\Subscriptions\Subscribable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Alert extends Model
{
    protected $guarded = [];

    public function queue()
    {
        $subscription = Subscription::findByType($this->{'subscribable_type'});

        if (!$subscription) return;

        $subscription->{'subscribers'}->each(function (Subscriber $subscriber) use ($subscription) {
            AlertQueueItem::create([
                'email' => $subscriber->{'email'},
                'name' => $subscription->{'name'},
                'subscribable_type' => $this->{'subscribable_type'},
                'subscribable_id' => $this->{'subscribable_id'},
                'subscriber_id' => $subscriber->getKey(),
            ]);
        });

        $this->update(['queued_at' => now()]);
    }

    public function subscribable(): MorphTo
    {
        return $this->morphTo();
    }

    public function send()
    {
        $this->update(['sent_at' => now()]);
    }

    public function getModel(): Subscribable
    {
        return $this->{'subscribable'};
    }
}
