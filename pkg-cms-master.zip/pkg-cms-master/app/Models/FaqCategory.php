<?php

namespace App\Models;

class FaqCategory extends SluggableModel
{
    public function faqs()
    {
        return $this->hasMany(Faq::class);
    }
}
