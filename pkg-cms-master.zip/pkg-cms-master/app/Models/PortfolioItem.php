<?php

namespace App\Models;

class PortfolioItem extends SluggableModel
{
    public function portfolio()
    {
        return $this->belongsTo(Portfolio::class);
    }
}
