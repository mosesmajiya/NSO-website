<?php

namespace App\Models;

use App\Services\Subscriptions\Story;
use App\Services\Subscriptions\Subscribable;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Collection;

class Event extends SluggableModel implements FuzzySearch, Subscribable
{
    use HasMetadata, Searchable;

    protected $dates = ['start_date', 'end_date'];

    public static function soon(): Collection
    {
        $nearestFuture = static::with('type')->published()->whereDate('start_date', '>', today()->subDay())->orderBy('start_date')->limit(3)->get();
        $soonest = static::with('type')->published()->orderBy('start_date', 'desc')->limit(3)->get();
        return $nearestFuture->count() >= 3 ? $nearestFuture : $soonest;
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(EventType::class, 'event_type_id');
    }

    public function getStartDate(): Carbon
    {
        return $this->{'start_date'};
    }

    public function getEndDate(): Carbon
    {
        return $this->{'end_date'};
    }

    public function getUrl(string $slug): string
    {
        return 'events/' . $slug;
    }

    public function getStory(): Story
    {
        return new Story($this->{'name'}, $this->getFullUrl(), $this->{'content'}, carbonise($this->{'published_at'}));
    }

    public function getFullUrl(): string
    {
        return sprintf('%s/events/%s', config('app.site_url'), $this->{'slug'});
    }
}
