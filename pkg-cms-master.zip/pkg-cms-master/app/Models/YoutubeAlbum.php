<?php

namespace App\Models;

class YoutubeAlbum extends SluggableModel implements FuzzySearch
{
   use Searchable;

    public function videos()
    {
        return $this->hasMany(YoutubeVideo::class);
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('banner')->singleFile();
    }

    public function searchable(): array
    {
        return ['name', 'description'];
    }

    public function fields(): array
    {
        return [
            'title' => 'name',
            'description' => 'description'
        ];
    }

    public function getUrl(string $slug) : string
    {
      return 'galleries/videos/'.$slug;
    }
}
