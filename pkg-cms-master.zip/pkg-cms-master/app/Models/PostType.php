<?php

namespace App\Models;

class PostType extends SluggableModel
{
    protected $guarded = [];
}
