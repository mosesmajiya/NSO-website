<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ScriptLock extends Model
{
    protected $guarded = [];

    public static function lock(string $tag): ?self
    {
        $script = static::firstOrCreate(['tag' => $tag]);
        if ($script->{'locked_at'}) return null;

        $script->update(['locked_at' => now(), 'runs' => $script->{'runs'} + 1]);
        return $script;
    }

    public function unlock(): void
    {
        $this->update(['locked_at' => null]);
    }
}
