<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class District extends SluggableModel
{
    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    public function censuses(): HasMany
    {
        return $this->hasMany(DistrictCensus::class);
    }
}
