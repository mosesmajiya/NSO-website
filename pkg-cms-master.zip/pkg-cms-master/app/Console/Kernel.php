<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('cms:queue-alerts')->everyMinute()->runInBackground();
        $schedule->command('cms:send-subscription-emails')->dailyAt('9:00')->runInBackground();
        $schedule->command('cms:send-subscription-emails')->dailyAt('11:00')->runInBackground();
        $schedule->command('cms:send-subscription-emails')->dailyAt('13:00')->runInBackground();
        $schedule->command('cms:send-subscription-emails')->dailyAt('15:00')->runInBackground();
        $schedule->command('cms:send-subscription-emails')->dailyAt('18:00')->runInBackground();
        $schedule->command('cms:unlock-scripts')->everyMinute()->runInBackground();
        $schedule->command('cms:clear-orphan-alerts')->daily()->runInBackground();
        $schedule->command('cms:clear-old-traffic-data')->everyMinute()->runInBackground();
        $schedule->command('queue:work --stop-when-empty')->everyMinute()->runInBackground();
        $schedule->command('telescope:prune')->dailyAt('3:00')->runInBackground();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
