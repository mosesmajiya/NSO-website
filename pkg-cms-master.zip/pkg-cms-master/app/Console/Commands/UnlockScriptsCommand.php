<?php

namespace App\Console\Commands;

use App\Services\ScriptUnlockService;
use Illuminate\Console\Command;

class UnlockScriptsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cms:unlock-scripts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Unlock one hour old hanging scripts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        return (new ScriptUnlockService())->run();
    }
}
