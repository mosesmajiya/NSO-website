<?php

namespace App\Console\Commands;

use App\Models\District;
use App\Models\DistrictCensus;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class UploadCensusDataCommand extends Command
{
    private $records = [];
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'census:upload';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Upload census data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle() : int
    {
        //district	population	population_density	poverty	life_expectancy_male	life_expectancy_female	fertility_rate	literacy
        $file = Storage::get('districts_census.csv');
        $records = collect(explode(PHP_EOL, $file));
        $attributes = $records->each(function(string $record){
            $record = str_replace("\r", '', $record);
            $attributes = explode(',', $record);
            try{
                $this->records[] = [
                    'district' => $attributes[0],
                    'population' => $attributes[1],
                    'population_density' => $attributes[2],
                    'poverty' => $attributes[3],
                    'life_expectancy_female' => $attributes[4],
                    'life_expectancy_male' => $attributes[5],
                    'fertility_rate' => $attributes[6],
                    'literacy' => $attributes[7],
                ];
            } catch(\Exception $exception){
                Log::error($exception->getMessage());
            }

        });

        collect($this->records)->each(function (array $record){
            $district = District::updateOrCreate([
                'name' => $record['district'],
            ], [
                'code' => $record['population'],
                'description' => 'desc',
                ]);
            $census = DistrictCensus::create(array_merge([
                'year' => '2018',
                'district_id' => $district->getKey(),
            ], collect($record)->except('district')->toArray()));
        });
        return 0;
    }
}
