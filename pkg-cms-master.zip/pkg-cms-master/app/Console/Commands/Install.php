<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class Install extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cms:install {--test}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Install the CMS';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        if (app()->environment() == "production" && $this->option("test")) {
            $this->error("You cannot install a test application in production environment");
            return;
        }

        $seeder = $this->option("test") ? "TestSeeder" : "DatabaseSeeder";

        if (!$this->confirm("This will delete all your data. Are you sure?")) {
            $this->info("The operation has been cancelled");
            return;
        }

        $this->info("Migrating the database");


        if (Artisan::call('migrate:fresh') != 0) {
            $this->error("Database migration failed");
            return;
        }

        $this->info("Database migration successful");

        if (Artisan::call("db:seed --class=$seeder") != 0) {
            $this->error("Failed to install the application");
        }

        $this->info("Application installed successfully");
    }
}
