<?php

namespace App\Console\Commands;

use App\Services\Subscriptions\QueueSubscriptionAlertsService;
use Illuminate\Console\Command;

class QueueAlertsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cms:queue-alerts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Make a queue of subscription alerts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(): int
    {
        return (new QueueSubscriptionAlertsService())->run();
    }
}
