<?php

namespace App\Console\Commands;

use App\Services\ClearOldTrafficDataService;
use Illuminate\Console\Command;

class ClearOldTrafficDataCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cms:clear-old-traffic-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clear old traffic data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        return (new ClearOldTrafficDataService())->service();
    }
}
