<?php

namespace App\Listeners;

use App\Events\SubscribablePublished;
use App\Models\Alert;

class CreateSubscriptionAlert
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param SubscribablePublished $event
     * @return void
     */
    public function handle(SubscribablePublished $event)
    {
        Alert::firstOrCreate([
            'subscribable_id' => $event->model->getKey(),
            'subscribable_type' => get_class($event->model)
        ]);
    }
}
