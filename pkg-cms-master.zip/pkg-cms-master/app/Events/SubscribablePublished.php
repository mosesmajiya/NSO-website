<?php

namespace App\Events;

use App\Models\SluggableModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class SubscribablePublished
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public SluggableModel $model;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(SluggableModel $model)
    {
        $this->model = $model;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
