<?php

namespace App\Exceptions;

use BlueCloud\ApiResponse\Exceptions\AbstractException;
use Throwable;

class UnauthorizedResourceException extends AbstractException
{
    public function __construct($message = "You are not authorized to access this resource", $code = 403, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
