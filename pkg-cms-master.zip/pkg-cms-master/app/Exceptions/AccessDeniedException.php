<?php

namespace App\Exceptions;

use BlueCloud\ApiResponse\Exceptions\AbstractException;
use Illuminate\Http\Response;
use Throwable;

class AccessDeniedException extends AbstractException
{
    public function __construct($message = "User not found", $code = Response::HTTP_UNAUTHORIZED, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
