<?php

namespace App\Exceptions;

use BlueCloud\ApiResponse\Exceptions\AbstractException;
use Throwable;

class InvalidCredentialsException extends AbstractException
{
    public function __construct($message = "The given credentials are invalid", $code = 412, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
