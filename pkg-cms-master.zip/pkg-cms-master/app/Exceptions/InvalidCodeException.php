<?php

namespace App\Exceptions;

use BlueCloud\ApiResponse\Exceptions\AbstractException;
use Throwable;

class InvalidCodeException extends AbstractException
{
    public function __construct($message = "The given code is invalid", $code = 400, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
