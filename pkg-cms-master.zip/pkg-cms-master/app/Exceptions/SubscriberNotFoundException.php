<?php

namespace App\Exceptions;

use BlueCloud\ApiResponse\Exceptions\AbstractException;
use Throwable;

class SubscriberNotFoundException extends AbstractException
{
    public function __construct($message = "", $code = 412, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
