<?php

namespace App\Providers;

use App\Services\Stats\DailyHits\DailyHitsService;
use App\Services\Stats\DailyHits\DailyHitsServiceInterface;
use App\Services\Stats\VisitorsByDevice\VisitorsByDeviceService;
use App\Services\Stats\VisitorsByDevice\VisitorsByDeviceServiceInterface;
use App\Services\Stats\VisitsByCountry\VisitsByCountryService;
use App\Services\Stats\VisitsByCountry\VisitsByCountryServiceInterface;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(DailyHitsServiceInterface::class, DailyHitsService::class);
        $this->app->bind(VisitsByCountryServiceInterface::class, VisitsByCountryService::class);
        $this->app->bind(VisitorsByDeviceServiceInterface::class, VisitorsByDeviceService::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
