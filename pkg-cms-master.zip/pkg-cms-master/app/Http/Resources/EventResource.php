<?php

namespace App\Http\Resources;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EventResource extends JsonResource
{
    /**
     * @var Event
     */
    private $event;

    public function __construct(Event $event)
    {
        parent::__construct($event);
        $this->event = $event;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        if ($this->event->hasMedia('banner'))
            $this->event->{'image'} = $this->event->getFirstMedia('banner')->getFullUrl();

        return array_merge($this->event->toArray(), [
            'start_date' => $this->event->getStartDate()->toDateTimeLocalString("minute"),
            'end_date' => $this->event->getEndDate()->toDateTimeLocalString("minute"),
            'in_progress' => $this->event->getStartDate()->isBefore(now()) && $this->event->getEndDate()->isAfter(now()),
            'past' => $this->event->getEndDate()->isBefore(now()),
        ]);
    }
}
