<?php

namespace App\Http\Resources;

use App\Models\Newsletter;
use Illuminate\Http\Request;

class NewsletterResource extends AbstractMediaResource
{
    /**
     * @var Newsletter
     */
    protected $post;

    public function __construct(Newsletter $post)
    {
        parent::__construct($post);
        $this->post = $post;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        $releases = $this->post->releases()->published()->orderByDesc('volume')->orderByDesc('issue')->get();

        return array_merge(
            $this->post->toArray(),
            $this->getBanner(),
            ['release_count' => $this->post->releases()->count()],
            ['releases' => NewsletterReleaseResource::collection($releases)]
        );
    }

}
