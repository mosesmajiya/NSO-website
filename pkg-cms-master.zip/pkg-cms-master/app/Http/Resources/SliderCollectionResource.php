<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Support\Collection;

class SliderCollectionResource extends ResourceCollection
{
    public $collects = SliderResource::class;
    private Collection $items;

    public function __construct(Collection $resource)
    {
        parent::__construct($resource);
        $this->items = $resource;
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return $this->items->toArray();
    }
}
