<?php

namespace App\Http\Resources;

use App\Models\Vacancy;
use Illuminate\Http\Request;

class VacancyResource extends AbstractMediaResource
{
    /**
     * @var Vacancy
     */
    protected $post;

    public function __construct(Vacancy $vacancy)
    {
        parent::__construct($vacancy);
        $this->post = $vacancy;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->post->toArray(), ['attachments' => $this->getAttachments()], $this->getBanner());
    }
}
