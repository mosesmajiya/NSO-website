<?php

namespace App\Http\Resources;

use App\Models\Project;
use Illuminate\Http\Request;

class ProjectResource extends AbstractMediaResource
{
    /** @var Project */
    protected $post;

    public function __construct(Project $project)
    {
        parent::__construct($project);
        $this->post = $project;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->post->toArray(), ['attachments' => $this->getAttachments()], $this->getBanner());
    }
}
