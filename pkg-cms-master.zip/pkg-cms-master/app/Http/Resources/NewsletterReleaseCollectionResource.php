<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Support\Collection;

class NewsletterReleaseCollectionResource extends ResourceCollection
{
    public $collects = NewsletterReleaseResource::class;

    public function __construct(Collection $collection)
    {
        parent::__construct($collection);
        $this->collection = $collection;
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return $this->collection->toArray();
    }
}
