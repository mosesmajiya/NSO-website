<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Pagination\LengthAwarePaginator;

class PostCollectionResource extends ResourceCollection
{
    public $collects = PostResource::class;
    /**
     * @var LengthAwarePaginator
     */
    private $paginator;

    public function __construct(LengthAwarePaginator $paginator)
    {
        parent::__construct($paginator);
        $this->paginator = $paginator;
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request): array
    {
        return $this->paginator->toArray();
    }
}
