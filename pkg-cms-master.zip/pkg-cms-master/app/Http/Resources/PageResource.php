<?php

namespace App\Http\Resources;

use App\Models\Page;
use Illuminate\Http\Request;

class PageResource extends AbstractMediaResource
{
    /**
     * @var Page
     */
    protected $post;

    public function __construct(Page $page)
    {
        parent::__construct($page);
        $this->post = $page;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        $page = $this->post->toArray();
        return array_merge($page, ['attachments' => $this->getAttachments()], $this->getBanner());
    }
}
