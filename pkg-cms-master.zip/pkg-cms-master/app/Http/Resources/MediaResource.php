<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class MediaResource extends JsonResource
{
    /** @var Media $resource */
    public $resource;

    public function __construct(Media $resource)
    {
        parent::__construct($resource);
        $this->resource = $resource;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->resource->toArray(), [
            'download' => url('api/download/' . $this->resource->getKey()),
            'url' => $this->resource->getFullUrl(),
            'humanized_size' => $this->resource->getHumanReadableSizeAttribute()
        ]);
    }
}
