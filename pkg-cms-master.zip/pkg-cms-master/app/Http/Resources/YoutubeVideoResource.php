<?php

namespace App\Http\Resources;

use App\Models\YoutubeAlbum;
use App\Models\YoutubeVideo;
use Illuminate\Http\Request;

class YoutubeVideoResource extends AbstractMediaResource
{
    /**
     * @var YoutubeVideo
     */
    protected $post;

    public function __construct(YoutubeAlbum $video)
    {
        parent::__construct($video);
        $this->post = $video;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge(
            $this->post->toArray(),
            ['attachments' => $this->getAttachments()],
            $this->getBanner(),
            ['videos' => $this->post->videos()->get()->toArray()]
        );
    }
}
