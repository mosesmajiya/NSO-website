<?php

namespace App\Http\Resources;

use App\Models\PhotoGallery;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PhotoGalleryResource extends AbstractMediaResource
{
    /**
     * @var PhotoGallery
     */
    protected $post;

    public function __construct(PhotoGallery $gallery)
    {
        parent::__construct($gallery);
        $this->post = $gallery;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge(
            $this->post->toArray(),
            $this->getCover(),
            ['photos' => $this->post->photos()->map(function (Media $photo) {
                return [
                    'url' => $photo->getFullUrl(),
                    'caption' => $photo->getCustomProperty('caption')
                ];
            })],
            ['total_photos' => $this->post->photos()->count()]
        );
    }
}
