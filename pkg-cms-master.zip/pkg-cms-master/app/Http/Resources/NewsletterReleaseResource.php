<?php

namespace App\Http\Resources;

use App\Models\NewsletterRelease;
use Illuminate\Http\Request;

class NewsletterReleaseResource extends AbstractMediaResource
{
    public function __construct(NewsletterRelease $post)
    {
        parent::__construct($post);
        $this->post = $post;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->post->toArray(), ['attachments' => $this->getAttachments()]);
    }
}
