<?php

namespace App\Http\Resources;

use App\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StaffResource extends JsonResource
{
    public function __construct(Staff $resource)
    {
        parent::__construct($resource);
        $this->resource = $resource;
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->resource->toArray(), [
            'position' => $this->resource->{'position'}->{'name'},
            'image_url' => $this->getAvatar()
        ]);
    }

    private function getAvatar(): string
    {
        if (!$this->resource->hasMedia('banner')) return '';
        return $this->resource->getFirstMedia('banner')->getFullUrl();
    }
}
