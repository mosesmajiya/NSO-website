<?php


namespace App\Http\Resources;


use App\Models\SluggableModel;
use Illuminate\Http\Resources\Json\JsonResource;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use function url;

abstract class AbstractMediaResource extends JsonResource
{
    /** @var SluggableModel */
    protected $post;

    protected function getBanner(): array
    {
        $media = $this->post->hasMedia('banner') ? $this->post->getFirstMedia('banner') : null;

        if (!$media) return [];

        return [
            'image_url' => $media->getFullUrl(),
            'caption' => $media->getCustomProperty('caption')
        ];
    }

    protected function getCover(): array
    {
        $media = $this->post->hasMedia('cover') ? $this->post->getFirstMedia('cover') : null;

        if (!$media) return [];

        return [
            'image_url' => $media->getFullUrl(),
        ];
    }

    protected function getAttachments(): array
    {
        $attachments = $this->post->hasMedia('attachment') ? $this->post->getMedia('attachment') : collect();
        if ($attachments->isEmpty()) return [];


        return $attachments->map(function (Media $attachment) {
            return [
                'url' => $attachment->getFullUrl(),
                'caption' => $attachment->getCustomProperty('caption'),
                'type' => $attachment->{'mime_type'},
                'id' => $attachment->getKey(),
                'download' => url('api/download/' . $attachment->getKey()),
                'size' => $attachment->getHumanReadableSizeAttribute()
            ];
        })->toArray();
    }
}
