<?php

namespace App\Http\Resources;

use App\Models\Department;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class DepartmentResource extends AbstractMediaResource
{
    /**
     * @var Department
     */
    protected $post;
    /**
     * @var Collection|mixed
     */
    private $staffCollection;
    /**
     * @var array|mixed
     */
    private $staff;

    public function __construct(Department $department)
    {
        parent::__construct($department);
        $this->post = $department;
        $this->staffCollection = new Collection();
    }

    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        $positions = $this->post->positions()
            ->whereHas('staff', function (Builder $builder) {
                return $builder->published();
            })
            ->orderBy('rank')->with('staff')->get();

        return array_merge($this->post->toArray(), ['staff' => $this->flattenStaffList($positions)]);
    }

    private function flattenStaffList(Collection $positions)
    {
        $allStaff = [];
        foreach ($positions as $position) {
            foreach ($position->{'staff'} as $staff) {
                if($staff->{'current'}==1){
                    $allStaff[] = new StaffResource($staff);
                }
            }
        }
        return $allStaff;
    }
}
