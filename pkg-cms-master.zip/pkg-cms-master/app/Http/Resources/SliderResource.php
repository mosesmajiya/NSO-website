<?php

namespace App\Http\Resources;

use App\Models\Slider;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class SliderResource extends AbstractMediaResource
{
    public function __construct(Slider $resource)
    {
        parent::__construct($resource);
        $this->post = $resource;
    }

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge($this->post->toArray(), $this->getCover());
    }
}
