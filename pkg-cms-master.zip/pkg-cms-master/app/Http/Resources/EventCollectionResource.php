<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Pagination\LengthAwarePaginator;

class EventCollectionResource extends ResourceCollection
{
    public $collects = EventResource::class;
    /**
     * @var LengthAwarePaginator
     */
    private $paginator;

    public function __construct(LengthAwarePaginator $paginator)
    {
        parent::__construct($paginator);
        $this->paginator = $paginator;
    }

    /**
     * Transform the resource collection into an array.
     *
     * @param Request $request
     * @return array
     */
    public function toArray($request)
    {
        return $this->paginator->toArray();
    }
}
