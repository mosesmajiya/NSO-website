<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\ProjectRequest;
use App\Models\Project;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class ProjectsController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Project::latest()->paginate(10)))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Project::recent()))->json();
    }


    public function show(Project $project)
    {
        return (new SuccessResponse($project->load('metadata', 'media')))->json();
    }

    public function update(Project $project, ProjectRequest $request)
    {
        $project->update($request->validated());
        return (new SuccessResponse($project->fresh()))->json();
    }

    public function destroy(Project $project)
    {
        $project->delete();
        return (new SuccessResponse())->json();
    }

    public function store(ProjectRequest $request)
    {
        return (new SuccessResponse(Project::create($request->validated())))->json();
    }

    public function publish(Project $project)
    {
        return (new SuccessResponse($project->publish()))->json();
    }

    public function unpublish(Project $project)
    {
        return (new SuccessResponse($project->unpublish()))->json();
    }

    public function attach(Project $project, string $collection, FileRequest $request)
    {
        $this->addFile($project, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Project $project, Media $media)
    {
        $project->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Project $project, string $collection)
    {
        return (new SuccessResponse($this->getFiles($project, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Project $project)
    {
        $project->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
