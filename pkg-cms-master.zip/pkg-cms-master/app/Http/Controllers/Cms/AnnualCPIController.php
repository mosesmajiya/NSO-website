<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\AnnualCPIRequest;
use App\Models\AnnualConsumerPriceIndex;
use Illuminate\Http\JsonResponse;

class AnnualCPIController extends Controller
{
    public function store(AnnualCPIRequest $request): JsonResponse
    {
        //if (!$request->totals100()) return $this->respond()->badRequest('The CPI values do not add up to 100')->json();

        AnnualConsumerPriceIndex::create(array_merge($request->validated()));

        return $this->respond()->ok()->json();
    }

    public function update(AnnualCPIRequest $request, AnnualConsumerPriceIndex $cpi): JsonResponse
    {
        //if (!$request->totals100()) return $this->respond()->badRequest('The CPI values do not add up to 100')->json();

        $cpi->update(array_merge($request->validated()));

        return $this->respond()->ok()->json();
    }

    public function destroy(AnnualConsumerPriceIndex $cpi): JsonResponse
    {
        $cpi->delete();
        return $this->respond()->ok()->json();
    }

    public function index(): JsonResponse
    {
        return $this->respond()->ok(AnnualConsumerPriceIndex::latest()->get())->json();
    }

    public function show(AnnualConsumerPriceIndex $cpi): JsonResponse
    {
        return $this->respond()->ok($cpi)->json();
    }
}
