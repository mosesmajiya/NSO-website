<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\CensusResourceRequest;
use App\Http\Requests\FileUploadRequest;
use App\Models\CensusResource;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CensusResourcesController extends Controller
{
    public function index(string $year): JsonResponse
    {
        $resources = CensusResource::where('year', $year)->latest()->with('media')->get()
            ->each(function (CensusResource $resource) {
                return array_merge($resource->toArray(), [
                    'resources' => $resource->getMedia()->map(function (Media $media) {
                        return [
                            'name' => $media->{'name'},
                            'url' => $media->getFullUrl(),
                            'size' => $media->getHumanReadableSizeAttribute()
                        ];
                    })
                ]);
            });
        return (new SuccessResponse($resources))->json();
    }

    public function show(string $year, CensusResource $resource): JsonResponse
    {
        $resource->load('media');

        return (new SuccessResponse($resource))->json();
    }

    public function store(CensusResourceRequest $request, string $year): JsonResponse
    {
        CensusResource::create(array_merge($request->validated(), ['year' => $year]));
        return (new SuccessResponse())->json();
    }

    public function upload(CensusResource $resource, FileUploadRequest $request): JsonResponse
    {
        $resource->addMedia($request->file('file'))->setName($request->get('caption'))->toMediaCollection();
        return (new SuccessResponse())->json();
    }

    public function destroyMedia(Media $media)
    {
        $media->delete();
        return (new SuccessResponse())->json();
    }

}
