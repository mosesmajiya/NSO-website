<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\NationalCensusRequest;
use App\Models\NationalCensus;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class NationalCensusController extends Controller
{
    public function store(NationalCensusRequest $request): JsonResponse
    {
        NationalCensus::create($request->validated());
        return (new SuccessResponse())->json();
    }

    public function index(): JsonResponse
    {
        return (new SuccessResponse(NationalCensus::all()))->json();
    }

    public function destroy(NationalCensus $census): JsonResponse
    {
        $census->forceDelete();
        return (new SuccessResponse())->json();
    }

    public function show(NationalCensus $census): JsonResponse
    {
        return (new SuccessResponse($census))->json();
    }

    public function update(NationalCensus $census, NationalCensusRequest $request): JsonResponse
    {
        $census->update($request->toArray());
        return (new SuccessResponse())->json();
    }
}
