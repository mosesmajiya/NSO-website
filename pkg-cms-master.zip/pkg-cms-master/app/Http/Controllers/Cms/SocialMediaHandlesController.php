<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\SocialMediaHandleRequest;
use App\Models\SocialMediaHandle;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class SocialMediaHandlesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(SocialMediaHandle::all()))->json();
    }

    public function show(SocialMediaHandle $socialMediaHandle)
    {
        return (new SuccessResponse($socialMediaHandle))->json();
    }

    public function update(SocialMediaHandle $socialMediaHandle, SocialMediaHandleRequest $request)
    {
        $socialMediaHandle->update($request->validated());
        return (new SuccessResponse($socialMediaHandle->fresh()))->json();
    }

    public function destroy(SocialMediaHandle $socialMediaHandle)
    {
        $socialMediaHandle->delete();
        return (new SuccessResponse())->json();
    }

    public function store(SocialMediaHandleRequest $request)
    {
        return (new SuccessResponse(SocialMediaHandle::create($request->validated())))->json();
    }
}
