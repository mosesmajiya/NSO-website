<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Role;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class RolesController extends Controller
{
    public function index(string $type)
    {
        return (new SuccessResponse(Role::where('type', $type)->get()))->json();
    }
}
