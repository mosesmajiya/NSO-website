<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\NewsletterReleaseRequest;
use App\Models\NewsletterRelease;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class NewsletterReleasesController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(NewsletterRelease::latest()->get()))->json();
    }

    public function show(NewsletterRelease $newsletterRelease)
    {
        return (new SuccessResponse($newsletterRelease->load('metadata', 'media')))->json();
    }

    public function publish(NewsletterRelease $newsletterRelease)
    {
        return (new SuccessResponse($newsletterRelease->publish()))->json();
    }

    public function unpublish(NewsletterRelease $newsletterRelease)
    {
        return (new SuccessResponse($newsletterRelease->unpublish()))->json();
    }

    public function update(NewsletterRelease $newsletterRelease, NewsletterReleaseRequest $request)
    {
        $newsletterRelease->update($request->validated());
        return (new SuccessResponse($newsletterRelease->fresh()))->json();
    }

    public function destroy(NewsletterRelease $newsletterRelease)
    {
        return (new SuccessResponse($newsletterRelease->delete()))->json();
    }

    public function store(NewsletterReleaseRequest $request)
    {
        return (new SuccessResponse(NewsletterRelease::create($request->validated())))->json();
    }

    public function metadata(MetadataRequest $request, NewsletterRelease $newsletterRelease)
    {
        $newsletterRelease->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }

    public function media(NewsletterRelease $newsletterRelease, string $collection)
    {
        return (new SuccessResponse($this->getFiles($newsletterRelease, $collection)))->json();
    }

    public function attach(NewsletterRelease $newsletterRelease, string $collection, FileRequest $request)
    {
        $this->addFile($newsletterRelease, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(NewsletterRelease $newsletterRelease, Media $media)
    {
        $newsletterRelease->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }
}
