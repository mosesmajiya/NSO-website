<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\SearchRequest;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    public function __invoke(SearchRequest $request)
    {
        $builder = DB::table($request->get('table'));

        $fields = explode(',', $request->get('fields'));
        $term = $request->get('term');

        $builder = $builder->where($fields[0], 'like', "%$term%");

        if (sizeof($fields) > 1) {
            for ($i = 1; $i < sizeof($fields); $i++) {
                $builder = $builder->orWhere($fields[$i], 'like', "%$term%");
            }
        }

        return (new SuccessResponse($builder->latest()->paginate(10)))->json();
    }
}
