<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Log;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\Request;

class LogsController extends Controller
{
    public function __invoke(Request $request)
    {
        return (new SuccessResponse(Log::with('user')->latest()->paginate(50)))->json();
    }
}
