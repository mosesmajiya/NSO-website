<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\SliderRequest;
use App\Models\Slider;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class SlidersController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Slider::orderBy('name')->paginate()))->json();
    }

    public function show(Slider $slider)
    {
        return (new SuccessResponse($slider->load('metadata', 'media')))->json();
    }

    public function update(Slider $slider, SliderRequest $request)
    {
        $slider->update($request->validated());
        return (new SuccessResponse($slider->fresh()))->json();
    }

    public function destroy(Slider $slider)
    {
        $slider->delete();
        return (new SuccessResponse())->json();
    }

    public function store(SliderRequest $request)
    {
        return (new SuccessResponse(Slider::create($request->validated())))->json();
    }

    public function publish(Slider $slider)
    {
        return (new SuccessResponse($slider->publish()))->json();
    }

    public function unpublish(Slider $slider)
    {
        return (new SuccessResponse($slider->unpublish()))->json();
    }

    public function attach(Slider $slider, string $collection, FileRequest $request)
    {
        $this->addFile($slider, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Slider $slider, Media $media)
    {
        $slider->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Slider $slider, string $collection)
    {
        return (new SuccessResponse($this->getFiles($slider, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Slider $slider)
    {
        $slider->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
