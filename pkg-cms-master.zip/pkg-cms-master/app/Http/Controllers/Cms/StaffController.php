<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\StaffRequest;
use App\Models\Staff;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class StaffController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Staff::all()))->json();
    }

    public function show(Staff $staff)
    {
        return (new SuccessResponse($staff->load('position', 'metadata')))->json();
    }

    public function update(Staff $staff, StaffRequest $request)
    {
        $staff->update($request->validated());
        return (new SuccessResponse($staff->fresh()))->json();
    }

    public function destroy(Staff $staff)
    {
        $staff->delete();
        return (new SuccessResponse())->json();
    }

    public function store(StaffRequest $request)
    {
        return (new SuccessResponse(Staff::create($request->validated())))->json();
    }

    public function publish(Staff $staff)
    {
        return (new SuccessResponse($staff->publish()))->json();
    }

    public function unpublish(Staff $staff)
    {
        return (new SuccessResponse($staff->unpublish()))->json();
    }

    public function attach(Staff $staff, string $collection, FileRequest $request)
    {
        $this->addFile($staff, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Staff $staff, Media $media)
    {
        $staff->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Staff $staff, string $collection)
    {
        return (new SuccessResponse($this->getFiles($staff, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Staff $staff)
    {
        $staff->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
