<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\EventTypeRequest;
use App\Models\EventType;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class EventTypesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(EventType::all()))->json();
    }

    public function show(EventType $eventType)
    {
        return (new SuccessResponse($eventType))->json();
    }

    public function update(EventType $eventType, EventTypeRequest $request)
    {
        $eventType->update($request->validated());
        return (new SuccessResponse($eventType->fresh()))->json();
    }

    public function destroy(EventType $eventType)
    {
        $eventType->delete();
        return (new SuccessResponse())->json();
    }

    public function store(EventTypeRequest $request)
    {
        return (new SuccessResponse(EventType::create($request->validated())))->json();
    }
}
