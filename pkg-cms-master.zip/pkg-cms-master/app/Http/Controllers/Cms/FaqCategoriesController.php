<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FaqCategoryRequest;
use App\Models\FaqCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class FaqCategoriesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(FaqCategory::orderBy('name')->withCount('faqs')->paginate(10)))->json();
    }

    public function show(FaqCategory $faqCategory)
    {
        return (new SuccessResponse($faqCategory->load('faqs')))->json();
    }

    public function update(FaqCategory $faqCategory, FaqCategoryRequest $request)
    {
        $faqCategory->update($request->validated());
        return (new SuccessResponse($faqCategory->fresh()))->json();
    }

    public function destroy(FaqCategory $faqCategory)
    {
        $faqCategory->delete();
        return (new SuccessResponse())->json();
    }

    public function store(FaqCategoryRequest $request)
    {
        return (new SuccessResponse(FaqCategory::create($request->validated())))->json();
    }

    public function publish(FaqCategory $faqCategory)
    {
        return (new SuccessResponse($faqCategory->publish()))->json();
    }

    public function unpublish(FaqCategory $faqCategory)
    {
        return (new SuccessResponse($faqCategory->unpublish()))->json();
    }
}
