<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\ReportSuperCategoryRequest;
use App\Models\ReportSuperCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class CensusReportSuperCategoriesController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(ReportSuperCategory::latest()->paginate()))->json();
    }

    public function store(ReportSuperCategoryRequest $request): JsonResponse
    {
        ReportSuperCategory::create($request->validated());
        return (new SuccessResponse())->json();
    }

    public function destroy(ReportSuperCategory $category): JsonResponse
    {
        $category->forceDelete();
        return (new SuccessResponse())->json();
    }

    public function show(ReportSuperCategory $category): JsonResponse
    {
        return (new SuccessResponse($category))->json();
    }

    public function update(ReportSuperCategory $category, ReportSuperCategoryRequest $request): JsonResponse
    {
        $category->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function publish(ReportSuperCategory $category): JsonResponse
    {
        $category->update(['published_at' => now()]);
        return (new SuccessResponse($category->fresh()))->json();
    }

    public function unpublish(ReportSuperCategory $category): JsonResponse
    {
        $category->update(['published_at' => null]);
        return (new SuccessResponse($category->fresh()))->json();
    }

    public function options(): JsonResponse
    {
        return (new SuccessResponse(ReportSuperCategory::published()->orderBy('name')->get(['name', 'id'])))->json();
    }
}
