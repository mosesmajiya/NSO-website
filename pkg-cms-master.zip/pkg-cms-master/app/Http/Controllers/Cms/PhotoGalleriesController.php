<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\PhotoGalleryRequest;
use App\Models\PhotoGallery;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PhotoGalleriesController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(PhotoGallery::latest()->paginate()))->json();
    }

    public function show(PhotoGallery $photoGallery)
    {
        return (new SuccessResponse($photoGallery->load('metadata', 'media')))->json();
    }

    public function update(PhotoGallery $photoGallery, PhotoGalleryRequest $request)
    {
        $photoGallery->update($request->validated());
        return (new SuccessResponse($photoGallery->fresh()))->json();
    }

    public function destroy(PhotoGallery $photoGallery)
    {
        $photoGallery->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PhotoGalleryRequest $request)
    {
        return (new SuccessResponse(PhotoGallery::create($request->validated())))->json();
    }

    public function publish(PhotoGallery $photoGallery)
    {
        return (new SuccessResponse($photoGallery->publish()))->json();
    }

    public function unpublish(PhotoGallery $photoGallery)
    {
        return (new SuccessResponse($photoGallery->unpublish()))->json();
    }

    public function attach(PhotoGallery $photoGallery, string $collection, FileRequest $request)
    {
        $this->addFile($photoGallery, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(PhotoGallery $photoGallery, Media $media)
    {
        $photoGallery->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(PhotoGallery $photoGallery, string $collection)
    {
        return (new SuccessResponse($this->getFiles($photoGallery, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, PhotoGallery $photoGallery)
    {
        $photoGallery->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
