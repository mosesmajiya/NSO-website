<?php


namespace App\Http\Controllers\Cms;


use App\Models\SluggableModel;
use Illuminate\Support\Collection;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

trait HandlesFiles
{
    protected function addFile(SluggableModel $model, string $collection, string $caption = null): void
    {
        $properties = $collection === 'attachment' ? ['caption' => $caption, 'downloads' => 0] : ['caption' => $caption];

        $model->addMediaFromRequest('file')
            ->withCustomProperties($properties)
            ->toMediaCollection($collection);

    }

    protected function getFiles(SluggableModel $model, string $collection): Collection
    {
        return $model->getMedia($collection)->reverse()->map(function (Media $media) {
            return array_merge([
                'url' => $media->getFullUrl(),
                'caption' => $media->getCustomProperty('caption'),
                'id' => $media->getKey(),
                'humanized_size' => $media->getHumanReadableSizeAttribute(),
                'created_at' => $media->{'created_at'},
                'download' => url('api/download/' . $media->getKey())
            ], $media->toArray());
        })->values();
    }
}
