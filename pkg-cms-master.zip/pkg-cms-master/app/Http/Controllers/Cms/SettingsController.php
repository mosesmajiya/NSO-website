<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\SettingRequest;
use App\Models\Setting;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class SettingsController extends Controller
{
    public function index()
    {
        $settings = Setting::getDefault();
        $result = $settings->toArray();

        if ($settings->hasMedia('logo'))
            $result['logo'] = $settings->getFirstMedia('logo')->getFullUrl();

        return (new SuccessResponse($result))->json();
    }

    public function show(Setting $setting)
    {
        return (new SuccessResponse($setting))->json();
    }

    public function update(Setting $setting, SettingRequest $request)
    {
        $setting->update($request->validated());
        return (new SuccessResponse($setting->fresh()))->json();
    }

    public function destroy(Setting $setting)
    {
        $setting->delete();
        return (new SuccessResponse())->json();
    }

    public function store(SettingRequest $request)
    {
        return (new SuccessResponse(Setting::create($request->validated())))->json();
    }
}
