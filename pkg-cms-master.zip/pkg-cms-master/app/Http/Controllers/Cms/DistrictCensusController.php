<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\DistrictCensusRequest;
use App\Models\District;
use App\Models\DistrictCensus;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class DistrictCensusController extends Controller
{
    public function store(DistrictCensusRequest $request, string $year): JsonResponse
    {
        DistrictCensus::create(array_merge(['year' => $year], $request->validated()));
        return (new SuccessResponse())->json();
    }

    public function index(int $year): JsonResponse
    {
        return (new SuccessResponse(DistrictCensus::where('year', $year)->with('district')->get()))->json();
    }

    public function destroy(DistrictCensus $census): JsonResponse
    {
        $census->forceDelete();
        return (new SuccessResponse())->json();
    }

    public function show(DistrictCensus $census): JsonResponse
    {
        $census->load('district.media');

        /** @var District $district */
        $district = $census->{'district'};

        if ($district->hasMedia()) $census->{'district'}->{'image_url'} = $district->getFirstMedia()->getFullUrl();

        return (new SuccessResponse($census))->json();
    }

    public function update(DistrictCensus $census, DistrictCensusRequest $request): JsonResponse
    {
        $census->update($request->validated());
        return (new SuccessResponse())->json();
    }
}
