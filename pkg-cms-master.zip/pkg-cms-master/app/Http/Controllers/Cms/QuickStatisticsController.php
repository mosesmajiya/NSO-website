<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\QuickStatisticsRequest;
use App\Models\QuickStat;
use Illuminate\Http\JsonResponse;

class QuickStatisticsController extends Controller
{
    public function index(): JsonResponse
    {
        return $this->respond()->ok(QuickStat::first())->json();
    }

    public function store(QuickStatisticsRequest $request) : JsonResponse
    {
        QuickStat::updateOrCreate([], $request->validated());

        return $this->respond()->ok()->json();
    }
}
