<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\CensusResource;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class CensusResourceTypesController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(CensusResource::all()))->json();
    }
}
