<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\MenuSetting;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class ToggleMenuSettingsController extends Controller
{
    public function __invoke(MenuSetting $menuSetting)
    {
        return (new SuccessResponse($menuSetting->toggle()))->json();
    }
}
