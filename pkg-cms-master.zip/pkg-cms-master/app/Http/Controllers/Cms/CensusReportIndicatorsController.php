<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\CensusReportIndicatorRequest;
use App\Models\Indicator;
use App\Models\Report;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class CensusReportIndicatorsController extends Controller
{
    public function store(CensusReportIndicatorRequest $request, Report $report): JsonResponse
    {
        return (new SuccessResponse($report->indicators()->create($request->validated())))->setLabel('indicator')
            ->json();
    }

    public function update(CensusReportIndicatorRequest $request, Indicator $indicator): JsonResponse
    {
        $indicator->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function destroy(Indicator $indicator): JsonResponse
    {
        $indicator->forceDelete();
        return (new SuccessResponse())->json();
    }

    public function show(Report $report): JsonResponse
    {
        return (new SuccessResponse($report->load('indicators')))->setLabel('report')->json();
    }
}
