<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\YoutubeAlbumCoverRequest;
use App\Http\Requests\YoutubeAlbumRequest;
use App\Models\YoutubeAlbum;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class YoutubeAlbumsController extends Controller
{
    use HandlesFiles;

    public function store(YoutubeAlbumRequest $request)
    {
        return (new SuccessResponse(YoutubeAlbum::create($request->validated())))->json();
    }

    public function attach(YoutubeAlbum $youtubeAlbum, string $collection, YoutubeAlbumCoverRequest $request)
    {
        $this->addFile($youtubeAlbum, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function media(YoutubeAlbum $youtubeAlbum, string $collection)
    {
        return (new SuccessResponse($this->getFiles($youtubeAlbum, $collection)))->json();
    }

    public function index()
    {
        return (new SuccessResponse(YoutubeAlbum::withCount('videos')->orderBy('name')->paginate(10)))->json();
    }

    public function show(YoutubeAlbum $youtubeAlbum)
    {
        return (new SuccessResponse($youtubeAlbum->load('videos')))->json();
    }

    public function update(YoutubeAlbumRequest $request, YoutubeAlbum $youtubeAlbum)
    {
        $youtubeAlbum->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function destroy(YoutubeAlbum $youtubeAlbum)
    {
        $youtubeAlbum->delete();
        return (new SuccessResponse())->json();
    }

    public function publish(YoutubeAlbum $youtubeAlbum)
    {
        return (new SuccessResponse($youtubeAlbum->publish()))->json();
    }

    public function unpublish(YoutubeAlbum $youtubeAlbum)
    {
        return (new SuccessResponse($youtubeAlbum->unpublish()))->json();
    }
}
