<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\VacancyRequest;
use App\Models\Vacancy;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class VacanciesController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Vacancy::orderBy('created_at', 'desc')->paginate(10)))->json();
    }

    public function show(Vacancy $vacancy)
    {
        return (new SuccessResponse($vacancy->load('metadata')))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Vacancy::recent()))->json();
    }

    public function update(Vacancy $vacancy, VacancyRequest $request)
    {
        $vacancy->update($request->validated());
        return (new SuccessResponse($vacancy->fresh()))->json();
    }

    public function destroy(Vacancy $vacancy)
    {
        $vacancy->delete();
        return (new SuccessResponse())->json();
    }

    public function store(VacancyRequest $request)
    {
        return (new SuccessResponse(Vacancy::create($request->validated())))->json();
    }

    public function publish(Vacancy $vacancy)
    {
        return (new SuccessResponse($vacancy->publish()))->json();
    }

    public function unpublish(Vacancy $vacancy)
    {
        return (new SuccessResponse($vacancy->unpublish()))->json();
    }

    public function attach(Vacancy $vacancy, string $collection, FileRequest $request)
    {
        $this->addFile($vacancy, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Vacancy $vacancy, Media $media)
    {
        $vacancy->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Vacancy $vacancy, string $collection)
    {
        return (new SuccessResponse($this->getFiles($vacancy, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Vacancy $vacancy)
    {
        $vacancy->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
