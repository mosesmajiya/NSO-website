<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\AboutRequest;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Models\About;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class AboutsController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(About::latest()->paginate(10)))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(About::recent()))->json();
    }

    public function show(About $about)
    {
        return (new SuccessResponse($about->load('metadata', 'media')))->json();
    }

    public function update(About $about, AboutRequest $request)
    {
        $about->update($request->validated());
        return (new SuccessResponse($about->fresh()))->json();
    }

    public function destroy(About $about)
    {
        $about->delete();
        return (new SuccessResponse())->json();
    }

    public function store(AboutRequest $request)
    {
        return (new SuccessResponse(About::create($request->validated())))->json();
    }

    public function publish(About $about)
    {
        return (new SuccessResponse($about->publish()))->json();
    }

    public function unpublish(About $about)
    {
        return (new SuccessResponse($about->unpublish()))->json();
    }

    public function attach(About $about, string $collection, FileRequest $request)
    {
        $this->addFile($about, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(About $about, Media $media)
    {
        $about->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(About $about, string $collection)
    {
        return (new SuccessResponse($this->getFiles($about, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, About $about)
    {
        $about->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }


}
