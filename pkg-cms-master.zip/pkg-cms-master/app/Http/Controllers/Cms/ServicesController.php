<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\ServiceRequest;
use App\Models\Service;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class ServicesController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Service::latest()->paginate(10)))->json();
    }

    public function show(Service $service)
    {
        return (new SuccessResponse($service->load('metadata')))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Service::recent()))->json();
    }

    public function update(Service $service, ServiceRequest $request)
    {
        $service->update($request->validated());
        return (new SuccessResponse($service->fresh()))->json();
    }

    public function destroy(Service $service)
    {
        $service->delete();
        return (new SuccessResponse())->json();
    }

    public function store(ServiceRequest $request)
    {
        return (new SuccessResponse(Service::create($request->validated())))->json();
    }

    public function publish(Service $service)
    {
        return (new SuccessResponse($service->publish()))->json();
    }

    public function unpublish(Service $service)
    {
        return (new SuccessResponse($service->unpublish()))->json();
    }

    public function attach(Service $service, string $collection, FileRequest $request)
    {
        $this->addFile($service, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Service $service, Media $media)
    {
        $service->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Service $service, string $collection)
    {
        return (new SuccessResponse($this->getFiles($service, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Service $service)
    {
        $service->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
