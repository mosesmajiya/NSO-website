<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\ImageRequest;
use App\Models\Report;
use Illuminate\Http\JsonResponse;

class ReportFeaturesController extends Controller
{
    public function store(Report $report, ImageRequest $request): JsonResponse
    {
        $report->addMedia($request->file('image'))->toMediaCollection('feature');
        $report->update(['featured_on' => now()]);

        return $this->respond()->ok()->json();
    }

    public function destroy(Report $report): JsonResponse
    {
        $report->getMedia('feature')->each->delete();
        $report->update(['featured_on' => null]);
        return $this->respond()->ok()->json();
    }

    public function show(Report $report): JsonResponse
    {
        if (!$report->hasMedia('feature'))
            return $this->respond()->ok(['featured' => false])->key('feature')->json();

        return $this->respond()->ok([
            'featured' => true,
            'id' => $report->getKey(),
            'image' => $report->getFirstMedia('feature')->getFullUrl()
        ])->key('feature')->json();
    }
}
