<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Subscriber;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\Request;

class SubscribersController extends Controller
{
    public function __invoke(Request $request)
    {
        return (new SuccessResponse(Subscriber::with('subscriptions')->orderByDesc('created_at')->paginate(50)))->json();
    }

    public function destroy(Subscriber $subscriber)
    {
        $subscriber->delete();
        return (new SuccessResponse())->json();
    }
}
