<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\AvatarRequest;
use App\Http\Requests\PasswordRequest;
use App\Models\User;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function store(Request $request)
    {
        $request->user()->update($request->only(['email', 'name']));
        return (new SuccessResponse())->json();
    }

    public function password(PasswordRequest $request)
    {
        $request->user()->update(['password' => Hash::make($request->get('new_password'))]);
        return (new SuccessResponse())->json();
    }

    public function avatar(AvatarRequest $request)
    {
        $request->user()->clearMediaCollection('avatar');
        $request->user()->addMediaFromRequest('file')->toMediaCollection('avatar');
        return (new SuccessResponse())->json();
    }

    public function show()
    {
        /** @var User $user */
        $user = \request()->user();
        $data = $user->toArray();

        if ($user->hasMedia('avatar'))
            $data['avatar'] = $user->getFirstMedia('avatar')->getFullUrl();

        return (new SuccessResponse($data))->json();
    }
}
