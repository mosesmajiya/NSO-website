<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\ReportRequest;
use App\Models\Download;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Exception;

class ReportsController extends Controller
{
    use HandlesFiles;

    public function store(ReportRequest $request)
    {
        return (new SuccessResponse(Download::create(
            array_merge($request->only(['name', 'description']), ['type' => 'report'])
        )))->json();
    }

    public function index()
    {
        return (new SuccessResponse(Download::where('type', 'report')->latest()->paginate()))->json();
    }

    public function show(Download $report)
    {
        return (new SuccessResponse($report->load('media')))->json();
    }

    public function attach(Download $report, string $collection, FileRequest $request)
    {
        $this->addFile($report, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }


    public function media(Download $report, string $collection)
    {
        return (new SuccessResponse($this->getFiles($report, $collection)))->json();
    }

    public function publish(Download $report)
    {
        return (new SuccessResponse($report->publish()))->json();
    }

    public function unpublish(Download $report)
    {
        return (new SuccessResponse($report->unpublish()))->json();
    }

    public function update(Download $report, ReportRequest $request)
    {
        $report->update($request->validated());
        return (new SuccessResponse($report->fresh()))->json();
    }

    public function destroy(Download $report)
    {
        try {
            $report->delete();
        } catch (Exception $e) {
        }
        return (new SuccessResponse())->json();
    }
}
