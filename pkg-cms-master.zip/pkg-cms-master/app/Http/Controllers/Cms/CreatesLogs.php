<?php


namespace App\Http\Controllers\Cms;


use App\Models\Log;

trait CreatesLogs
{
    public static function booted()
    {
        static::created(function ($model) {
            $model->creationLog();
        });

        static::updated(function ($model) {
            $model->editingLog();
        });

        static::deleting(function ($model) {
            $model->deleteLog();
        });
    }

    protected function creationLog(): Log
    {
        return $this->log('Created');
    }

    protected function log(string $event): Log
    {
        $user = auth()->user() ? auth()->id() : 1;

        $log = sprintf("$event %s %s", strtolower(class_basename(static::class)), $this->getLogColumn());
        return Log::create(['log' => $log, 'user_id' => $user]);
    }

    protected function getLogColumn()
    {
        return $this->{'name'};
    }

    protected function editingLog(): Log
    {
        return $this->log('Edited');
    }

    protected function deleteLog(): Log
    {
        return $this->log('Deleted');
    }

}
