<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\MonthlyCPIRequest;
use App\Models\MonthlyConsumerPriceIndex;
use Illuminate\Http\JsonResponse;

class MonthlyCPIController extends Controller
{
    public function store(MonthlyCPIRequest $request): JsonResponse
    {
        //if (!$request->totals100()) return $this->respond()->badRequest('The CPI values do not add up to 100')->json();

        MonthlyConsumerPriceIndex::create(array_merge($request->validated()));

        return $this->respond()->ok()->json();
    }

    public function update(MonthlyCPIRequest $request, MonthlyConsumerPriceIndex $cpi): JsonResponse
    {
        //if (!$request->totals100()) return $this->respond()->badRequest('The CPI values do not add up to 100')->json();

        $cpi->update(array_merge($request->validated()));

        return $this->respond()->ok()->json();
    }

    public function destroy(MonthlyConsumerPriceIndex $cpi): JsonResponse
    {
        $cpi->delete();
        return $this->respond()->ok()->json();
    }

    public function index(): JsonResponse
    {
        return $this->respond()->ok(MonthlyConsumerPriceIndex::latest()->get())->json();
    }

    public function show(MonthlyConsumerPriceIndex $cpi): JsonResponse
    {
        return $this->respond()->ok($cpi)->json();
    }
}
