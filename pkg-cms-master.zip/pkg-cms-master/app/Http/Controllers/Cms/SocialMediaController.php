<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\SocialMediaRequest;
use App\Models\SocialMedia;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class SocialMediaController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(SocialMedia::all()))->json();
    }

    public function show(SocialMedia $socialMedia)
    {
        return (new SuccessResponse($socialMedia))->json();
    }

    public function update(SocialMedia $socialMedia, SocialMediaRequest $request)
    {
        $socialMedia->update($request->validated());
        return (new SuccessResponse($socialMedia->fresh()))->json();
    }

    public function destroy(SocialMedia $socialMedia)
    {
        $socialMedia->delete();
        return (new SuccessResponse())->json();
    }

    public function store(SocialMediaRequest $request)
    {
        return (new SuccessResponse(SocialMedia::create($request->validated())))->json();
    }

    public function publish(SocialMedia $socialMedia)
    {
        return (new SuccessResponse($socialMedia->publish()))->json();
    }

    public function unpublish(SocialMedia $socialMedia)
    {
        return (new SuccessResponse($socialMedia->unpublish()))->json();
    }

    public function attach(SocialMedia $socialMedia, string $collection, FileRequest $request)
    {
        $socialMedia->addMediaFromRequest($request->get('file'))->toMediaCollection($collection);
        return (new SuccessResponse())->json();
    }

    public function detach(SocialMedia $socialMedia, Media $media)
    {
        $socialMedia->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(SocialMedia $socialMedia, string $collection)
    {
        return (new SuccessResponse($socialMedia->getMediaCollection($collection)))->json();
    }
}
