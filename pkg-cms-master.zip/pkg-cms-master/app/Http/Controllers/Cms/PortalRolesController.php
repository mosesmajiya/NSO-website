<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Role;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class PortalRolesController extends Controller
{
    public function __invoke(string $type): JsonResponse
    {
        return (new SuccessResponse(Role::where('type', $type)->get()))->json();
    }
}
