<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FaqRequest;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Models\Faq;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class FaqsController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Faq::latest()->paginate(10)))->json();
    }

    public function show(Faq $faq)
    {
        return (new SuccessResponse($faq->load('metadata')))->json();
    }

    public function update(Faq $faq, FaqRequest $request)
    {
        $faq->update($request->validated());
        return (new SuccessResponse($faq->fresh()))->json();
    }

    public function destroy(Faq $faq)
    {
        $faq->delete();
        return (new SuccessResponse())->json();
    }

    public function store(FaqRequest $request)
    {
        return (new SuccessResponse(Faq::create($request->validated())))->json();
    }

    public function publish(Faq $faq)
    {
        return (new SuccessResponse($faq->publish()))->json();
    }

    public function unpublish(Faq $faq)
    {
        return (new SuccessResponse($faq->unpublish()))->json();
    }

    public function attach(Faq $faq, string $collection, FileRequest $request)
    {
        $this->addFile($faq, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Faq $faq, Media $media)
    {
        $faq->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Faq $faq, string $collection)
    {
        return (new SuccessResponse($this->getFiles($faq, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Faq $faq)
    {
        $faq->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
