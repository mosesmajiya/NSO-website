<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\ReportCategoryRequest;
use App\Models\ReportCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class CensusReportCategoriesController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(ReportCategory::latest()->paginate()))->json();
    }

    public function store(ReportCategoryRequest $request): JsonResponse
    {
        ReportCategory::create($request->validated());
        return (new SuccessResponse())->json();
    }

    public function show(ReportCategory $category): JsonResponse
    {
        return (new SuccessResponse($category))->json();
    }

    public function destroy(ReportCategory $category): JsonResponse
    {
        $category->forceDelete();
        return (new SuccessResponse())->json();
    }

    public function update(ReportCategory $category, ReportCategoryRequest $request): JsonResponse
    {
        $category->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function publish(ReportCategory $category): JsonResponse
    {
        $category->update(['published_at' => now()]);
        return (new SuccessResponse($category->fresh()))->json();
    }

    public function unpublish(ReportCategory $category): JsonResponse
    {
        $category->update(['published_at' => null]);
        return (new SuccessResponse($category->fresh()))->json();
    }

    public function options(): JsonResponse
    {
        return (new SuccessResponse(ReportCategory::published()->orderBy('name')->get(['id', 'name'])))->json();
    }
}
