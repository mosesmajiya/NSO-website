<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\CensusReportRequest;
use App\Http\Requests\ReportDocumentRequest;
use App\Models\Report;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CensusReportsController extends Controller
{
    public function store(CensusReportRequest $request): JsonResponse
    {
        /** @var Report $report */
        $report = Report::create($request->only('title', 'abstract', 'source', 'report_category_id'));
        $report->superCategories()->attach(json_decode($request->get('report_super_categories')));
        return (new SuccessResponse())->json();
    }

    public function index(): JsonResponse
    {
        $reports = Report::with('category', 'superCategories')->latest()->paginate();
        return (new SuccessResponse($reports))->json();
    }

    public function show(Report $report): JsonResponse
    {
        $report = $report->load('category', 'superCategories');
        $response = array_merge($report->toArray(), ['documents' => $report->getMedia()->map(function (Media $media) {
            return [
                'filesize' => $media->getHumanReadableSizeAttribute(),
                'url' => $media->getFullUrl(),
                'name' => $media->{'name'},
                'id' => $media->getKey(),
            ];
        })]);
        return (new SuccessResponse($response))->json();
    }

    public function publish(Report $report): JsonResponse
    {
        $report->update(['published_at' => now()]);
        return (new SuccessResponse($report->fresh()))->json();
    }

    public function unpublish(Report $report): JsonResponse
    {
        $report->update(['published_at' => null]);
        return (new SuccessResponse($report->fresh()))->json();
    }

    public function destroy(Report $report): JsonResponse
    {
        $report->superCategories()->detach($report->superCategories);
        $report->indicators()->delete();
        $report->delete();
        return (new SuccessResponse())->json();
    }

    public function update(Report $report, CensusReportRequest $request): JsonResponse
    {
        $report->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function destroyMedia(Report $report, Media $media): JsonResponse
    {
        $media->{'model'}->deleteMedia($media->getKey());

        return $this->respond()->ok($report->fresh())->key('report')->json();
    }

    public function addMedia(Report $report, ReportDocumentRequest $request): JsonResponse
    {
        $report->addMedia($request->file('file'))->setName($request->get('name'))->toMediaCollection();

        return (new SuccessResponse($report->fresh()))->setLabel('report')->json();
    }
}
