<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\CensusMediaRequest;
use App\Models\NationalCensus;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class NationalCensusMediaController extends Controller
{
    public function store(CensusMediaRequest $request, NationalCensus $census): JsonResponse
    {
        $census->addMedia($request->file('file'))->toMediaCollection($request->get('collection'));
        return (new SuccessResponse())->json();
    }
}
