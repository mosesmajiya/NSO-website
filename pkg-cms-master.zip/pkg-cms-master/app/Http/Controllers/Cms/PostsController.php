<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\PostRequest;
use App\Models\Post;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PostsController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Post::latest()->with('type')->paginate(10)))->json();
    }

    public function show(Post $post)
    {
        return (new SuccessResponse($post->load('metadata')))->json();
    }

    public function update(Post $post, PostRequest $request)
    {
        $post->update($request->validated());
        return (new SuccessResponse($post->fresh()))->json();
    }

    public function destroy(Post $post)
    {
        $post->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PostRequest $request)
    {
        return (new SuccessResponse(Post::create($request->validated())))->json();
    }

    public function publish(Post $post)
    {
        return (new SuccessResponse($post->publish()))->json();
    }

    public function unpublish(Post $post)
    {
        return (new SuccessResponse($post->unpublish()))->json();
    }

    public function attach(Post $post, string $collection, FileRequest $request)
    {
        $this->addFile($post, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Post $post, Media $media)
    {
        $post->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Post $post, string $collection)
    {
        return (new SuccessResponse($this->getFiles($post, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Post $post)
    {
        $post->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
