<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\BrandingRequest;
use App\Models\Setting;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class BrandingController extends Controller
{
    public function store(BrandingRequest $request)
    {
        Setting::pull()->addMediaFromRequest('file')->toMediaCollection('logo');
        return (new SuccessResponse())->json();
    }

    public function index()
    {
        $image = Setting::pull()->getFirstMedia('logo');
        $image = $image ? $image->getFullUrl() : $image;
        return (new SuccessResponse($image))->json();
    }
}
