<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\DistrictRequest;
use App\Models\District;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class DistrictsController extends Controller
{
    public function store(DistrictRequest $request): JsonResponse
    {
        District::create($request->validated());
        return (new SuccessResponse())->json();
    }

    public function destroy(District $district): JsonResponse
    {
        $district->delete();
        return (new SuccessResponse())->json();
    }

    public function update(DistrictRequest $request, District $district): JsonResponse
    {
        $district->update($request->validated());
        return (new SuccessResponse())->json();
    }

    public function show(District $district): JsonResponse
    {
        if ($district->hasMedia()) {
            $district->{'image'} = $district->getFirstMedia()->getFullUrl();
            $district->{'image_id'} = $district->getFirstMedia()->getKey();
        }

        return (new SuccessResponse($district->load('region')))->json();
    }

    public function index(): JsonResponse
    {
        return (new SuccessResponse(District::with('region')->orderBy('name')->get()))->json();
    }
}
