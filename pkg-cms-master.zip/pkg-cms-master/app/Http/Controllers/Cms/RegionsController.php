<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Region;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class RegionsController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(Region::all()))->json();
    }
}
