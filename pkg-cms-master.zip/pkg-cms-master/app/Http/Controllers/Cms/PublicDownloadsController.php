<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PublicDownloadRequest;
use App\Models\Download;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Exception;

class PublicDownloadsController extends Controller
{
    use HandlesFiles;

    public function store(PublicDownloadRequest $request)
    {
        return (new SuccessResponse(Download::create(
            ['name' => $request->get('name'), 'type' => 'public']
        )))->json();
    }

    public function index()
    {
        return (new SuccessResponse(Download::where('type', 'public')->latest()->paginate()))->json();
    }

    public function show(Download $publicDownload)
    {
        return (new SuccessResponse($publicDownload->load('media')))->json();
    }

    public function attach(Download $publicDownload, string $collection, FileRequest $request)
    {
        $this->addFile($publicDownload, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }


    public function media(Download $publicDownload, string $collection)
    {
        return (new SuccessResponse($this->getFiles($publicDownload, $collection)))->json();
    }

    public function publish(Download $publicDownload)
    {
        return (new SuccessResponse($publicDownload->publish()))->json();
    }

    public function unpublish(Download $publicDownload)
    {
        return (new SuccessResponse($publicDownload->unpublish()))->json();
    }

    public function update(Download $publicDownload, PublicDownloadRequest $request)
    {
        $publicDownload->update($request->validated());
        return (new SuccessResponse($publicDownload->fresh()))->json();
    }

    public function destroy(Download $publicDownload)
    {
        try {
            $publicDownload->delete();
        } catch (Exception $e) {
        }
        return (new SuccessResponse())->json();
    }
}
