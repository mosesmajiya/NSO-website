<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\PostTypeRequest;
use App\Models\PostType;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class PostTypesController extends Controller
{
    public function store(PostTypeRequest $request)
    {
        return (new SuccessResponse(PostType::create($request->validated())))->json();
    }

    public function index()
    {
        return (new SuccessResponse(PostType::orderBy('name')->paginate(10)))->json();
    }

    public function show(PostType $postType)
    {
        return (new SuccessResponse($postType))->json();
    }

    public function destroy(PostType $postType)
    {
        $postType->delete();
        return (new SuccessResponse())->json();
    }

    public function update(PostTypeRequest $request, PostType $postType)
    {
        $postType->update($request->validated());
        return (new SuccessResponse())->json();
    }
}
