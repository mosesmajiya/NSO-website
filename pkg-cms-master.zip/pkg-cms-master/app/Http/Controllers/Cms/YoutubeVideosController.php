<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\YoutubeVideoRequest;
use App\Models\YoutubeVideo;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class YoutubeVideosController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(YoutubeVideo::latest()->get()))->json();
    }

    public function show(YoutubeVideo $youtubeVideo)
    {
        return (new SuccessResponse($youtubeVideo))->json();
    }

    public function update(YoutubeVideo $youtubeVideo, YoutubeVideoRequest $request)
    {
        $youtubeVideo->update($request->validated());
        return (new SuccessResponse($youtubeVideo->fresh()))->json();
    }

    public function destroy(YoutubeVideo $youtubeVideo)
    {
        $youtubeVideo->delete();
        return (new SuccessResponse())->json();
    }

    public function store(YoutubeVideoRequest $request)
    {
        return (new SuccessResponse(YoutubeVideo::create($request->validated())))->json();
    }

    public function publish(YoutubeVideo $youtubeVideo)
    {
        return (new SuccessResponse($youtubeVideo->publish()))->json();
    }

    public function unpublish(YoutubeVideo $youtubeVideo)
    {
        return (new SuccessResponse($youtubeVideo->unpublish()))->json();
    }

    public function attach(YoutubeVideo $youtubeVideo, string $collection, FileRequest $request)
    {
        $youtubeVideo->addMediaFromRequest($request->get('file'))->toMediaCollection($collection);
        return (new SuccessResponse())->json();
    }

    public function detach(YoutubeVideo $youtubeVideo, Media $media)
    {
        $youtubeVideo->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(YoutubeVideo $youtubeVideo, string $collection)
    {
        return (new SuccessResponse($youtubeVideo->getMediaCollection($collection)))->json();
    }
}
