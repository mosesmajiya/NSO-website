<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\CensusMediaRequest;
use App\Models\NationalCensus;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CensusMediaController extends Controller
{
    public function store(CensusMediaRequest $request, NationalCensus $census): JsonResponse
    {
        $census->addMedia($request->file('file'))->toMediaCollection($request->get('collection'));

        return $this->respond()->ok()->json();
    }

    public function index(NationalCensus $census): JsonResponse
    {
        $media = $census->getMedia('images')->map(function (Media $media) {
            return [
                'id' => $media->getKey(),
                'url' => $media->getFullUrl()
            ];
        });
        return $this->respond()->ok($media)->key('media')->json();
    }

    public function destroy(Media $media): JsonResponse
    {
        $media->{'model'}->deleteMedia($media->getKey());
        return $this->respond()->ok()->json();
    }
}
