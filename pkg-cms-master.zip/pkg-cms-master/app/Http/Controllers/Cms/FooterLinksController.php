<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\LinkRequest;
use App\Models\Link;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class FooterLinksController extends Controller
{
    public function store(LinkRequest $request)
    {
        return (new SuccessResponse(Link::create($request->validated())))->json();
    }

    public function index()
    {
        return (new SuccessResponse(Link::orderBy('name')->paginate(10)))->json();
    }

    public function show(Link $footer_link)
    {
        return (new SuccessResponse($footer_link))->json();
    }

    public function destroy(Link $footer_link)
    {
        $footer_link->delete();
        return (new SuccessResponse())->json();
    }

    public function update(LinkRequest $request, Link $footer_link)
    {
        $footer_link->update($request->validated());
        return (new SuccessResponse())->json();
    }
}
