<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\NewsletterRequest;
use App\Models\Newsletter;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Database\Eloquent\Relations\Relation;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class NewslettersController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Newsletter::withCount('releases')->latest()->paginate()))->json();
    }

    public function show(Newsletter $newsletter)
    {
        $newsletter = $newsletter->load(['releases' => function (Relation $relation) {
            return $relation->orderByDesc('volume')->orderByDesc('issue');
        }, 'metadata']);
        return (new SuccessResponse($newsletter))->json();
    }

    public function update(Newsletter $newsletter, NewsletterRequest $request)
    {
        $newsletter->update($request->validated());
        return (new SuccessResponse($newsletter->fresh()))->json();
    }

    public function destroy(Newsletter $newsletter)
    {
        $newsletter->delete();
        return (new SuccessResponse())->json();
    }

    public function store(NewsletterRequest $request)
    {
        return (new SuccessResponse(Newsletter::create($request->validated())))->json();
    }

    public function publish(Newsletter $newsletter)
    {
        return (new SuccessResponse($newsletter->publish()))->json();
    }

    public function unpublish(Newsletter $newsletter)
    {
        return (new SuccessResponse($newsletter->unpublish()))->json();
    }

    public function attach(Newsletter $newsletter, string $collection, FileRequest $request)
    {
        $this->addFile($newsletter, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Newsletter $newsletter, Media $media)
    {
        $newsletter->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Newsletter $newsletter, string $collection)
    {
        return (new SuccessResponse($this->getFiles($newsletter, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Newsletter $newsletter)
    {
        $newsletter->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
