<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Report;
use App\Models\ReportSuperCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReportSuperCategoriesController extends Controller
{
    public function index(Report $report): JsonResponse
    {
        return (new SuccessResponse($report->load('superCategories')))->setLabel('report')->json();
    }

    public function store(Report $report, Request $request): JsonResponse
    {
        $report->superCategories()->attach($request->get('category'));
        return (new SuccessResponse($report->load('superCategories')))->setLabel('report')->json();
    }

    public function destroy(Report $report, ReportSuperCategory $category): JsonResponse
    {
        $report->superCategories()->detach($category);
        return (new SuccessResponse($report->load('superCategories')))->setLabel('report')->json();
    }
}
