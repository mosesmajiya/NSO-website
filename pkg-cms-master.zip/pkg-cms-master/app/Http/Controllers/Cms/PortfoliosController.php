<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PortfolioRequest;
use App\Models\Portfolio;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PortfoliosController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Portfolio::latest()->get()))->json();
    }

    public function show(Portfolio $portfolio)
    {
        return (new SuccessResponse($portfolio))->json();
    }

    public function update(Portfolio $portfolio, PortfolioRequest $request)
    {
        $portfolio->update($request->validated());
        return (new SuccessResponse($portfolio->fresh()))->json();
    }

    public function destroy(Portfolio $portfolio)
    {
        $portfolio->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PortfolioRequest $request)
    {
        return (new SuccessResponse(Portfolio::create($request->validated())))->json();
    }

    public function publish(Portfolio $portfolio)
    {
        return (new SuccessResponse($portfolio->publish()))->json();
    }

    public function unpublish(Portfolio $portfolio)
    {
        return (new SuccessResponse($portfolio->unpublish()))->json();
    }

    public function attach(Portfolio $portfolio, string $collection, FileRequest $request)
    {
        $portfolio->addMediaFromRequest($request->get('file'))->toMediaCollection($collection);
        return (new SuccessResponse())->json();
    }

    public function detach(Portfolio $portfolio, Media $media)
    {
        $portfolio->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Portfolio $portfolio, string $collection)
    {
        return (new SuccessResponse($portfolio->getMediaCollection($collection)))->json();
    }
}
