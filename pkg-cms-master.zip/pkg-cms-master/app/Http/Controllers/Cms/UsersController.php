<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Requests\UserRequest;
use App\Models\User;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class UsersController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(User::orderBy('name')->paginate(10)))->json();
    }

    public function show(User $user)
    {
        return (new SuccessResponse($user))->json();
    }

    public function update(User $user, UpdateUserRequest $request)
    {
        $user->update($request->validated());
        return (new SuccessResponse($user->fresh()))->json();
    }

    public function destroy(User $user)
    {
        $user->delete();
        return (new SuccessResponse())->json();
    }

    public function store(UserRequest $request)
    {
        $user = User::add($request->only('email', 'password', 'name'));
        $user->roles()->attach($request->get('roles'));

        return (new SuccessResponse())->json();
    }
}
