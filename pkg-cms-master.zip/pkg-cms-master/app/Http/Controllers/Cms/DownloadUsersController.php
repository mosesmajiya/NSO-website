<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\DownloadUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Mail\DownloadUserCreated;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Mail;

class DownloadUsersController extends Controller
{
    public function store(DownloadUserRequest $request): JsonResponse
    {
        $password = strtolower(generate_key());
        $user = User::add(array_merge(['password' => $password], $request->only('email', 'name')));
        $user->roles()->attach($request->get('roles'));

        Mail::queue(new DownloadUserCreated($user, $password));
        return $this->respond()->ok()->json();
    }

    public function index(): JsonResponse
    {
        $users = User::whereHas('roles', function (Builder $q) {
            $q->where('type', 'portal');
        })->paginate();

        return $this->respond()->ok($users)->key('users')->json();
    }

    public function update(User $user, UpdateUserRequest $request): JsonResponse
    {
        $user->update($request->validated());
        return $this->respond()->ok()->json();
    }

    public function destroy(User $user): JsonResponse
    {
        $user->delete();
        return $this->respond()->ok()->json();
    }
}
