<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Department;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class DepartmentPositions extends Controller
{
    public function index(Department $department)
    {
        return (new SuccessResponse($department->positions()->get()))->json();
    }
}
