<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PrivateDownloadRequest;
use App\Models\Download;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Exception;
use Illuminate\Http\JsonResponse;

class PrivateDownloadsController extends Controller
{
    use HandlesFiles;

    public function store(PrivateDownloadRequest $request): JsonResponse
    {
        /** @var Download $download */
        $download = Download::create(['name' => $request->get('name'), 'type' => 'private']);
        $download->roles()->sync($request->get('roles'));
        return $this->respond()->ok()->json();
    }

    public function index()
    {
        return (new SuccessResponse(Download::where('type', 'private')->paginate()))->json();
    }

    public function show(Download $privateDownload)
    {
        return (new SuccessResponse($privateDownload->load('media', 'roles')))->json();
    }

    public function attach(Download $privateDownload, string $collection, FileRequest $request)
    {
        $this->addFile($privateDownload, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }


    public function media(Download $privateDownload, string $collection)
    {
        return (new SuccessResponse($this->getFiles($privateDownload, $collection)))->json();
    }

    public function publish(Download $privateDownload)
    {
        return (new SuccessResponse($privateDownload->publish()))->json();
    }

    public function unpublish(Download $privateDownload)
    {
        return (new SuccessResponse($privateDownload->unpublish()))->json();
    }

    public function update(Download $privateDownload, PrivateDownloadRequest $request)
    {
        $privateDownload->update($request->only('name'));
        $privateDownload->roles()->sync($request->get('roles'));
        return (new SuccessResponse($privateDownload->fresh()))->json();
    }

    public function destroy(Download $privateDownload)
    {
        try {
            $privateDownload->delete();
        } catch (Exception $e) {
        }
        return (new SuccessResponse())->json();
    }
}
