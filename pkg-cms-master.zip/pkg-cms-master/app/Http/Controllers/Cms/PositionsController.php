<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PositionRequest;
use App\Models\Position;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PositionsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Position::orderBy('name')->paginate(10)))->json();
    }

    public function show(Position $position)
    {
        return (new SuccessResponse($position))->json();
    }

    public function update(Position $position, PositionRequest $request)
    {
        $position->update($request->validated());
        return (new SuccessResponse($position->fresh()))->json();
    }

    public function destroy(Position $position)
    {
        $position->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PositionRequest $request)
    {
        return (new SuccessResponse(Position::create($request->validated())))->json();
    }

    public function publish(Position $position)
    {
        return (new SuccessResponse($position->publish()))->json();
    }

    public function unpublish(Position $position)
    {
        return (new SuccessResponse($position->unpublish()))->json();
    }

    public function attach(Position $position, string $collection, FileRequest $request)
    {
        $position->addMediaFromRequest($request->get('file'))->toMediaCollection($collection);
        return (new SuccessResponse())->json();
    }

    public function detach(Position $position, Media $media)
    {
        $position->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Position $position, string $collection)
    {
        return (new SuccessResponse($position->getMediaCollection($collection)))->json();
    }
}
