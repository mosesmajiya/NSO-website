<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegionalCensusRequest;
use App\Models\RegionalCensus;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class RegionalCensusController extends Controller
{
    public function index(string $year): JsonResponse
    {
        return (new SuccessResponse(RegionalCensus::where('year', $year)->with('region')->get()))->json();
    }

    public function store(RegionalCensusRequest $request, string $year): JsonResponse
    {
        RegionalCensus::create(array_merge($request->validated(), ['year' => $year]));
        return (new SuccessResponse())->json();
    }

    public function update(RegionalCensus $census, RegionalCensusRequest $request): JsonResponse
    {
        $census->update($request->validated());
        return (new SuccessResponse())->json();
    }
}
