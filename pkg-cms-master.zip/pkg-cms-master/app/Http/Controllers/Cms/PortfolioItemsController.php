<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PortfolioItemRequest;
use App\Models\PortfolioItem;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PortfolioItemsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(PortfolioItem::latest()->get()))->json();
    }

    public function show(PortfolioItem $portfolioItem)
    {
        return (new SuccessResponse($portfolioItem))->json();
    }

    public function update(PortfolioItem $portfolioItem, PortfolioItemRequest $request)
    {
        $portfolioItem->update($request->validated());
        return (new SuccessResponse($portfolioItem->fresh()))->json();
    }

    public function destroy(PortfolioItem $portfolioItem)
    {
        $portfolioItem->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PortfolioItemRequest $request)
    {
        return (new SuccessResponse(PortfolioItem::create($request->validated())))->json();
    }

    public function publish(PortfolioItem $portfolioItem)
    {
        return (new SuccessResponse($portfolioItem->publish()))->json();
    }

    public function unpublish(PortfolioItem $portfolioItem)
    {
        return (new SuccessResponse($portfolioItem->unpublish()))->json();
    }

    public function attach(PortfolioItem $portfolioItem, string $collection, FileRequest $request)
    {
        $portfolioItem->addMediaFromRequest($request->get('file'))->toMediaCollection($collection);
        return (new SuccessResponse())->json();
    }

    public function detach(PortfolioItem $portfolioItem, Media $media)
    {
        $portfolioItem->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(PortfolioItem $portfolioItem, string $collection)
    {
        return (new SuccessResponse($portfolioItem->getMediaCollection($collection)))->json();
    }
}
