<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\PublicDownloadRequest;
use App\Http\Requests\SpeechRequest;
use App\Models\Download;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Exception;

class SpeechesController extends Controller
{
    use HandlesFiles;

    public function store(SpeechRequest $request)
    {
        return (new SuccessResponse(Download::create(
            array_merge($request->only(['name', 'description']), ['type' => 'speech'])
        )))->json();
    }

    public function index()
    {
        return (new SuccessResponse(Download::where('type', 'speech')->latest()->paginate()))->json();
    }

    public function show(Download $speech)
    {
        return (new SuccessResponse($speech->load('media')))->json();
    }

    public function attach(Download $speech, string $collection, FileRequest $request)
    {
        $this->addFile($speech, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }


    public function media(Download $speech, string $collection)
    {
        return (new SuccessResponse($this->getFiles($speech, $collection)))->json();
    }

    public function publish(Download $speech)
    {
        return (new SuccessResponse($speech->publish()))->json();
    }

    public function unpublish(Download $speech)
    {
        return (new SuccessResponse($speech->unpublish()))->json();
    }

    public function update(Download $speech, PublicDownloadRequest $request)
    {
        $speech->update($request->validated());
        return (new SuccessResponse($speech->fresh()))->json();
    }

    public function destroy(Download $speech)
    {
        try {
            $speech->delete();
        } catch (Exception $e) {
        }
        return (new SuccessResponse())->json();
    }
}
