<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\MediaRequest;
use App\Models\District;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DistrictMediaController extends Controller
{
    public function store(MediaRequest $request, District $district): JsonResponse
    {
        $district->addMedia($request->file('file'))->toMediaCollection();
        return (new SuccessResponse())->json();
    }

    public function destroy(District $district, Media $media): JsonResponse
    {
        $district->deleteMedia($media);
        return (new SuccessResponse())->json();
    }
}
