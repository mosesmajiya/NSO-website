<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Report;
use App\Models\Subscriber;
use App\Models\Traffic;
use App\Services\Stats\DailyHits\DailyHitsClient;
use App\Services\Stats\VisitorsByDevice\VisitorsByDeviceClient;
use App\Services\Stats\VisitsByCountry\VisitsByCountryClient;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class DashboardController extends Controller
{
    public function dailyHits()
    {
        return (new SuccessResponse((new DailyHitsClient())->get()))->json();
    }

    public function visitsByCountry()
    {
        return (new SuccessResponse((new VisitsByCountryClient())->get()))->json();
    }

    public function visitorsByDevice()
    {
        return (new SuccessResponse((new VisitorsByDeviceClient())->get()))->json();
    }

    public function visitorsToday()
    {
        return (new SuccessResponse(['visitors_today' => Traffic::getForToday()]))->json();
    }

    public function visitorsThisMonth()
    {
        return (new SuccessResponse(['visitors_this_month' => Traffic::getForThisMonth()]))->json();
    }

    public function totalSubscribers()
    {
        return (new SuccessResponse(['total_subscribers' => Subscriber::count()]))->json();
    }

    public function popularArticles()
    {
        $articles = Post::published()->popular()->with('type')->take(3)->get()->map(function (Post $post) {
            if ($post->hasMedia('banner'))
                $post->{'image'} = $post->getFirstMedia('banner')->getFullUrl();

            return $post;
        });
        return (new SuccessResponse($articles))->json();
    }

    public function popularReports()
    {
        $articles = Report::published()->popular()->take(3)->get();
        return (new SuccessResponse($articles))->json();
    }
}
