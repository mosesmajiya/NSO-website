<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Requests\PageRequest;
use App\Models\Page;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PagesController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Page::latest()->paginate(10)))->json();
    }

    public function show(Page $page)
    {
        return (new SuccessResponse($page->load('media', 'metadata')))->json();
    }

    public function update(Page $page, PageRequest $request)
    {
        $page->update($request->validated());
        return (new SuccessResponse($page->fresh()))->json();
    }

    public function destroy(Page $page)
    {
        $page->delete();
        return (new SuccessResponse())->json();
    }

    public function store(PageRequest $request)
    {
        return (new SuccessResponse(Page::create($request->validated())))->json();
    }

    public function publish(Page $page)
    {
        return (new SuccessResponse($page->publish()))->json();
    }

    public function unpublish(Page $page)
    {
        return (new SuccessResponse($page->unpublish()))->json();
    }

    public function attach(Page $page, string $collection, FileRequest $request)
    {
        $this->addFile($page, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Page::recent()))->json();
    }

    public function detach(Page $page, Media $media)
    {
        $page->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Page $page, string $collection)
    {
        return (new SuccessResponse($this->getFiles($page, $collection)))->json();
    }

    public function metadata(MetadataRequest $request, Page $page)
    {
        $page->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
