<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Models\ProjectStage;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class ProjectStagesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(ProjectStage::all()))->json();
    }
}
