<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\DepartmentRequest;
use App\Models\Department;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class DepartmentsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Department::withCount('staff')->orderBy('rank')->paginate(10)))->json();
    }

    public function show(Department $department)
    {
        return (new SuccessResponse($department->load('staff')))->json();
    }

    public function update(Department $department, DepartmentRequest $request)
    {
        $department->update($request->validated());
        return (new SuccessResponse($department->fresh()))->json();
    }

    public function destroy(Department $department)
    {
        $department->delete();
        return (new SuccessResponse())->json();
    }

    public function store(DepartmentRequest $request)
    {
        return (new SuccessResponse(Department::create($request->validated())))->json();
    }

    public function publish(Department $department)
    {
        return (new SuccessResponse($department->publish()))->json();
    }

    public function unpublish(Department $department)
    {
        return (new SuccessResponse($department->unpublish()))->json();
    }
}
