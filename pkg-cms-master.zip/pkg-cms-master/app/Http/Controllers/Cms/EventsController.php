<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use App\Http\Requests\EventRequest;
use App\Http\Requests\FileRequest;
use App\Http\Requests\MetadataRequest;
use App\Http\Resources\EventResource;
use App\Models\Event;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class EventsController extends Controller
{
    use HandlesFiles;

    public function index()
    {
        return (new SuccessResponse(Event::latest()->orderBy('start_date', 'desc')->paginate(10)))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Event::recent()))->json();
    }


    public function show(Event $event)
    {
        return (new SuccessResponse(new EventResource($event->load('metadata'))))->json();
    }

    public function update(Event $event, EventRequest $request)
    {
        $event->update($request->validated());
        return (new SuccessResponse($event->fresh()))->json();
    }

    public function destroy(Event $event)
    {
        $event->delete();
        return (new SuccessResponse())->json();
    }

    public function store(EventRequest $request)
    {
        return (new SuccessResponse(Event::create($request->validated())))->json();
    }

    public function publish(Event $event)
    {
        return (new SuccessResponse($event->publish()))->json();
    }

    public function unpublish(Event $event)
    {
        return (new SuccessResponse($event->unpublish()))->json();
    }

    public function attach(Event $event, string $collection, FileRequest $request)
    {
        $this->addFile($event, $collection, $request->get('caption'));
        return (new SuccessResponse())->json();
    }

    public function detach(Event $event, Media $media)
    {
        $event->deleteMedia($media->getKey());
        return (new SuccessResponse())->json();
    }

    public function media(Event $event, string $collection)
    {
        return (new SuccessResponse($this->getFiles($event, $collection)))->json();
    }


    public function metadata(MetadataRequest $request, Event $event)
    {
        $event->addMetadata($request->get('description'), $request->get('keywords'));
        return (new SuccessResponse())->json();
    }
}
