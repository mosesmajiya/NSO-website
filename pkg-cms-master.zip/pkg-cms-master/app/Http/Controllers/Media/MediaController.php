<?php

namespace App\Http\Controllers\Media;

use App\Http\Controllers\Controller;
use App\Http\Requests\MediaCaptionRequest;
use App\Http\Resources\MediaResource;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use BlueCloud\ApiResponse\Responses\UnprocessableEntityResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class MediaController extends Controller
{
    public function destroy(Media $media)
    {
        if ($media->delete()) return (new SuccessResponse())->json();

        return (new UnprocessableEntityResponse())->json();
    }

    public function show(Media $media)
    {
        return (new SuccessResponse(new MediaResource($media)))->json();
    }

    public function update(Media $media, MediaCaptionRequest $request)
    {
        $media->setCustomProperty('caption', $request->get('caption'))->save();

        return (new SuccessResponse())->json();
    }
}
