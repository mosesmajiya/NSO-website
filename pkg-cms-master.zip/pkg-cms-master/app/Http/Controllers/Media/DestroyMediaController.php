<?php

namespace App\Http\Controllers\Media;

use App\Http\Controllers\Controller;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use BlueCloud\ApiResponse\Responses\UnprocessableEntityResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DestroyMediaController extends Controller
{
    public function __invoke(Media $media)
    {
        if ($media->delete()) return (new SuccessResponse())->json();

        return (new UnprocessableEntityResponse())->json();
    }
}
