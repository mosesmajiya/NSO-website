<?php

namespace App\Http\Controllers\Media;

use App\Http\Controllers\Controller;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DownloadController extends Controller
{
    public function __invoke(Media $media)
    {
        $count = $media->hasCustomProperty('downloads')
            ? $media->getCustomProperty('downloads') : 0;
        $media->setCustomProperty('downloads', $count + 1)->save();
        return response()->download($media->getPath(), $media->{'file_name'});
    }
}
