<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\UserFeedbackRequest;
use App\Mail\CodeCreated;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    public function feedback(UserFeedbackRequest $request)
    {
        Mail::send(new CodeCreated($request));
        return (new SuccessResponse())->json();
    }


}
