<?php

namespace App\Http\Controllers\Auth;

use App\Exceptions\AccessDeniedException;
use App\Exceptions\InvalidCredentialsException;
use App\Exceptions\UnauthorizedResourceException;
use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Config;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;


    /**
     * Handle a login request to the application.
     *
     * @param LoginRequest $request
     * @return RedirectResponse|Response|JsonResponse
     *
     * @throws UnauthorizedResourceException
     * @throws InvalidCredentialsException|AccessDeniedException
     */
    public function login(LoginRequest $request)
    {
        $user = User::findByEmail($request->get('email'));

        if ($user->isNotAdmin())
            return $this->respond()->unauthorized('You are not authorized to access this resource')->json();

        if ($user->invalidPassword(request('password')))
            return $this->respond()->status(412)->message('The given credentials are invalid')->json();

        $token = $user->createToken('access_token');

        return (new SuccessResponse([
            'name' => $user->{'name'},
            'accessToken' => $token->plainTextToken,
            'email' => $user->{'email'},
            'modules' => Config::get('modules.optional'),
        ]))->json();
    }

    public function logout(): JsonResponse
    {
        request()->user()->currentAccessToken()->delete();
        return (new SuccessResponse())->json();
    }
}
