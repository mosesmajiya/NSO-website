<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostCollectionResource;
use App\Models\Download;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class DownloadsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new PostCollectionResource(Download::published()->public()->paginate(10))))->json();
    }

    public function locked(): JsonResponse
    {
        return $this->respond()->ok(new PostCollectionResource(Download::published()->locked(user())->paginate(10)))
            ->key('downloads')->json();
    }

    public function report()
    {
        return (new SuccessResponse(new PostCollectionResource(Download::published()->report()->latest('published_at')->paginate(10))))->json();
    }

    public function speech()
    {
        return (new SuccessResponse(new PostCollectionResource(Download::published()->speech()->latest('published_at')->paginate(10))))->json();
    }
}
