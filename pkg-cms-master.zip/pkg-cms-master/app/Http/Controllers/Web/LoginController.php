<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Models\User;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class LoginController extends Controller
{
    public function __invoke(LoginRequest $request): JsonResponse
    {
        $user = User::findByEmail($request->get('email'));

        if ($user->isAdmin())
            return $this->respond()->unauthorized('You are not authorized to access this resource')->json();

        if ($user->invalidPassword(request('password')))
            return $this->respond()->status(412)->message('The given credentials are invalid')->json();

        $token = $user->createToken('access_token');

        return (new SuccessResponse([
            'name' => $user->{'name'},
            'accessToken' => $token->plainTextToken,
            'email' => $user->{'email'}
        ]))->json();
    }
}
