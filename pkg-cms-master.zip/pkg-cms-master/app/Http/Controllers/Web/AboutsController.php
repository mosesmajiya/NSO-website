<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Models\Department;
use App\Models\Staff;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;

class AboutsController extends Controller
{
    public function priority(): JsonResponse
    {
        $abouts = About::published()->orderBy('rank')->take(4)->get();
        return (new SuccessResponse($abouts))->json();
    }

    public function index(): JsonResponse
    {
        $data = About::published()->orderBy('rank')->get()->map(function (About $about) {
            if ($about->hasMedia('banner'))
                $about->{'image'} = $about->getFirstMedia('banner')->getFullUrl();
            return $about;
        });
        return (new SuccessResponse($data))->json();
    }

    public function ceo(): JsonResponse
    {
        $department = Department::orderBy('rank')->first();
        /** @var Staff $staff */
        $staff = Staff::published()->current()->whereHas('position', function (Builder $builder) use ($department) {
            $builder->where('department_id', $department->getKey())->where('rank', $department->positions()->min('rank'));
        })->with('position', 'department')
            ->where('department_id', $department->getKey())
            ->first();

        if($staff)
        {
            if ($staff->hasMedia('banner')) {
                $staff->{'image_url'} = $staff->getFirstMedia('banner')->getFullUrl();
            }
        }

        return (new SuccessResponse($staff))->json();

    }

    public function formerCeo(): JsonResponse
    {
        $department = Department::orderBy('rank')->first();
        /** @var Staff $staff */
        $staff = Staff::published()->former()->whereHas('position', function (Builder $builder) use ($department) {
            $builder->where('department_id', $department->getKey())->where('rank', $department->positions()->min('rank'));
        })->with('department')->where('department_id', $department->getKey())->get();

        if($staff)
        {
            $staff->each(function ($item) {
                if ($item->hasMedia('banner')) {
                    $item->{'image_url'} = $item->getFirstMedia('banner')->getFullUrl();
                }
            });
        }

        return (new SuccessResponse($staff))->json();
    }
}
