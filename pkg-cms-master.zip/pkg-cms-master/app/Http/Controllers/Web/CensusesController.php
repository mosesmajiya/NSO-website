<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\CensusResource;
use App\Models\District;
use App\Models\DistrictCensus;
use App\Models\NationalCensus;
use App\Models\RegionalCensus;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class CensusesController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(NationalCensus::orderBy('year', 'desc')->get()))->json();
    }

    public function show(int $year): JsonResponse
    {
        /** @var NationalCensus $national */
        $national = NationalCensus::with('media')->where('year', $year)->first();
        $districtCensuses = DistrictCensus::with('district.media')->where('year', $year)->get();
        $result = [
            'media' => $national->media()->where('collection_name', 'images')->latest()->take(3)
                ->get()->map(function (Media $media) {
                    return ['url' => $media->getFullUrl()];
                }),
            'resources' => CensusResource::whereHas('media')->orderBy('priority')->with('media')
                ->where('year', $year)->get()
                ->map(function (CensusResource $censusResource) {
                    return array_merge($censusResource->only(['id', 'name', 'priority', 'year']),
                        ['media' => $censusResource->getMedia()->map(function (Media $media) {
                            return [
                                'name' => $media->{'name'},
                                'size' => $media->getHumanReadableSizeAttribute(),
                                'url' => $media->getFullUrl(),
                            ];
                        })]);
                }),
            'national' => $national->withoutRelations(),
            'districts' => $districtCensuses->map(function (DistrictCensus $census) {
                /** @var District $district */
                $district = $census->{'district'};
                if ($district->hasMedia()) $district->{'image_url'} = $district->getFirstMedia()->getFullUrl();

                return $census;
            }),
            'regions' => RegionalCensus::with('region')->where('year', $year)->get()
                ->map(function (RegionalCensus $regionalCensus) use ($districtCensuses) {
                    $region = $regionalCensus->{'region'};
                    return array_merge($region->only(['id', 'name']),
                        ['census' => $regionalCensus->withoutRelations()],
                        ['districts' => $districtCensuses->filter(function (DistrictCensus $districtCensus) use ($region) {
                            return $districtCensus->{'district'}->{'region_id'} == $region->getKey();
                        })->values()->map(function (DistrictCensus $districtCensus) {
                            /** @var District $district */
                            $district = $districtCensus->{'district'};
                            return array_merge(
                                $district->withoutRelations()->toArray(),
                                ['image_url' => $district->hasMedia() ? $district->getFirstMedia()->getFullUrl() : ''],
                                ['census' => $districtCensus->withoutRelations()->toArray()]
                            );
                        })]
                    );
                }),

        ];
        return (new SuccessResponse($result))->json();
    }
}
