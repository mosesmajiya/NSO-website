<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ProjectStage;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Database\Eloquent\Builder;

class ProjectStagesController extends Controller
{
    public function index()
    {
        $stages = ProjectStage::withCount(['projects as count' => function (Builder $builder) {
            $builder->where('published_at', '!=', null);
        }])->orderBy('rank')->get();

        return (new SuccessResponse($stages))->json();
    }
}
