<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\SubscribeRequest;
use App\Models\Subscription;
use App\Services\SubscriptionService;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class SubscriptionsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Subscription::all()))->json();
    }

    public function store(SubscribeRequest $request)
    {
        (new SubscriptionService($request->get('email')))->subscribe($request->get('publications'));

        return (new SuccessResponse())->json();
    }
}
