<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\QuickStat;
use Illuminate\Http\JsonResponse;

class QuickStatsController extends Controller
{
    public function __invoke(): JsonResponse
    {
        return $this->respond()->ok(QuickStat::first())->key('quick_stats')->json();
    }
}
