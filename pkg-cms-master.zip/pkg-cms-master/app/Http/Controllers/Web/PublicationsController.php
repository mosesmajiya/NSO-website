<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Report;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class PublicationsController extends Controller
{
    public function index(): JsonResponse
    {
        $builder = Report::published()->orderBy('published_at', 'desc');
        if (request()->input('super-categories'))
            $builder->with('media', 'category')->whereHas('superCategories', function ($q) {
                $q->where('slug', request()->input('super-categories'));
            });

        return (new SuccessResponse($builder->paginate()))->setLabel('publications')->json();
    }

    public function show(Report $publication): JsonResponse
    {
        $publication->countView();
        $publication->{'attachments'} = $publication->getMedia()->map(function (Media $media) {
            return [
                'name' => $media->{'name'},
                'filesize' => $media->getHumanReadableSizeAttribute(),
                'url' => $media->getFullUrl()
            ];
        });
        return $this->respond()->ok($publication->load('indicators'))->key('publication')->json();
    }
}
