<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ConsumerPriceWeight;

class CPIWeightsController extends Controller
{
    public function index()
    {
        $result = ConsumerPriceWeight::first();
        return $this->respond()->ok($result)->json();
    }
}
