<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Link;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class LinksController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Link::all()))->json();
    }
}
