<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\AnnualConsumerPriceIndex;
use Illuminate\Http\JsonResponse;

class AnnualCPIController extends Controller
{
    public function index(): JsonResponse
    {
        $result = AnnualConsumerPriceIndex::orderBy('date', 'desc')->get();
        return $this->respond()->ok($result)->json();
    }
}
