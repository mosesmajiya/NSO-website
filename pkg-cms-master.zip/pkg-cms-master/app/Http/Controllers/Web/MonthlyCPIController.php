<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\MonthlyConsumerPriceIndex;
use Illuminate\Http\JsonResponse;

class MonthlyCPIController extends Controller
{
    public function index(int $year): JsonResponse
    {
        $result = MonthlyConsumerPriceIndex::whereYear('date', $year)->orderBy('date', 'desc')->get();

        return $this->respond()->ok($result)->json();
    }
}
