<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProcurementCollectionResource;
use App\Http\Resources\ProcurementResource;
use App\Models\Post;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class ProcurementController extends Controller
{
    public function advertisement()
    {
        return (new SuccessResponse(new ProcurementCollectionResource(Post::advertisement()->published()->latest('published_at')->paginate(10))))->json();
    }

    public function notice()
    {
        return (new SuccessResponse(new ProcurementCollectionResource(Post::notice()->published()->latest('published_at')->paginate(10))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new ProcurementResource(Post::findByPublishedSlug($slug)->load('type')->countView())))->json();
    }
}
