<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\DepartmentCollectionResource;
use App\Http\Resources\DepartmentResource;
use App\Models\Department;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class DepartmentsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new DepartmentCollectionResource(Department::published()->orderBy('rank')->paginate(50))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new DepartmentResource(Department::findByPublishedSlug($slug))))->json();
    }
}
