<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Services\SiteSearch;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class SearchController extends Controller
{
    private SiteSearch $siteSearch;

    public function __construct()
    {
        $this->siteSearch = new SiteSearch();
    }

    public function search(string $query): JsonResponse
    {
        $results = $this->siteSearch->search($query);

        return (new SuccessResponse($results))->json();
    }
}
