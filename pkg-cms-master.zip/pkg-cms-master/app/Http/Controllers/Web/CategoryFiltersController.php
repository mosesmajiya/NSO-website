<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ReportCategory;

class CategoryFiltersController extends Controller
{
    public function index(ReportCategory $category)
    {
        return $this->respond()->ok($category->reports)->key('reports')->json();
    }
}
