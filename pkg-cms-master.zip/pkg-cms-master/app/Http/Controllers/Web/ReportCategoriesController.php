<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ReportCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class ReportCategoriesController extends Controller
{
    public function show(ReportCategory $category): JsonResponse
    {
        return (new SuccessResponse($category))->json();
    }
}
