<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\FaqCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class FaqController extends Controller
{
    public function index()
    {
        $data = FaqCategory::published()->whereHas('faqs')->get()->map(function (FaqCategory $category) {
            $category->{'questions'} = $category->faqs()->published()->get();
            return $category;
        });
        return (new SuccessResponse($data))->json();
    }
}
