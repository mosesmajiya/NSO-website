<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\SliderCollectionResource;
use App\Http\Resources\SliderResource;
use App\Models\Slider;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\Request;

class SlidersController extends Controller
{
    public function __invoke()
    {
        return (new SuccessResponse(SliderResource::collection(Slider::published()->orderBy('name')->get())))->json();
    }
}

