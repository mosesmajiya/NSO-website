<?php

namespace App\Http\Controllers\Web;

use App\Http\Resources\PostResource;
use App\Models\Post;
use App\Models\Service;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class ServicesController extends \App\Http\Controllers\Controller
{
    public function index()
    {
        $services = Service::published()->with('media')->get()->map(function(Service $service){
            return array_merge($service->toArray(), [
                'attachments' => $service->hasMedia('attachment') ? $service->getFirstMedia('attachment')->getFullUrl() : null,
                'banner' => $service->hasMedia('banner') ?  $service->getFirstMedia('banner')->getFullUrl() : null
            ]);
        });

        return (new SuccessResponse($services))->json();
    }

    public function show(Service $service)
    {
        $result = array_merge($service->toArray(), [
            'attachments' => $service->hasMedia('attachment') ? $service->getFirstMedia('attachment')->getFullUrl() : null,
            'banner' => $service->hasMedia('banner') ?  $service->getFirstMedia('banner')->getFullUrl() : null
        ]);

        return (new SuccessResponse($result))->json();
    }
}
