<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\NewsletterResource;
use App\Models\Newsletter;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class NewslettersController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(Newsletter::published()->withCount('releases')->latest()->get()))->json();
    }

    public function show(string $slug)
    {
        $newsletter = Newsletter::findByPublishedSlug($slug)->countView();
//            ->load(['releases' => function (Relation $relation) {
//                return $relation->orderByDesc('volume')->orderByDesc('issue');
//            }]
//            );
//        /** @var NewsletterRelease $release */
//        $release = $newsletter->releases()->first();

        return (new SuccessResponse(new NewsletterResource($newsletter)))->json();
    }
}
