<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\PageCollectionResource;
use App\Http\Resources\PageResource;
use App\Models\Page;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class PagesController extends Controller
{
    public function popular()
    {
        return (new SuccessResponse(new PageCollectionResource(Page::published()->popular()->paginate(3))))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Page::latest()->published()->take(5)->get()))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new PageResource(Page::findByPublishedSlug($slug)->countView())))->json();
    }
}
