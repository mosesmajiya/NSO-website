<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\MonthlyConsumerPriceIndex;
use Illuminate\Http\JsonResponse;

class MonthlyCPIGraphController extends Controller
{
    public function index(): JsonResponse
    {
        $result = MonthlyConsumerPriceIndex::latest('date')->limit(13)->get([
            'id', 'date', 'food', 'non_food_inflation', 'inflation_rate'
        ])->sortByDesc('date');

        return $this->respond()->ok($result)->json();
    }
}
