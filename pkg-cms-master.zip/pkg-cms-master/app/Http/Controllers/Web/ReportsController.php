<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\ReportCollectionResource;
use App\Models\Report;
use App\Models\ReportCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class ReportsController extends Controller
{
    public function index(ReportCategory $category): JsonResponse
    {
        $reports = $category->reports()->with(['media'])->paginate();

        return (new SuccessResponse($reports))->json();
    }

    public function show(Report $report): JsonResponse
    {
        if ($report->isNotPublished()) throw new NotFoundHttpException();

        $report->load('indicators', 'media');

        if ($report->hasMedia()) {
            $media = $report->getFirstMedia();
            $report->{'document'} = [
                'size' => $media->getHumanReadableSizeAttribute(),
                'path' => $media->getFullUrl()
            ];
        }

        return (new SuccessResponse($report))->json();
    }

    public function featured()
    {
    }

    public function recent(): JsonResponse
    {
        return (new SuccessResponse(Report::published()->latest()->limit(6)->with(['superCategories'])->get()))->json();
    }

    public function recentFull(): JsonResponse
    {
        return (new SuccessResponse(Report::published()->latest()->limit(15)->with(['superCategories'])->get()))->json();
    }
}
