<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Staff;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class StaffController extends Controller
{
    public function show(string $slug)
    {

        /** @var Staff $staff */
        $staff = Staff::where('slug', $slug)->with('position')->firstOrFail();

        $staff->{'image_url'} = $staff->hasMedia('banner')
            ? $staff->getFirstMedia('banner')->getFullUrl()
            : null;

        $result = array_merge($staff->toArray(), ['position' => $staff->{'position'}->{'name'}]);

        return (new SuccessResponse($result))->json();
    }
}
