<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProjectCollectionResource;
use App\Http\Resources\ProjectResource;
use App\Models\Project;
use App\Services\Projects\ProjectSummary;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\Request;

class ProjectsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new ProjectCollectionResource(Project::published()->with('stage')->latest()->paginate(6))))->json();
    }

    public function category(string $category)
    {
        return (new SuccessResponse(new ProjectCollectionResource(Project::published()->category($category)->with('stage')->latest()->paginate(6))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new ProjectResource(Project::findByPublishedSlug($slug)->countView()->load('stage'))))->json();
    }

    public function popular()
    {
        return (new SuccessResponse(new ProjectCollectionResource(Project::published()->popular()->with('stage')->paginate(3))))->json();
    }

    public function filter(Request $request)
    {
        return (new SuccessResponse(new ProjectCollectionResource(Project::published()->category('normal')->byStage($request->get('filters'))->with('stage')->paginate(6))))->json();
    }

    public function summary()
    {
        return (new SuccessResponse((new ProjectSummary())->get()))->json();
    }

    public function progress()
    {
        $projects = Project::getWithPhase();

        $phases = $projects->map->{'phase'}->unique()->values()->map(function (string $phase) use ($projects) {
            return [
                'name' => $phase,
                'projects' => $projects->filter(function ($project) use ($phase) {
                    return $project['phase'] == $phase;
                })->values()->toArray()
            ];
        });

        return (new SuccessResponse($phases))->json();
    }
}
