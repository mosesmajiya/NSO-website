<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Report;
use Illuminate\Http\JsonResponse;

class LatestPublicationsController extends Controller
{
    public const LIMIT = 6;

    public function __invoke(): JsonResponse
    {
        $results = Report::latest('published_at')->limit(self::LIMIT)->published()->get();
        return $this->respond()->ok($results)->key('publications')->json();
    }
}
