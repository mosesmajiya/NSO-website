<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\InvalidCodeException;
use App\Exceptions\InvalidCredentialsException;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\NewPasswordRequest;
use App\Http\Requests\SendCodeRequest;
use App\Http\Requests\VerifyCodeRequest;
use App\Mail\CodeCreated;
use App\Models\PasswordReset;
use App\Models\User;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Support\Facades\Hash;
use Mail;

class AuthController extends Controller
{
    public function sendCode(SendCodeRequest $request)
    {
        $user = User::findByEmail($request->get('email'));
        Mail::send(new CodeCreated($user->createResetCode(), $user));
        return (new SuccessResponse())->json();
    }

    public function verify(VerifyCodeRequest $request)
    {
        $token = PasswordReset::findByEmailAndCode($request->get('email'), $request->get('code'));
        if (!$token) throw new InvalidCodeException();
        $token->verify();
        return (new SuccessResponse())->json();
    }

    public function newPassword(NewPasswordRequest $request)
    {
        $token = PasswordReset::findByEmailAndCode($request->get('email'), $request->get('code'));
        if (!$token) throw new InvalidCredentialsException('The request could not be verified', 400);
        $user = User::findByEmail($request->get('email'));
        $user->updatePassword($request->get('password'));
        return (new SuccessResponse())->json();
    }

    public function changePassword(ChangePasswordRequest $request)
    {
        /** @var User $user */
        $user = $request->user();
        if (!Hash::check($request->get('current_password'), $user->{'password'}))
            throw new InvalidCredentialsException();

        $user->update(['password' => Hash::make($request->get('password'))]);
        return (new SuccessResponse())->json();
    }
}
