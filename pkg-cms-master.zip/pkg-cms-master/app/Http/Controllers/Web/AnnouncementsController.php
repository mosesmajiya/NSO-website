<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostCollectionResource;
use App\Models\Post;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;

class AnnouncementsController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(
            new PostCollectionResource(
                Post::whereHas('type', function (Builder $builder) {
                    $builder->where('slug', 'announcement');
                })->published()->latest('published_at')->paginate(5)
            ))
        )->json();
    }
}
