<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ReportSuperCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class ReportSuperCategoriesController extends Controller
{
    public function index(): JsonResponse
    {
        return (new SuccessResponse(ReportSuperCategory::published()->orderBy('name')->get()))
            ->setLabel('categories')->json();
    }

    public function show(ReportSuperCategory $category)
    {
        return (new SuccessResponse($category))->setLabel('category')->json();
    }
}
