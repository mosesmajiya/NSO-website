<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\VacancyCollectionResource;
use App\Http\Resources\VacancyResource;
use App\Models\Vacancy;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class VacanciesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new VacancyCollectionResource(Vacancy::published()->orderBy('deadline','desc')->paginate(10))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new VacancyResource(Vacancy::findByPublishedSlug($slug))))->json();
    }
}
