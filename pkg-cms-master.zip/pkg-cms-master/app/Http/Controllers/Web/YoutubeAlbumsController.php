<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\YoutubeVideoCollectionResource;
use App\Http\Resources\YoutubeVideoResource;
use App\Models\YoutubeAlbum;
use App\Models\YoutubeVideo;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class YoutubeAlbumsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new YoutubeVideoCollectionResource(YoutubeAlbum::published()->orderBy('name')->paginate(50))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new YoutubeVideoResource(YoutubeAlbum::findByPublishedSlug($slug))))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(YoutubeVideo::whereHas('album', function ($query){
                $query->published();
            })->with('album')->latest()->take(2)->get()))->json();
    }
}
