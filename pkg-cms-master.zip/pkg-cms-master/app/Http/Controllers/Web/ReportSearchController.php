<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ReportSuperCategory;
use App\Services\ReportSearch;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class ReportSearchController extends Controller
{
    public function search(string $query, ReportSuperCategory $category): JsonResponse
    {
        $results = (new ReportSearch($category, $query))->search();

        return (new SuccessResponse($results))->json();
    }
}
