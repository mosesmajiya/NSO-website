<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostCollectionResource;
use App\Http\Resources\PostResource;
use App\Models\Post;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class NewsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new PostCollectionResource(Post::news()->published()->latest('published_at')->paginate(5))))->json();
    }

    public function popular()
    {
        return (new SuccessResponse(PostResource::collection(Post::news()->popular()->take(5)->get())))->json();
    }

    public function recent()
    {
        return (new SuccessResponse(Post::news()->latest()->published()->take(5)->get()))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new PostResource(Post::findByPublishedSlug($slug)->load('type')->countView())))->json();
    }
}
