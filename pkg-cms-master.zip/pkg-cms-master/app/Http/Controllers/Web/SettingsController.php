<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class SettingsController extends Controller
{
    public function __invoke()
    {
        return (new SuccessResponse(Setting::first()))->json();
    }
}
