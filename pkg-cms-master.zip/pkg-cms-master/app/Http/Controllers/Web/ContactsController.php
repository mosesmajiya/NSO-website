<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserFeedbackRequest;
use App\Mail\UserFeedback;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Mail;

class ContactsController extends Controller
{
    public function store(UserFeedbackRequest $request)
    {
        Mail::queue(new UserFeedback($request));
        return (new SuccessResponse())->json();
    }
}
