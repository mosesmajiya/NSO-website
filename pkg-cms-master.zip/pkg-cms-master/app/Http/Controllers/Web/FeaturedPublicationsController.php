<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Report;
use App\Transformers\FeaturedPublicationTransformer;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;

class FeaturedPublicationsController extends Controller
{
    public function index(): JsonResponse
    {
        $result = Report::published()->featured()->orderBy('featured_on', 'desc')
            ->whereHas('media', function (Builder $builder) {
                return $builder->where('collection_name', 'feature');
            })
            ->with(['media', 'superCategories'])->limit(6)->get()
            ->map(function (Report $report) {
                return (new FeaturedPublicationTransformer($report))->transform();
            });

        return $this->respond()->ok($result)->json();
    }
}
