<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\EventCollectionResource;
use App\Http\Resources\EventResource;
use App\Models\Event;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class EventsController extends Controller
{
    public function soon()
    {
        $events = Event::soon()->map(function (Event $event) {
            if ($event->hasMedia('banner'))
                $event->{'image'} = $event->getFirstMedia('banner')->getFullUrl();

            return $event;
        });
        return (new SuccessResponse(EventResource::collection(Event::soon())))->json();
    }

    public function index()
    {
        return (new SuccessResponse(new EventCollectionResource(Event::published()->latest('start_date')->paginate(6))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new EventResource(Event::published()->where('slug', $slug)->with('type')
            ->firstOrFail()->countView())))->json();
    }

    public function popular()
    {
        return (new SuccessResponse(new EventCollectionResource(Event::published()->popular()->paginate(3))))->json();
    }
}
