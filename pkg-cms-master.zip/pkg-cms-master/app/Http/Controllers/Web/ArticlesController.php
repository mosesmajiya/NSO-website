<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Post;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Http\JsonResponse;

class ArticlesController extends Controller
{
    public function popular()
    {
        $articles = Post::published()->news()->popular()->with('type')->take(3)->get()->map(function (Post $post) {
            if ($post->hasMedia('banner'))
                $post->{'image'} = $post->getFirstMedia('banner')->getFullUrl();

            return $post;
        });
        return (new SuccessResponse($articles))->json();
    }

    public function latest(): JsonResponse
    {
        $articles = Post::newsAnnouncement()->published()->with('type')->latest('published_at')->take(3)->get()
            ->map(function (Post $post) {
                if ($post->hasMedia('banner'))
                    $post->{'image'} = $post->getFirstMedia('banner')->getFullUrl();

                return $post;
            });
        return (new SuccessResponse($articles))->json();
    }
    public function latestTwo(): JsonResponse
    {
        $articles = Post::newsAnnouncement()->published()->with('type')->latest('published_at')->take(2)->get()
            ->map(function (Post $post) {
                if ($post->hasMedia('banner'))
                    $post->{'image'} = $post->getFirstMedia('banner')->getFullUrl();

                return $post;
            });
        return (new SuccessResponse($articles))->json();
    }

    public function procurement()
    {
        $articles = Post::procurement()->published()->with('type')->latest('published_at')->take(3)->get()->map(function (Post $post) {
            if ($post->hasMedia('banner'))
                $post->{'image'} = $post->getFirstMedia('banner')->getFullUrl();

            return $post;
        });
        return (new SuccessResponse($articles))->json();
    }
}
