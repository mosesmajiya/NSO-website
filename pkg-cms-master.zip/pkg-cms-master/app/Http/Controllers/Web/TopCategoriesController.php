<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\ReportSuperCategory;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class TopCategoriesController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(ReportSuperCategory::orderBy('views','desc')->limit(12)->get()))->json();
    }
}
