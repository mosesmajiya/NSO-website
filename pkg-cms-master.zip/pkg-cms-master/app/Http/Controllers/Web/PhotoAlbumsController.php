<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\PhotoGalleryCollectionResource;
use App\Http\Resources\PhotoGalleryResource;
use App\Models\PhotoGallery;
use BlueCloud\ApiResponse\Responses\SuccessResponse;

class PhotoAlbumsController extends Controller
{
    public function index()
    {
        return (new SuccessResponse(new PhotoGalleryCollectionResource(PhotoGallery::published()->orderBy('name')->paginate(50))))->json();
    }

    public function show(string $slug)
    {
        return (new SuccessResponse(new PhotoGalleryResource(PhotoGallery::findByPublishedSlug($slug))))->json();
    }
}
