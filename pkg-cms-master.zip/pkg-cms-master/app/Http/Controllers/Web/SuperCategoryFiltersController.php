<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Report;
use App\Models\ReportSuperCategory;

class SuperCategoryFiltersController extends Controller
{
    public function index(ReportSuperCategory $superCategory)
    {
        $categories = $superCategory->reports->map(function (Report $report){
            return $report->category->only(['name', 'slug']);
        })->unique();

        return $this->respond()->ok($categories)->key("categories")->json();
    }
}
