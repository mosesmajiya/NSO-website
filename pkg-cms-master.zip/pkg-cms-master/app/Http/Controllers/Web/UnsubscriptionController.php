<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\UnsubscriptionRequest;
use App\Models\Subscriber;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Crypt;

class UnsubscriptionController extends Controller
{
    public function index(string $slug): JsonResponse
    {
        $subscriber = Subscriber::findByEmail(Crypt::decryptString($slug));
        if (!$subscriber) return $this->respond()->notFound()->json();
        return $this->respond()->ok($subscriber->{'subscriptions'})->key('subscriptions')->json();
    }

    public function destroy(string $slug, UnsubscriptionRequest $request): JsonResponse
    {
        $subscriber = Subscriber::findByEmail(Crypt::decryptString($slug));
        $subscriber->unsubscribe($request->get('subscriptions'));
        if (!$subscriber->subscriptions()->exists()) $subscriber->delete();
        return $this->respond()->ok()->json();
    }
}
