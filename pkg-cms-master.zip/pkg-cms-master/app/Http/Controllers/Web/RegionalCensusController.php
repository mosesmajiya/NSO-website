<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Region;
use BlueCloud\ApiResponse\Responses\SuccessResponse;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;

class RegionalCensusController extends Controller
{
    public function show(string $year): JsonResponse
    {
        $result = [
            'regions' => Region::whereHas('censuses', function (Builder $builder) use ($year) {
                $builder->where('year', $year);
            })
                ->whereHas('districts.censuses', function (Builder $builder) use ($year) {
                    $builder->where('year', $year);
                })
                ->with([
                    'censuses' => function (HasMany $builder) use ($year) {
                        $builder->where('year', $year);
                    },
                    'districts.censuses' => function (HasMany $builder) use ($year) {
                        $builder->where('year', $year);
                    }])->get(),
        ];
        return (new SuccessResponse($result))->json();
    }
}
