<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class NationalCensusRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'year' => 'required|date_format:Y',
            'description' => 'required|string|max:300',
            'abstract' => 'required|string',
            'population' => 'required|numeric',
            'poverty' => 'required|numeric',
            'population_density' => 'required|numeric',
            'literacy' => 'required|numeric',
            'fertility_rate' => 'required|numeric',
            'life_expectancy_female' => 'required|numeric',
            'life_expectancy_male' => 'required|numeric',
        ];
    }
}
