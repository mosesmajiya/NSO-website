<?php

namespace App\Http\Requests;

class MonthlyCPIRequest extends CPIRequest
{

}
