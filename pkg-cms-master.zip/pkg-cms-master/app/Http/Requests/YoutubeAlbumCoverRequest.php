<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class YoutubeAlbumCoverRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'file' => 'required|image',
        ];
    }
}
