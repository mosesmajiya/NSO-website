<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class SubscribeRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'email' => 'required|email',
            'publications' => 'required|array'
        ];
    }

    public function messages()
    {
        return [
            'publications.required' => 'Please select at least one publication',
            'publications.array' => 'Please select at least one publication',
        ];
    }
}
