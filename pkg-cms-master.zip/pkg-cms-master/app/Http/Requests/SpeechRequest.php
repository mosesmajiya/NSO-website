<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class SpeechRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'name' => 'required|string',
            'description' => 'required|string',
        ];
    }
}
