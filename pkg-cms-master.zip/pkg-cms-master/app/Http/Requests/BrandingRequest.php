<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class BrandingRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'file' => 'required|image'
        ];
    }
}
