<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class SettingRequest extends AbstractRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'organization_name' => 'required|string',
            'email' => 'required|string',
            'web_address' => 'required|string',
            'postal_address' => 'required|string',
            'physical_address' => 'required|string',
            'phone' => 'required|string',
            'meta_description' => 'required|string',
            'facebook' => 'sometimes|string',
            'twitter' => 'sometimes|string',
            'instagram' => 'sometimes|string',
            'skype' => 'sometimes|string',
            'google_map' => 'sometimes|string',
            'youtube' => 'sometimes|string',
            'linkedin' => 'sometimes|string',
        ];
    }
}
