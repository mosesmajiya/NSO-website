<?php

namespace App\Http\Requests;

class AnnualCPIRequest extends CPIRequest
{

}
