<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class NewsletterReleaseRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'volume' => 'required|numeric',
            'issue' => 'required|numeric',
            'published_on' => 'required|date',
            'newsletter_id' => 'required|exists:newsletters,id',
            'content' => 'required|string',
        ];
    }
}
