<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class ChangePasswordRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'password' => 'required|string|confirmed',
            'current_password' => 'required|string',
        ];
    }
}
