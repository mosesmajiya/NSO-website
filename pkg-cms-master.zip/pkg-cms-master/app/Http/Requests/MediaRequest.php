<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class MediaRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'file' => 'required|file'
        ];
    }
}
