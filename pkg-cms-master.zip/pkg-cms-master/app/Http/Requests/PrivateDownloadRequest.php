<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class PrivateDownloadRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'name' => 'required|string',
            'roles' => 'required|array',
            'roles.*' => 'exists:roles,id'
        ];
    }
}
