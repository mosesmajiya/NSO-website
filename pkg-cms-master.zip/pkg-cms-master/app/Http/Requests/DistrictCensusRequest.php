<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class DistrictCensusRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'district_id' => 'required|exists:districts,id',
            'population' => 'required|numeric',
            'year' => 'sometimes|numeric',
            'population_density' => 'required|numeric',
            'literacy' => 'required|numeric',
            'fertility_rate' => 'required|numeric',
            'life_expectancy_female' => 'required|numeric',
            'life_expectancy_male' => 'required|numeric',
        ];
    }
}
