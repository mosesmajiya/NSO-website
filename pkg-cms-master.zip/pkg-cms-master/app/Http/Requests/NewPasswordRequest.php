<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class NewPasswordRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'code' => 'required|string',
            'password' => 'required|string|confirmed',
            'email' => 'required|email|exists:password_resets'
        ];
    }
}
