<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class SliderRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'name' => 'required|string',
            'content' => 'required|string',
        ];
    }
}
