<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class UnsubscriptionRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'subscriptions' => 'required|array',
            'subscriptions.*' => 'required|exists:subscriptions,id'
        ];
    }
}
