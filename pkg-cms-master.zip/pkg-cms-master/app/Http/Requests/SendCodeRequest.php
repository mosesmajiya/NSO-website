<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class SendCodeRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'email' => 'required|email|exists:users'
        ];
    }
}
