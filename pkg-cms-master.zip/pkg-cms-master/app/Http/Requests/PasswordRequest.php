<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class PasswordRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'new_password' => 'required|string|confirmed',
        ];
    }
}
