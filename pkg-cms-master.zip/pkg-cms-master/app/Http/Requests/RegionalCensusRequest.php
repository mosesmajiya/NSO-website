<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class RegionalCensusRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'region_id' => 'required|numeric|exists:regions,id',
            'population' => 'required|numeric',
            'population_density' => 'required|numeric',
            'poverty' => 'required|numeric',
            'literacy' => 'required|numeric',
            'life_expectancy_male' => 'required|numeric',
            'life_expectancy_female' => 'required|numeric',
            'fertility_rate' => 'required|numeric'
        ];
    }
}
