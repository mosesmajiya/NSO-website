<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class UserRequest extends AbstractRequest
{
    public function rules(): array
    {
        $rules = [
            'name' => 'required|string',
            'email' => 'required|email',
            'roles' => 'required|array',
            'roles.*' => 'required|exists:roles,id'
        ];
        if ($this->method() === 'POST') $rules = array_merge($rules, ['password' => 'required|string|min:6']);
        return $rules;
    }
}
