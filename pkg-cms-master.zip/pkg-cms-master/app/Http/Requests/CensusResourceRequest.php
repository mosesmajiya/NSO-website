<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class CensusResourceRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'name' => 'required|string'
        ];
    }
}
