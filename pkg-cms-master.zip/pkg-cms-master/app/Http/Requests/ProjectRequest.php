<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class ProjectRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'name' => 'required|string',
            'project_stage_id' => 'required|exists:project_stages,id',
            'type' => 'required|string',
            'ministry' => 'required|string',
            'sector' => 'required|string',
            'advisor' => 'required|string',
            'content' => 'required|string',
            'category' => 'required|string|in:normal,private',
            'start_date' => 'required|date',
            'url' => 'sometimes|url',
        ];
    }
}
