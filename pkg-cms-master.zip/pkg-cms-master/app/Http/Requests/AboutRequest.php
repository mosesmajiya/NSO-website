<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class AboutRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'category' => 'required|string',
            'content' => 'required|string',
            'rank' => 'required|integer',
            'icon' => 'required|string',
        ];
    }
}
