<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class ReportDocumentRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'file' => 'required|file',
            'name' => 'required|string'
        ];
    }
}
