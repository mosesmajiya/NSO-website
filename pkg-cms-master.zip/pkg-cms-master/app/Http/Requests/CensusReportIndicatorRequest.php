<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class CensusReportIndicatorRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'indicator' => 'required|string'
        ];
    }
}
