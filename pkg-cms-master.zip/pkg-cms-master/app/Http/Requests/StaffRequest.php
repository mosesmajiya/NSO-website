<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class StaffRequest extends AbstractRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'position_id' => 'required|exists:positions,id',
            'phone_number' => 'nullable|string',
            'email' => 'nullable|email',
            'profile' => 'sometimes|string',
            'current' => 'required',
            'department_id' => 'required|exists:departments,id',
        ];
    }
}
