<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class CensusReportRequest extends AbstractRequest
{
    public function rules(): array
    {
        $rules = [
            'title' => 'required|string',
            'abstract' => 'required|string',
            'source' => 'required|string',
            'report_category_id' => 'required|exists:report_categories,id',
        ];

        if ($this->method() == 'PATCH') return $rules;
        return array_merge($rules, ['report_super_categories' => 'required']);
    }
}
