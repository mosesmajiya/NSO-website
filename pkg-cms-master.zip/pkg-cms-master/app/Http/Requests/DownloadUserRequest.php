<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class DownloadUserRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'roles' => 'required|array',
            'roles.*' => 'required|exists:roles,id',
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
        ];
    }
}
