<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class AvatarRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'file' => 'required|image'
        ];
    }
}
