<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class DistrictRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'name' => 'required|string',
            'description' => 'required|string',
            'code' => 'required|string',
            'region_id' => 'sometimes|exists:regions,id'
        ];
    }
}
