<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class QuickStatisticsRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'population' => 'required|numeric',
            'inflation_rate' => 'required|numeric',
            'gross_domestic_product' => 'required|numeric',
            'unemployment_rate' => 'required|numeric',
        ];
    }
}
