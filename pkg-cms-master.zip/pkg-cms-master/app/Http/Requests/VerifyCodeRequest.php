<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class VerifyCodeRequest extends AbstractRequest
{
    public function rules()
    {
        return [
            'email' => 'required|email',
            'code' => 'required|string'
        ];
    }
}
