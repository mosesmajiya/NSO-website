<?php


namespace App\Http\Requests;


use BlueCloud\ApiResponse\Requests\AbstractRequest;

class CPIRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'all_items' => 'required|numeric',
            'food' => 'required|numeric',
            'beverage_and_tobacco' => 'required|numeric',
            'clothing_and_footwear' => 'required|numeric',
            'housing' => 'required|numeric',
            'household_operation' => 'required|numeric',
            'transport' => 'required|numeric',
            'miscellaneous' => 'required|numeric',
            'inflation_rate' => 'required|numeric',
            'non_food_inflation' => 'required|numeric',
            'date' => 'required|date',
        ];
    }

    public function totals100(): bool
    {
        return $this->total() === 100.0;
    }

    public function total(): float
    {
        return array_sum($this->except(['date', 'inflation_rate', 'non_food_inflation']));
    }
}
