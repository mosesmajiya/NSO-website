<?php

namespace App\Http\Requests;

use BlueCloud\ApiResponse\Requests\AbstractRequest;

class CensusMediaRequest extends AbstractRequest
{
    public function rules(): array
    {
        return [
            'file' => 'required|file',
            'collection' => 'sometimes|string'
        ];
    }
}
