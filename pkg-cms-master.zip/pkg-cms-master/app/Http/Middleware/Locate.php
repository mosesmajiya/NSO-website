<?php

namespace App\Http\Middleware;

use App\Models\Traffic;
use Closure;
use Illuminate\Http\Request;

class Locate
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $location = geoip($request->ip());

        Traffic::create([
            'ip' => $location->ip,
            'iso_code' => $location->iso_code,
            'country' => $location->country,
            'city' => $location->city,
            'lat' => $location->lat,
            'lon' => $location->lon,
            'timezone' => $location->timezone,
            'user_agent' => $request->header('x-user-agent'),
        ]);
        return $next($request);
    }
}
