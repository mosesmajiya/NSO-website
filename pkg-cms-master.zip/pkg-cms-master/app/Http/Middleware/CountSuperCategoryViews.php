<?php

namespace App\Http\Middleware;

use App\Models\Report;
use App\Models\ReportSuperCategory;
use Closure;
use Illuminate\Http\Request;

class CountSuperCategoryViews
{
    public function handle(Request $request, Closure $next)
    {
        return $next($request);
    }

    public function terminate(Request $request): void
    {
        /** @var Report $publication */
        $publication = $request->route('publication');

        $publication->superCategories()->get()->each(function (ReportSuperCategory $category) {
            $category->increment('views');
        });

    }

}
