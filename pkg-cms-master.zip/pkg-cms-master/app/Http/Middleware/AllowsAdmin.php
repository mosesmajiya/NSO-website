<?php

namespace App\Http\Middleware;

use App\Exceptions\UnauthorizedResourceException;
use Closure;
use Illuminate\Http\Request;

class AllowsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     * @throws UnauthorizedResourceException
     */
    public function handle($request, Closure $next)
    {
        if ($request->user()->isNotAdmin()) throw new UnauthorizedResourceException();

        return $next($request);
    }

}
