<?php

namespace App\Http\Middleware;

use App\Exceptions\UnauthorizedResourceException;
use App\Models\User;
use Closure;
use Illuminate\Http\Request;

class AllowsMember
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->user()) {
            $user = $request->user();
        } elseif (!empty($request->get('email'))) {
            $user = User::findByEmail($request->get('email'));
        } else {
            throw new UnauthorizedResourceException('kumapeto');
        }
        if (!$user || !$user->isMember()) throw new UnauthorizedResourceException();

        return $next($request);
    }
}
