<?php

namespace App\Http\Middleware;

use App\Exceptions\InvalidCredentialsException;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PasswordProtected
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Hash::check($request->get('password'), $request->user()->{'password'})) {
            throw new InvalidCredentialsException("The given password is incorrect");
        }
        return $next($request);
    }
}
