<?php

/** @var Factory $factory */

use App\Models\Portfolio;
use App\Models\PortfolioItem;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(PortfolioItem::class, function (Faker $faker) {
    $portfolio = Portfolio::inRandomOrder()->firstOr(function () {
        return \factory(Portfolio::class)->create();
    });
    return [
        'name' => ucwords($faker->sentence),
        'content' => $faker->paragraphs(3, true),
        'portfolio_id' => $portfolio->getKey(),
    ];
});
