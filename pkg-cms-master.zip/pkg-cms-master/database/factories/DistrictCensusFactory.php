<?php

/** @var Factory $factory */

use App\Models\District;
use App\Models\DistrictCensus;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(DistrictCensus::class, function (Faker $faker) {
    return [
        'district_id' => factory(District::class),
        'year' => $faker->year,
        'population' => $faker->numberBetween(10000, 500000),
        'literacy' => $faker->numberBetween(1, 100),
        'population_density' => $faker->numberBetween(1, 100),
        'life_expectancy_male' => $faker->numberBetween(1, 100),
        'life_expectancy_female' => $faker->numberBetween(1, 100),
        'fertility_rate' => $faker->numberBetween(1, 100),
    ];
});
