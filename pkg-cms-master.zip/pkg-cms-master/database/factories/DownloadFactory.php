<?php

/** @var Factory $factory */

use App\Models\Download;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Download::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'type' => $faker->randomElement(['public', 'private']),
    ];
});

$factory->state(Download::class, 'private', ['type' => 'private']);
$factory->state(Download::class, 'published', ['published_at' => now()]);
