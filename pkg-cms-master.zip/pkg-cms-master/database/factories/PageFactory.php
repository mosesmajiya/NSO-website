<?php

/** @var Factory $factory */

use App\Models\Page;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Page::class, function (Faker $faker) {
    return [
        'title' => ucwords($faker->sentence),
        'content' => $faker->paragraphs(3, true)
    ];
});
