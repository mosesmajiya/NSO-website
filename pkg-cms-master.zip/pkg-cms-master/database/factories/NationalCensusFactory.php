<?php

/** @var Factory $factory */

use App\Models\NationalCensus;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(NationalCensus::class, function (Faker $faker) {
    return [
        'year' => $faker->year,
        'description' => $faker->sentence,
        'abstract' => $faker->paragraphs(3, true),
        'population' => $faker->numberBetween(10000000, 20000000),
        'literacy' => $faker->numberBetween(1, 100),
        'poverty' => $faker->numberBetween(1, 100),
        'population_density' => $faker->numberBetween(1, 100),
        'life_expectancy_male' => $faker->numberBetween(1, 100),
        'life_expectancy_female' => $faker->numberBetween(1, 100),
        'fertility_rate' => $faker->numberBetween(1, 100),
    ];
});
