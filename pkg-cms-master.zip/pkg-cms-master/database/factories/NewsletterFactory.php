<?php

/** @var Factory $factory */

use App\Models\Newsletter;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Newsletter::class, function (Faker $faker) {
    return [
        'name' => ucfirst($faker->sentence),
        'slug' => $faker->slug,
        'content' => $faker->paragraphs(3, true),
        'editor' => $faker->name,
    ];
});

$factory->state(Newsletter::class, 'notPublished', ['published_at' => null]);
$factory->state(Newsletter::class, 'published', ['published_at' => now()]);
