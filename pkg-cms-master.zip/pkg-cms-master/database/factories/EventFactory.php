<?php

/** @var Factory $factory */

use App\Models\Event;
use App\Models\EventType;
use Carbon\Carbon;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Event::class, function (Faker $faker) {
    $startDate = Carbon::parse($faker->dateTimeBetween('tomorrow', '+ 30 days'));
    $eventType = EventType::inRandomOrder()->firstor(function () {
        return \factory(EventType::class)->create();
    });

    return [
        'name' => ucwords($faker->sentence),
        'link' => $faker->url,
        'content' => $faker->paragraphs(3, true),
        'start_date' => $startDate,
        'end_date' => $startDate->addDays($faker->numberBetween(1, 30)),
        'venue' => $faker->city,
        'event_type_id' => $eventType->getKey()
    ];
});
