<?php

/** @var Factory $factory */

use App\Models\SocialMedia;
use App\Models\SocialMediaHandle;
use App\Models\Staff;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(SocialMediaHandle::class, function (Faker $faker) {
    $staff = Staff::inRandomOrder()->firstOr(function () {
        return \factory(Staff::class)->create();
    });
    $socialMedia = SocialMedia::inRandomOrder()->firstOr(function () {
        return \factory(SocialMedia::class)->create();
    });
    return [
        'staff_id' => $staff->getKey(),
        'social_media_id' => $socialMedia->getKey(),
        'handle' => $faker->word
    ];
});
