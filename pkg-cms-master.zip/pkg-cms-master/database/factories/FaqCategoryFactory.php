<?php

/** @var Factory $factory */

use App\Models\FaqCategory;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(FaqCategory::class, function (Faker $faker) {
    return [
        'name' => ucwords($faker->sentence),
    ];
});
