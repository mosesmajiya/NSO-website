<?php

/** @var Factory $factory */

use App\Models\Report;
use App\Models\ReportCategory;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Report::class, function (Faker $faker) {
    return [
        'title' => $faker->sentence,
        'abstract' => $faker->sentences(3, true),
        'source' => $faker->company,
        'report_category_id' => ReportCategory::firstOrCreate([], factory(ReportCategory::class)->make()->toArray())->getKey(),
    ];
});

$factory->state(Report::class, 'published', ['published_at' => now()]);
$factory->state(Report::class, 'notPublished', ['published_at' => null]);
