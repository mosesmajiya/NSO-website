<?php

/** @var Factory $factory */

use App\Models\Post;
use App\Models\PostType;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Post::class, function (Faker $faker) {
    $postType = PostType::firstOr(function () {
        return \factory(PostType::class)->create();
    });
    return [
        'title' => ucwords($faker->sentence),
        'post_type_id' => $postType->getKey(),
        'content' => $faker->paragraphs(3, true),
    ];
});

$factory->state(Post::class, "news", function () {
    $postType = PostType::where('slug', "news")->firstOr(function () {
        return \factory(PostType::class)->create(['name' => 'News']);
    });
    return [
        'post_type_id' => $postType->getKey()
    ];
});

$factory->state(Post::class, "announcement", function () {
    $postType = PostType::where('slug', "announcement")->firstOr(function () {
        return \factory(PostType::class)->create(['name' => 'Announcement']);
    });
    return [
        'post_type_id' => $postType->getKey()
    ];
});

$factory->state(Post::class, "ita", function () {
    $postType = PostType::where('slug', "intention-to-award")->firstOr(function () {
        return \factory(PostType::class)->create(['name' => 'Intention to Award']);
    });
    return [
        'post_type_id' => $postType->getKey()
    ];
});
