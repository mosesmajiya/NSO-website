<?php

/** @var Factory $factory */

use App\Models\Traffic;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Traffic::class, function (Faker $faker) {
    return [
        'ip' => $faker->ipv4,
        'iso_code' => $faker->countryISOAlpha3,
        'country' => $faker->country,
        'city' => $faker->city,
        'lat' => $faker->latitude,
        'lon' => $faker->longitude,
        'timezone' => $faker->timezone,
        'user_agent' => $faker->randomElement(['mobile', 'tablet', 'desktop']),
    ];
});
