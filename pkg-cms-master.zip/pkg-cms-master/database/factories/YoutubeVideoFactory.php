<?php

/** @var Factory $factory */

use App\Models\YoutubeAlbum;
use App\Models\YoutubeVideo;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(YoutubeVideo::class, function (Faker $faker) {
    $album = YoutubeAlbum::firstOr(function () {
        return \factory(YoutubeAlbum::class)->create();
    });
    return [
        'name' => $faker->sentence,
        'video_id' => $faker->word,
        'youtube_album_id' => $album->getKey(),
    ];
});
