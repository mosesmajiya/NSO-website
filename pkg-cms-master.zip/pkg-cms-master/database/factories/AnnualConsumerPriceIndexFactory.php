<?php

/** @var Factory $factory */

use App\Models\AnnualConsumerPriceIndex;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(AnnualConsumerPriceIndex::class, function (Faker $faker) {
    return [
        'food' => $faker->numberBetween(1, 100),
        'beverage_and_tobacco' => $faker->numberBetween(1, 100),
        'clothing_and_footwear' => $faker->numberBetween(1, 100),
        'housing' => $faker->numberBetween(1, 100),
        'household_operation' => $faker->numberBetween(1, 100),
        'transport' => $faker->numberBetween(1, 100),
        'miscellaneous' => $faker->numberBetween(1, 100),
        'inflation_rate' => $faker->numberBetween(1, 100),
        'non_food_inflation' => $faker->numberBetween(1, 100),
        'all_items' => 100,
        'date' => today()
    ];
});
