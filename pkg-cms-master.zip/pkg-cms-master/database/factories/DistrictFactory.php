<?php

/** @var Factory $factory */

use App\Models\District;
use App\Models\Region;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;
use Illuminate\Http\UploadedFile;

$factory->define(District::class, function (Faker $faker) {
    return [
        'name' => $faker->city,
        'description' => $faker->paragraph,
        'code' => $faker->bothify('MW####'),
        'region_id' => Region::firstOrCreate(factory(Region::class)->make()->toArray())

    ];
});

$factory->state(District::class, 'with_image', [])
    ->afterCreatingState(District::class, 'with_image', function (District $district, Faker $faker) {
        $district->addMedia(UploadedFile::fake()->image(sprintf('%s.jpg', $faker->word)))->toMediaCollection();
    });
