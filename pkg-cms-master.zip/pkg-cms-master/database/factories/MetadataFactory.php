<?php

/** @var Factory $factory */

use App\Models\About;
use App\Models\Metadata;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Metadata::class, function (Faker $faker) {
    $about = About::find(8);
    return [
        'metadatable_id' => $about->id,
        'metadatable_type' => get_class($about),
        'description' => $faker->paragraph,
        'keywords' => $faker->words(5, true)
    ];
});
