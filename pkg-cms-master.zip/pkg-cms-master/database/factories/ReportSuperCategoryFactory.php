<?php

/** @var Factory $factory */

use App\Models\ReportSuperCategory;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(ReportSuperCategory::class, function (Faker $faker) {
    return [
        'name' => $faker->word,
        'slug' => $faker->slug,
        'description' => $faker->paragraph,
        'published_at' => now()
    ];
});

$factory->state(ReportSuperCategory::class, 'notPublished', ['published_at' => null]);
$factory->state(ReportSuperCategory::class, 'draft', ['published_at' => null]);
$factory->state(ReportSuperCategory::class, 'published', ['published_at' => now()]);
