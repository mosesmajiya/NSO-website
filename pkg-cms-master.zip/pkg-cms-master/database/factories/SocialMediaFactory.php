<?php

/** @var Factory $factory */

use App\Models\SocialMedia;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(SocialMedia::class, function (Faker $faker) {
    return [
        'name' => ucwords($faker->sentence),
        'base_url' => $faker->domainName,
        'icon' => $faker->word,
    ];
});
