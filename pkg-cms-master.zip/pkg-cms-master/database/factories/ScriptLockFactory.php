<?php

/** @var Factory $factory */

use App\Models\ScriptLock;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(ScriptLock::class, function (Faker $faker) {
    return [
        'tag' => $faker->word()
    ];
});
