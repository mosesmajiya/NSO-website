<?php

/** @var Factory $factory */

use App\Models\AlertQueueItem;
use App\Models\Subscriber;
use App\Models\Vacancy;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(AlertQueueItem::class, function (Faker $faker) {
    return [
        'email' => $faker->safeEmail,
        'name' => $faker->sentence,
        'subscribable_type' => Vacancy::class,
        'subscribable_id' => Vacancy::firstOrCreate([], \factory(Vacancy::class)->make()->toArray()),
        'subscriber_id' => Subscriber::firstOrCreate([], \factory(Subscriber::class)->make()->toArray())
    ];
});
