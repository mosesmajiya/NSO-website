<?php

/** @var Factory $factory */

use App\Models\Newsletter;
use App\Models\NewsletterRelease;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(NewsletterRelease::class, function (Faker $faker) {
    return [
        'volume' => $faker->numberBetween(1, 10),
        'issue' => $faker->numberBetween(1, 10),
        'published_on' => now()->subDays($faker->numberBetween(1, 10)),
        'newsletter_id' => Newsletter::firstOrCreate([], \factory(Newsletter::class)->make()->toArray()),
        'content' => $faker->paragraphs(3, true)
    ];
});
