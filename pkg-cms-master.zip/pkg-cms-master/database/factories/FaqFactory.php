<?php

/** @var Factory $factory */

use App\Models\Faq;
use App\Models\FaqCategory;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Faq::class, function (Faker $faker) {
    $category = FaqCategory::inRandomOrder()->firstOr(function () {
        return \factory(FaqCategory::class)->create();
    });
    return [
        'question' => ucfirst($faker->sentence),
        'response' => $faker->paragraphs(3, true),
        'faq_category_id' => $category->getKey()
    ];
});
