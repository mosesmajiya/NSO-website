<?php

/** @var Factory $factory */

use App\Models\Link;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Link::class, function (Faker $faker) {
    return [
        'name' => $faker->company,
        'url' => $faker->url,
        'type' => $faker->randomElement(['local', 'foreign']),
    ];
});

$factory->state(Link::class, 'local', function () {
    return ['type' => 'local'];
});

$factory->state(Link::class, 'foreign', function () {
    return ['type' => 'foreign'];
});

