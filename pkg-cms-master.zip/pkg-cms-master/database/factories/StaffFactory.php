<?php

/** @var Factory $factory */

use App\Models\Department;
use App\Models\Position;
use App\Models\Staff;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Staff::class, function (Faker $faker) {
    $position = Position::inRandomOrder()->firstOr(function () {
        return \factory(Position::class)->create();
    });
    $department = Department::inRandomOrder()->firstOr(function () {
        return \factory(Department::class)->create();
    });
    return [
        'name' => $faker->name(),
        'position_id' => $position->getKey(),
        'department_id' => $department->getKey()
    ];
});
