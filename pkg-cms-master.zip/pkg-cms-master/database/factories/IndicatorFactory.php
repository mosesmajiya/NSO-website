<?php

/** @var Factory $factory */

use App\Models\Indicator;
use App\Models\Report;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Indicator::class, function (Faker $faker) {
    return [
        'indicator' => $faker->sentence,
        'report_id' => Report::firstOrCreate([], collect(factory(Report::class)->make()->toArray())
            ->except('filesize', 'document')->toArray()),
    ];
});
