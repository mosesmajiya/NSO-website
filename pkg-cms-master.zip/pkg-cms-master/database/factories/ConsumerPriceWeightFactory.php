<?php

/** @var Factory $factory */

use App\Models\ConsumerPriceWeight;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(ConsumerPriceWeight::class, function (Faker $faker) {
    return [
        //
    ];
});
