<?php

/** @var Factory $factory */

use App\Models\Vacancy;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Vacancy::class, function (Faker $faker) {
    return [
        'position' => $faker->jobTitle,
        'job_type' => $faker->randomElement(['permanent', 'contract', 'temporary']),
        'content' => $faker->paragraphs(3, true),
        'deadline' => now()->addDays($faker->numberBetween(1, 15)),
    ];
});

$factory->state(Vacancy::class, 'notPublished', ['published_at' => null]);
$factory->state(Vacancy::class, 'published', ['published_at' => now()]);
