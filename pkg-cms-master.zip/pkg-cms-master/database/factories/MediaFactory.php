<?php

/** @var Factory $factory */

use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Spatie\MediaLibrary\MediaCollections\Models\Media::class, function (Faker $faker) {
    return [
        'model_id' => 1,
        'model_type' => $faker->word,
        'uuid' => $faker->uuid,
        'collection_name' => 'default',
        'name' => $faker->word,
        'file_name' => sprintf('%s.%s', $faker->word, $faker->fileExtension),
        'disk' => 'local',
        'size' => $faker->numberBetween(1, 5044),
        'manipulations' => 'none',
        'custom_properties' => 'none',
        'responsive_images' => 'none',
    ];
});
