<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ProjectStage;
use Faker\Generator as Faker;

$factory->define(ProjectStage::class, function (Faker $faker) {
    return [
        'name' => ucwords($faker->word),
        'rank' => $faker->numberBetween(1, 10)
    ];
});
