<?php

/** @var Factory $factory */

use App\Models\YoutubeAlbum;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(YoutubeAlbum::class, function (Faker $faker) {
    return [
        'name' => $faker->sentence,
        'description' => $faker->sentence,
    ];
});
