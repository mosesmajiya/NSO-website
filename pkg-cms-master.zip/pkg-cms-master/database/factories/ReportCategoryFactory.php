<?php

/** @var Factory $factory */

use App\Models\ReportCategory;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(ReportCategory::class, function (Faker $faker) {
    return [
        'name' => $faker->word,
        'description' => $faker->paragraph
    ];
});

$factory->state(ReportCategory::class, 'notPublished', ['published_at' => null]);
$factory->state(ReportCategory::class, 'published', ['published_at' => now()]);
