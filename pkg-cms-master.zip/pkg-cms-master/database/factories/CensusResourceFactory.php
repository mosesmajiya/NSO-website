<?php

/** @var Factory $factory */

use App\Models\CensusResource;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(CensusResource::class, function (Faker $faker) {
    return [
        'name' => $faker->word,
        'priority' => $faker->numberBetween(1, 10)
    ];
});
