<?php

/** @var Factory $factory */

use App\Models\MenuSetting;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(MenuSetting::class, function (Faker $faker) {
    return [
        'label' => $faker->word,
        'enabled' => $faker->boolean,
        'model' => ucfirst($faker->word),
    ];
});
