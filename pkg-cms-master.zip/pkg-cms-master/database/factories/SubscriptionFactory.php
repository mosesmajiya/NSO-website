<?php

/** @var Factory $factory */

use App\Models\Subscription;
use App\Models\Vacancy;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Subscription::class, function (Faker $faker) {
    return [
        'name' => ucwords($faker->sentence),
        'model' => Vacancy::class
    ];
});
