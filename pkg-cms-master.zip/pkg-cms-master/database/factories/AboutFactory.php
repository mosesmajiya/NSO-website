<?php

/** @var Factory $factory */

use App\Models\About;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(About::class, function (Faker $faker) {
    return [
        'category' => ucwords($faker->sentence),
        'content' => $faker->paragraphs(3, true),
        'icon' => $faker->word,
        'rank' => $faker->numberBetween(1, 10)
    ];
});

$factory->state(About::class, "published", function () {
    return [
        'published_at' => now()
    ];
});
