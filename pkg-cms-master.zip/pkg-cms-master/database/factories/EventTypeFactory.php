<?php

/** @var Factory $factory */

use App\Models\EventType;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(EventType::class, function (Faker $faker) {
    return [
        'name' => ucwords($faker->sentence),
    ];
});
