<?php

/** @var Factory $factory */

use App\Models\Department;
use App\Models\Position;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Position::class, function (Faker $faker) {
    $department = Department::inRandomOrder()->firstOr(function () {
        return \factory(Department::class)->create();
    });
    return [
        'name' => ucwords($faker->sentence),
        'rank' => $faker->numberBetween(1, 10),
        'department_id' => $department->getKey(),
    ];
});
