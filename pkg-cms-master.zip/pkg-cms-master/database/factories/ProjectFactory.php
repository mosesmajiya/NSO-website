<?php

/** @var Factory $factory */

use App\Models\Project;
use App\Models\ProjectStage;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;
use Illuminate\Support\Carbon;

$factory->define(Project::class, function (Faker $faker) {
    $startDate = Carbon::parse($faker->dateTimeBetween('tomorrow', '+ 30 days'));
    $projectStage = ProjectStage::firstOr(function () {
        return \factory(ProjectStage::class)->create();
    });

    return [
        'name' => ucwords($faker->sentence),
        'content' => $faker->paragraphs(5, true),
        'start_date' => $startDate,
        'project_stage_id' => $projectStage->getKey(),
        'end_date' => $faker->randomElement([$startDate->addDays($faker->numberBetween(30, 180)), null]),
        'url' => $faker->randomElement([null, $faker->url]),
    ];
});

$factory->state(Project::class, 'published', function () {
    return ['published_at' => now()->subDays(random_int(0, 50))];
});
