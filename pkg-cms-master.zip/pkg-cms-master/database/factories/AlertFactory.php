<?php

/** @var Factory $factory */

use App\Models\Alert;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Alert::class, function (Faker $faker) {
    return [
        //
    ];
});
