<?php

/** @var Factory $factory */

use App\Models\Region;
use App\Models\RegionalCensus;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(RegionalCensus::class, function (Faker $faker) {
    return [
        'region_id' => Region::firstOrCreate(factory(Region::class)->make()->toArray()),
        'year' => $faker->year,
        'population' => $faker->numberBetween(10000, 500000),
        'literacy' => $faker->numberBetween(1, 100),
        'population_density' => $faker->numberBetween(1, 100),
        'life_expectancy_male' => $faker->numberBetween(1, 100),
        'life_expectancy_female' => $faker->numberBetween(1, 100),
        'fertility_rate' => $faker->numberBetween(1, 100),
    ];
});
