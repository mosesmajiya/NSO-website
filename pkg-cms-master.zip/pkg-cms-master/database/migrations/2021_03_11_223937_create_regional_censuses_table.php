<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRegionalCensusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('regional_censuses', function (Blueprint $table) {
            $table->id();
            $table->integer('year');
            $table->foreignId('region_id')->constrained();
            $table->integer('population');
            $table->float('population_density');
            $table->float('literacy');
            $table->float('fertility_rate');
            $table->float('life_expectancy_female');
            $table->float('life_expectancy_male');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('regional_censuses');
    }
}
