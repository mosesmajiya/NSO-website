<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubscriberSubscriptionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subscriber_subscription', function (Blueprint $table) {
            $table->id();
            $table->foreignId("subscriber_id");
            $table->foreignId("subscription_id");
            $table->timestamps();

            $table->unique(["subscriber_id", "subscription_id"]);
            $table->foreign('subscriber_id')->references("id")->on("subscribers")->cascadeOnDelete();
            $table->foreign('subscription_id')->references("id")->on("subscriptions")->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subscriber_subscription');
    }
}
