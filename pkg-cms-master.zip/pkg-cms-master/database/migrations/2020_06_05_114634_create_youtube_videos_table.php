<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateYoutubeVideosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('youtube_videos', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("name");
            $table->string("video_id");
            $table->foreignId('youtube_album_id');
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign('youtube_album_id')->references('id')->on('youtube_albums')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('youtube_videos');
    }
}
