<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("name");
            $table->foreignId('project_stage_id');
//            $table->longText("content");
            $table->date("start_date");
            $table->date("end_date")->nullable();
            $table->string("url")->nullable();
            $table->string('type')->nullable();
            $table->string('ministry')->nullable();
            $table->string('sector')->nullable();
            $table->string('advisor')->nullable();
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();
        });
        DB::statement("ALTER TABLE projects ADD content MEDIUMBLOB");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
