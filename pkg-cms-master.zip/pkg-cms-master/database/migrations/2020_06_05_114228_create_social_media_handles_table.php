<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSocialMediaHandlesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('social_media_handles', function (Blueprint $table) {
            $table->id();
            $table->foreignId("staff_id");
            $table->foreignId("social_media_id");
            $table->string("handle");
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign("staff_id")->references("id")->on("staff")->cascadeOnDelete();
            $table->foreign("social_media_id")->references("id")->on("social_media")->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('social_media_handles');
    }
}
