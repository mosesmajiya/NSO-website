<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateStaffTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('staff', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("name");
            $table->foreignId("position_id");
            $table->foreignId("department_id");
//            $table->longText("profile")->nullable();
            $table->string("phone_number")->nullable();
            $table->string("email")->nullable();
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign("position_id")->references("id")->on("positions")->cascadeOnDelete();
            $table->foreign("department_id")->references("id")->on("departments")->cascadeOnDelete();
        });
        DB::statement("ALTER TABLE staff ADD profile MEDIUMBLOB NULL");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('staff');
    }
}
