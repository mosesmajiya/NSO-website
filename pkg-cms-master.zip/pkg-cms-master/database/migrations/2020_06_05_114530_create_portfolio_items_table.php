<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePortfolioItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('portfolio_items', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("name");
            $table->longText("content");
            $table->foreignId("portfolio_id");
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign("portfolio_id")->references("id")->on("portfolios")->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('portfolio_items');
    }
}
