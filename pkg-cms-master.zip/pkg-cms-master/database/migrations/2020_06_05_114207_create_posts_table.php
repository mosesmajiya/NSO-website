<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("title");
            $table->foreignId('post_type_id');
            $table->string("author")->nullable();
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime("expires_at")->nullable();
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign('post_type_id')->references('id')->on('post_types')->cascadeOnDelete();
        });
        DB::statement("ALTER TABLE posts ADD content MEDIUMBLOB");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
