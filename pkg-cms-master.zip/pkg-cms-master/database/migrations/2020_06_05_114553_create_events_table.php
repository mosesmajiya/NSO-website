<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("name");
            $table->string("link")->nullable();
//            $table->longText("content");
            $table->dateTime("start_date");
            $table->dateTime("end_date");
            $table->string("venue");
            $table->foreignId("event_type_id");
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign("event_type_id")->references("id")->on("event_types")->cascadeOnDelete();
        });
        DB::statement("ALTER TABLE events ADD content MEDIUMBLOB");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events');
    }
}
