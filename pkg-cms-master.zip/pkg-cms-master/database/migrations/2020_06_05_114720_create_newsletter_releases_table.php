<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateNewsletterReleasesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('newsletter_releases', function (Blueprint $table) {
            $table->id();
            $table->string("volume");
            $table->string("issue");
            $table->string('slug');
            $table->date("published_on");
//            $table->text("content");
            $table->bigInteger("views")->default(0);
            $table->boolean("notification_sent")->default(false);
            $table->foreignId('newsletter_id');
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign('newsletter_id')->references('id')->on('newsletters')->cascadeOnDelete();
        });
        DB::statement("ALTER TABLE newsletter_releases ADD content MEDIUMBLOB");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('newsletter_releases');
    }
}
