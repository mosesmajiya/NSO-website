<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateVacanciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vacancies', function (Blueprint $table) {
            $table->id();
            $table->string("slug");
            $table->string("position");
            $table->enum("job_type", ["permanent", "temporary", "contract"]);
            $table->foreignId("department_id")->nullable();
//            $table->longText("content");
            $table->dateTime("deadline");
            $table->unsignedBigInteger("views")->default(0);
            $table->dateTime('published_at')->nullable();
            $table->timestamps();

            $table->foreign("department_id")->references("id")->on("departments")->cascadeOnDelete();
        });
        DB::statement("ALTER TABLE vacancies ADD content MEDIUMBLOB");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vacancies');
    }
}
