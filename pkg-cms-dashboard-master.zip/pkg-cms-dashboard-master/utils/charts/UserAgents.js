import {Doughnut, mixins} from "vue-chartjs";
// const { reactiveProp } = mixins

export default {
  extends: Doughnut,
  mixins: mixins.reactiveProp,
  props: ['options', 'chartData'],
  watch: {
    chartData: {
      handler: function () {
        this.$data._chart.update()
      }
    }
  },
  mounted() {
    this.renderChart(this.chartData, this.options)
  }
}
