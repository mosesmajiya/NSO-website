// import axios from "~/.nuxt/axios";
//
// const api = axios.create({
//   baseURL: 'http://pkg-cms.test/api',
// });
//
// export default api;

export default function ({$axios, redirect}, inject) {
  // Create a custom axios instance
  const api = $axios.create({
    headers: {
      common: {
        Accept: 'application/json, */*'
      }
    }
  })

  // Set baseURL to something different
  api.setBaseURL('http://pkg-cms.test/api')

  // Inject to context as $api
  inject('api', api)
}
