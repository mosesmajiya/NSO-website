export default class Form {
  constructor(data) {
    this.originalData = data;
    for (let field in data) {
      this[field] = data[field];
    }
    this.errorBag = new ErrorBag();
  }

  data() {
    let data = {};

    for (let property in this.originalData) {
      data[property] = this[property];
    }
    return data;
  }

  reset() {
    let preserve = [];
    for (let field in this.originalData) {
      if (preserve.includes(field)) continue;
      this[field] = '';
    }
    this.errorBag.clear();
  }

  setFormData(data) {
    let formData = new FormData();
    for (let field in data) {
      formData.append(field, data[field]);
    }
    return formData;
  }

  patch(url) {
    return this.submit('patch', url);
  }

  put(url) {
    return this.submit('put', url);
  }

  post(url) {
    return this.submit('post', url);
  }

  delete(url) {
    return this.submit('delete', url);
  }

  load(obj) {
    Object.entries(obj).forEach(
      ([key, value]) => {
        this[key] = value;
      }
    );
  }

  submit(requestType, url) {
    this.errorBag.clear();
    let payload = this.setFormData(this.data());
    if (requestType === 'patch' || requestType === 'put') {
      payload = this.data();
    }
    return new Promise((resolve, reject) => {

      api[requestType](url, payload)
        .then(response => {
          resolve(response.data);
        })
        .catch(err => {
          if (err.response.status === 422) this.onFail(err.response.data.result);

          if (err.response.status === 401) {
            this.errorBag.setDefault(err.response.data.result.message);
          }
          reject(err.response.data);
        });
    });
  }

  onFail(response) {
    this.errorBag.record(response.error);
    this.errorBag.setDefault(response.message);
    this.loading = false;
  }
}

export class ErrorBag {
  constructor() {
    this.errors = {};
  }

  get(field) {
    if (this.errors.hasOwnProperty(field)) {
      return this.errors[field][0];
    }
    return null;
  }

  record(errors) {
    this.errors = errors;
  }

  setDefault(message) {
    this.errors['message'] = message;
  }


  clear(field) {
    if (field) {
      if (this.errors.hasOwnProperty(field)) {
        return delete this.errors[field];
      }
      return;
    }
    this.errors = {};
  }

  has(field) {
    return this.errors.hasOwnProperty(field);
  }

  any() {
    return Object.keys(this.errors).length > 0;
  }

  hasDefault() {
    if (this.errors.hasOwnProperty('message')) {
      return this.errors.message;

    }
  }

  getDefault() {
    if (this.errors.message) {
      return this.errors.message;
    }
  }
}
