<template>
  <div class="bg-primary-500 text-primary-100 border-r rounded-l w-72 pt-12 pb-8">
    <slot></slot>
  </div>
</template>

<script>
  export default {
    name: "Sidenav"
  }
</script>

<style scoped>

</style>
