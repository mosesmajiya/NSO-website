<template>
  <div>
    <div class="mt-8 flex flex-wrap items-stretch" v-if="banners.length">
      <image-card
        :caption="i.caption"
        :remark="$moment(i.created_at).fromNow()"
        :source="i.url"
        :to="getTarget(i)"
        custom-class="w-1/3"
        v-bind:id="i.id"
        v-bind:key="i.id"
        v-for="i in banners"
        v-if="banners"
        v-on:deleted="$router.go(0)"
      />
    </div>

    <div class="mt-8 flex flex-wrap items-stretch border-t pt-8" v-if="attachments.length">
      <attachment-card
        :filename="i.caption"
        :remark="$moment(i.created_at).fromNow()"
        :to="i.download"
        custom-class="w-1/3"
        link-icon="download"
        v-bind:id="i.id"
        v-bind:key="i.id"
        v-for="i in attachments"
        v-on:deleted="$router.go(0)"
      />
    </div>
  </div>
</template>

<script>
import AttachmentCard from "./AttachmentCard";
import ImageCard from "./ImageCard";

export default {
  name: "MediaList",
  components: {ImageCard, AttachmentCard},
  props: ['attachments', 'banners', 'namespace', 'data', 'category'],
  methods: {
    getTarget(item) {
      if (this.category)
        return `/cms/${this.category}/${this.$route.params.id}/${this.namespace}/${this.data.id}/media/${item.id}`

      return `/cms/${this.namespace}/${this.data.id}/media/${item.id}`
    }
  }
}
</script>
