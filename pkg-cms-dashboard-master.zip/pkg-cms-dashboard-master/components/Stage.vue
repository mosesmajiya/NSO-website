<template>
  <div class="m-5 rounded border">
    <div class="bg-gray-100 py-3 px-5">
      <h1 class="text-2xl">{{ title }}</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle"></slot>
      </h2>
    </div>

    <div class="p-5">
      <slot/>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Stage",
    props: ['title', 'subtitle']
  }
</script>
