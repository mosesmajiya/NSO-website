<template>
  <div class="px-8 py-5 bg-gray-100 border-t border-l border-r rounded-t">
    <div class="flex items-center justify-between">
      <h1 class="text-2xl">{{ title }}</h1>
      <span>
          <span class="flex" v-if="live">
            <i class="material-icons text-green-500">fiber_manual_record</i>
          </span>
          <span class="flex" v-else>
            <i class="material-icons text-gray-500">fiber_manual_record</i>
          </span>
        </span>
    </div>
    <h2 class="text-sm pt-4">
      {{ subTitle }}
    </h2>
  </div>
</template>

<script>
  export default {
    name: "ViewCategory",
    props: ['title', 'subTitle', 'live']
  }
</script>
