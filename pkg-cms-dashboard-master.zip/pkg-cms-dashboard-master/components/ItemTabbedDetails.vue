<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-chevron-left class="w-6 h-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex" exact>
        <svg-file class="w-6 h-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex">
        <svg-pencil-alt class="w-6 h-6 mr-2"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/media`" class="flex">
        <svg-camera class="w-6 h-6 mr-2"/>
        Media
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/metadata`" class="flex">
        <svg-code class="w-6 h-6 mr-2"/>
        Metadata
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>
import ContextualMenu from "./ContextualMenu";
import TabItem from "./tabItem";
import FaIcon from "./FaIcon";
import SvgChevronLeft from "@/components/icons/svg-chevron-left";
import SvgFile from "@/components/icons/svg-file";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";
import SvgCamera from "@/components/icons/svg-camera";
import SvgCode from "@/components/icons/svg-code";

export default {
  name: "ItemTabbedDetails",
  components: {SvgCode, SvgCamera, SvgPencilAlt, SvgFile, SvgChevronLeft, FaIcon, TabItem, ContextualMenu},
  props: ['data', 'namespace', 'menu']
}
</script>
