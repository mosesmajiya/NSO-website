<template>
  <div class="flex items-center justify-center text-gray-200 watermark">CONTENT</div>
</template>

<script>
  export default {
    name: "landing"
  }
</script>

<style scoped>
  .watermark {
    font-size: 16rem;
  }
</style>
