<template>
  <div :class="customClass" class="relative">
    <button @click="isOpen = true" class="focus:outline-none">
      <svg-delete class="mx-2 my-1 text-sm text-gray-500 hover:text-gray-600 h-4 w-4"/>
    </button>
    <div class="inset-0 bg-black opacity-75 w-full h-full fixed flex" v-if="isOpen">

    </div>
    <div @click.exact="isOpen = false" class="inset-0 fixed flex justify-center items-center" v-if="isOpen">
      <div @click.stop class="absolute w-84 rounded opacity-100 bg-gray-100 shadow">
        <div class="border-b-2 border-primary-500 text-xl px-8 py-4">
          {{ title }}
        </div>
        <div class="px-8 py-4">
          {{ message }}
          <div class="mt-4 flex">
            <form-button @click="dismiss" accent="red" custom-class="mr-4 flex-1">
              Confirm
            </form-button>
            <form-button @click="isOpen = false" accent="gray" custom-class="flex-1">
              Cancel
            </form-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FormButton from "./FormButton";
import FaIcon from "./FaIcon";
import SvgDelete from "./icons/svg-delete";

export default {
  name: "ConfirmIcon",
  components: {SvgDelete, FaIcon, FormButton},
  props: {

    accent: {
      default: 'gray',
    },
    message: String,
    title: String,
    label: String,
    type: {
      default: 'button'
    },
    faIcon: String,
    icon: String,
    customClass: String,
  },
  data() {
    return {
      isOpen: false
    }
  },
  methods: {
    dismiss() {
      this.isOpen = false;
      this.$emit('confirmed')
    }
  },
  created() {
    if (process.client) {
      const handleEscape = e => {
        if (e.key === 'Esc' || e.key === 'Escape') {
          this.isOpen = false
        }
      }
      const handleEnter = e => {
        if (e.key === 'Enter') {
          this.$emit('confirmed')
        }
      }
      document.addEventListener('keydown', handleEscape)
      document.addEventListener('keydown', handleEnter)

      this.$once('hook:beforeDestroy', () => {
        document.removeEventListener('keydown', handleEscape)
        document.removeEventListener('keydown', handleEnter)
      })
    }
  }
}
</script>

