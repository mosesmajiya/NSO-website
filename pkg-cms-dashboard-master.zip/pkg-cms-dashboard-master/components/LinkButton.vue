<template>
  <nuxt-link :to="to"
             :class="`btn flex items-center bg-${accent}-500 text-white hover:bg-${accent}-600 px-4 py-2 text-sm rounded mr-4`">
    <i class="material-icons mr-2" v-if="icon">{{icon}}</i>
    <slot/>
  </nuxt-link>
</template>

<script>
  export default {
    name: "LinkButton",
    props: ['icon', 'to', 'accent']
  }
</script>
