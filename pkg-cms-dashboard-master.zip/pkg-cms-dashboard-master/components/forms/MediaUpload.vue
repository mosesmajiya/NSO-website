<template>
  <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">
    <text-input
      label="Caption"
      name="caption"
      v-bind:error="errors.caption"
      v-bind:value="form.caption"
      v-on:input="form.caption = $event"
    />

    <div class="flex mb-5">
      <dropdown-input
        class="md:w-1/2 md:mr-4"
        label="Type"
        name="type"
        v-bind:error="errors.type"
        v-bind:options="[
            {value: 'banner', label: imageType},
            {value: 'attachment', label: 'Attachment'},
          ]"
        v-bind:value="form.type"
        v-on:change="form.type = $event"
      />

      <file-input class="md:w-1/2" id="file" label="File" v-bind:error="errors.file" v-model="form.file"/>
    </div>

    <form-submit accent="primary">Upload File</form-submit>
  </form>
</template>

<script>
  import TextInput from "./TextInput";
  import DropdownInput from "./DropdownInput";
  import FileInput from "./FileInput";
  import FormSubmit from "./FormSubmit";

  export default {
    name: "MediaUpload",
    components: {FormSubmit, FileInput, DropdownInput, TextInput},
    props: {
      namespace: String,
      urlParam: {
        default: 'id'
      },
      imageType: {
        default: 'Banner'
      }
    },
    data() {
      return {
        form: {
          file: '',
          caption: '',
          type: ''
        },
        errors: [],
      }
    },
    methods: {
      onSubmit() {
        let formData = new FormData();
        let type = this.form.type ? this.form.type : 'banner'
        formData.append('file', this.form.file)
        formData.append('type', this.form.type)
        formData.append('caption', this.form.caption)

        this.$axios.post(`/${this.namespace}/${this.$route.params[this.urlParam]}/attach/${type}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
          .then(() => this.$router.go())
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
