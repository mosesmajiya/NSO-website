<template>
  <div class="pb-5">
    <label>
      <span class="block mb-2">{{ label }}</span>
      <slot/>
    </label>
    <p class="text-red-500 text-sm">{{ error }}</p>
  </div>
</template>

<script>
  export default {
    name: "FormGroup",
    props: {
      error: String,
      label: {
        type: String,
        required: true
      },
    }
  }
</script>
