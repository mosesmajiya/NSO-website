<template>
  <div class="pb-5">
    <label>{{ label }}
      <input
        :id="name"
        :name="name"
        :type="type"
        autocomplete="off"
        v-bind:value="value"
        :placeholder="placeholder"
        step="any"
        class="block w-full border border-gray-300 rounded mt-2 px-4 py-2 focus:outline-none focus:border-gray-500"
        v-on:input="$emit('input', $event.target.value)"
      />
    </label>
    <slot></slot>
    <p class="text-red-500 text-sm">{{ error }}</p>
  </div>
</template>

<script>
  export default {
    name: "TextInput",
    props: {
      error: String,
      label: {
        type: String,
        required: false
      },
      name: {
        type: String,
        required: true
      },
      value: {
        required: false
      },
      type: {
        default: 'text'
      },
      placeholder: {
        type: String,
      }
    }

  }
</script>
