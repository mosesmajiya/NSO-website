<template>
  <div class="mb-5">
    <form-button @click="$emit('click')" type="submit" v-bind:accent="accent">
      <slot>Save</slot>
    </form-button>
  </div>
</template>

<script>
  import FormButton from "../FormButton";

  export default {
    name: "FormSubmit",
    props: ['accent'],
    components: {FormButton}
  }
</script>
