<template>
  <div class="pb-5">
    <label class="block mb-2">{{ label }}</label>
    <client-only>
      <vue-pell-editor
        v-model="editorContent"
        :actions="pellEditorOptions"
        :classes="editorClasses"
        :content="editorContent"
        :placeholder="editorPlaceholder"
        :style-with-css="false"
        default-paragraph-separator="p"
        @change="doSomething"
        @mounted="doSomethingAfterMounted"
        v-on:input="$emit('input', $event)"
      >
      </vue-pell-editor>
    </client-only>

    <client-only>
      <quill-editor v-if="false" ref="editor" :options="editorOption" v-bind:value="value"
                    v-on:input="$emit('input', $event)"/>
    </client-only>
    <p class="text-red-500 text-sm">{{ error }}</p>
  </div>
</template>

<script>
import FormGroup from "./FormGroup";

export default {
  name: "ParagraphInput",
  components: {FormGroup},
  props: ['label', 'error', 'value'],
  watch: {
    value: function (newValue) {
      this.editorContent = newValue
    }
  },
  methods: {
    doSomething(e) {
    },
    doSomethingAfterMounted() {
      console.log(this.value)
      console.log('aa')
      this.editorContent = this.value
    }
  },
  data() {
    return {
      editorOption: {
        theme: 'snow',
        modules: {}
      },
      pellEditorOptions: [
        'heading1',
        'heading2',
        'paragraph',
        'bold',
        'underline',
        {
          name: 'italic',
          result: () => window.pell.exec('italic')
        },
        {
          name: 'link',
          result: () => {
            const url = window.prompt('Enter the link URL')
            if (url) window.pell.exec('createLink', ensureHTTP(url))
          }
        }
      ],
      editorPlaceholder: 'Write something amazing...',
      editorContent: this.value,
      editorClasses: {
        actionbar: 'pell-actionbar p-1 rounded-t border',
        button: 'pell-button',
        content: 'pell-content text-sm border rounded-b border-t-0 focus:border-gray-500',
        selected: 'pell-button-selected'
      }
    }
  }
}
</script>

<style>
.pell-content h1 {
  @apply text-2xl pt-4 pb-2;
}

.pell-content h2 {
  @apply text-lg py-2;
}
</style>
