<template>
  <div>
    <label>{{ label }}
      <input
        class="flex-1 py-1 mt-1 px-4 flex-grow outline-none block border border-gray-300 rounded w-full bg-white"
        type="file"
        v-bind:id="id"
        v-on:change="handleFileChange"
      />
    </label>
    <div class="text-sm text-red-500" v-if="error">{{ error }}</div>
  </div>
</template>

<script>
  export default {
    name: "FileInput",
    props: {
      error: String,
      id: String,
      label: String,
      value: {required: false}
    },
    methods: {
      handleFileChange(e) {
        this.$emit('input', e.target.files[0])
      }
    }
  }
</script>
