<template>
  <metadata-stage title="Metadata" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input
        label="Keywords"
        name="keywords"
        v-bind:error="errors.keywords"
        v-bind:value="form.keywords"
        v-on:input="form.keywords = $event"
      />
      <form-group label="Description">
        <textarea
          class="px-4 py-2 w-full block border border-gray-300 focus:outline-none focus:border-gray-400 rounded "
          v-model="form.description">
        </textarea>
        <p class="text-red-500 text-sm">{{ errors.description }}</p>

      </form-group>
      <form-submit>Update</form-submit>
    </form>
  </metadata-stage>
</template>

<script>
  import MetadataStage from "../MetadataStage";
  import TextInput from "./TextInput";
  import FormGroup from "./FormGroup";
  import FormSubmit from "./FormSubmit";

  export default {
    name: "MetadataEdit",
    components: {FormSubmit, FormGroup, TextInput, MetadataStage},
    props: ['namespace', 'form', 'data', 'namespaceId'],
    data() {
      return {
        errors: [],
        form: {
          description: '',
          keywords: ''
        }
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`${this.namespace}/${this.$route.params[this.namespaceId]}/metadata`, this.form)
          .then(() => this.$router.go())
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
