<template>
  <div class="pb-5">
    <label>{{ label }}
      <select
        class="px-4 py-2 mt-2 border border-gray-300 w-full block rounded bg-white focus:outline-none focus:border-gray-400"
        v-bind:name="name"
        v-bind:value="value"
        v-on:change="$emit('change', $event.target.value)"
      >
        <option></option>
        <option v-for="option in options" v-bind:key="option.value" :selected="value === option.value"
                v-bind:value="option.value">{{
            option.label
          }}
        </option>
      </select>
    </label>
    <div class="text-sm text-red-500" v-if="error">{{ error }}</div>
  </div>
</template>

<script>
export default {
  name: "DropdownInput",
  props: {
    label: String,
    name: String,
    options: Array,
    error: {required: false},
    value: {required: false}
  }
}
</script>
