<template>
  <div class="pb-5">
    <label>{{ label }}
      <textarea
        :id="name"
        :name="name"
        :rows="rows"
        autocomplete="off"
        class="block w-full border border-gray-300 rounded mt-2 px-4 py-2 focus:outline-none focus:border-gray-500"
        v-bind:value="value"
        v-on:input="$emit('input', $event.target.value)"
      >
        </textarea>
    </label>
    <slot></slot>
    <p class="text-red-500 text-sm">{{ error }}</p>
  </div>
</template>

<script>

export default {
  name: "LongTextInput",
  props: {
    error: String,
    label: {
      type: String,
      required: true
    },
    rows: {
      type: Number,
      default: 5
    },
    name: {
      type: String,
      required: true
    },
    value: {
      required: true
    }
  }
}
</script>

<style scoped>

</style>
