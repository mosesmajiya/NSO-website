<template>
  <div class="flex items-start">
    <form-submit accent="primary" class="mr-4">
      <slot>Save</slot>
    </form-submit>
    <form-link v-bind:to="to">Cancel</form-link>
  </div>
</template>

<script>
  import FormSubmit from "./FormSubmit";
  import FormLink from "./FormLink";

  export default {
    name: "FormActions",
    components: {FormLink, FormSubmit},
    props: ['to']
  }
</script>
