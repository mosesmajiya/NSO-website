<template>
  <nuxt-link
    :class="`bg-primary-500 hover:bg-primary-600 text-white rounded px-4 py-2 focus:outline-none ${customClass}
              focus:bg-primary-700`"
    v-bind:to="to"
  >
    <span class="flex items-center justify-center">
    <i
      class="material-icons mr-2"
      v-if="icon"
    >
      {{ icon }}
    </i>
      <font-awesome-icon :icon="['fas', faIcon]" class="mr-2" v-if="faIcon"/>
      <slot>Submit</slot>

    </span>
  </nuxt-link>
</template>

<script>
  export default {
    name: "FormLink",
    props:
      {
        accent: {
          default: 'gray',
        },
        to: String,
        faIcon: String,
        icon: String,
        customClass: String
      }
  }
</script>
