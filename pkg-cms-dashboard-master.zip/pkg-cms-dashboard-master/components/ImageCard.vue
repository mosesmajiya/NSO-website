<template>
  <div :class="`rounded w-1/3 ${customClass}`">
    <div class="mr-4 mb-8 shadow hover:shadow-lg overflow-hidden">
      <nuxt-link v-bind:to="to">
        <img :alt="caption" :src="source" class="object-cover h-48 w-full rounded-t"/>
      </nuxt-link>
      <p class="text-sm text-gray-600 p-3 h-16">{{ caption | str_limit(80) }}</p>
      <div class="flex px-3 pb-3 rounded-b">
        <p class="text-xs flex-grow">{{ remark }}</p>
        <div class="flex">
          <nuxt-link :to="to" v-if="to">
            <fa-icon
              :icon="linkIcon"
              class="mx-2 my-1 text-sm text-gray-500 hover:text-gray-600 mr-4"
            />
          </nuxt-link>
          <confirm-icon
            :icon="actionIcon"
            v-on:confirmed="destroy"
            message="This item will be deleted permanently"
            title="Delete Confirmation"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import FaIcon from "./FaIcon";
  import ConfirmButton from "./ConfirmButton";
  import ConfirmIcon from "./ConfirmIcon";

  export default {
    name: "ImageCard",
    components: {ConfirmIcon, ConfirmButton, FaIcon},
    props: {
      customClass: {
        type: String,
        required: true
      },
      caption: {
        type: String,
        required: false,
      },
      source: {
        type: String,
        required: true
      },
      remark: {
        type: String,
        required: true
      },
      actionIcon: {
        type: String,
        default: 'trash'
      },
      linkIcon: {
        type: String,
        default: 'edit'
      },
      to: {
        type: String,
        required: true
      },
      id: {required: true}
    },
    methods: {
      async destroy() {
        let deleted = await this.$axios.delete(`media/${this.id}`)
        if (deleted) this.$emit('deleted')
      }
    }
  }
</script>

