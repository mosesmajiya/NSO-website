<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 p-8">
      <form @submit.prevent="onSearch" class="flex">
        <input
          v-model="term"
          class="text-lg flex-grow border border-r-0 focus:shadow focus:border-transparent p-2 rounded-l outline-none px-4"
          type="text">
        <button
          class="btn flex items-center shadow bg-primary-500 text-white hover:bg-primary-600 focus:outline-none px-4 py-2 text-sm rounded-r"
          type="submit">
          Search
        </button>
      </form>
      <p class="pt-5" v-if="searching">
        Searching for <span class="font-bold">{{ term }}</span>
        <button
          @click="$emit('cancel')"
          class="focus:outline-none text-gray-500 hover:text-gray-700 px-3 uppercase text-sm ml-4 border border-gray-400 rounded-full"
        >
          Clear
        </button>
      </p>
    </div>

    <div class="pb-8">
      <slot/>
    </div>
  </div>
</template>

<script>
  import FaIcon from "./FaIcon";

  export default {
    name: "IndexStage",
    components: {FaIcon},
    props: ['title', 'subtitle', 'fields', 'table'],
    data() {
      return {
        term: '',
        searching: false,
      }
    },
    methods: {
      async onSearch() {
        this.$axios.post(`/search`, {term: this.term, fields: this.fields, table: this.table})
          .then(response => {
            this.$emit('loadeddata', response.data.data)
            this.searching = true
          })
      }
    }
  }
</script>
