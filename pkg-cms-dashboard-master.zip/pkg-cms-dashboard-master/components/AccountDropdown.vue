<template>
  <div class="z-10 relative">
    <button
      @click="isOpen = !isOpen"
      class="relative z-10 block h-8 w-8 rounded-full overflow-hidden border-2 border-gray-200 focus:outline-none
    focus:border-gray-500">
      <img v-if="avatar" :src="avatar" alt="avatar" class="h-full w-full object-cover"/>
      <img v-else alt="avatar" class="h-full w-full object-cover" src="~assets/images/no-image.png"/>
    </button>
    <button
      @click="isOpen = false"
      class="fixed inset-0 bg-black opacity-25 h-full w-full cursor-default"
      tabindex="-1"
      v-if="isOpen"
    ></button>
    <div
      class="absolute right-0 mt-2 w-64 bg-white rounded py-2 shadow-xl"
      v-if="isOpen">
      <div class="block text-center border-b px-4 pt-2 pb-3 text-gray-800">
        <div class="text-lg leading-none">{{ username }}</div>
        <span class="text-xs">{{ email }}</span>
      </div>
      <button @click="openAccountSettings"
              class="flex px-4 py-2 text-gray-800 hover:bg-primary-500 hover:text-white w-full text-left focus:outline-none">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
          <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Account Settings
      </button>
      <button @click="signOut"
              class="flex w-full text-left px-4 py-2 text-gray-800 hover:bg-primary-500 hover:text-white">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Sign Out
      </button>
    </div>
  </div>
</template>

<script>
import FaIcon from "./FaIcon";

export default {
  name: "AccountDropdown",
  components: {FaIcon},
  data() {
    return {
      isOpen: false
    }
  },
  methods: {
    async signOut() {
      let response = (await this.$axios.post(`logout`)).data
      if (response.status.success) {
        localStorage.removeItem('user')
        localStorage.removeItem('token')
        localStorage.removeItem('email')
        await this.$router.push('login')
      }
    },
    openAccountSettings() {
      this.isOpen = false
      this.$router.push('/settings/account')
    }
  },
  computed: {
    email() {
      return localStorage.getItem('email')
    },
    username() {
      return localStorage.getItem('user')
    },
    avatar() {
      return this.$store.getters['user/GET_AVATAR']
    }
  },
  created() {
    if (process.client) {
      const handleEscape = (e) => {
        if (e.key === 'Esc' || e.key === 'Escape') {
          this.isOpen = false;
        }
      }
      document.addEventListener('keydown', handleEscape)

      this.$once('hook:beforeDestroy', () => {
        document.removeEventListener('keydown', handleEscape)
      })
    }

  }
}
</script>
