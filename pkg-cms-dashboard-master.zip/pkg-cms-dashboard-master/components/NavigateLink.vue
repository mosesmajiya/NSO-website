<template>
  <a
    :class="`bg-${accent}-500 hover:bg-${accent}-600 text-white rounded px-4 py-2 focus:outline-none ${customClass}
              focus:bg-${accent}-700`" v-bind:href="to"
    v-bind:target="target"
  >
    <span class="flex items-center justify-center">
      <slot>Submit</slot>
    </span>
  </a>
</template>

<script>
  export default {
    name: "NavigateLink",
    props: {
      accent: {
        default: 'gray'
      },
      to: String,
      target: {
        default: "_blank"
      },
      customClass: String
    }
  }
</script>

