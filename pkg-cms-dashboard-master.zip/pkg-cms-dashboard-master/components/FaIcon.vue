<template>
  <font-awesome-icon :class="customClass" :icon="[iconType, icon]"/>
</template>

<script>
  export default {
    name: "FaIcon",
    props: {
      customClass: String,
      icon: String,
      iconType: {
        default: 'fas'
      }
    },
  }
</script>
