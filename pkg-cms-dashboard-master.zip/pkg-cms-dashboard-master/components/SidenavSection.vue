<template>
  <ul class="text-sm secondary-nav">
    <sidenav-divider :action="action" :action-to="actionTo" :icon="icon">{{ label }}</sidenav-divider>
    <slot></slot>
  </ul>
</template>

<script>
import SidenavDivider from "./SidenavDivider";

export default {
  name: "SidenavSection",
  components: {SidenavDivider},
  props: ['icon', 'label', 'action', 'actionTo']
}
</script>
