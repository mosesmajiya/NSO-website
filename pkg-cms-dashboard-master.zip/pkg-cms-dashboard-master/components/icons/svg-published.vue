<template>
  <svg :class="published" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <path class="" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8z" fill="currentColor"></path>
  </svg>
</template>

<script>
export default {
  name: "svg-published",
  props: ['on'],
  computed: {
    published() {
      return this.on ? 'w-4 h-4 text-green-500' : 'w-4 h-4 text-gray-400'
    }
  }
}
</script>

<style scoped>

</style>
