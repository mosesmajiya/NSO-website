<template>
  <line-chart v-bind:chart-data="chartData" v-bind:options="options" v-if="chartData"/>
</template>

<script>
import LineChart from "@/utils/charts/DailyHits";

export default {
  components: {LineChart},
  created() {
    if (!process.browser) return
    this.$axios.get('dashboard/daily-hits')
      .then(res => {
        let chart = res.data.data
        this.chartData = {
          labels: chart.map(i => i.date),
          datasets: [
            {
              label: 'Daily Hits',
              data: chart.map(i => i.value),
              backgroundColor: 'rgba(43,160,219, 0.2)',
              borderColor: 'rgba(43,160,219, 0.3)',
              borderWidth: 2,
              pointRadius: 2,
              gridLines: false,
            }
          ]
        }
        this.options = {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            xAxes: [
              {
                gridLines: {
                  color: 'rgba(0,0,0,0.05)'
                }
              }
            ],
            yAxes: [
              {
                gridLines: {
                  color: 'rgba(0,0,0,0.05)'
                },
                ticks: {
                  beginAtZero: false
                }
              }
            ]
          }
        }

      })
  },
  data() {
    return {
      loaded: true,
      chartData: null,
      options: null
    }
  },
}
</script>

<style>

</style>
