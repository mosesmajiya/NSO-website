<template>
  <pie-chart v-bind:chart-data="chartData" v-bind:options="options" v-if="chartData"/>
</template>

<script>
import PieChart from "@/utils/charts/UserAgents";

export default {
  components: {PieChart},
  created() {
    if (!process.browser) return
    this.$axios.get('dashboard/visits-by-device')
      .then(res => {
        let chart = res.data.data
        this.chartData = {
          labels: chart.map(i => i.device),
          datasets: [
            {
              data: chart.map(i => i.value),
              backgroundColor: ['rgba(43,160,219, 0.9)', 'rgba(246,155,40, 0.5)', 'rgba(255, 0, 0, 0.6)'],
              borderColor: 'rgba(255,255,255, 1)',
              borderWidth: 2,
              pointRadius: 2,
              gridLines: false,
            }
          ]
        }
        this.options = {
          responsive: true,
          maintainAspectRatio: false,
        }

      })
  },
  data() {
    return {
      loaded: true,
      chartData: null,
      options: null
    }
  },
}
</script>

<style>

</style>
