<template>
  <nuxt-link :to="to" class="items-center py-4 border-b-4 px-5 border-gray-200 hover:text-primary-500">
    <slot/>
  </nuxt-link>
</template>

<script>
  export default {
    name: "tabItem",
    props: ['to']
  }
</script>
