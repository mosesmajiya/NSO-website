<template>
  <div v-if="page">
    <side-info-item title="Description" v-if="page && page.metadata">{{ page.metadata.description }}</side-info-item>
    <side-info-item title="Keywords" v-if="page && page.metadata">{{ page.metadata.keywords }}</side-info-item>
    <side-info-item title="Slug">{{ page.slug }}</side-info-item>
    <side-info-item title="Created">{{ $moment(page.created_at).format("D MMMM YYYY, h:mm a") }}</side-info-item>
    <side-info-item title="Updated">{{ $moment(page.updated_at).format("D MMMM YYYY, h:mm a") }}</side-info-item>
    <side-info-item title="Views">{{ page.views }}</side-info-item>
    <side-info-item title="State">
      <span class="flex" v-if="page.published_at">
        <i class="material-icons text-green-500">fiber_manual_record</i>
        Live
      </span>
      <span class="flex" v-else>
        <i class="material-icons text-gray-500">fiber_manual_record</i>
        Draft
      </span>
    </side-info-item>
  </div>
</template>

<script>
  import SideInfoItem from "./SideInfoItem";

  export default {
    name: "PageDetails",
    components: {SideInfoItem},
    props: {
      page: {
        type: Object
      }
    }
  }
</script>

