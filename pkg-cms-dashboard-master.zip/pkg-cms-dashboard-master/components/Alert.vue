<template>
  <div :class="`flex items-center bg-${accent}-200 px-2 py-1 border-l-4 border-${accent}-500 rounded`">
    <div class="pl-2 pr-3">
      <i :class="`material-icons text-${accent}-800`">{{ icon }}</i>
    </div>
    <div>
      <h2 :class="`text-xl text-${accent}-800`">{{ title }}</h2>
      <p :class="`text-sm text-${accent}-600`">{{ body }}</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Alert",
    props: ['accent', 'title', 'body', 'icon']
  }
</script>
