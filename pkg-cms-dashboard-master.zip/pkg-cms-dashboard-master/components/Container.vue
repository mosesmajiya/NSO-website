<template>
  <div class="max-w-4xl">
    <slot></slot>
  </div>
</template>

<script>
  export default {
    name: "Container"
  }
</script>

<style scoped>

</style>
