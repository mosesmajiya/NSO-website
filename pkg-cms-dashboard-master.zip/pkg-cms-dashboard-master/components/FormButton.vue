<template>
  <button
    :class="cssClass" class="text-white rounded px-4 py-2 focus:outline-none"
    :type="type"
    @click="$emit('click')">
    <span class="flex items-center justify-center">
    <i
      class="material-icons mr-2"
      v-if="icon"
    >
      {{ icon }}
    </i>
      <slot>Submit</slot>

    </span>
  </button>
</template>

<script>
export default {
  name: "FormButton",
  computed: {
    cssClass() {
      return `bg-primary-500 hover:bg-primary-600 ${this.customClass} focus:bg-primary-700`
    }
  },
  props:
    {
      accent: {
        default: 'primary',
      },
      type: {
        default: 'button'
      },
      faIcon: String,
      icon: String,
      customClass: {
        default: ''
      }
    }

}
</script>

<style>

</style>

