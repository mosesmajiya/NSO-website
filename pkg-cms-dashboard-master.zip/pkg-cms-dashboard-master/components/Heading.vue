<template>
  <h1 class="text-2xl my-2">
    <slot></slot>
  </h1>
</template>

<script>
  export default {
    name: "Heading"
  }
</script>
