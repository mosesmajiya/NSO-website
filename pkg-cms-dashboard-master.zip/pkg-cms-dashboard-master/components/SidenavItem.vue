<template>
  <li class="py-px">
    <nuxt-link :to="to"
               class="block hover:text-white hover:border-gray-100 border-l-4 border-transparent pl-6 py-1">
      <slot></slot>
    </nuxt-link>
  </li>
</template>

<script>
  export default {
    name: "SidenavItem",
    props: ['to']
  }
</script>
