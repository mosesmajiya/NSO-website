<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">{{ title }}</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle">
          <div class="flex">
            <div class="flex mr-4">
              <svg-bar-graph class="w-5 h-5 mr-2"/>
              <p>{{ data.views }} views</p>
            </div>
            <div class="flex mr-4 items-center" v-if="data.url">
              <svg-globe class="w-5 h-5 mr-2"/>
              <p><a class="hover:text-underline" target="_blank" v-bind:href="data.url">{{ data.url }}</a></p>
            </div>
            <div class="flex mr-4">
              <svg-clock-solid class="w-5 h-5 mr-2"/>
              <p>{{ $moment(data.created_at).fromNow() }}</p>
            </div>

          </div>
        </slot>
      </h2>
    </div>

    <div class="p-8 flex flex-row">
      <div class="flex-1 content text-lg text-gray-600 font-editor">
        <slot/>
      </div>
      <div class="w-1/4 ml-8">
        <div class="border">
          <h3 class="bg-gray-200 px-5 py-3">Details</h3>
          <div class="px-5 pb-3">
            <slot name="details">
              <page-details v-bind:page="data"/>
            </slot>
          </div>
        </div>
        <div class="mt-5">
          <slot name="actions">
            <div class="flex">
              <form-button
                @click="$emit('onTogglePublish')"
                custom-class="flex-1 mr-2">
                <svg-unpublish v-if="data.published_at" class="mr-2"/>
                <svg-publish v-else class="mr-2"/>
                {{ data.published_at ? 'Unpublish' : 'Publish' }}
              </form-button>
              <confirm-button
                @confirmed="$emit('onDelete')"
                custom-class="flex-1"
                icon="delete"
                label="Delete"
                title="Confirm Deletion"
                v-bind:message="`${data[headingColumn]} will be permanently deleted.`"
              >
                Delete
              </confirm-button>
            </div>
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PageDetails from "./PageDetails";
import FormButton from "./FormButton";
import ConfirmButton from "./ConfirmButton";
import FaIcon from "./FaIcon";
import SvgBarGraph from "@/components/icons/svg-bar-graph";
import SvgClock from "@/components/icons/svg-clock";
import SvgGlobe from "@/components/icons/svg-globe";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgUnpublish from "./icons/svg-unpublish";
import SvgPublish from "./icons/svg-publish";

export default {
  name: "ViewStage",
  components: {
    SvgPublish,
    SvgUnpublish,
    SvgClockSolid, SvgGlobe, SvgClock, SvgBarGraph, FaIcon, ConfirmButton, FormButton, PageDetails
  },
  props: ['title', 'subtitle', 'data', 'headingColumn']
}
</script>
