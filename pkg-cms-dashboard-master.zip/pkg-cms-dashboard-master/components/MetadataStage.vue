<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">{{ title }}</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle">Edit Page Metadata</slot>
      </h2>
    </div>

    <div class="p-8 flex flex-row">
      <div class="flex-1">
        <slot/>
      </div>
      <div class="w-1/4 ml-8">
        <div class="border">
          <h3 class="bg-gray-200 px-5 py-3">Details</h3>
          <div class="px-5 pb-3">
            <slot name="details">
              <page-details v-bind:page="data" v-if="data"/>
            </slot>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import PageDetails from "./PageDetails";

  export default {
    name: "MetadataStage",
    components: {PageDetails},
    props: ['title', 'subtitle', 'data']
  }
</script>
