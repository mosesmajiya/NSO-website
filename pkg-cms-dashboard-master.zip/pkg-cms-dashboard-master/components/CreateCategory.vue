<template>
  <div>
    <navigate-back :to="`/cms/${category}`"/>
    <div class="border-gray-300 border rounded m-8">
      <div class="bg-gray-200 px-8 py-5">
        <h1 class="text-2xl">{{ title }}</h1>
        <h2 class="text-sm pt-4">{{ subTitle }}</h2>
      </div>
      <div class="p-8">
        <slot/>
      </div>
    </div>
  </div>
</template>

<script>
  import NavigateBack from "./NavigateBack";

  export default {
    name: "CreateCategory",
    components: {NavigateBack},
    props: ['category', 'title', 'subTitle']
  }
</script>
