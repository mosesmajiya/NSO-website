<template>
  <div class="mt-4 text-sm">
    <p class="text-gray-500">{{ title }}</p>
    <p>
      <slot/>
    </p>
  </div>
</template>

<script>
  export default {
    name: "SideInfoItem",
    props: ['title']
  }
</script>
