<template>
  <ul class="flex h-16 ml-6 items-center text-gray-500 main-nav">
    <main-nav-item exact to="/">Dashboard</main-nav-item>
    <main-nav-item to="/cms">Manage Content</main-nav-item>
    <main-nav-item to="/settings">Settings</main-nav-item>
  </ul>
</template>

<script>
  import MainNavItem from "./MainNavItem";

  export default {
    name: "MainNav",
    components: {MainNavItem}
  }
</script>
