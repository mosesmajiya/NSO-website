<template>
  <li
    class="flex items-center mt-4 pt-2 border-t border-primary-400 uppercase font-bold text-xs pl-6 ml-1 text-primary-300 py-1 block font-mono">
    <i class="material-icons mr-2">{{ icon }}</i>
    <p class="flex-1">
      <slot></slot>
    </p>
    <nuxt-link v-if="action" :to="actionTo"
               class="capitalize bg-primary-300 hover:bg-primary-600 hover:text-primary-400 text-primary-600 border-primary-400 text-xs px-2 py-px rounded mr-2">
      {{ action }}
    </nuxt-link>
  </li>
</template>

<script>
export default {
  name: "SidenavDivider",
  props: ['icon', 'action', 'actionTo']
}
</script>
