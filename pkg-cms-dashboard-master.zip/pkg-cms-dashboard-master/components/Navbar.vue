<template>
  <header class="bg-white border-b-4 border-primary-500 sm:px-8 sm:flex sm:justify-between sm:items-center">
    <div class="px-8 flex items-center justify-between sm:p-0">
      <div class="h-16 flex items-center">
        <a href="/"><img class="h-12" v-bind:src="logo" v-if="logo"/></a>
      </div>
      <div class="sm:hidden">
        <button
          @click="isOpen = !isOpen"
          class="px-2 py-1 focus:outline-none hover:text-primary-500">
          <fa-icon :icon="isOpen ? 'times' : 'bars'"/>
        </button>
      </div>
    </div>
    <nav :class="isOpen ? 'block' : 'hidden'" class="sm:block">
      <div class="main-nav px-6 pb-4 pt-2 sm:flex sm:p-0">
        <nuxt-link class="px-2 py-1 block hover:bg-gray-200 rounded sm:hover:bg-transparent" to="/dashboard">Dashboard
        </nuxt-link>
        <nuxt-link class="mt-1 px-2 py-1 block hover:bg-gray-200 rounded sm:py-0 sm:ml-2 sm:hover:bg-transparent"
                   to="/cms">Manage Content
        </nuxt-link>
        <nuxt-link class="mt-1 px-2 py-1 block hover:bg-gray-200 rounded sm:py-0 sm:ml-2 sm:hover:bg-transparent"
                   to="/settings">Settings
        </nuxt-link>
<!--        <nuxt-link class="mt-1 px-2 py-1 block hover:bg-gray-200 rounded sm:py-0 sm:ml-2 sm:hover:bg-transparent"-->
<!--                   to="/extras">Extras-->
<!--        </nuxt-link>-->
        <account-dropdown @onOpenSettings="openAccountSettings" class="ml-4 hidden sm:block"/>
      </div>
      <div class="z-10 px-8 py-5 border-t border-gray-200 sm:hidden">
        <div class="flex items-center">
          <div
            class="z-10 block h-8 w-8 rounded-full overflow-hidden border-2 border-gray-200">
            <img v-if="hasAvatar" :src="avatar" alt="avatar" class="h-full w-full object-cover"/>
            <img v-else alt="avatar" class="h-full w-full object-cover" src="https://source.unsplash.com/60x60"/>
          </div>
          <span class="ml-3 font-semibold">John MF Doe</span>
        </div>

        <div class="mt-4">
          <button @click="openAccountSettings" class="block text-gray-600 hover:text-gray-700 mt-2">Account settings
          </button>
          <a class="block text-gray-600 hover:text-gray-700 mt-2 " href="#">Sign out</a>
        </div>
      </div>
    </nav>
  </header>
</template>

<script>
import MainNav from "./MainNav";
import AccountDropdown from "./AccountDropdown";
import FaIcon from "./FaIcon";

export default {
  name: "Navbar",
  components: {FaIcon, AccountDropdown, MainNav},
  data() {
    return {
      isOpen: false
    }
  },
  props: ['logo'],
  computed: {
    hasAvatar() {
      return !!this.avatar;
    },
    avatar() {
      return this.$store.getters['user/GET_AVATAR']
    }
  },
  methods: {
    openAccountSettings() {
      this.isOpen = false
      this.$router.push('/settings/account')
    }
  }
}
</script>
