<template>
  <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
    <nuxt-link class="px-4 py-2 hover:text-primary-500" v-bind:to="to">
      <svg-chevron-left class="w-6"/>
    </nuxt-link>
  </contextual-menu>
</template>

<script>
  import ContextualMenu from "./ContextualMenu";
  import LinkButton from "./LinkButton";
  import FaIcon from "./FaIcon";
  import SvgChevronLeft from "./icons/svg-chevron-left";

  export default {
    name: "NavigateBack",
    components: {SvgChevronLeft, FaIcon, LinkButton, ContextualMenu},
    props: {
      to: String,
      namespace: {
        default: 'about'
      },
      menu: {
        default: 'CMS'
      }
    }
  }
</script>
