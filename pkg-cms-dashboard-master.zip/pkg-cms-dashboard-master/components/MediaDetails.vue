<template>
  <div>
    <side-info-item title="Name" v-if="media.name">{{ media.name }}</side-info-item>
    <side-info-item title="Mime Type" v-if="media.mime_type">{{ media.mime_type }}</side-info-item>
    <side-info-item title="Size">{{ media.humanized_size }}</side-info-item>
    <side-info-item title="URL">{{ media.url }}</side-info-item>
  </div>
</template>

<script>
  import SideInfoItem from "./SideInfoItem";

  export default {
    name: "MediaDetails",
    components: {SideInfoItem},
    props: {
      media: {
        type: Object
      }
    }
  }
</script>
