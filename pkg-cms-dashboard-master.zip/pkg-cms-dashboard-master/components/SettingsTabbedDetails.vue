<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
      <tab-item :to="`/${menu}/${namespace}/`">
        <svg-arrow-left class="h-6 w-6"/>
      </tab-item>
      <slot>
        <tab-item :to="`/settings/${namespace}/${data.id}`" class="flex items-center">
          <svg-pencil-alt class="mr-2 h-6 w-6"/>
          Edit
        </tab-item>
      </slot>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>
import ContextualMenu from "./ContextualMenu";
import TabItem from "./tabItem";
import FaIcon from "./FaIcon";
import SvgArrowLeft from "@/components/icons/svg-arrow-left";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";

export default {
  name: "SettingsTabbedDetails",
  components: {SvgPencilAlt, SvgArrowLeft, FaIcon, TabItem, ContextualMenu},
  props: ['data', 'namespace', 'menu']
}
</script>
