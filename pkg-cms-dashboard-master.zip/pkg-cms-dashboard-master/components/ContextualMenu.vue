<template>
  <div
    class="h-16 bg-gray-100 border-b border-gray-200 justify-between flex flex-row px-8 items-center text-gray-500 tertiary-nav">
    <div class="flex">
      <slot/>
    </div>
    <div class="capitalize hidden md:block"><span>{{ menu }}</span> /
      <span>{{ namespace.toString().replaceAll('-', ' ') }}</span>
    </div>
  </div>
</template>

<script>
  export default {
    name: "ContextualMenu",
    props: {
      namespace: {
        default: 'About',
      },
      menu: {
        default: 'CMS'
      }
    }
  }
</script>
