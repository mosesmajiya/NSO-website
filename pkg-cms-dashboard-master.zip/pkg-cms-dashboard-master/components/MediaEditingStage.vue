<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">Media Caption</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle">
          Edit Media Caption
        </slot>
      </h2>
    </div>

    <div class="p-8 flex flex-row">
      <div class="flex-1">
        <slot>
          <form @submit.prevent="onSubmit">
            <text-input
              label="Caption"
              name="caption"
              v-bind:error="errors.caption" v-bind:value="form.caption"
              v-on:input="form.caption = $event"/>

            <form-actions :to="navigateTo">Update</form-actions>
          </form>
        </slot>
        <div class="mt-4 pt-8 border-t border-gray-300">
          <img :src="url" alt="details" class="object-cover"/>
        </div>
      </div>
      <div class="w-1/4 ml-8">
        <div class="border">
          <h3 class="bg-gray-200 px-5 py-3">Details</h3>
          <div class="px-5 py-3">
            <media-details v-bind:media="media"/>
          </div>
        </div>
        <div class="mt-5">
          <slot name="actions">
            <div class="flex">
              <navigate-link class="flex-1 mr-4" v-bind:to="media.download">
                <fa-icon custom-class="mr-4" icon="download"/>
                Download
              </navigate-link>
              <confirm-button
                @confirmed="destroy"
                custom-class="flex-1"
                icon="delete"
                label="Delete"
                title="Confirm Deletion"
                v-bind:message="`${media.name} will be permanently deleted.`"
              >
                Delete
              </confirm-button>
            </div>
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import TextInput from "./forms/TextInput";
  import FormSubmit from "./forms/FormSubmit";
  import FormActions from "./forms/FormActions";
  import MediaDetails from "./MediaDetails";
  import FormButton from "./FormButton";
  import ConfirmButton from "./ConfirmButton";
  import FormLink from "./forms/FormLink";
  import FaIcon from "./FaIcon";
  import NavigateBack from "./NavigateBack";
  import NavigateLink from "./NavigateLink";

  export default {
    name: "MediaEditingStage",
    components: {
      NavigateLink,
      NavigateBack,
      FaIcon, FormLink, ConfirmButton, FormButton, MediaDetails, FormActions, FormSubmit, TextInput
    },
    props: ['namespace', 'url', 'form', 'media', 'category', 'to'],
    data() {
      return {
        errors: [],
        form: {
          caption: ''
        }
      }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`media/${this.$route.params.media_id}`, this.form)
          .then(() => this.$router.push(this.navigateTo))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      async destroy() {
        let deleted = await this.$axios.delete(`media/${this.$route.params.media_id}`)
        if (deleted) this.$router.push(this.navigateTo)
      }
    },
    computed: {
      navigateTo() {
        if (this.to) return this.to
        return `/cms/${this.namespace}/${this.$route.params.id}/media`;
      }
    }
  }
</script>
