<template>
  <li>
    <nuxt-link :to="to" class="px-4 py-2">
      <slot/>
    </nuxt-link>
  </li>
</template>

<script>
  export default {
    name: "MainNavItem",
    props: ['to']
  }
</script>
