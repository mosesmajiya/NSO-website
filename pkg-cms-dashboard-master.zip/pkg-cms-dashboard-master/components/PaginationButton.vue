<template>
  <button
    :class="{'bg-gray-100 text-gray-500 cursor-not-allowed': disabled}"
    :disabled="disabled"
    @click="$emit('click')"
    class="border px-3 py-1 focus:outline-none bg-gray-200 rounded-2xl">
    <slot/>
  </button>
</template>

<script>
  export default {
    name: "PaginationButton",
    props: ['disabled']
  }
</script>

