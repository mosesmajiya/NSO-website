<template>
  <div class="">
    <div class="mx-auto justify-center py-2 mt-4 flex space-x-1" v-if="paginator.last_page > 1">
      <pagination-button @click="fetch(paginator.first_page_url)" v-bind:disabled="!paginator.prev_page_url">
        <svg-page-backward/>
      </pagination-button>
      <pagination-button :disabled="!paginator.prev_page_url" @click="fetch(paginator.prev_page_url)">
        <svg-page-step-backward/>
      </pagination-button>
      <pagination-button>
        <span class="text-xs">{{ `${paginator.from} to ${paginator.to} of ${paginator.total}`}}</span>
      </pagination-button>
      <pagination-button :disabled="!paginator.next_page_url" @click="fetch(paginator.next_page_url)">
        <svg-page-step-forward/>
      </pagination-button>
      <pagination-button :disabled="!paginator.next_page_url" @click="fetch(paginator.last_page_url)">
        <svg-page-forward/>
      </pagination-button>
    </div>
  </div>

</template>

<script>
  import FaIcon from "./FaIcon";
  import PaginationButton from "./PaginationButton";
  import SvgPageBackward from "./icons/svg-page-backward";
  import SvgPageStepBackward from "./icons/svg-page-step-backward";
  import SvgPageStepForward from "./icons/svg-page-step-forward";
  import SvgPageForward from "./icons/svg-page-forward";

  export default {
    name: "Pagination",
    components: {SvgPageForward, SvgPageStepForward, SvgPageStepBackward, SvgPageBackward, PaginationButton, FaIcon},
    props: {
      paginator: Object
    },
    methods: {
      async fetch(url) {
        let response = (await this.$axios.get(url)).data;

        this.$emit('loadeddata', response.data)
      }
    }
  }
</script>
