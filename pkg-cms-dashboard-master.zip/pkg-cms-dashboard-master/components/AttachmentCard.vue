<template>
  <div :class="`rounded w-1/3 ${customClass}`">
    <div class="mr-4 mb-8 shadow hover:shadow-lg">
      <p class="text-sm text-gray-600 p-3 flex items-center">
        <svg-attachment class="w-5 h-5 mr-2"/>
        {{ filename }}
      </p>
      <div class="flex px-3 pb-3 ">
        <p class="text-xs flex-grow">{{ remark }}</p>
        <div class="flex">
          <a :href="to" target="_blank">
            <svg-download class="mx-2 my-1 text-sm text-gray-500 hover:text-gray-600 mr-4 h-4 w-4"/>
          </a>
          <confirm-icon
            custom-class="relative"
            :icon="actionIcon"
            message="This item will be deleted permanently"
            title="Delete Confirmation"
            v-on:confirmed="destroy"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FaIcon from "./FaIcon";
import ConfirmIcon from "./ConfirmIcon";
import SvgAttachment from "./icons/svg-attachment";
import SvgDownload from "./icons/svg-download";

export default {
  name: "AttachmentCard",
  components: {SvgDownload, SvgAttachment, ConfirmIcon, FaIcon},
  props: {
    customClass: {
      type: String,
      required: true
    },
    filename: {
      type: String,
      required: true,
    },
    remark: {
        type: String,
        required: true
      },
      actionIcon: {
        type: String,
        default: 'trash'
      },
      linkIcon: {
        type: String,
        default: 'edit'
      },
      to: {
        required: true
      },
      id: {required: true}
    },
    methods: {
      async destroy() {
        let deleted = await this.$axios.delete(`media/${this.id}`)
        if (deleted) this.$emit('deleted')
      }
    }
  }
</script>

