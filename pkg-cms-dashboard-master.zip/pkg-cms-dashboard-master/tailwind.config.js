/*
** TailwindCSS Configuration File
**
** Docs: https://tailwindcss.com/docs/configuration
** Default: https://github.com/tailwindcss/tailwindcss/blob/master/stubs/defaultConfig.stub.js
*/
module.exports = {
  future: {
    removeDeprecatedGapUtilities: true,
    purgeLayersByDefault: false
  },
  purge: false,
  theme: {
    fontFamily: {
      'sans': ['Open Sans', 'Sans-serif'],
      'editor': ['Crimson Text', 'Sans-serif']
    },
    extend: {
      spacing: {
        '72': '18rem',
        '84': '21rem',
        '96': '24rem',
        '108': '27rem',
        '120': '30rem',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
      },
      colors: {
        primary: {
          900: 'hsl(200,71%,11%)',
          800: 'hsl(200,71%,21%)',
          700: 'hsl(200,71%,31%)',
          600: 'hsl(200,71%,41%)',
          500: 'hsl(200,71%,51%)',
          400: 'hsl(200,71%,61%)',
          300: 'hsl(200,71%,71%)',
          200: 'hsl(200,71%,81%)',
          100: 'hsl(200,71%,91%)',
          50: 'hsl(200,71%,96%)'
        }
      }
    }
  },
  variants: {
    borderWidth: ['responsive', 'last', 'hover', 'focus'],
    visibility: ['responsive', 'hover', 'group-hover'],
    padding: ['responsive', 'odd']
  },
  plugins: [],
}
