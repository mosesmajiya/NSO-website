export default class Form {
  constructor(data) {
    for (let field in data) {
      this[field] = data[field]
    }
    this.errorBag = new ErrorBag();
  }
}

class ErrorBag {
  constructor() {
    this.errors = {};
  }
}
