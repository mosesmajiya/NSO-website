# CMS
* [x] Newsletter releases route returning 404
* [x] Order newsletter releases ya volume and issue
* [x] Public Downloads to have: edit, slug, publish
* [x] Public Downloads to have header with name of download category
* [x] Newsletters - error 500
* [x] Newsletters - should have one file upload
* [x] Settings - change listing of items in all views to a single line
* [x] Staff Departments - id error
* [x] Positions - id error
* [x] Users - id error
* [x] Dashboard - skipped dates on graph
* [x] User Activity - searching not working
* [x] Create new token on every API call except for the dashboard
* [x] My Account - remove unsplash images (upload local default img) and display uploaded image
* [x] Speeches and Reports - to be placed under POSTS, to clone public downloads. Include description.
* [x] Private Downloads - to clone public downloads with USERS and PERMISSIONS options from permissions table
TYPES: report, speech, private, public.
* [x] Branding logo
* [x] Project stats
* [x] Procurement post types on homepage
* [x] Dashboard not showing logo and site title
* [x] PAGES section - edit not working
* [x] Adding newsletter release is failing to save
* [x] Adding media to Public Downloads is not working
* [ ] Deleting a newspaper release deletes FAQs - it jumps from one section to the other
* [x] Form buttons are not showing
* [x] SVG icon not finalised for all  views
* [x] Editing people pulling wrong data

# Website
* [x] Home page: slider, posts, email subscription
* [x] Headers without banners are not showing a default banner
* [x] Newsletters should be sorted by Volume, Issue with latest first
* [x] Newsletters download
* [x] SEO
* [x] Logged in users for downloads
* [x] Search sitewide
* [ ] Menu breaking on caret click
