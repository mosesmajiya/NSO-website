<template>
  <div class="min-h-screen antialiased flex flex-col bg-gray-200 text-gray-700">
    <navbar v-bind:logo="settings.logo"/>
    <nuxt class="m-8 shadow bg-white rounded flex-1 overflow-hidden"/>
  </div>
</template>

<script>
import MainNav from "../components/MainNav";
import AccountDropdown from "../components/AccountDropdown";
import FaIcon from "../components/FaIcon";
import Navbar from "../components/Navbar";

export default {
  middleware: 'authenticated',
  components: {Navbar, FaIcon, AccountDropdown, MainNav},
  created() {
    this.$store.dispatch('getSettings')
    this.$store.dispatch('user/FETCH_USER')
  },
  head() {
    return {
      title: 'CMS | ' + this.settings.organization_name || '',
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  computed: {
    settings() {
      return this.$store.state.settings
    }
  }
}
</script>

<style lang="css">
.main-nav .nuxt-link-active, .main-nav .nuxt-link-exact-active {
  @apply text-primary-600
}

.btn.nuxt-link-active, .btn.nuxt-link-exact-active {
  @apply text-white
}


.secondary-nav .nuxt-link-exact-active, .secondary-nav .nuxt-link-active {
  @apply text-white border-gray-500 bg-gray-100 text-primary-700
}

.tertiary-nav .nuxt-link-exact-active, .tertiary-nav .nuxt-link-exact-active {
  @apply text-primary-500 border-primary-500
}


.category-nav .nuxt-link-exact-active, .category-nav .nuxt-link-exact-active {
  @apply text-primary-500 border-primary-500
}

.material-icons {
  font-size: 1.4rem;
  padding: 0 1px;
}
</style>
