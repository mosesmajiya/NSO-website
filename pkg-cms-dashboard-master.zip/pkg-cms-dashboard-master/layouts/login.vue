<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "login",
    middleware: 'guest',
    created() {
      this.$store.dispatch('getSettings')
    },
  }
</script>
