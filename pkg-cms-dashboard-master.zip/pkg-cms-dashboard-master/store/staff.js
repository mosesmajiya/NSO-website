export const state = () => ({
  members: [],
  member: {}
});

export const mutations = {
  GET_ONE(state, member) {
    state.member = member
  }
}

export const actions = {
  async FETCH_ONE({commit}, id) {
    if (!process.browser) return
    let response = (await this.$axios.get(`/staff/${id}`)).data;
    commit('GET_ONE', response.data)
  }
}

export const getters = {
  MEMBER(state) {
    return state.member
  }
}
