export const state = () => ({
  name: '',
  token: '',
  email: ''
});

export const mutations = {
  LOGIN(state, {name, accessToken, email}) {
    state.name = name
    state.token = accessToken
    state.email = email
  },
  LOGOUT(state) {
    state.name = ''
    state.token = ''
    state.email = ''
  }
}

export const actions = {
  async LOGIN({commit}, {name, accessToken, email}) {
    commit('LOGIN', {name, accessToken, email})
    localStorage.setItem('user', name)
    localStorage.setItem('token', accessToken)
    localStorage.setItem('email', email)
  },

  async LOGOUT({commit}) {
    let response = (await this.$axios.post(`logout`)).data
    if (response.status.success) {
      localStorage.removeItem('user')
      localStorage.removeItem('token')
      localStorage.removeItem('email')
      commit('LOGOUT')
    }
  }
}

export const getters = {
  GET_TOKEN(state) {
    return state.token
  },
  GET_NAME(state) {
    return state.name
  },
  GET_EMAIL(state) {
    return state.email
  },
  AUTHENTICATED(state) {
    if (process.client) {
      return !!localStorage.getItem('token')
    }

    return !!state.token
  },
  GUEST(state) {
    return !this.getters.AUTHENTICATED
  }
}
