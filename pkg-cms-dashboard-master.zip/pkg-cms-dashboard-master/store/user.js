export const state = () => ({
  user: {}
});

export const mutations = {
  SET_USER(state, user) {
    state.user = user
  }
}

export const actions = {
  async FETCH_USER({commit}) {
    if (!process.browser) return
    let response = (await this.$axios.get(`/user`)).data;
    commit('SET_USER', response.data)
  }
}

export const getters = {
  GET_USER(state) {
    return state.user
  },
  GET_AVATAR(state) {
    return state.user.avatar
  }
}
