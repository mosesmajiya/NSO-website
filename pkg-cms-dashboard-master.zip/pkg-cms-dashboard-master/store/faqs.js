export const state = () => ({
  faq: {}
});

export const mutations = {
  setFaq(state, faq) {
    state.faq = faq
  }
}

export const actions = {
  async fetchOne({commit}, id) {
    let faq = (await this.$axios.get(`/faqs/${id}`)).data;
    commit('setFaq', faq.data)
  }
}

export const getters = {
  getFaq(state) {
    return state.faq
  }
}
