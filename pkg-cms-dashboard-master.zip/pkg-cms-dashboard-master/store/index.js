export const state = () => ({
  settings: {}
})

export const actions = {
  async nuxtServerInit({state}, ctx) {
    let settings = (await ctx.$axios.get('/settings')).data;
    state.settings = settings.data
  },
  async getSettings({commit}) {
    let settings = (await this.$axios.get('/settings')).data.data;
    commit('addSettings', settings)
  }
}

export const mutations = {
  addSettings(state, settings) {
    state.settings = settings
  }
}
