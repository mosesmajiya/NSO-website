export const state = () => ({
  positions: []
});

export const mutations = {
  SET_POSITIONS(state, positions) {
    state.positions = positions
  }
}

export const actions = {
  async FETCH_POSITIONS({commit}, id) {
    if (!process.browser) return
    let positions = (await this.$axios.get(`/departments/${id}/positions`)).data;
    commit('SET_POSITIONS', positions.data)
  }
}

export const getters = {
  GET_POSITIONS(state) {
    return state.positions
  }
}
