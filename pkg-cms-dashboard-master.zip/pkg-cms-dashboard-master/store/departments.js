export const state = () => ({
  items: []
});

export const mutations = {
  SET_ITEMS(state, items) {
    state.items = items
  }
}

export const actions = {
  async FETCH_ITEMS({commit}) {
    if (!process.browser) return
    let items = (await this.$axios.get(`/departments/`)).data;
    commit('SET_ITEMS', items.data.data)
  }
}

export const getters = {
  GET_ITEMS(state) {
    return state.items
  }
}
