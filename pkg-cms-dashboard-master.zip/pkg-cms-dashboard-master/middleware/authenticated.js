export default function ({redirect}) {
  if (process.client) {
    if (!localStorage.getItem('token')) {
      return redirect('/login')
    }
  }
}
