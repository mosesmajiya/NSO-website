export default function ({redirect}) {
  if (process.browser) {
    // if (hasToken()) return redirect('/dashboard')
  }
}

function hasToken() {
  return !!localStorage.getItem('token')
}
