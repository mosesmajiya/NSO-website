export default {
  async created() {
    if (!process.browser) return
    let media = (await this.$axios.get(`media/${this.$route.params.media_id}`)).data
    let caption = media.data.custom_properties.caption ? media.data.custom_properties.caption : ''
    this.form = {caption}
    this.url = media.data.url
    this.media = media.data
  }
}
