export default {
  created() {
    if (!process.browser) return
    if (this.namespace) {
      this.$axios.get(`${this.namespace}/${this.$route.params.id}/media/banner`)
        .then(res => this.banners = res.data.data)
      this.$axios.get(`${this.namespace}/${this.$route.params.id}`)
        .then(res => this.about = res.data.data)
      this.$axios.get(`${this.namespace}/${this.$route.params.id}/media/attachment`)
        .then(res => this.attachments = res.data.data)
    }
  },
  data() {
    return {
      about: {},
      banners: [],
      attachments: [],
    }
  }
}
