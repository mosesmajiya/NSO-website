export default {
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data;
    this.data = response
    this.form = response
  },

  data() {
    return {
      data: {}
    }
  }
}
