export default {
  created() {
    if (!process.browser) return
    if (this.namespace)
      this.$axios.get(this.namespace).then(res => this.data = res.data.data)
  },
}
