export default {
  async created() {
    if (!process.browser) return
    if (this.namespace) {
      let response = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data;
      this.form = response
      this.data = response
    }
  }
}
