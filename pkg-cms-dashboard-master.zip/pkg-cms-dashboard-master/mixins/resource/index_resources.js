export default {
  async created() {
    if (!process.browser) return
    if (this.namespace) {
      this.loaded = false
      this.$axios.get(`${this.namespace}/${this.$route.params.id}`)
        .then(res => {
          this.data = res.data.data
          this.loaded = true
        })
    }
  },
  data() {
    return {
      data: {},
      loaded: false
    }
  },
}
