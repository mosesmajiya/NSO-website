export default {
  created() {
    if (!process.browser) return
    if (this.namespace)
      this.$axios.get(`${this.namespace}/recent`).then(res => this.recent = res.data.data)
  }
}
