<template>
  <div>forgot password</div>
</template>

<script>
  export default {
    name: "forgot-password",
    layout: 'login'
  }
</script>

<style scoped>

</style>
