<template>
  <div class="m-8">
    <view-category :sub-title="`All Releases`" v-bind:live="data.published_at"
                   v-bind:title="data.name" v-if="data"/>
    <nuxt/>
  </div>
</template>

<script>
import ViewCategory from "../../../../components/ViewCategory";
import index_resources from "@/mixins/resource/index_resources";

export default {
  name: "index",
  components: {ViewCategory},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      menu: 'cms',
      namespace: 'newsletters',
    }
  }
}
</script>
