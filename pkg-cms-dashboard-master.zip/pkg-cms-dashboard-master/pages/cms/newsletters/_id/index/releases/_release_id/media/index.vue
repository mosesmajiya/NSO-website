<template>
  <div>
    <form class="p-8 border border-gray-300 rounded bg-gray-100" method="post" @submit.prevent="onSubmit">
      <div class="mb-5">
        <file-input id="file" v-model="form.file" label="File" v-bind:error="errors.file"/>
      </div>

      <form-submit accent="primary">Upload File</form-submit>
    </form>

    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:category="category"
                v-bind:data="data" v-bind:namespace="namespace"/>
  </div>
</template>

<script>
import FormSubmit from "../../../../../../../../components/forms/FormSubmit";
import TextInput from "../../../../../../../../components/forms/TextInput";
import MediaUpload from "../../../../../../../../components/forms/MediaUpload";
import MediaList from "../../../../../../../../components/MediaList";
import DropdownInput from "@/components/forms/DropdownInput";
import FileInput from "@/components/forms/FileInput";

export default {
  name: "media",
  components: {FileInput, DropdownInput, MediaList, MediaUpload, TextInput, FormSubmit},
  async created() {
    this.banners = (await this.$axios.get(`newsletterReleases/${this.$route.params.release_id}/media/banner`)).data.data
    this.data = (await this.$axios.get(`newsletterReleases/${this.$route.params.release_id}`)).data.data
    this.attachments = (await this.$axios.get(`newsletterReleases/${this.$route.params.release_id}/media/attachment`)).data.data
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      let type = this.form.type ? this.form.type : 'banner'
      formData.append('file', this.form.file)
      formData.append('type', this.form.type)
      formData.append('caption', this.form.caption)

      this.$axios.post(`/newsletterReleases/${this.$route.params[this.urlParam]}/attach/${type}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go())
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      form: {
        caption: 'attachment',
        type: 'attachment',
        file: ''
      },
      errors: [],
      namespace: 'newsletters',
      category: 'newsletters',
      urlParam: 'release_id',
      attachments: [],
      banners: [],
      data: {}
    }
  }
}
</script>

