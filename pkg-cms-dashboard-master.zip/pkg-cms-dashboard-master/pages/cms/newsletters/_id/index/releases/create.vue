<template>
  <form @submit.prevent="onSubmit" class="px-8 pt-8 border border-t-0 rounded-b">
    <div class="md:flex">
      <text-input class="md:flex-1 md:mr-4" label="Volume" name="volume" v-bind:error="errors.volume"
                  v-bind:value="form.volume" v-on:input="form.volume = $event"/>

      <text-input class="md:flex-1 md:mr-4" label="Issue" name="issue" v-bind:error="errors.issue"
                  v-bind:value="form.issue" v-on:input="form.issue = $event"/>
    </div>

    <text-input :error="errors.published_on" :value="form.published_on" label="Published on" name="published_on"
                type="date" @input="form.published_on = $event"/>

    <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                     v-bind:value="form.content" v-on:input="form.content = $event"/>

    <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`"/>
  </form>
</template>

<script>
import FormActions from "../../../../../../components/forms/FormActions";
import TextInput from "../../../../../../components/forms/TextInput";
import ParagraphInput from "../../../../../../components/forms/ParagraphInput";
import DropdownInput from "../../../../../../components/forms/DropdownInput";

export default {
  name: "create",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions},
  data() {
    return {
      namespace: 'newsletters',
      collective: 'releases',
      form: {
        volume: '',
        newsletter_id: this.$route.params.id,
        published_on: '',
        issue: '',
        content: ''
      },
      errors: []
    }
  },
  methods: {
    onSubmit() {
      let form = new FormData();
      for (let field in this.form) {
        if (this.form[field]) form.append(field, this.form[field])
      }

      this.$axios.post(`/${this.collective}/`, form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },

}
</script>
