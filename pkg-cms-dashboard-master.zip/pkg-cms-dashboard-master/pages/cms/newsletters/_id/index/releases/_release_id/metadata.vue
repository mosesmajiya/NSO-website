<template>
  <div class="my-8 rounded">
    <div class="py-8 flex flex-row">
      <div class="flex-1">
        <form @submit.prevent="onSubmit">
          <text-input
            label="Keywords"
            name="keywords"
            v-bind:error="errors.keywords"
            v-bind:value="form.keywords"
            v-on:input="form.keywords = $event"
          />
          <form-group label="Description">
        <textarea
          class="px-4 py-2 w-full block border border-gray-300 focus:outline-none focus:border-gray-400 rounded "
          v-model="form.description">
        </textarea>
            <p class="text-red-500 text-sm">{{ errors.description }}</p>

          </form-group>
          <form-submit>Update</form-submit>
        </form>
      </div>
      <div class="w-1/4 ml-8">
        <div class="border">
          <h3 class="bg-gray-200 px-5 py-3">Details</h3>
          <div class="px-5 pb-3">
            <slot name="details">
              <page-details v-bind:page="data" v-if="data"/>
            </slot>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>


import MetadataEdit from "../../../../../../../components/forms/MetadataEdit";
import PageDetails from "@/components/PageDetails";
import TextInput from "@/components/forms/TextInput";
import FormGroup from "@/components/forms/FormGroup";
import FormSubmit from "@/components/forms/FormSubmit";

export default {
  name: "metadata",
  components: {FormSubmit, FormGroup, TextInput, PageDetails, MetadataEdit},
  async created() {
    let response = (await this.$axios.get(`${this.namespace}/${this.$route.params.release_id}`)).data.data
    this.form = response.metadata ? response.metadata : {description: '', keywords: ''}
    this.data = response
  },
  data() {
    return {
      form: {
        description: '',
        keywords: '',
      },
      errors: [],
      data: {},
      namespace: 'newsletterReleases',
      namespaceId: 'release_id',
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`${this.namespace}/${this.$route.params[this.namespaceId]}/metadata`, this.form)
        .then(() => this.$router.go())
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
