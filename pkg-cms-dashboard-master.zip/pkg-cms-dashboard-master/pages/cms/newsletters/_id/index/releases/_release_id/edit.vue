<template>
  <form @submit.prevent="onSubmit">
    <div class="md:flex">
      <text-input class="md:flex-1 md:mr-4" label="Volume" name="volume" v-bind:error="errors.volume"
                  v-bind:value="form.volume" v-on:input="form.volume = $event"/>

      <text-input class="md:flex-1 md:mr-4" label="Issue" name="issue" v-bind:error="errors.issue"
                  v-bind:value="form.issue" v-on:input="form.issue = $event"/>

      <text-input class="md:flex-1" label="Published on" name="published_on" type="date"
                  v-bind:error="errors.published_on"
                  v-bind:value="form.published_on" v-on:input="form.published_on = $event"/>
    </div>

    <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                     v-bind:value="form.content" v-on:input="form.content = $event"/>

    <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}/${collective}/${collectiveId}`"/>
  </form>
</template>

<script>
import FormActions from "../../../../../../../components/forms/FormActions";
import TextInput from "../../../../../../../components/forms/TextInput";
import ParagraphInput from "../../../../../../../components/forms/ParagraphInput";
import DropdownInput from "../../../../../../../components/forms/DropdownInput";

export default {
  name: "edit",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions},
  async created() {
    let response = (await this.$axios.get(`newsletterReleases/${this.collectiveId}`))
    this.form = response.data.data
  },
  data() {
    return {
      errors: [],
      namespace: 'newsletters',
      collective: 'releases',
      form: {
        issue: '',
        newsletter_id: this.$route.params.id,
        volume: '',
        content: '',
        published_on: '',
      },
    }
  },
  computed: {
    collectiveId() {
      return this.$route.params.release_id
    },
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/newsletterReleases/${this.collectiveId}`, this.getFormData())
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}/${this.collective}/${this.collectiveId}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    getFormData() {
      let form = new FormData();
      for (let field in this.form) {
        if (this.form[field]) form.append(field, this.form[field])
      }

      let object = {};
      form.forEach((value, key) => {
        object[key] = value
      });
      return object
    }
  }
}
</script>
