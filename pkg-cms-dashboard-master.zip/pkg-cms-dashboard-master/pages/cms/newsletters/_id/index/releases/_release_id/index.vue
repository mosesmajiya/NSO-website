<template>
  <div v-if="data && data.volume">
    <p class="font-bold text-gray-500">Name</p>
    <h1 class="pb-4">Volume {{ data.volume }} - Issue {{ data.issue }}</h1>

    <p class="font-bold text-gray-500">Published On</p>
    <div class="pb-4" v-if="data.published_on">{{ data.published_on | moment('Do MMMM YYYY') }}</div>

    <div class="pb-4" v-if="data.content">
      <p class="font-bold text-gray-500">Content</p>
      <div v-html="data.content"></div>
    </div>

    <div class="flex mt-8">
      <form-button
        :fa-icon="data.published_at ? 'unlink' : 'link'"
        @click="togglePublish"
        custom-class="mr-2">
        {{ data.published_at ? 'Unpublish' : 'Publish' }}
      </form-button>
      <confirm-button
        @confirmed="destroy"
        custom-class="flex"
        icon="delete"
        label="Delete"
        title="Confirm Deletion"
        v-bind:message="`Volume ${data.volume} - Issue ${data.issue} will be permanently deleted.`"
      >
        Delete
      </confirm-button>
    </div>
  </div>
</template>

<script>
import FormButton from "../../../../../../../components/FormButton";
import ConfirmButton from "../../../../../../../components/ConfirmButton";

export default {
  name: "index",
  components: {ConfirmButton, FormButton},
  async created() {
    let response = (await this.$axios.$get(`newsletterReleases/${this.$route.params.release_id}`))
    this.data = response.data
  },
  data() {
    return {
      collective: 'newsletterReleases',
      data: {},
    }
  },
  computed: {
    collectiveId() {
      return this.$route.params.release_id
    }
  },
  methods: {
    togglePublish() {
      if (this.data.published_at) {
        this.unpublish()
      } else {
        this.publish()
      }
    },
    publish() {
      this.$axios.post(`${this.collective}/${this.collectiveId}/publish`)
        .then(() => this.$router.go())
    },
    unpublish() {
      this.$axios.delete(`${this.collective}/${this.collectiveId}/unpublish`)
        .then(() => this.$router.go())
    },
    destroy() {
      this.$axios.delete(`${this.collective}/${this.collectiveId}`)
        .then(() => this.$router.push(`/cms/newsletters/${this.$route.params.id}`))
    }
  }
}
</script>
