<template>
  <div>
    <div class="flex px-8 py-6 border border-t-0">
      <link-button :to="`/cms/${namespace}/${$route.params.id}/${collective}/create`" accent="primary" icon="add">
        New Release
      </link-button>

      <form-button
        :fa-icon="data.published_at ? 'unlink' : 'link'"
        @click="togglePublish"
        custom-class="mr-4">
        {{ data.published_at ? 'Unpublish' : 'Publish' }}
      </form-button>

      <confirm-button @confirmed="destroy" accent="gray" fa-icon="trash" label="Delete Newsletter"
                      message="This newsletter including all its releases will be deleted permanently"
                      title="Confirm Deletion"/>

    </div>
    <div class="w-full border mt-8 rounded" v-if="data[collective] && data[collective].length">
      <nuxt-link :key="item.id" :to="`/cms/${namespace}/${$route.params.id}/${collective}/${item.id}`"
                 class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block" v-for="item in data[collective]">
        <div class="leading-loose">Volume {{ item.volume }} Issue {{ item.issue }}</div>
        <div class="text-sm flex">
          <div class="flex-grow flex">
            <div class="mr-4 flex items-center">
              <svg-clock-solid/>
              {{ $moment(item.created_at).fromNow() }}
            </div>
            <div class="mr-4 flex items-center">
              <svg-eye/>
              {{ item.views }} views
            </div>
          </div>
          <svg-published :on="item.published_at"/>
        </div>
      </nuxt-link>
    </div>
  </div>
</template>

<script>
import LinkButton from "../../../../../components/LinkButton";
import FaIcon from "../../../../../components/FaIcon";
import ConfirmButton from "../../../../../components/ConfirmButton";
import FormButton from "../../../../../components/FormButton";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgEye from "@/components/icons/svg-eye";
import SvgPublished from "../../../../../components/icons/svg-published";

export default {
  name: "index",
  components: {SvgPublished, SvgEye, SvgClockSolid, FormButton, ConfirmButton, FaIcon, LinkButton},
  async created() {
    this.data = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      namespace: 'newsletters',
      collective: 'releases',
      data: {}
    }
  },
  methods: {
    destroy() {
      this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
    },
    togglePublish() {
      if (this.data.published_at) {
        return this.unpublish();
      } else {
        return this.publish()
      }
    },
    publish() {
      this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
        .then(() => this.$router.go())
    },
    unpublish() {
      this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
        .then(() => this.$router.go())
    }
  }
}
</script>
