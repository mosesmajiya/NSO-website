<template>
  <edit-category sub-title="Change department details" title="Edit Department" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Newsletter Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name" v-on:input="form.name = $event"/>

      <div class="md:flex">

        <text-input
          @input="form.editor = $event"
          class="w-full"
          label="Editor"
          name="editor"
          v-bind:error="errors.editor"
          v-bind:value="form.editor"
        />
      </div>

      <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                       v-bind:value="form.content" v-on:input="form.content = $event"/>

      <form-actions :to="`/cms/${namespace}`"/>
    </form>
  </edit-category>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import PageDetails from "../../../../components/PageDetails";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import EditCategory from "../../../../components/EditCategory";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {EditCategory, ParagraphInput, PageDetails, TextInput, FormActions, EditingStage},
  mixins: [edit_resource],
  data() {
    return {
      data: {},
      form: {
        name: '',
        description: '',
        rank: '',
      },
      errors: [],
      namespace: 'newsletters'
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
