<template>
  <editing-stage subtitle="Upload Page Media" title="Page Media" v-bind:data="data">
    <media-upload :namespace="namespace"/>
    <nuxt/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:data="data"
                v-bind:namespace="namespace"/>
  </editing-stage>
</template>

<script>
import MediaUpload from "../../../../../components/forms/MediaUpload";
import MediaList from "../../../../../components/MediaList";
import EditingStage from "../../../../../components/EditingStage";
import media_index from "@/mixins/media/media_index";

export default {
  name: "index",
  components: {
    EditingStage,
    MediaList,
    MediaUpload,
  },
  mixins: [media_index],
  data() {
    return {
      namespace: 'newsletters',
      data: {},
      banners: [],
      attachments: [],
    }
  },
}
</script>
