<template>
  <div>
    <create-category sub-title="Create a newsletter" title="Newsletters" v-bind:category="category">
      <form @submit.prevent="onSubmit">
        <text-input label="Newsletter Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name" v-on:input="form.name = $event"/>

        <div class="md:flex">

          <text-input
            @input="form.editor = $event"
            class="w-full"
            label="Editor"
            name="editor"
            v-bind:error="errors.editor"
            v-bind:value="form.editor"
          />
        </div>

        <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                         v-bind:value="form.content" v-on:input="form.content = $event"/>

        <form-actions :to="`/cms/${namespace}`"/>
      </form>
    </create-category>
  </div>
</template>

<script>
import TextInput from "../../../components/forms/TextInput";
import FormActions from "../../../components/forms/FormActions";
import CreateCategory from "../../../components/CreateCategory";
import ParagraphInput from "../../../components/forms/ParagraphInput";

export default {
  name: "create",
  components: {ParagraphInput, CreateCategory, FormActions, TextInput},
  data() {
    return {
      form: {
        name: '',
        content: '',
        editor: '',
      },
      errors: [],
      namespace: 'newsletters',
      category: 'newsletters',
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(this.category, this.form)
        .then(() => this.$router.push(`/cms/${this.category}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }

}
</script>
