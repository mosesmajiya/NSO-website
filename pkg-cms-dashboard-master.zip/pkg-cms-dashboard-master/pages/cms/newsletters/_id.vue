<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespaceHumanized">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-arrow-left/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${$route.params.id}`" class="flex items-center">
        <svg-list class="h-6 w-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${$route.params.id}/edit`" class="flex items-center">
        <svg-pencil-alt class="mr-2 h-6 w-6"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${$route.params.id}/media`" class="flex items-center">
        <svg-camera class="mr-2 h-6 w-6"/>
        Media
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${$route.params.id}/metadata`" class="flex items-center">
        <svg-code class="mr-2 h-6 w-6"/>
        Metadata
      </tab-item>
    </contextual-menu>
    <nuxt/>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import TabItem from "../../../components/tabItem";
import FaIcon from "../../../components/FaIcon";
import SvgArrowLeft from "@/components/icons/svg-arrow-left";
import SvgDocumentText from "@/components/icons/svg-document-text";
import SvgList from "@/components/icons/svg-list";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";
import SvgCamera from "@/components/icons/svg-camera";
import SvgCode from "@/components/icons/svg-code";

export default {
  name: "_id",
  components: {
    SvgCode,
    SvgCamera,
    SvgPencilAlt,
    SvgList,
    SvgDocumentText,
    SvgArrowLeft,
    FaIcon,
    TabItem,
    ContextualMenu
  },
  data() {
    return {
      namespace: 'newsletters',
      namespaceHumanized: 'Newsletters',
      menu: 'CMS'
    }
  }
}
</script>

