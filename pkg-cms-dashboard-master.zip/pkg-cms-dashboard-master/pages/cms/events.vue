<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "events"
  }
</script>

<style scoped>

</style>
