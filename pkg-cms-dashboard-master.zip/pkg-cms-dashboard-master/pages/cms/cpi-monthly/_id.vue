<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-chevron-left class="w-6 h-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex" exact>
        <svg-file class="w-6 h-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex">
        <svg-pencil-alt class="w-6 h-6 mr-2"/>
        Edit
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>

</template>

<script>

import index_resources from "~/mixins/resource/index_resources";
import ContextualMenu from "../../../components/ContextualMenu";
import TabItem from "../../../components/tabItem";
import SvgPencilAlt from "../../../components/icons/svg-pencil-alt";
import SvgFile from "../../../components/icons/svg-file";
import SvgChevronLeft from "../../../components/icons/svg-chevron-left";

export default {
  name: "_id",
  mixins: [index_resources],

  components: {SvgChevronLeft, SvgFile, SvgPencilAlt, TabItem, ContextualMenu},
  data() {
    return {
      data: {},
      namespace: "cpi-monthly",
      menu: "CMS"
    }
  }
}
</script>
