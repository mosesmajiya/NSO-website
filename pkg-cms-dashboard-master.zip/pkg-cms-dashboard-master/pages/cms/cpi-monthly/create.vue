<template>
  <div>
    <navigate-back namespace="cpi-monthly" to="/cms"/>
    <creation-stage heading-field="year" namespace="census" subtitle="Add new monthly indices" title="New Monthly Indices">
      <form @submit.prevent="onSubmit">
        <p class="text-red-500 text-sm">{{ message }}</p>
        <text-input @input="form.date = $event" class="w-1/5 md:flex-1 md:mr-4" label="Date" name="date"
                    type="date"
                    v-bind:error="errors.date" v-bind:value="form.date"/>
        <div class="flex flex-wrap -mx-1">
          <div class="px-1 w-1/5">
            <text-input :error="errors.food" :value="form.food" label="Food"
                        name="food"
                        @input="form.food = $event" type="number"/>
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.beverage_and_tobacco" :value="form.beverage_and_tobacco" label="Beverage & Tobacco"
                        name="beverage_and_tobacco"
                        @input="form.beverage_and_tobacco = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.clothing_and_footwear" :value="form.clothing_and_footwear" label="Clothing & Footwear"
                        name="clothing_and_footwear"
                        @input="form.clothing_and_footwear = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.housing" :value="form.housing" label="Housing" name="housing"
                        @input="form.housing = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.household_operation" :value="form.household_operation" label="Household Operation"
                        name="household_operation" @input="form.household_operation = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.transport" :value="form.transport" label="Transport"
                        name="transport" @input="form.transport = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.miscellaneous" :value="form.miscellaneous" label="Miscellaneous"
                        name="miscellaneous"
                        @input="form.miscellaneous = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.all_items" :value="form.all_items" label="All Items"
                        name="all_items"
                        @input="form.all_items = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.inflation_rate" :value="form.inflation_rate" label="Inflation Rate"
                        name="inflation_rate"
                        @input="form.inflation_rate = $event" type="number" />
          </div>
          <div class="px-1 w-1/5">
            <text-input :error="errors.non_food_inflation" :value="form.non_food_inflation" label="Non-food Inflation"
                        name="non_food_inflation"
                        @input="form.non_food_inflation = $event" type="number" />
          </div>
        </div>

        <form-actions to="/cms/cpi-monthly"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import FormActions from "../../../components/forms/FormActions";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import LongTextInput from "../../../components/forms/LongTextInput";

export default {
  name: "create",
  components: {LongTextInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  data() {
    return {
      errors: {},
      form: {
        date: '',
        food: '',
        inflation_rate: '',
        beverage_and_tobacco: '',
        housing: '',
        miscellaneous: '',
        all_items: '',
        clothing_and_footwear: '',
        transport: '',
        household_operation: '',
        non_food_inflation: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post('/cpi/monthly', this.form)
        .then(() => this.$router.push(`/cms/cpi-monthly`))
        .catch(err => this.errors = err.response.data.status.errors)

    }
  }
}
</script>

<style scoped>

</style>
