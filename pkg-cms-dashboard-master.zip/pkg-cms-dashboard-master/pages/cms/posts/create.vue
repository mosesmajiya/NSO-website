<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a post" title="New Post"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Title" name="title" type="text" v-bind:error="errors.title" v-bind:value="form.title"
                    v-on:input="form.title = $event"/>

        <dropdown-input @change="form.post_type_id = $event" label="Post Type"
                        v-bind:error="errors.post_type_id"
                        v-bind:options="options" v-bind:value="form.post_type_id"/>

        <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                         v-bind:value="form.content"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "../../../components/forms/DropdownInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  mixins: [create_resource],
  created() {
    if (!process.browser) return
    this.$axios.get('/post-types')
      .then(res => this.options = res.data.data.data.map(function (type) {
        return {
          value: type.id,
          label: type.name
        }
      }))
  },
  data() {
    return {
      form: {
        title: '',
        content: '',
        post_type_id: '',
      },
      options: [],
      namespace: 'posts',
      recent: [],
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`/${this.namespace}`, this.getFormData())
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    getFormData() {
      let form = new FormData();
      for (let field in this.form) {
        if (this.form[field]) form.append(field, this.form[field])
      }

      let object = {};
      form.forEach((value, key) => {
        object[key] = value
      });
      return object
    }
  }
}
</script>
