<template>
  <editing-stage subtitle="Edit post" title="Edit Post" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Title" name="title" type="text" v-bind:error="errors.title" v-bind:value="form.title"
                  v-on:input="form.title = $event"/>

      <dropdown-input @change="form.post_type_id = $event" class="md:flex-1" label="Post Type"
                      v-bind:error="errors.post_type_id"
                      v-bind:options="options" v-bind:value="form.post_type_id"/>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>

    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";
import FormLink from "../../../../components/forms/FormLink";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";
import DropdownInput from "../../../../components/forms/DropdownInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {
    DropdownInput,
    EditingStage, FormActions, FormLink, FormButton, LinkButton, ParagraphInput, TextInput, FormSubmit
  },
  mixins: [edit_resource],
  created() {
    if (!process.browser) return
    this.$axios.get('/post-types')
      .then(res => {
        let eventTypes = res.data.data.data
        this.options = eventTypes.map(function (type) {
          return {value: type.id, label: type.name}
        })
      })
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    getFormData() {
      let form = new FormData();
      for (let field in this.form) {
        if (this.form[field]) form.append(field, this.form[field])
      }

      let object = {};
      form.forEach((value, key) => {
        object[key] = value
      });
      return object
    }
  },
  data() {
    return {
      data: {},
      form: {
        title: '',
        content: '',
        post_type_id: '',
      },
      options: [],
      namespace: 'posts',
      errors: []
    }
  }
}
</script>

