<template>
  <media-editing-stage :namespace="namespace" v-bind:form="form" v-bind:media="media" v-bind:url="url"/>
</template>

<script>

import MediaEditingStage from "../../../../../components/MediaEditingStage";
import media_id from "@/mixins/media/media_id";

export default {
  name: "_media_id",
  components: {MediaEditingStage},
  mixins: [media_id],
  data() {
    return {
      form: {
        caption: ''
      },
      url: '',
      namespace: 'posts',
      media: {}
    }
  },
}
</script>
