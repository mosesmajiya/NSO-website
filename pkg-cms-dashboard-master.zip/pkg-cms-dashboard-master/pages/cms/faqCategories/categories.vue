<template>
  <nuxt/>
</template>

<script>

  export default {
    name: "categories",
  }
</script>

