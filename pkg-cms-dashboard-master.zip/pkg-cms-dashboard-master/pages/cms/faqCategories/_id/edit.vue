<template>
  <div>
    <div class="m-8 rounded border">
      <div class="bg-gray-200 py-5 px-8">
        <h1 class="text-2xl">Edit FAQ Category</h1>
        <h2 class="text-sm pt-4">
          <slot name="subtitle">
            Edit FAQ Category
          </slot>
        </h2>
      </div>

      <div class="p-8 flex flex-row">
        <div class="flex-1">
          <form @submit.prevent="onSubmit">
            <text-input @input="form.name = $event" label="FAQ Category Name" name="name" v-bind:error="errors.name"
                        v-bind:value="form.name"/>
            <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>
          </form>
        </div>
        <div class="w-1/4 ml-8">
          <div class="border">
            <h3 class="bg-gray-200 px-5 py-3">Details</h3>
            <div class="px-5 pb-3">
              <slot name="details">
                <page-details :page="data"/>
              </slot>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import PageDetails from "../../../../components/PageDetails";

export default {
  name: "edit",
  components: {PageDetails, TextInput, FormActions, EditingStage},
  async created() {
    let response = (await this.$axios.get(`faqCategories/${this.$route.params.id}`)).data.data
    this.form = response
    this.data = response
  },
  data() {
    return {
      data: {},
      form: {
        name: ''
      },
      errors: [],
      namespace: 'faqCategories'
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/faqCategories/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
