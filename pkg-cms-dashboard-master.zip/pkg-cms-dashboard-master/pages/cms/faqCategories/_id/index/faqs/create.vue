<template>
  <form @submit.prevent="onSubmit" class="px-8 pt-8 border border-t-0 rounded-b">
    <text-input label="Question" name="question" v-bind:error="errors.question"
                v-bind:value="form.question" v-on:input="form.question = $event"/>

    <paragraph-input label="Response" name="response" v-bind:error="errors.response"
                     v-bind:value="form.response" v-on:input="form.response = $event"/>

    <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`"/>
  </form>
</template>

<script>
  import FormActions from "../../../../../../components/forms/FormActions";
  import TextInput from "../../../../../../components/forms/TextInput";
  import ParagraphInput from "../../../../../../components/forms/ParagraphInput";

  export default {
    name: "create",
    components: {ParagraphInput, TextInput, FormActions},
    data() {
      return {
        namespace: 'faqCategories',
        form: {
          question: '',
          response: '',
          faq_category_id: this.$route.params.id
        },
        errors: []
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`/faqs/`, this.form)
          .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
