<template>
  <div>
    <media-upload v-bind:namespace="namespace" v-bind:url-param="urlParam"/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:category="category"
                v-bind:data="data" v-bind:namespace="namespace"/>
  </div>
</template>

<script>
import FormSubmit from "../../../../../../../../components/forms/FormSubmit";
import TextInput from "../../../../../../../../components/forms/TextInput";
import MediaUpload from "../../../../../../../../components/forms/MediaUpload";
import MediaList from "../../../../../../../../components/MediaList";
import media_index from "@/mixins/media/media_index";

export default {
  name: "media",
  components: {MediaList, MediaUpload, TextInput, FormSubmit},
  mixins: [media_index],
  data() {
    return {
      form: {
        caption: '',
        type: '',
        file: ''
      },
      errors: [],
      namespace: 'faqs',
      category: 'faqCategories',
      urlParam: 'faq_id',
      attachments: [],
      banners: [],
      data: {}
    }
  }
}
</script>

