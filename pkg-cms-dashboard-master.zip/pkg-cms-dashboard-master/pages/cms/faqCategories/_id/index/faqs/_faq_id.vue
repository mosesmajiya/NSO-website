<template>
  <div>
    <div class="border border-t-0 rounded-b py-4"></div>
    <div class="mt-8 rounded px-8 border">
      <div class="border-b flex items-center justify-between">
        <nav class="category-nav flex">
          <nuxt-link :to="`/cms/faqCategories/${$route.params.id}`"
                     class="px-4 border-b-2 -mb-px border-transparent  py-5 text-gray-600 hover:text-primary-500 text-sm">
            <fa-icon icon="chevron-left"/>
          </nuxt-link>
          <nuxt-link :to="`/cms/faqCategories/${$route.params.id}/faqs/${$route.params.faq_id}`"
                     class="px-4 border-b-2 -mb-px border-transparent  py-5 text-gray-600 hover:text-primary-500 text-sm">
            Details
          </nuxt-link>
          <nuxt-link :to="`/cms/faqCategories/${$route.params.id}/faqs/${$route.params.faq_id}/edit`"
                     class="px-4 border-b-2 -mb-px border-transparent  py-5 text-gray-600 hover:text-primary-500 text-sm">
          Edit
          </nuxt-link>
          <nuxt-link :to="`/cms/faqCategories/${$route.params.id}/faqs/${$route.params.faq_id}/media`"
                     class="px-4 border-b-2 -mb-px border-transparent  py-5 text-gray-600 hover:text-primary-500 text-sm">
            Media
          </nuxt-link>
          <nuxt-link :to="`/cms/faqCategories/${$route.params.id}/faqs/${$route.params.faq_id}/metadata`"
                     class="px-4 border-b-2 -mb-px border-transparent  py-5 text-gray-600 hover:text-primary-500 text-sm">
            Metadata
          </nuxt-link>
        </nav>
        <div>
          <svg-published :on="item.published_at"/>
        </div>
      </div>
      <nuxt class="my-8"/>
    </div>
  </div>
</template>

<script>
import FaIcon from "../../../../../../components/FaIcon";
import SvgPublished from "../../../../../../components/icons/svg-published";

export default {
  name: "_faq_id",
  components: {SvgPublished, FaIcon},
  async created() {
    await this.$store.dispatch('faqs/fetchOne', this.$route.params.faq_id)
  },
  computed: {
    item() {
      return this.$store.getters['faqs/getFaq']
    }
  }
}
</script>
