<template>
  <div>
    <p class="font-bold text-gray-500">Question</p>
    <h1 class="pb-4">{{ data.question }}</h1>

    <p class="font-bold text-gray-500">Response</p>
    <div v-html="data.response"></div>

    <div class="flex mt-8">
      <form-button
        :fa-icon="data.published_at ? 'unlink' : 'link'"
        @click="togglePublish"
        custom-class="mr-2">
        {{ data.published_at ? 'Unpublish' : 'Publish'}}
      </form-button>
      <confirm-button
        @confirmed="destroy"
        custom-class="flex"
        icon="delete"
        label="Delete"
        title="Confirm Deletion"
        v-bind:message="`${data[headingColumn]} will be permanently deleted.`"
      >
        Delete
      </confirm-button>
    </div>
  </div>
</template>

<script>
import FormButton from "../../../../../../../components/FormButton";
import ConfirmButton from "../../../../../../../components/ConfirmButton";

export default {
  name: "index",
  components: {ConfirmButton, FormButton},
  // mixins: [index_resources],
  data() {
    return {
      // data: {},
      headingColumn: 'question',
    }
  },
  async created() {
    await this.$store.dispatch('faqs/fetchOne', this.$route.params.faq_id)
  },
  computed: {
    data() {
      return this.$store.getters['faqs/getFaq']
    }
  },
  methods: {
    togglePublish() {
      if (this.data.published_at) {
        this.unpublish()
      } else {
        this.publish()
      }
    },
    publish() {
      this.$axios.post(`faqs/${this.$route.params.faq_id}/publish`)
          .then(() => this.$router.go())
      },
      unpublish() {
        this.$axios.delete(`faqs/${this.$route.params.faq_id}/unpublish`)
          .then(() => this.$router.go())
      },
      destroy() {
        this.$axios.delete(`faqs/${this.$route.params.faq_id}`)
          .then(() => this.$router.push(`/cms/faqCategories/${this.$route.params.id}`))
      }
    }
  }
</script>
