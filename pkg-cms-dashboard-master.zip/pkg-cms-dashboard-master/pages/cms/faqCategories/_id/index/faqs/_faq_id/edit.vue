<template>
  <form @submit.prevent="onSubmit">
    <text-input label="Question" name="question" v-bind:error="errors.question"
                v-bind:value="form.question" v-on:input="form.question = $event"/>

    <paragraph-input label="Response" name="response" v-bind:error="errors.response"
                     v-bind:value="form.response" v-on:input="form.response = $event"/>

    <form-actions v-bind:to="`/cms/faqCategories/${$route.params.id}/faqs/${$route.params.faq_id}`"/>
  </form>
</template>

<script>
import FormActions from "../../../../../../../components/forms/FormActions";
import TextInput from "../../../../../../../components/forms/TextInput";
import ParagraphInput from "../../../../../../../components/forms/ParagraphInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {ParagraphInput, TextInput, FormActions},
  mixins: [edit_resource],
  data() {
    return {
      errors: [],
      namespace: 'faqs',
      form: {
        question: '',
        response: '',
        faq_category_id: this.$route.params.id
      }
    }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`/faqs/${this.$route.params.faq_id}`, this.form)
          .then(() => this.$router.push(`/cms/faqCategories/${this.$route.params.id}/faqs/${this.$route.params.faq_id}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
