<template>
  <div>
    create
  </div>
</template>

<script>
  export default {
    name: "create"
  }
</script>
