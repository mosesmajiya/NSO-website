<template>
  <div>
    <div class="flex px-8 py-6 border border-t-0">
      <link-button :to="`/cms/faqCategories/${$route.params.id}/faqs/create`" accent="primary" icon="add">
        Create FAQ
      </link-button>

      <form-button
        :fa-icon="data.published_at ? 'unlink' : 'link'"
        @click="togglePublish"
        custom-class="mr-4">
        {{ data.published_at ? 'Unpublish' : 'Publish'}}
      </form-button>

      <confirm-button @confirmed="destroy" accent="gray" fa-icon="trash" label="Delete Category"
                      message="This FAQ category including all its questions will be deleted permanently"
                      title="Confirm Deletion"/>

    </div>
    <div v-if="data.faqs && data.faqs.length" class="w-full border mt-8 rounded">
      <nuxt-link :key="item.id" :to="`/cms/${namespace}/${$route.params.id}/faqs/${item.id}`"
                 class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block" v-for="item in data.faqs">
        <div class="leading-loose">{{ item.question }}</div>
        <div class="text-sm flex">
          <div class="flex-grow flex">
            <div class="mr-4 flex items-center">
              <svg-clock-solid/>
              {{ $moment(item.created_at).fromNow() }}
            </div>
            <div class="mr-4 flex items-center">
              <svg-eye/>
              {{ item.views }} views
            </div>
          </div>
          <svg-published :on="item.published_at"/>
        </div>
      </nuxt-link>
    </div>
  </div>
</template>

<script>
import LinkButton from "../../../../../components/LinkButton";
import FaIcon from "../../../../../components/FaIcon";
import ConfirmButton from "../../../../../components/ConfirmButton";
import FormButton from "../../../../../components/FormButton";
import index_resources from "@/mixins/resource/index_resources";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgEye from "@/components/icons/svg-eye";
import SvgPublished from "../../../../../components/icons/svg-published";

export default {
  name: "index",
  components: {SvgPublished, SvgEye, SvgClockSolid, FormButton, ConfirmButton, FaIcon, LinkButton},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'faqCategories'
    }
  },
  methods: {
    destroy() {
      this.$axios.delete(`faqCategories/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
      },
      togglePublish() {
        if (this.data.published_at) {
          return this.unpublish();
        } else {
          return this.publish()
        }
      },
      publish() {
        this.$axios.post(`faqCategories/${this.$route.params.id}/publish`)
          .then(() => this.$router.go())
      },
      unpublish() {
        this.$axios.delete(`faqCategories/${this.$route.params.id}/unpublish`)
          .then(() => this.$router.go())
      }
    }
  }
</script>
