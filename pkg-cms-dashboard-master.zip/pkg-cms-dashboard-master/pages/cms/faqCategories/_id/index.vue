<template>
  <div class="m-8">
    <div class="px-8 py-5 bg-gray-100 border-t border-l border-r rounded-t">
      <div class="flex items-center justify-between">
        <h1 class="text-2xl">{{ data.name }}</h1>
        <span>
          <span class="flex" v-if="data.published_at">
            <i class="material-icons text-green-500">fiber_manual_record</i>
          </span>
          <span class="flex" v-else>
            <i class="material-icons text-gray-500">fiber_manual_record</i>
          </span>
        </span>
      </div>
      <h2 class="text-sm pt-4">

        View FAQs under {{ data.name }}
      </h2>
    </div>
    <nuxt/>
  </div>
</template>

<script>
import FaIcon from "../../../../components/FaIcon";
import LinkButton from "../../../../components/LinkButton";

export default {
  name: "index",
  components: {LinkButton, FaIcon},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`faqCategories/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {},
      menu: 'cms',
      namespace: 'faqCategories',
    }
  }
}
</script>
