<template>
  <div>
    <navigate-back to="/cms/faqCategories"/>
    <div class="border-gray-300 border rounded m-8">
      <div class="bg-gray-200 px-8 py-5">
        <h1 class="text-2xl">FAQ Categories</h1>
        <h2 class="text-sm pt-4">Create a FAQ Category</h2>
      </div>
      <div class="p-8">
        <form @submit.prevent="onSubmit">
          <text-input label="Category Name" name="name" v-bind:error="errors.name"
                      v-bind:value="form.name" v-on:input="form.name = $event"/>

          <form-actions :to="`/cms/${namespace}`"/>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
  import NavigateBack from "../../../components/NavigateBack";
  import TextInput from "../../../components/forms/TextInput";
  import FormActions from "../../../components/forms/FormActions";

  export default {
    name: "create",
    components: {FormActions, TextInput, NavigateBack},
    data() {
      return {
        form: {
          name: ''
        },
        errors: [],
        namespace: 'faqCategories'
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`faqCategories`, this.form)
          .then(() => this.$router.push(`/cms/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }

  }
</script>
