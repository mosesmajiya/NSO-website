<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <div class="border-gray-300 border rounded m-8">
      <div class="bg-gray-200 px-8 py-5">
        <h1 class="text-2xl">FAQ Categories</h1>
        <h2 class="text-sm pt-4">Manage FAQ Categories</h2>
      </div>
      <div class="p-8">
        <form @submit.prevent="onSubmit" class="px-8 pt-8 border border-gray-300 rounded-t bg-gray-100">
          <text-input label="Category Name" name="name" v-bind:error="errors.name"
                      v-bind:value="form.name" v-on:input="form.name = $event"/>

          <form-submit accent="primary"/>
        </form>
        <div class="w-full border-b border-l border-r rounded-b">
          <div :key="item.id"
               class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block group" v-for="item in data">
            <div class="leading-loose">
              {{ item[headingColumn] }}
              <span class="bg-gray-300 text-xs px-3 py-2 rounded-full font-bold ">{{ item.faqs_count}}</span>
            </div>
            <div class="text-sm flex">
              <div class="flex-grow flex">
                <div class="mr-4 flex items-center">
                  <svg-clock-solid/>
                  {{ $moment(item.created_at).fromNow() }}
                </div>
              </div>
              <div class="invisible group-hover:visible flex">
                <link-button accent="gray" v-bind:to="`/cms/faqs/categories/${item.id}`">Edit</link-button>
                <confirm-button
                  @confirmed="destroy(item)"
                  accent="red"
                  label="Delete"
                  title="Confirm Deletion"
                  v-bind:message="`${item[headingColumn]} will be permanently deleted.`"
                >
                  Delete
                </confirm-button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import NavigateBack from "../../../../components/NavigateBack";
import EditingStage from "../../../../components/EditingStage";
import TextInput from "../../../../components/forms/TextInput";
import FormSubmit from "../../../../components/forms/FormSubmit";
import FaIcon from "../../../../components/FaIcon";
import ConfirmIcon from "../../../../components/ConfirmIcon";
import ConfirmButton from "../../../../components/ConfirmButton";
import NavigateLink from "../../../../components/NavigateLink";
import LinkButton from "../../../../components/LinkButton";
import SvgClockSolid from "@/components/icons/svg-clock-solid";

export default {
  name: "categories",
  components: {
    SvgClockSolid,
    LinkButton,
    NavigateLink, ConfirmButton, ConfirmIcon, FaIcon, FormSubmit, TextInput, EditingStage, NavigateBack
  },
  created() {
    if (!process.browser) return
    this.$axios.get('faqCategories')
      .then(res => this.data = res.data.data)
  },
    data() {
      return {
        data: [],
        form: {
          name: ''
        },
        errors: [],
        namespace: 'faqs',
        headingColumn: 'name',
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post('faqCategories', this.form)
          .then(() => this.$router.go())
          .catch(err => this.errors = err.response.data.status.errors)
      },
      destroy(item) {
        this.$axios.delete(`faqCategories/${item.id}`)
          .then(() => this.$router.go())
      }
    }
  }
</script>

<style scoped>

</style>
