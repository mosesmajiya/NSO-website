<template>
  <div>
    <navigate-back to="/cms/pages"/>
    <creation-stage heading-field="title" namespace="pages" subtitle="Create a page" title="New Page"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Title" name="title" type="text" v-bind:error="errors.title" v-bind:value="form.title"
                    v-on:input="form.title = $event"></text-input>

        <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                         v-bind:value="form.content"/>

        <form-submit/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage},
  mixins: [create_resource],
  data() {
    return {
      namespace: 'pages',
      form: {
        title: '',
        content: ''
      },
      recent: [],
      errors: [],
    }
    },
    methods: {
      onSubmit() {
        this.$axios.post('/pages', this.form)
          .then(() => this.$router.push('/cms/pages'))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
