<template>
  <metadata-edit namespace="pages" v-bind:data="data" v-bind:form="form"/>
</template>

<script>
import MetadataEdit from "~/components/forms/MetadataEdit";
import resource_metadata from "@/mixins/resource/resource_metadata";

export default {
  name: "metadata",
  components: {MetadataEdit},
  mixins: [resource_metadata],
  data() {
    return {
      namespace: 'pages',
      form: {
        description: '',
        keywords: '',
      },
      data: {}
    }
  }
  }
</script>
