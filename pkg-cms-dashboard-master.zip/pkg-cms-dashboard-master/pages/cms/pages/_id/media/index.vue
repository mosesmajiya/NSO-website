<template>
  <editing-stage subtitle="Upload page media" title="Page Media" v-bind:data="data">
    <media-upload :namespace="namespace"/>
    <nuxt/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:data="data"
                v-bind:namespace="namespace"/>
  </editing-stage>
</template>

<script>
import EditingStage from "~/components/EditingStage";
import MediaUpload from "~/components/forms/MediaUpload";
import MediaList from "~/components/MediaList";
import media_index from "@/mixins/media/media_index";

export default {
  name: "index",
  components: {
    MediaList,
    MediaUpload,
    EditingStage,
  },
  mixins: [media_index],
  data() {
    return {
      namespace: 'pages',
      data: {},
      banners: [],
      attachments: [],
    }
  },
}
</script>
