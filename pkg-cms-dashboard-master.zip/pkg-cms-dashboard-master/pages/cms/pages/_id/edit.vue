<template>
  <editing-stage subtitle="Edit page" title="Edit Page" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Title" name="title" type="text" v-bind:error="errors.title" v-bind:value="form.title"
                  v-on:input="form.title = $event"></text-input>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-submit/>
    </form>
  </editing-stage>
</template>

<script>
import EditingStage from "~/components/EditingStage";
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {ParagraphInput, TextInput, FormSubmit, EditingStage},
  mixins: [edit_resource],
  methods: {
    onSubmit() {
      this.$axios.patch(`/pages/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/pages/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      namespace: 'pages',
      form: {
        title: '',
        content: ''
      },
      errors: []
    }
  }
}
</script>

