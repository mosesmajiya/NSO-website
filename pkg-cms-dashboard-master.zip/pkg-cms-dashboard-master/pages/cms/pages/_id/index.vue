<template>
  <view-stage :title="data.title" @onDelete="onDelete" @onTogglePublish="togglePublish" heading-column="title"
              v-bind:data="data">
    <div v-html="data.content"></div>
  </view-stage>
</template>

<script>
import ViewStage from "~/components/ViewStage";
import index_resources from "@/mixins/resource/index_resources";

export default {
  name: "index",
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'pages'
    }
  },
  components: {ViewStage},
  methods: {
    onDelete() {
      this.$axios.delete(`pages/${this.$route.params.id}`)
          .then(() => this.$router.push('/cms/pages'))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`pages/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`pages/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
