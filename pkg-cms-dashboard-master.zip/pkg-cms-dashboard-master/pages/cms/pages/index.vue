<template>
  <div>
    <contextual-menu>
      <link-button accent="primary" icon="playlist_add" to="/cms/pages/create">New Page</link-button>
    </contextual-menu>
    <index-stage @cancel="$router.go()" @loadeddata="data = $event" fields="title,content" table="pages">
      <div class="w-full">
        <nuxt-link :key="item.id" :to="`/cms/pages/${item.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block" v-for="item in data.data">
          <div class="leading-loose">{{ item.title }}</div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(item.created_at).fromNow() }}
              </div>
              <div class="mr-4 flex items-center">
                <svg-eye/>
                {{ item.views }} views
              </div>
            </div>
            <svg-published :on="item.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination @loadeddata="data = $event" v-bind:paginator="data" v-if="data.from"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "~/components/ContextualMenu";
import LinkButton from "~/components/LinkButton";
import FaIcon from "~/components/FaIcon";
import Pagination from "~/components/Pagination";
import IndexStage from "../../../components/IndexStage";
import global_index from "@/mixins/resource/global_index";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgBarGraph from "@/components/icons/svg-bar-graph";
import SvgEye from "@/components/icons/svg-eye";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index",
  components: {
    SvgPublished,
    SvgEye, SvgBarGraph, SvgClockSolid, IndexStage, Pagination, FaIcon, LinkButton, ContextualMenu
  },
  mixins: [global_index],
  data() {
    return {
      data: {},
      namespace: 'pages'
    }
  }
}
</script>
