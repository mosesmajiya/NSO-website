<template>
  <editing-stage subtitle="Edit service" title="Edit Service" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Position" name="position" type="text" v-bind:error="errors.position"
                  v-bind:value="form.position"
                  v-on:input="form.position = $event"></text-input>

      <dropdown-input @change="form.job_type = $event" label="Job type" name="job_type" v-bind:error="errors.job_type"
                      v-bind:options="options" v-bind:value="form.job_type"/>

      <text-input @input="form.deadline = $event" label="Deadline" name="deadline" type="date"
                  v-bind:error="errors.deadline" v-bind:value="form.deadline"/>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>

    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";
import FormLink from "../../../../components/forms/FormLink";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";
import DropdownInput from "../../../../components/forms/DropdownInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {
    DropdownInput,
    EditingStage, FormActions, FormLink, FormButton, LinkButton, ParagraphInput, TextInput, FormSubmit
  },
  mixins: [edit_resource],
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      form: {
        position: '',
        content: '',
        deadline: '',
        job_type: '',
      },
      namespace: 'vacancies',
      errors: [],
      options: [
        {label: 'Temporary', value: 'temporary'},
        {label: 'Permanent', value: 'permanent'},
        {label: 'Contract', value: 'contract'},
      ]
    }
  }
}
</script>

