<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a vacancy" title="New Vacancy"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Position" name="position" type="text" v-bind:error="errors.position"
                    v-bind:value="form.position"
                    v-on:input="form.position = $event"/>

        <dropdown-input @change="form.job_type = $event" label="Job type" name="job_type" v-bind:error="errors.job_type"
                        v-bind:options="options" v-bind:value="form.job_type"/>

        <text-input @input="form.deadline = $event" label="Deadline" name="deadline" type="date"
                    v-bind:error="errors.deadline" v-bind:value="form.deadline"/>

        <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                         v-bind:value="form.content"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "../../../components/forms/DropdownInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  mixins: [create_resource],
  data() {
    return {
      form: {
        position: '',
        content: '',
        job_type: '',
        deadline: '',
      },
      namespace: 'vacancies',
      recent: [],
        errors: [],
        options: [
          {label: 'Temporary', value: 'temporary'},
          {label: 'Permanent', value: 'permanent'},
          {label: 'Contract', value: 'contract'},
        ]
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`/${this.namespace}`, this.form)
          .then(() => this.$router.push(`/cms/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
