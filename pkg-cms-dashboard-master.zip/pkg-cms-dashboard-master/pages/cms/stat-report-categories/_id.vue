<template>
  <div>
    <contextual-menu menu="CMS" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-chevron-left class="w-6 h-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}`" class="flex" exact>
        <svg-file class="w-6 h-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/edit`" class="flex">
        <svg-pencil-alt class="w-6 h-6 mr-2"/>
        Edit
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>
import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import ContextualMenu from "../../../components/ContextualMenu";
import TabItem from "../../../components/tabItem";
import SvgChevronLeft from "../../../components/icons/svg-chevron-left";
import SvgFile from "../../../components/icons/svg-file";
import SvgPencilAlt from "../../../components/icons/svg-pencil-alt";

export default {
  name: "_id",
  components: {SvgPencilAlt, SvgFile, SvgChevronLeft, TabItem, ContextualMenu, ItemTabbedDetails},
  async created() {
    if (!process.browser) return
    this.loaded = false
    this.$axios.get(`census/report-categories/${this.$route.params.id}`)
      .then(res => {
        this.category = res.data.data
        this.loaded = true
      })
  },
  data() {
    return {
      category: {},
      loaded: false,
      namespace: 'stat-report-categories'
    }
  }
}
</script>
