<template>
  <div>
    <contextual-menu :namespace="namespace">
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New Category
      </link-button>
    </contextual-menu>
    <index-stage fields="name,description" table="abouts" @cancel="$router.go(0)" @loadeddata="data = $event">
      <div class="w-full">
        <nuxt-link v-for="category in categories.data" :key="category.id"
                   :to="`/cms/${namespace}/${category.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block">
          <div class="leading-loose">{{ category.name }}</div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(category.created_at).fromNow() }}
              </div>
            </div>
            <svg-published :on="category.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination v-if="categories.from" v-bind:paginator="categories" @loadeddata="categories = $event"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "~/components/ContextualMenu";
import LinkButton from "~/components/LinkButton";
import IndexStage from "~/components/IndexStage";
import SvgClockSolid from "~/components/icons/svg-clock-solid";
import FaIcon from "~/components/FaIcon";
import Pagination from "~/components/Pagination";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index.vue",
  components: {SvgPublished, Pagination, FaIcon, SvgClockSolid, IndexStage, LinkButton, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get(this.api).then(res => this.categories = res.data.data)
  },
  data() {
    return {
      categories: {},
      menu: "CMS",
      api: 'census/report-categories',
      namespace: 'stat-report-categories',
    }
  }
}
</script>

<style scoped>

</style>
