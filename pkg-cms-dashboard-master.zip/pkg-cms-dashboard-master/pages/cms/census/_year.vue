<template>
  <div>
    <contextual-menu namespace="census">
      <tab-item :to="`/cms/census/${this.$route.params.year}/summary`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        View
      </tab-item>
      <tab-item :to="`/cms/census/${this.$route.params.year}/national`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        National
      </tab-item>
      <tab-item :to="`/cms/census/${this.$route.params.year}/regional`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
          <path d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Regional
      </tab-item>
      <tab-item :to="`/cms/census/${this.$route.params.year}/district`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
          <path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        District
      </tab-item>
      <tab-item :to="`/cms/census/${this.$route.params.year}/resources`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Resources
      </tab-item>
      <tab-item :to="`/cms/census/${this.$route.params.year}/media`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Media
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import IndexStage from "../../../components/IndexStage";
import ViewStage from "../../../components/ViewStage";
import TabItem from "../../../components/tabItem";

export default {
  name: "_year",
  components: {TabItem, ViewStage, IndexStage, ContextualMenu},
  mounted() {
    // this.$router.push(`/cms/census/${this.$route.params.year}/summary`)
  }
}
</script>

<style scoped>

</style>
