<template>
  <div>
    <navigate-back namespace="census" to="/cms"/>
    <creation-stage heading-field="year" namespace="census" subtitle="Create new census" title="Create Census">
      <form @submit.prevent="onSubmit">
        <text-input :error="errors.year" :value="form.year" label="Year" name="year" @input="form.year = $event"/>
        <long-text-input :error="errors.description" :rows="2" :value="form.description" label="Description"
                         name="description"
                         @input="form.description = $event"/>

        <long-text-input :error="errors.abstract" :rows="5" :value="form.abstract" label="Abstract"
                         name="abstract"
                         @input="form.abstract = $event"/>
        <div class="flex flex-wrap -mx-1">
          <div class="px-1 w-1/3">
            <text-input :error="errors.population" :value="form.population" label="Population"
                        name="population"
                        @input="form.population = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.population_density" :value="form.population_density" label="Population Density"
                        name="population_density"
                        @input="form.population_density = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.poverty" :value="form.poverty" label="Poverty"
                        name="poverty"
                        @input="form.poverty = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.literacy" :value="form.literacy" label="Literacy"
                        name="literacy"
                        @input="form.literacy = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.life_expectancy_female" :value="form.life_expectancy_female"
                        label="Life Expectancy Female"
                        name="life_expectancy_female"
                        @input="form.life_expectancy_female = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.life_expectancy_male" :value="form.life_expectancy_male"
                        label="Life Expectancy Male"
                        name="life_expectancy_male"
                        @input="form.life_expectancy_male = $event"/>
          </div>
          <div class="px-1 w-1/3">
            <text-input :error="errors.fertility_rate" :value="form.fertility_rate" label="Fertility Rate"
                        name="fertility_rate"
                        @input="form.fertility_rate = $event"/>
          </div>

        </div>

        <form-actions to="/"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import FormActions from "../../../components/forms/FormActions";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import LongTextInput from "../../../components/forms/LongTextInput";

export default {
  name: "create",
  components: {LongTextInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  data() {
    return {
      errors: {},
      form: {
        year: '',
        description: '',
        abstract: '',
        population: '',
        population_density: '',
        literacy: '',
        poverty: '',
        life_expectancy_male: '',
        life_expectancy_female: '',
        fertility_rate: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post('/census/national', this.form)
        .then(() => this.$router.push('/'))
        .catch(err => this.errors = err.response.data.status.errors)

    }
  }
}
</script>

<style scoped>

</style>
