<template>
  <div v-if="regions.length" class="p-8">
    <form @submit.prevent="onSubmit" class="border rounded p-8 shadow bg-gray-200">
      <div class="flex space-x-2">
        <div class="flex-1">
          <dropdown-input :error="errors.region_id" :options="regionOptions" :value="form.region_id" label="Region"
                          name="region_id" @change="form.region_id = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.population" :value="form.population" label="Population" name="population"
                      type="number"
                      @input="form.population = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.population_density" :value="form.population_density" label="Population Density"
                      name="population_density" type="number"
                      @input="form.population_density = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.poverty" :value="form.poverty" label="Poverty" name="poverty"
                      type="number" @input="form.poverty = $event"/>
        </div>
      </div>
      <div class="flex space-x-2">

        <div class="flex-1">
          <text-input :error="errors.literacy" :value="form.literacy" label="Literacy" name="literacy"
                      type="number" @input="form.literacy = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.life_expectancy_male" :value="form.life_expectancy_male"
                      label="Life Expectancy Male"
                      name="life_expectancy_male" type="number"
                      @input="form.life_expectancy_male = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.life_expectancy_female" :value="form.life_expectancy_female"
                      label="Life Expectancy Female"
                      name="life_expectancy_female" type="number"
                      @input="form.life_expectancy_female = $event"/>
        </div>
        <div class="flex-1">
          <text-input :error="errors.fertility_rate" :value="form.fertility_rate" label="Fertility Rate"
                      name="fertility_rate"
                      type="name" @input="form.fertility_rate = $event"/>
        </div>
      </div>
      <div>
        <FormButton type="submit">Submit</FormButton>
        <form-button class="ml-4" type="button" @click="cancelEdit">Cancel</form-button>
      </div>
    </form>
    <div class="pt-8">
      <div v-for="(record, index) in records" v-if="records.length" :key="index" class="shadow px-4 pt-2 mb-4 rounded">
        <h1 class="text-lg mb-2">{{ record.region.name }}</h1>
        <div class="flex flex-wrap">
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Population</h2>
            <div>{{ record.population }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Population Density</h2>
            <div>{{ record.population_density }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Poverty</h2>
            <div>{{ record.poverty }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Literacy</h2>
            <div>{{ record.literacy }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Life Expectancy Male</h2>
            <div>{{ record.life_expectancy_male }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Life Expectancy Female</h2>
            <div>{{ record.life_expectancy_female }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <h2 class="text-xs">Ferility Rate</h2>
            <div>{{ record.fertility_rate }}</div>
          </div>
          <div class="w-1/4 pb-4">
            <button class="p-2 hover:text-primary-500" title="Edit record" @click="onEdit(record)">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                   xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                  stroke-linecap="round" stroke-linejoin="round"
                  stroke-width="2"></path>
              </svg>
            </button>
            <button class="hover:text-red-500 ml-4 p-2" title="Delete record" @click="onDestroy(record)">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                   xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                  stroke-linecap="round" stroke-linejoin="round"
                  stroke-width="2"></path>
              </svg>
            </button>
          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import FormActions from "../../../../components/forms/FormActions";
import FormButton from "../../../../components/FormButton";
import DropdownInput from "../../../../components/forms/DropdownInput";
import TextInput from "../../../../components/forms/TextInput";

export default {
  name: "regional",
  components: {TextInput, DropdownInput, FormButton, FormActions, FormSubmit},
  created() {
    this.$axios.get('regions')
      .then(res => this.regions = res.data.data)
    this.$axios.get(`census/regional/${this.$route.params.year}`)
      .then(res => this.records = res.data.data)
  },
  data() {
    return {
      editing: false,
      records: [],
      regions: [],
      errors: {},
      form: {
        region_id: '',
        population: '',
        population_density: '',
        poverty: '',
        literacy: '',
        fertility_rate: '',
        life_expectancy_male: '',
        life_expectancy_female: '',
      }
    }
  },
  computed: {
    regionOptions() {
      return this.regions.map(i => {
        return {
          value: i.id,
          label: i.name
        }
      })
    }
  },
  methods: {
    onSubmit() {
      if (this.editing) {
        this.$axios.patch(`census/regional/${this.form.id}`, this.form)
          .then(() => this.$router.go(0))
          .catch(err => this.errors = err.response.data.status.errors)
      } else {
        this.$axios.post(`census/regional/${this.$route.params.year}`, this.form)
          .then(() => this.$router.go(0))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    },
    onDestroy(record) {

    },
    onEdit(record) {
      this.form = record
      this.editing = true
    },
    cancelEdit() {
      this.editing = false
      this.form = {
        region_id: '',
        population: '',
        population_density: '',
        poverty: '',
        literacy: '',
        fertility_rate: '',
        life_expectancy_male: '',
        life_expectancy_female: '',
      }
    }
  }
}
</script>

<style scoped>

</style>
