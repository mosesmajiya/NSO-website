<template>
  <div>
    <div class="m-8 rounded border">
      <div class="bg-gray-200 py-5 px-8">
        <h1 class="text-2xl">Census Media</h1>
        <h2 class="text-sm pt-4">
          <slot name="subtitle">
            Manage Census Media
          </slot>
        </h2>
      </div>

      <div class="p-8 flex flex-row">
        <div class="flex-1">
          <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">
            <div class="mb-5">
              <file-input id="file" label="File" v-bind:error="errors.file" v-model="form.file"/>
            </div>
            <form-button type="submit">Upload File</form-button>
          </form>
        </div>
      </div>

      <div class="p-8 pt-0 flex flex-wrap -mr-4">
        <div class="rounded w-1/3" v-for="(image, index) in media" :key="index">
          <div class="mr-4 mb-8 shadow hover:shadow-lg overflow-hidden">
            <img :src="image.url" class="object-cover h-48 w-full rounded-t" alt=""/>
            <confirm-icon
              icon="trash"

              v-on:confirmed="destroy(image.id)"
              message="This item will be deleted permanently"
              title="Delete Confirmation"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import TextInput from "../../../../components/forms/TextInput";
import FileInput from "../../../../components/forms/FileInput";
import FormButton from "../../../../components/FormButton";
import ConfirmIcon from "../../../../components/ConfirmIcon";

export default {
  name: "media",
  components: {ConfirmIcon, FormButton, FileInput, TextInput},
  created() {
    this.$axios.get(`census/media/${this.$route.params.year}`)
      .then(res => this.media = res.data.media)
  },
  data() {
    return {
      form: {
        file: '',
      },
      namespace: 'census',
      errors: [],
      media: [],
    }
  },
  methods: {
    destroy(id) {
      this.$axios.delete(`census/media/${id}`)
        .then(() => this.media.splice(this.media.findIndex(i => i.id === id), 1))
    },
    onSubmit() {
      let formData = new FormData()
      formData.append('file', this.form.file)

      this.$axios.post(`census/media/${this.$route.params.year}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
