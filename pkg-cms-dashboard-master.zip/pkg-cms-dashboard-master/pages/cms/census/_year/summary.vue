<template>
  <div v-if="census" class="m-8 rounded border p-8">
    <div class="flex flex-wrap">
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Population</div>
        <div class="font-editor">{{ census.population }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Population Density</div>
        <div class="font-editor">{{ census.population_density }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Poverty</div>
        <div class="font-editor">{{ census.poverty }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Literacy</div>
        <div class="font-editor">{{ census.literacy }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Life Expectancy Female</div>
        <div class="font-editor">{{ census.life_expectancy_female }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Life Expectancy Male</div>
        <div class="font-editor">{{ census.life_expectancy_male }}</div>
      </div>
      <div class="pb-4 w-1/4">
        <div class="font-bold text-lg">Fertility Rate</div>
        <div class="font-editor">{{ census.fertility_rate }}</div>
      </div>
    </div>
    <hr class="my-5"/>
    <div class="pb-4 mt-5">
      <div class="font-bold text-xl">Description</div>
      <div class="font-editor mt-5">{{ census.description }}</div>
    </div>
    <div class="pb-4">
      <div class="font-bold text-xl">Abstract</div>
      <div v-html="census.abstract" class="font-editor mt-5"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "summary",
  created() {
    this.$axios.get(`/census/national/${this.$route.params.year}`)
      .then(res => this.census = res.data.data)
  },
  data() {
    return {
      census: null
    }
  }
}
</script>

<style scoped>

</style>
