<template>
  <div>
    Create File
  </div>
</template>

<script>
export default {
  name: "create"
}
</script>

<style scoped>

</style>
