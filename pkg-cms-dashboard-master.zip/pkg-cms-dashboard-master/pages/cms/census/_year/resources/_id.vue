<template>
  <div v-if="resource" class="m-8">
    <h1 class="text-lg pb-4">{{ resource.name }}</h1>
    <form class="p-8 border border-gray-300 rounded bg-gray-100" method="post" @submit.prevent="onSubmit">
      <text-input
        label="Caption"
        name="caption"
        class="md:w-1/2"
        v-bind:error="errors.caption"
        v-bind:value="form.caption"
        v-on:input="form.caption = $event"
      />
      <div class="flex mb-5">
        <file-input id="file" v-model="form.file" class="md:w-1/2" label="File" v-bind:error="errors.file"/>
      </div>

      <form-submit accent="primary">Upload File</form-submit>
    </form>
    <div v-if="resource.media.length" class="pt-4 flex flex-wrap">
      <div v-for="(item, index) in resource.media" :key="index"
           class="flex pt-2 bg-gray-100 border px-2 py-1 rounded mr-4">
        <span>{{ item.name }}</span>
        <button :title="`Delete ${item.name}`" class="ml-2 text-gray-400 hover:text-red-500 focus:outline-none"
                @click="destroyFile(item.id)">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"></path>
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import TextInput from "../../../../../components/forms/TextInput";
import FormButton from "../../../../../components/FormButton";
import FileInput from "../../../../../components/forms/FileInput";
import FormSubmit from "../../../../../components/forms/FormSubmit";

export default {
  name: "_id",
  components: {FormSubmit, FileInput, FormButton, TextInput},
  created() {
    this.$axios.get(`census/resources/${this.$route.params.year}/${this.$route.params.id}`)
      .then(res => this.resource = res.data.data)
  },
  data() {
    return {
      resource: null,
      form: {
        file: '',
        caption: '',
      },
      errors: [],
    }
  },
  methods: {
    destroyFile(id) {
      this.$axios.delete(`census/resources/files/${id}`)
        .then(() => this.$router.go(0))
    },
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)
      formData.append('caption', this.form.caption)

      this.$axios.post(`census/resources/${this.$route.params.id}/files`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>

<style scoped>

</style>
