<template>
  <div class="m-8 rounded border p-8">
    <form @submit.prevent="onSubmit">
      <text-input :error="errors.year" :value="form.year" label="Year" name="year" @input="form.year = $event" class="w-24"/>
      <long-text-input
        :error="errors.description" :rows="2" :value="form.description" label="Description"
        name="description"
        @input="form.description = $event"/>

      <paragraph-input
        :error="errors.abstract" :value="form.abstract" label="Abstract"
        @input="form.abstract = $event"/>

      <div class="flex flex-wrap -mx-1">
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.population" :value="form.population" label="Population"
            name="population"
            @input="form.population = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.population_density" :value="form.population_density" label="Population Density"
            name="population_density"
            @input="form.population_density = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.poverty" :value="form.poverty" label="Poverty"
            name="poverty"
            @input="form.poverty = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.literacy" :value="form.literacy" label="Literacy"
            name="literacy"
            @input="form.literacy = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.life_expectancy_female" :value="form.life_expectancy_female"
            label="Life Expectancy Female"
            name="life_expectancy_female"
            @input="form.life_expectancy_female = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.life_expectancy_male" :value="form.life_expectancy_male"
            label="Life Expectancy Male"
            name="life_expectancy_male"
            @input="form.life_expectancy_male = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.fertility_rate" :value="form.fertility_rate" label="Fertility Rate"
            name="fertility_rate"
            @input="form.fertility_rate = $event"/>
        </div>

      </div>
      <form-actions :to="`/cms/census/${this.$route.params.year}/summary`"/>
    </form>
  </div>
</template>

<script>
import LongTextInput from "../../../../components/forms/LongTextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import TextInput from "../../../../components/forms/TextInput";
import FormActions from "../../../../components/forms/FormActions";
import CreationStage from "../../../../components/CreationStage";
import NavigateBack from "../../../../components/NavigateBack";
import IndexStage from "../../../../components/IndexStage";

export default {
  name: "national",
  components: {IndexStage, LongTextInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  created() {
    this.$axios.get(`census/national/${this.$route.params.year}`)
      .then(res => this.form = res.data.data)
  },
  data() {
    return {
      errors: {},
      form: {
        year: '',
        description: '',
        abstract: '',
        population: '',
        population_density: '',
        literacy: '',
        poverty: '',
        life_expectancy_male: '',
        life_expectancy_female: '',
        fertility_rate: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch('/census/national', this.form)
        .then(() => this.$router.push(`/cms/census/${this.$route.params.year}/summary`))
        .catch(err => this.errors = err.response.data.status.errors)

    }
  }
}
</script>

<style scoped>

</style>
