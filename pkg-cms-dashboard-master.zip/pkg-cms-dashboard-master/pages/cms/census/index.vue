<template>
  <div>
    <contextual-menu :namespace="namespace" menu="CMS">
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New Census</link-button>
    </contextual-menu>
    <index-stage fields="year" table="national_censuses" @cancel="$router.go(0)" @loadeddata="censuses = $event">
      <div class="w-full">
        <nuxt-link v-for="item in censuses" :key="item.id"
                   :to="`/cms/${namespace}/${item.id}`"
                   class="py-3 px-8 border-b last:border-b-0 hover:bg-gray-100 block">
          <div class="leading-loose">{{ item[headingField] }}</div>
        </nuxt-link>
      </div>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import IndexStage from "../../../components/IndexStage";
import Pagination from "../../../components/Pagination";

export default {
  name: "index",
  components: {Pagination, IndexStage, LinkButton, ContextualMenu},
  async created() {
    if (!process.browser) return
    this.censuses = (await this.$axios.get('census/national')).data.data
  },
  data() {
    return {
      namespace: 'census',
      censuses: [],
      menu: 'CMS',
      headingField: 'year'
    }
  }
}
</script>

<style scoped>

</style>
