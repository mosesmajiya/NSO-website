<template>
  <div class="m-8 rounded border p-8">
    <h1 class="text-2xl mb-5 ml-1">Quick Home Page Statistics</h1>
    <form @submit.prevent="onSubmit" class="border rounded p-8 shadow bg-gray-200">
      <div class="flex flex-wrap -mx-1">
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.population" :value="form.population" label="Population"
            name="population"
            @input="form.population = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.inflation_rate" :value="form.inflation_rate" label="Inflation Rate"
            name="inflation_rate"
            @input="form.inflation_rate = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.gross_domestic_product" :value="form.gross_domestic_product" label="Gross Domestic Product"
            name="gross_domestic_product"
            @input="form.gross_domestic_product = $event"/>
        </div>
        <div class="px-1 w-1/3">
          <text-input
            :error="errors.unemployment_rate" :value="form.unemployment_rate" label="Unemployment Rate"
            name="unemployment_rate"
            @input="form.unemployment_rate = $event"/>
        </div>

      </div>
      <form-actions :to="`/cms/`"/>
    </form>
  </div>
</template>

<script>
import LongTextInput from "../../../components/forms/LongTextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import TextInput from "../../../components/forms/TextInput";
import FormActions from "../../../components/forms/FormActions";
import CreationStage from "../../../components/CreationStage";
import NavigateBack from "../../../components/NavigateBack";
import IndexStage from "../../../components/IndexStage";

export default {
  name: "national",
  components: {IndexStage, LongTextInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  created() {
    this.$axios.get(`quickstats`)
      .then(res => {
        if (res.data.data) this.form = res.data.data
      })
  },
  data() {
    return {
      errors: {},
      form: {
        population: '',
        inflation_rate: '',
        gross_domestic_product: '',
        unemployment_rate: ''
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post('/quickstats', this.form)
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
