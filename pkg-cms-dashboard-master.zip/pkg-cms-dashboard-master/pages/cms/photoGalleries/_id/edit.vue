<template>
  <editing-stage subtitle="Edit photo gallery" title="Edit Gallery" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                  v-on:input="form.title = $event"></text-input>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>

    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";
import FormLink from "../../../../components/forms/FormLink";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";
import DropdownInput from "@/components/forms/DropdownInput";

export default {
  name: "edit",
  components: {
    DropdownInput,
    EditingStage, FormActions, FormLink, FormButton, LinkButton, ParagraphInput, TextInput, FormSubmit
  },
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`photoGalleries/${this.$route.params.id}`)).data.data
    this.form = response
    this.data = response
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`photoGalleries/${this.$route.params.id}`, this.$stripFields(this.form))
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        content: '',
      },
      namespace: "photoGalleries",
      errors: [],
      stages: []
    }
  }
}
</script>

