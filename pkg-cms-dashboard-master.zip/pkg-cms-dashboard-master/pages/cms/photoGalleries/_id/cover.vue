<template>
  <editing-stage subtitle="Upload album cover" title="Album Cover" v-bind:data="data">
    <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">

      <file-input class="pb-5" id="file" label="File" v-bind:error="errors.file" v-model="form.file"/>

      <form-submit accent="primary">Upload File</form-submit>
    </form>
    <nuxt/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:data="data"
                v-bind:namespace="namespace"/>
  </editing-stage>
</template>

<script>
import MediaUpload from "../../../../components/forms/MediaUpload";
import MediaList from "../../../../components/MediaList";
import EditingStage from "../../../../components/EditingStage";
import TextInput from "@/components/forms/TextInput";
import DropdownInput from "@/components/forms/DropdownInput";
import FileInput from "@/components/forms/FileInput";
import FormSubmit from "@/components/forms/FormSubmit";

export default {
  name: "index",
  components: {
    FormSubmit,
    FileInput,
    DropdownInput,
    TextInput,
    EditingStage,
    MediaList,
    MediaUpload,
  },
  async mounted() {
    this.banners = (await this.$axios.get(`photoGalleries/${this.$route.params.id}/media/cover`)).data.data
    this.data = (await this.$axios.get(`photoGalleries/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      namespace: "photoGalleries",
      data: {},
      banners: [],
      attachments: [],
      form: {
        file: '',
        caption: '',
        type: ''
      },
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)
      formData.append('type', 'cover')
      formData.append('caption', 'Album cover')

      this.$axios.post(`/photoGalleries/${this.$route.params.id}/attach/cover`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go())
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
