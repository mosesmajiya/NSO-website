<template>
  <view-stage :title="data.name" @onDelete="onDelete" @onTogglePublish="togglePublish" heading-column="name"
              v-if="data && data.name" v-bind:data="data">
    <div v-html="data.content"></div>
  </view-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";

export default {
  name: "index",
  components: {ViewStage},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`photoGalleries/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {},
      namespace: 'photo-galleries'
    }
  },
  methods: {
    onDelete() {
      this.$axios.delete(`photoGalleries/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/photoGalleries`))
    },
    togglePublish() {
      if (!this.data.published_at) {
        this.$axios.post(`photoGalleries/${this.$route.params.id}/publish`)
          .then(response => this.data = response.data.data)
      } else {
        this.$axios.delete(`photoGalleries/${this.$route.params.id}/unpublish`)
          .then(response => this.data = response.data.data)
      }
    }
  }
}
</script>
