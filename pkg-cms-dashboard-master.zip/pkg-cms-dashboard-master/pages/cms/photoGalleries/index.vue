<template>
  <div>
    <contextual-menu>
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New Gallery</link-button>
    </contextual-menu>
    <index-stage :table="namespace" @cancel="$router.go()" @loadeddata="data = $event" fields="name,content">
      <div class="w-full">
        <nuxt-link :key="item.id" :to="`/cms/${namespace}/${item.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block" v-for="item in data.data">
          <div class="leading-loose">{{ item[headingField] }}</div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(item.created_at).fromNow() }}
              </div>
              <div class="mr-4 flex items-center">
                <svg-eye/>
                {{ item.views }} views
              </div>
            </div>
            <svg-published :on="item.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination @loadeddata="data = $event" v-bind:paginator="data" v-if="data.from"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "~/components/ContextualMenu";
import LinkButton from "~/components/LinkButton";
import FaIcon from "~/components/FaIcon";
import Pagination from "~/components/Pagination";
import IndexStage from "../../../components/IndexStage";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgEye from "@/components/icons/svg-eye";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index",
  components: {SvgPublished, SvgEye, SvgClockSolid, IndexStage, Pagination, FaIcon, LinkButton, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get('photoGalleries')
      .then(res => this.data = res.data.data)
  },
  data() {
    return {
      data: {},
      namespace: "photoGalleries",
      headingField: 'name',
    }
  }
}
</script>
