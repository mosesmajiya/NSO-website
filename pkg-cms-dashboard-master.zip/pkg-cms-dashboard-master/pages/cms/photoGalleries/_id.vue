<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 19l-7-7m0 0l7-7m-7 7h18" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
        </svg>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex items-center" exact>
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex items-center">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/media`" class="flex items-center">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
          <path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Media
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/metadata`" class="flex items-center">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Metadata
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/cover`" class="flex items-center">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Cover
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>

import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import ContextualMenu from "@/components/ContextualMenu";
import TabItem from "@/components/tabItem";
import FaIcon from "@/components/FaIcon";

export default {
  name: "_id",
  components: {FaIcon, TabItem, ContextualMenu, ItemTabbedDetails},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`photoGalleries/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {},
      namespace: "photoGalleries",
      menu: "CMS"
    }
  }
}
</script>

