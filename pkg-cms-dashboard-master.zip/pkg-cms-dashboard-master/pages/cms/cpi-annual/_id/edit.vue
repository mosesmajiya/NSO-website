<template>
  <editing-stage subtitle="Edit district" title="Edit District" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input :error="errors.name" :value="form.name" label="Name" name="name" @input="form.name = $event"/>
      <text-input :error="errors.code" :value="form.code" label="Code" name="name" @input="form.code = $event"/>
      <paragraph-input :error="errors.description" :value="form.description" label="Description" name="description"
                       @input="form.description = $event"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>
    </form>
  </editing-stage>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import edit_resource from "~/mixins/resource/edit_resource";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import FormActions from "../../../../components/forms/FormActions";

export default {
  name: "edit",
  components: {FormActions, ParagraphInput, TextInput, EditingStage},
  mixins: [edit_resource],
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        description: '',
        code: '',
      },
      namespace: 'districts',
      errors: []
    }
  }
}
</script>

<style scoped>

</style>
