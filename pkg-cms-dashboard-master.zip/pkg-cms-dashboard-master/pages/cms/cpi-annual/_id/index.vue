<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">Year {{ $moment(data.date).format('YYYY') }} Consumer Price Indices</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle">
          <div class="flex">
            <div class="flex mr-4">
              <svg-bar-graph class="w-5 h-5 mr-2"/>
              <p>{{ data.views }} views</p>
            </div>
            <div class="flex mr-4 items-center" v-if="data.url">
              <svg-globe class="w-5 h-5 mr-2"/>
              <p><a class="hover:text-underline" target="_blank" v-bind:href="data.url">{{ data.url }}</a></p>
            </div>
            <div class="flex mr-4">
              <svg-clock-solid class="w-5 h-5 mr-2"/>
              <p>{{ $moment(data.created_at).fromNow() }}</p>
            </div>

          </div>
        </slot>
      </h2>
    </div>

    <div class="p-8 flex flex-row">
      <div class="flex-1 content text-lg text-gray-600 font-editor">
        <div class="flex flex-wrap">
          <div class="mr-4 my-1"> Food: <span class="italic font-semibold"> {{ data.food }}</span> </div>
          <div class="mr-4 my-1"> Beverage &amp; Tobacco: <span class="italic font-bold"> {{ data.beverage_and_tobacco }}</span> </div>
          <div class="mr-4 my-1"> Clothing &amp; Footwear: <span class="italic font-bold"> {{ data.clothing_and_footwear }}</span> </div>
          <div class="mr-4 my-1"> Housing: <span class="italic font-bold"> {{ data.housing }}</span> </div>
          <div class="mr-4 my-1"> Household Operation: <span class="italic font-bold"> {{ data.household_operation }}</span> </div>
          <div class="mr-4 my-1"> Transport: <span class="italic font-bold"> {{ data.transport }}</span> </div>
          <div class="mr-4 my-1"> Miscellaneous: <span class="italic font-bold"> {{ data.miscellaneous }}</span> </div>
          <div class="mr-4 my-1"> All Items: <span class="italic font-bold"> {{ data.all_items }}</span> </div>
          <div class="mr-4 my-1"> Inflation Rate: <span class="italic font-bold"> {{ data.inflation_rate }}</span> </div>
          <div class="mr-4 my-1"> Non-food Inflation: <span class="italic font-bold"> {{ data.non_food_inflation }}</span> </div>
        </div>
      </div>
      <div class="w-1/4 ml-8">
        <div class="border">
          <h3 class="bg-gray-200 px-5 py-3">Details</h3>
          <div class="px-5 pb-3">
            <slot name="details">
              <page-details v-bind:page="data"/>
            </slot>
          </div>
        </div>
        <div class="mt-5">
          <slot name="actions">
            <div class="flex">
              <confirm-button
                @confirmed="destroy()"
                custom-class="flex-1"
                icon="delete"
                label="Delete"
                title="Confirm Deletion"
                v-bind:message="`${data.date} CPI will be permanently deleted.`"
              >
                Delete
              </confirm-button>
            </div>
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ViewStage from "../../../../components/ViewStage";
import index_resources from "~/mixins/resource/index_resources";
import SvgClockSolid from "../../../../components/icons/svg-clock-solid";
import FormButton from "../../../../components/FormButton";
import ConfirmButton from "../../../../components/ConfirmButton";
import PageDetails from "../../../../components/PageDetails";
import SvgBarGraph from "../../../../components/icons/svg-bar-graph";
import SvgGlobe from "../../../../components/icons/svg-globe";


export default {
  name: "index",
  components: {SvgGlobe, SvgBarGraph, PageDetails, ConfirmButton, FormButton, SvgClockSolid, ViewStage},
  mixins: [index_resources],
  created() {
    this.$axios.get(`/cpi/annual/${this.$route.params.id}`)
      .then(res => this.data = res.data.data)
  },
  data() {
    return {
      data: {},
      namespace: 'cpi-annual'
    }
  },
  methods: {
    destroy(){
      this.$axios.delete(`/cpi/annual/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>

<style scoped>

</style>
