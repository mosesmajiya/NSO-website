<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "projects"
  }
</script>

<style scoped>

</style>
