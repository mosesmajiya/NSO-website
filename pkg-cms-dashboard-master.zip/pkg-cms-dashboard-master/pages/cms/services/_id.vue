<template>
  <item-tabbed-details v-if="loaded" v-bind:data="data" v-bind:menu="menu" v-bind:namespace="namespace"/>
</template>

<script>

import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import index_resources from "@/mixins/resource/index_resources";

export default {
  name: "_id",
  components: {ItemTabbedDetails},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: "services",
      menu: "CMS"
    }
  }
}
</script>

