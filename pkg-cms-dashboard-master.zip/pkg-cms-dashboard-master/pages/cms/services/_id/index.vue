<template>
  <view-stage :title="data.name" @onDelete="onDelete" @onTogglePublish="togglePublish" heading-column="name"
              v-bind:data="data">
    <div v-html="data.content"></div>
  </view-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";
import index_resources from "@/mixins/resource/index_resources";

export default {
  name: "index",
  components: {ViewStage},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'services'
    }
  },
  methods: {
    onDelete() {
      this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
