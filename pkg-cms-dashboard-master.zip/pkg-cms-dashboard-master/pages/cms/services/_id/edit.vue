<template>
  <editing-stage subtitle="Edit service" title="Edit Service" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                  v-on:input="form.name = $event"></text-input>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>

    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";
import FormLink from "../../../../components/forms/FormLink";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {EditingStage, FormActions, FormLink, FormButton, LinkButton, ParagraphInput, TextInput, FormSubmit},
  mixins: [edit_resource],
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        content: '',
      },
      namespace: 'services',
      errors: []
    }
  }
}
</script>

