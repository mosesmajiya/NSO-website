<template>
  <metadata-edit :namespace="namespace" v-bind:data="data" v-bind:form="form" v-bind:namespace-id="namespaceId"/>
</template>

<script>

import MetadataEdit from "../../../../components/forms/MetadataEdit";
import resource_metadata from "@/mixins/resource/resource_metadata";

export default {
  name: "metadata",
  components: {MetadataEdit},
  mixins: [resource_metadata],
  data() {
    return {
      form: {
        description: '',
        keywords: '',
      },
      data: {},
      namespace: 'services',
      namespaceId: 'id'
    }
  }
}
</script>
