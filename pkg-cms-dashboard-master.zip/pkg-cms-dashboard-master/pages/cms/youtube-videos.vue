<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "youtube-videos"
  }
</script>
