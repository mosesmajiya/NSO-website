<template>
  <div>
    <contextual-menu menu="CMS" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-arrow-left class="h-6 w-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex items-center" exact>
        <svg-list class="mr-2 h-6 w-6"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex items-center">
        <svg-pencil-alt class="mr-2 h-6 w-6"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/media`" class="flex items-center">
        <svg-camera class="mr-2 h-6 w-6"/>
        Media
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>

</template>

<script>
import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import index_resources from "@/mixins/resource/index_resources";
import ContextualMenu from "@/components/ContextualMenu";
import TabItem from "@/components/tabItem";
import FaIcon from "@/components/FaIcon";
import SvgArrowLeft from "@/components/icons/svg-arrow-left";
import SvgList from "@/components/icons/svg-list";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";
import SvgCamera from "@/components/icons/svg-camera";

export default {
  name: "_id",
  components: {SvgCamera, SvgPencilAlt, SvgList, SvgArrowLeft, FaIcon, TabItem, ContextualMenu, ItemTabbedDetails},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'private-downloads'
    }
  }
}
</script>
