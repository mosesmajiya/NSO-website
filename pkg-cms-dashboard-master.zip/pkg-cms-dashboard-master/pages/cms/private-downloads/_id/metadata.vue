<template>
  <metadata-stage title="Metadata">
    <template v-slot:subtitle>
      Edit page metadata
    </template>
    <form @submit.prevent="onSubmit">
      <text-input
        label="Keywords"
        name="keywords"
        v-bind:error="errors.keywords"
        v-bind:value="form.keywords"
        v-on:input="form.keywords = $event"
      />
      <form-group label="Description">
        <textarea
          v-model="form.description"
          class="px-4 py-2 w-full block border border-gray-300 focus:outline-none focus:border-gray-400 rounded ">
        </textarea>
        <p class="text-red-500 text-sm">{{ errors.description }}</p>

      </form-group>
      <form-button type="submit">Update</form-button>
    </form>
    <template v-if="about" v-slot:details>
      <page-details v-if="about" v-bind:page="about"/>
    </template>
  </metadata-stage>
</template>

<script>
import MetadataStage from "../../../../components/MetadataStage";
import PageDetails from "../../../../components/PageDetails";
import FormButton from "../../../../components/FormButton";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import resource_metadata from "@/mixins/resource/resource_metadata";

export default {
  name: "metadata",
  components: {FormGroup, TextInput, FormButton, PageDetails, MetadataStage},
  mixins: [resource_metadata],
  data() {
    return {
      data: {},
      namespace: 'private-downloads',
      form: {
        description: '',
        keywords: ''
      },
      errors: {}
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`abouts/${this.$route.params.id}/metadata`, this.form)
        .then(() => this.$router.go())
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
