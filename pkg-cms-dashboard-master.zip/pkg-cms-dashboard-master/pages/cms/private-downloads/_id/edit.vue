<template>
  <div>
    <editing-stage :title="data.name">
      <template v-slot:subtitle>
        Edit an about page
      </template>

      <form @submit.prevent="onSubmit">
        <text-input
          label="Name"
          name="name"
          v-bind:error="errors.name"
          v-bind:value="form.name"
          v-on:input="form.name = $event"
        />

        <div class="pb-4">
          <p class="pb-2">
            Roles
            <span class="block text-sm text-red-500">{{ errors.roles }}</span>
          </p>
          <label v-for="(option, index) in roleOptions" :key="index" class="flex items-center">
            <input :checked="hasRole(option.id)" :name="option.id" type="checkbox"
                   @change="syncRoles($event.target.name)">
            <span class="pl-2">{{ option.name }}</span>
          </label>
        </div>

        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>

      <template v-slot:details>
        <page-details :page="data"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import FormButton from "../../../../components/FormButton";
import EditingStage from "../../../../components/EditingStage";
import SideInfoItem from "../../../../components/SideInfoItem";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import ParagraphInput from "@/components/forms/ParagraphInput";

export default {
  name: "edit",
  components: {ParagraphInput, FormGroup, TextInput, PageDetails, SideInfoItem, EditingStage, FormButton},
  async created() {
    if (process.browser) {
      this.roles = (await this.$axios.get('roles/portal')).data.data
      if (this.namespace) {
        let response = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data;
        this.form.name = response.name
        this.form.roles = response.roles.map(role => role.id)
        this.data = response
      }
    }
  },
  data() {
    return {
      form: {
        name: '',
        roles: [],
      },
      data: {},
      namespace: 'private-downloads',
      recent: [],
      roles: [],
      errors: {},
    }
  },
  computed: {
    roleOptions() {
      return this.roles.map(function (role) {
        return {
          id: role.id,
          name: role.name
        }
      })
    }
  },
  methods: {
    hasRole(role) {
      return this.form.roles.includes(parseInt(role))
    },
    syncRoles(role) {
      if (this.hasRole(role)) {
        this.form.roles.splice(this.form.roles.indexOf(parseInt(role)), 1)
      } else {
        this.form.roles.push(parseInt(role))
      }
    },
    onSubmit() {
      this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
