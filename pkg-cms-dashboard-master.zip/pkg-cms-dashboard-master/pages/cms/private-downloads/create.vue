<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage title="New Download Category">
      <template v-slot:subtitle>
        Create a download category
      </template>
      <form @submit.prevent="onSubmit">
        <text-input
          label="Name"
          name="name"
          v-bind:error="errors.name"
          v-bind:value="form.name"
          v-on:input="form.name = $event"
        />

        <div class="pb-4">
          <p class="pb-2">
            Allowed User Groups
            <span class="block text-sm text-red-500">{{ errors.roles }}</span>
          </p>
          <label v-for="(option, index) in roleOptions" :key="index" class="flex items-center">
            <input :checked="hasRole(option.id)" :name="option.id" type="checkbox"
                   @change="syncRoles($event.target.name)">
            <span class="pl-2">{{ option.name }}</span>
          </label>
        </div>

        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-if="recent.length" v-slot:recent>
        <div v-for="item in recent" v-if="recent" class="text-sm pt-4">
          <p class="text-gray-500">{{ $moment(item.created_at).fromNow() }}</p>
          <nuxt-link :to="`/cms/${namespace}/${item.id}`" class="hover:text-gray-600">{{ item.category }}</nuxt-link>
        </div>
      </template>

    </creation-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Alert from "../../../components/Alert";
import FormButton from "../../../components/FormButton";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormGroup from "../../../components/forms/FormGroup";
import NavigateBack from "../../../components/NavigateBack";
import ParagraphInput from "@/components/forms/ParagraphInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    ParagraphInput,
    NavigateBack,
    FormGroup,
    TextInput, CreationStage, FormButton, Alert, LinkButton, ContextualMenu
  },
  async created() {
    if (process.browser) {
      this.roles = (await this.$axios.get('roles/portal')).data.data
    }
  },
  mixins: [create_resource],
  data() {
    return {
      form: {
        name: '',
        roles: []
      },
      namespace: 'private-downloads',
      recent: [],
      roles: [],
      errors: {},
      editorOption: {
        theme: 'snow',
        modules: {}
      }
    }
  },
  computed: {
    roleOptions() {
      return this.roles.map(function (role) {
        return {
          id: role.id,
          name: role.name
        }
      })
    }
  },
  methods: {
    hasRole(role) {
      return this.form.roles.includes(role)
    },
    syncRoles(role) {
      if (this.hasRole(role)) {
        this.form.roles.splice(this.form.roles.indexOf(role), 1)
      } else {
        this.form.roles.push(role)
      }
    },
    onSubmit() {
      this.$axios.post(this.namespace, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
