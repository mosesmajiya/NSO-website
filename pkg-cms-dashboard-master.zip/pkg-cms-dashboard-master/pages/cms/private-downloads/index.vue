<template>
  <div>
    <contextual-menu>
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New Download Category
      </link-button>
    </contextual-menu>
    <index-stage fields="category,content" table="abouts" @cancel="$router.go()" @loadeddata="data = $event">
      <div class="w-full">
        <nuxt-link v-for="about in data.data" :key="about.id"
                   :to="`/cms/${namespace}/${about.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block">
          <div class="leading-loose">{{ about.name }}</div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(about.created_at).fromNow() }}
              </div>
            </div>
            <svg-published :on="about.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination v-if="data.from" v-bind:paginator="data" @loadeddata="data = $event"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Stage from "../../../components/Stage";
import IndexStage from "../../../components/IndexStage";
import FaIcon from "../../../components/FaIcon";
import Pagination from "../../../components/Pagination";
import global_index from "@/mixins/resource/global_index";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index",
  components: {SvgPublished, SvgClockSolid, Pagination, FaIcon, IndexStage, Stage, LinkButton, ContextualMenu},
  mixins: [global_index],
  data() {
    return {
      data: {},
      menu: "CMS",
      namespace: 'private-downloads',
    }
  }
}
</script>
