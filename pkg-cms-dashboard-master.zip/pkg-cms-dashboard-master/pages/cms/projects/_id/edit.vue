<template>
  <editing-stage subtitle="Edit project" title="Edit Project" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                  v-on:input="form.title = $event"></text-input>

      <div class="md:flex">
        <text-input class="md:mr-4 w-full" label="Type" name="type" type="text"
                    v-bind:error="errors.type" v-bind:value="form.type"
                    v-on:input="form.type = $event"/>

        <text-input class="w-full" label="Ministry" name="ministry" type="text"
                    v-bind:error="errors.ministry" v-bind:value="form.ministry" v-on:input="form.ministry = $event"/>
      </div>

      <div class="md:flex">
        <text-input class="md:mr-4 w-full" label="Sector" name="sector" type="text"
                    v-bind:error="errors.sector" v-bind:value="form.sector"
                    v-on:input="form.sector = $event"/>

        <text-input class="w-full" label="Advisor" name="advisor" type="text"
                    v-bind:error="errors.advisor" v-bind:value="form.advisor" v-on:input="form.advisor = $event"/>
      </div>

      <div class="md:flex">
        <text-input class="md:mr-4 w-full" label="Start date" name="start_date" type="date"
                    v-bind:error="errors.start_date" v-bind:value="form.start_date"
                    v-on:input="form.start_date = $event"/>

        <text-input class="w-full" label="End date" name="end_date" type="date"
                    v-bind:error="errors.end_date" v-bind:value="form.end_date" v-on:input="form.end_date = $event"/>
      </div>

      <text-input @input="form.url = $event" label="Website URL" name="url" v-bind:error="errors.url"
                  v-bind:value="form.url"/>

      <div class="md:flex">
        <dropdown-input :error="errors.project_stage_id" :options="stages" :value="form.project_stage_id"
                        class="md:mr-4 w-full"
                        label="Project Stage" name="project_stage_id" @change="form.project_stage_id = $event"/>
        <dropdown-input class="w-full" label="Project Category" name="category" v-bind:error="errors.category"
                        v-bind:options="options"
                        v-bind:value="form.category" @change="form.category = $event"/>
      </div>

      <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                       v-bind:value="form.content"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>

    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";
import FormLink from "../../../../components/forms/FormLink";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";
import DropdownInput from "@/components/forms/DropdownInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {
    DropdownInput,
    EditingStage, FormActions, FormLink, FormButton, LinkButton, ParagraphInput, TextInput, FormSubmit
  },
  mixins: [edit_resource],
  async created() {
    if (!process.browser) return
    this.$axios.get('/project-stages').then(res => this.stages = res.data.data.map(stage => {
      return {value: stage.id, label: stage.name}
    }))
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.$stripFields(this.form))
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        type: '',
        ministry: '',
        sector: '',
        url: '',
        advisor: '',
        project_stage_id: '',
        content: '',
        start_date: '',
        end_date: '',
        category: ''
      },
      namespace: 'projects',
      errors: [],
      stages: [],
      options: [
        {label: 'Normal', value: 'normal'},
        {label: 'Private', value: 'private'},
      ]
    }
  }
}
</script>

