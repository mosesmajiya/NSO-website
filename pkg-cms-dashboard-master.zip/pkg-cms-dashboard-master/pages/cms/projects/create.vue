<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a project" title="New Project"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                    v-on:input="form.name = $event"/>

        <div class="md:flex">
          <text-input class="md:mr-4 w-full" label="Type" name="type" type="text"
                      v-bind:error="errors.type" v-bind:value="form.type"
                      v-on:input="form.type = $event"/>

          <text-input class="w-full" label="Ministry" name="ministry" type="text"
                      v-bind:error="errors.ministry" v-bind:value="form.ministry" v-on:input="form.ministry = $event"/>
        </div>

        <div class="md:flex">
          <text-input class="md:mr-4 w-full" label="Sector" name="sector" type="text"
                      v-bind:error="errors.sector" v-bind:value="form.sector"
                      v-on:input="form.sector = $event"/>

          <text-input class="w-full" label="Advisor" name="advisor" type="text"
                      v-bind:error="errors.advisor" v-bind:value="form.advisor" v-on:input="form.advisor = $event"/>
        </div>

        <div class="md:flex">
          <text-input class="md:mr-4 w-full" label="Start date" name="start_date" type="date"
                      v-bind:error="errors.start_date" v-bind:value="form.start_date"
                      v-on:input="form.start_date = $event"/>

          <text-input class="w-full" label="End date" name="end_date" type="date"
                      v-bind:error="errors.end_date" v-bind:value="form.end_date" v-on:input="form.end_date = $event"/>
        </div>

        <text-input @input="form.url = $event" label="Website URL" name="url" v-bind:error="errors.url"
                    v-bind:value="form.url"/>

        <div class="md:flex">
          <dropdown-input :error="errors.project_stage_id" :options="stages" :value="form.project_stage_id"
                          class="md:mr-4 w-full"
                          label="Project Stage" name="project_stage_id" @change="form.project_stage_id = $event"/>
          <dropdown-input class="w-full" label="Project Category" name="category" v-bind:error="errors.category"
                          v-bind:options="options"
                          v-bind:value="form.category" @change="form.category = $event"/>
        </div>

        <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                         v-bind:value="form.content"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "@/components/forms/DropdownInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  mixins: [create_resource],
  created() {
    if (!process.browser) return
    this.$axios.get('/project-stages').then(res => this.stages = res.data.data.map(stage => {
      return {value: stage.id, label: stage.name}
    }))
  },
  data() {
    return {
      form: {
        name: '',
        content: '',
        type: '',
        ministry: '',
        sector: '',
        advisor: '',
        start_date: '',
        end_date: '',
        project_stage_id: '',
        url: '',
        category: ''
      },
      namespace: 'projects',
      recent: [],
      errors: [],
      stages: [],
      options: [
        {label: 'Normal', value: 'normal'},
        {label: 'Private', value: 'private'},
      ]
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`/${this.namespace}`, this.$stripFields(this.form))
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
