<template>
  <nuxt-child/>
</template>

<script>
export default {
  name: "districts"
}
</script>

<style scoped>

</style>
