<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "vacancies"
  }
</script>

<style scoped>

</style>
