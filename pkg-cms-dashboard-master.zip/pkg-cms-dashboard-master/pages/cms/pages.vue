<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "pages"
  }
</script>
