<template>
  <div>
    <navigate-back to="/cms/about"/>
    <creation-stage title="New Page">
      <template v-slot:subtitle>
        Create an about page
      </template>
      <form @submit.prevent="onSubmit">
        <text-input
          label="Category"
          name="category"
          v-bind:error="errors.category"
          v-bind:value="form.category"
          v-on:input="form.category = $event"
        />

        <div class="md:flex">
          <text-input
            @input="form.icon = $event"
            label="Icon "
            name="icon"
            v-bind:error="errors.icon"
            v-bind:value="form.icon"
            class="md:mr-4 w-full"
          >
            <a href="https://material.io/resources/icons/?style=outline" target="_blank"
               class="text-gray-600 text-sm mt-3 py-2 px-4 border rounded inline-block">Available Icons</a>
          </text-input>

          <text-input
            @input="form.rank = $event"
            label="Rank"
            name="rank"
            v-bind:error="errors.rank"
            v-bind:value="form.rank"
            class="w-full"
          />
        </div>

        <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                         v-bind:value="form.content" v-on:input="form.content = $event"/>


        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-if="recent.length" v-slot:recent>
        <div class="text-sm pt-4" v-for="item in recent" v-if="recent">
          <p class="text-gray-500">{{ $moment(item.created_at).fromNow() }}</p>
          <nuxt-link :to="`/cms/about/${item.id}`" class="hover:text-gray-600">{{ item.category }}</nuxt-link>
        </div>
      </template>

    </creation-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Alert from "../../../components/Alert";
import FormButton from "../../../components/FormButton";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormGroup from "../../../components/forms/FormGroup";
import NavigateBack from "../../../components/NavigateBack";
import ParagraphInput from "@/components/forms/ParagraphInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    ParagraphInput,
    NavigateBack,
    FormGroup,
    TextInput, CreationStage, FormButton, Alert, LinkButton, ContextualMenu
  },
  mixins: [create_resource],
  data() {
    return {
      form: {
        category: '',
        content: '',
        icon: '',
        rank: ''
      },
      namespace: 'abouts',
      recent: [],
      errors: {},
      editorOption: {
        theme: 'snow',
        modules: {}
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post('abouts', this.form)
        .then(() => this.$router.push('/cms/about'))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
