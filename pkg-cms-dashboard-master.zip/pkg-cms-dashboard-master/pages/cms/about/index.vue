<template>
  <div>
    <contextual-menu>
      <link-button accent="primary" icon="playlist_add" to="/cms/about/create">New About Page</link-button>
    </contextual-menu>
    <index-stage @cancel="$router.go()" @loadeddata="data = $event" fields="category,content" table="abouts">
      <div class="w-full">
        <nuxt-link :to="`/cms/about/${about.id}`" class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block"
                   :key="about.id" v-for="about in data.data">
          <div class="leading-loose">{{ about.category }}</div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(about.created_at).fromNow() }}
              </div>
              <div class="mr-4 flex items-center">
                <svg-eye/>
                {{ about.views }} views
              </div>
            </div>
            <svg-published :on="about.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination @loadeddata="data = $event" v-bind:paginator="data" v-if="data.from"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Stage from "../../../components/Stage";
import IndexStage from "../../../components/IndexStage";
import FaIcon from "../../../components/FaIcon";
import Pagination from "../../../components/Pagination";
import global_index from "@/mixins/resource/global_index";
import SvgClock from "@/components/icons/svg-clock";
import SvgBarGraph from "@/components/icons/svg-bar-graph";
import SvgClockSolid from "@/components/icons/svg-clock-solid";
import SvgEye from "@/components/icons/svg-eye";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index",
  components: {
    SvgPublished,
    SvgEye,
    SvgClockSolid, SvgBarGraph, SvgClock, Pagination, FaIcon, IndexStage, Stage, LinkButton, ContextualMenu
  },
  mixins: [global_index],
  data() {
    return {
      data: {},
      menu: "CMS",
      namespace: 'abouts',
    }
  }
}
</script>
