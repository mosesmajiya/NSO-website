<template>
  <item-tabbed-details v-if="loaded" namespace="about" v-bind:data="data"/>
</template>

<script>
import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import index_resources from "@/mixins/resource/index_resources";

export default {
  name: "_id",
  components: {ItemTabbedDetails},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'abouts'
    }
  }
}
</script>
