<template>
  <media-editing-stage :namespace="namespace" v-bind:form="form" v-bind:media="media" v-bind:url="url"/>
</template>

<script>
import EditingStage from "~/components/EditingStage";
import PageDetails from "~/components/PageDetails";
import FormButton from "~/components/FormButton";
import TextInput from "~/components/forms/TextInput";
import MediaEditingStage from "~/components/MediaEditingStage";
import media_id from "@/mixins/media/media_id";

export default {
  name: "_media_id",
  components: {MediaEditingStage, TextInput, FormButton, PageDetails, EditingStage},
  mixins: [media_id],
  data() {
    return {
      form: {
        caption: ''
      },
      url: '',
      namespace: 'about',
      media: {},
      menu: "CMS",
      errors: []
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`media/${this.$route.params.media_id}`, this.form)
        .then(() => this.$router.push(`/cms/about/${this.$route.params.id}/media`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
