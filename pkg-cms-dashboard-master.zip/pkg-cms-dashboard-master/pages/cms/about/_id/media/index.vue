<template>
  <div>
    <editing-stage title="Page Media">
      <template v-slot:subtitle>Upload page media</template>
      <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">
        <text-input
          label="Caption"
          name="caption"
          v-bind:error="errors.caption"
          v-bind:value="form.caption"
          v-on:input="form.caption = $event"
        />

        <div class="flex mb-5">
          <dropdown-input
            class="md:w-1/2 md:mr-4"
            label="Type"
            name="type"
            v-bind:error="errors.type"
            v-bind:options="[
            {value: 'banner', label: 'Banner'},
            {value: 'attachment', label: 'Attachment'},
          ]"
            v-bind:value="form.type"
            v-on:change="form.type = $event"
          />

          <file-input class="md:w-1/2" id="file" label="File" v-bind:error="errors.file" v-model="form.file"/>
        </div>

        <form-button type="submit">Upload File</form-button>
      </form>

      <nuxt/>
      <div class="mt-8 flex flex-wrap items-stretch" v-if="banners.length && about">
        <image-card
          :caption="i.caption"
          :remark="$moment(i.created_at).fromNow()"
          :source="i.url"
          :to="`/cms/about/${about.id}/media/${i.id}`"
          custom-class="w-1/3"
          v-bind:id="i.id"
          v-bind:key="i.id"
          v-for="i in banners"
          v-if="banners"
          v-on:deleted="$router.go()"
        />
      </div>

      <div class="mt-8 flex flex-wrap items-stretch border-t pt-8" v-if="attachments.length">
        <attachment-card
          :filename="i.caption"
          :remark="$moment(i.created_at).fromNow()"
          :to="i.download"
          v-bind:id="i.id"
          custom-class="w-1/3"
          link-icon="download"
          v-bind:key="i.id"
          v-for="i in attachments"
          v-on:deleted="$router.go()"
        />
      </div>
      <template v-if="about" v-slot:details>
        <page-details v-bind:page="about"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import EditingStage from "../../../../../components/EditingStage";
import PageDetails from "../../../../../components/PageDetails";
import ImageCard from "../../../../../components/ImageCard";
import AttachmentCard from "../../../../../components/AttachmentCard";
import TextInput from "../../../../../components/forms/TextInput";
import FormButton from "../../../../../components/FormButton";
import DropdownInput from "../../../../../components/forms/DropdownInput";
import FileInput from "../../../../../components/forms/FileInput";
import media_index from "@/mixins/media/media_index";

export default {
  name: "index",
  components: {
    FileInput,
    DropdownInput,
    FormButton,
    TextInput,
    AttachmentCard,
    ImageCard,
    PageDetails,
    EditingStage,
  },
  mixins: [media_index],
  data() {
    return {
      form: {
        file: '',
        caption: '',
        type: ''
      },
      namespace: 'abouts',
      about: null,
      errors: [],
      banners: [],
      attachments: [],
    }
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      let type = this.form.type ? this.form.type : 'banner'
      formData.append('file', this.form.file)
      formData.append('type', this.form.type)
      formData.append('caption', this.form.caption)

      this.$axios.post(`/abouts/${this.$route.params.id}/attach/${type}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>

