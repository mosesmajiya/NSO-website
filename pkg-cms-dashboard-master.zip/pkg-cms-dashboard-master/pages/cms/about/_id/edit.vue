<template>
  <div>
    <editing-stage title="Edit Page">
      <template v-slot:subtitle>
        Edit an about page
      </template>

      <form @submit.prevent="onSubmit">

        <text-input
          label="Category"
          name="category"
          v-bind:error="errors.category"
          v-bind:value="form.category"
          v-on:input="form.category = $event"
        />

        <div class="md:flex">
          <text-input
            label="Icon"
            name="icon"
            v-bind:error="errors.icon"
            v-bind:value="form.icon"
            v-on:input="form.icon = $event"
            class="md:mr-4 w-full"
          >
            <a href="https://material.io/resources/icons/?style=outline" target="_blank"
               class="text-gray-600 text-sm mt-3 py-2 px-4 border rounded inline-block">Available Icons</a>
          </text-input>

          <text-input
            label="Rank"
            name="rank"
            v-bind:error="errors.rank"
            v-bind:value="form.rank"
            v-on:input="form.rank = $event"
            class="w-full"
          />
        </div>

        <paragraph-input label="Content" name="content" v-bind:error="errors.content"
                         v-bind:value="form.content" v-on:input="form.content = $event"/>


        <div class="pb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-slot:details>
        <page-details :page="data"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import FormButton from "../../../../components/FormButton";
import EditingStage from "../../../../components/EditingStage";
import SideInfoItem from "../../../../components/SideInfoItem";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import ParagraphInput from "@/components/forms/ParagraphInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {ParagraphInput, FormGroup, TextInput, PageDetails, SideInfoItem, EditingStage, FormButton},
  mixins: [edit_resource],
  data() {
    return {
      form: {
        category: '',
        content: '',
        rank: ''
      },
      data: {},
      namespace: 'abouts',
      recent: [],
      errors: {},
      editorOption: {
        theme: 'snow',
        modules: {}
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`abouts/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/about/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
