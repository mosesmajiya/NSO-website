<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "photo-galleries"
  }
</script>

<style scoped>

</style>
