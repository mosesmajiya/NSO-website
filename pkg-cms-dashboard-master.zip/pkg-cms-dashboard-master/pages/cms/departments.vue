<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "departments"
  }
</script>
