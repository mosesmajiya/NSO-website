<template>
  <div v-if="data">
    <p class="font-bold text-gray-500">Name</p>
    <h1 class="pb-4">{{ data.name }}</h1>

    <p class="font-bold text-gray-500">Position</p>
    <div class="pb-4" v-html="data.position.name" v-if="data.position"></div>

    <div class="pb-4" v-if="data.email">
      <p class="font-bold text-gray-500">Email</p>
      <div v-html="data.email"></div>
    </div>

    <div class="pb-4" v-if="data.phone_number">
      <p class="font-bold text-gray-500">Phone Number</p>
      <div v-html="data.phone_number"></div>
    </div>

    <div class="pb-4">
      <p class="font-bold text-gray-500">Status</p>
      <div v-html="currentStaff()"></div>
    </div>

    <div class="pb-4" v-if="data.profile">
      <p class="font-bold text-gray-500">Profile</p>
      <div class="font-editor mt-5" v-html="data.profile"></div>
    </div>



    <div class="flex mt-8">
      <form-button
        :fa-icon="data.published_at ? 'unlink' : 'link'"
        @click="togglePublish"
        custom-class="mr-2">
        {{ data.published_at ? 'Unpublish' : 'Publish' }}
      </form-button>
      <confirm-button
        @confirmed="destroy"
        custom-class="flex"
        icon="delete"
        label="Delete"
        title="Confirm Deletion"
        v-bind:message="`${data[headingColumn]} will be permanently deleted.`"
      >
        Delete
      </confirm-button>
    </div>
  </div>
</template>

<script>
import FormButton from "../../../../../../../components/FormButton";
import ConfirmButton from "../../../../../../../components/ConfirmButton";

export default {
  name: "index",
  components: {ConfirmButton, FormButton},
  created() {
    this.$store.dispatch('staff/FETCH_ONE', this.$route.params.staff_id)
  },
  data() {
    return {
      headingColumn: 'question',
      collective: 'staff',
    }
  },
  computed: {
    data() {
      return this.$store.getters['staff/MEMBER']
    },
    collectiveId() {
      return this.$route.params.staff_id
    },
  },
  methods: {
    currentStaff() {
      if(this.data.current===1){
        return 'Current Staff'
      } else return 'Former Staff'
    },
    togglePublish() {
      if (this.data.published_at) {
        this.unpublish()
      } else {
        this.publish()
      }
    },
    publish() {
      this.$axios.post(`${this.collective}/${this.collectiveId}/publish`)
        .then(() => this.$router.go())
    },
    unpublish() {
      this.$axios.delete(`${this.collective}/${this.collectiveId}/unpublish`)
        .then(() => this.$router.go())
    },
    destroy() {
      this.$axios.delete(`${this.collective}/${this.collectiveId}`)
        .then(() => this.$router.push(`/cms/faqCategories/${this.$route.params.id}`))
    }
  }
}
</script>
