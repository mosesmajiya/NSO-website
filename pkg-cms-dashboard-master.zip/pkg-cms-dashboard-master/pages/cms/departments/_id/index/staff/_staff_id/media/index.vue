<template>
  <div>
    <media-upload image-type="Profile Picture" v-bind:namespace="namespace" v-bind:url-param="urlParam"/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:category="category"
                v-bind:data="data" v-bind:namespace="namespace"/>
  </div>
</template>

<script>
import FormSubmit from "../../../../../../../../components/forms/FormSubmit";
import TextInput from "../../../../../../../../components/forms/TextInput";
import MediaUpload from "../../../../../../../../components/forms/MediaUpload";
import MediaList from "../../../../../../../../components/MediaList";

export default {
  name: "media",
  components: {MediaList, MediaUpload, TextInput, FormSubmit},
  created() {
    if (!process.browser) return
    if (this.namespace) {
      this.$axios.get(`${this.namespace}/${this.$route.params.staff_id}/media/banner`)
        .then(res => this.banners = res.data.data)
      this.$axios.get(`${this.namespace}/${this.$route.params.staff_id}`)
        .then(res => this.about = res.data.data)
      this.$axios.get(`${this.namespace}/${this.$route.params.staff_id}/media/attachment`)
        .then(res => this.attachments = res.data.data)
    }
  },
  data() {
    return {
      form: {
        caption: '',
        type: '',
        file: ''
      },
      errors: [],
      namespace: 'staff',
      category: 'departments',
      urlParam: 'staff_id',
      attachments: [],
      banners: [],
      data: {}
    }
  }
}
</script>

