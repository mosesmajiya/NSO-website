<template>
  <metadata-edit :namespace="namespace" :namespace-id="namespaceId" v-bind:data="data" v-bind:form="form"/>
</template>

<script>


import MetadataEdit from "../../../../../../../components/forms/MetadataEdit";
import resource_metadata from "@/mixins/resource/resource_metadata";

export default {
  name: "metadata",
  components: {MetadataEdit},
  mixins: [resource_metadata],
  data() {
    return {
      form: {
        description: '',
        keywords: '',
      },
      data: {},
      namespace: 'staff',
      namespaceId: 'staff_id',
    }
  }
}
</script>
