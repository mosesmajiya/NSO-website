<template>
  <form @submit.prevent="onSubmit">
    <div class="md:flex">
      <text-input class="md:flex-1 md:mr-4" label="Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name" v-on:input="form.name = $event"/>

      <dropdown-input @change="form.position_id = $event" class="md:flex-1" label="Position" name="position_id"
                      v-bind:error="errors.position_id" v-bind:options="positions" v-bind:value="form.position_id"/>
    </div>

    <div class="md:flex">
      <text-input class="md:flex-1 md:mr-4" label="Email address" name="email" v-bind:error="errors.email"
                  v-bind:value="form.email" v-on:input="form.email = $event"/>

      <text-input class="md:flex-1" label="Phone Number" name="phone_number" v-bind:error="errors.phone_number"
                  v-bind:value="form.phone_number" v-on:input="form.phone_number = $event"/>
    </div>

    <div class="md:flex">
      <dropdown-input @change="form.current = $event" label="Current Staff?" name="current" v-bind:error="errors.current"
                      v-bind:options="options" v-bind:value="form.current"/>
    </div>

    <paragraph-input label="Profile" name="profile" v-bind:error="errors.profile"
                     v-bind:value="form.profile" v-on:input="form.profile = $event"/>

    <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}/${collective}/${collectiveId}`"/>
  </form>
</template>

<script>
import FormActions from "../../../../../../../components/forms/FormActions";
import TextInput from "../../../../../../../components/forms/TextInput";
import ParagraphInput from "../../../../../../../components/forms/ParagraphInput";
import DropdownInput from "../../../../../../../components/forms/DropdownInput";

export default {
  name: "edit",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions},
  async created() {
    await this.$store.dispatch('positions/FETCH_POSITIONS', this.$route.params.id)
    if (!process.browser) return
    if (this.namespace) {
      let response = (await this.$axios.get(`staff/${this.$route.params.staff_id}`)).data.data;
      this.form = response
      this.data = response
    }
  },
  data() {
    return {
      errors: [],
      options:  [{label: 'Yes', value: '1'}, {label: 'No, Former Staff', value: '0'}],
      namespace: 'departments',
      collective: 'staff',
      form: {
        name: '',
        department_id: this.$route.params.id,
        profile: '',
        phone_number: '',
        email: '',
        position_id: '',
        current:''
      },
    }
  },
  computed: {
    collectiveId() {
      return this.$route.params.staff_id
    },
    positions() {
      return this.$store.getters['positions/GET_POSITIONS'].map((position) => {
        return {label: position.name, value: position.id}
      })
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.collective}/${this.collectiveId}`, this.getFormData())
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}/${this.collective}/${this.collectiveId}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    getFormData() {
      let form = new FormData();
      for (let field in this.form) {
        form.append(field, this.form[field])
      }

      let object = {};
      form.forEach((value, key) => {
        object[key] = value
      });
      return object
    }
  }
}
</script>
