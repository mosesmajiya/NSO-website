<template>
  <edit-category sub-title="Change department details" title="Edit Department" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input @input="form.name = $event" label="FAQ Category Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>

      <div class="md:flex">
        <text-input
          @input="form.icon = $event"
          label="Icon "
          name="icon"
          v-bind:error="errors.icon"
          v-bind:value="form.icon"
          class="md:mr-4 w-full"
        >
          <a href="https://material.io/resources/icons/?style=outline" target="_blank"
             class="text-gray-600 text-sm mt-3 py-2 px-4 border rounded inline-block">Available Icons</a>
        </text-input>

        <text-input
          @input="form.rank = $event"
          label="Rank"
          name="rank"
          v-bind:error="errors.rank"
          v-bind:value="form.rank"
          class="w-full"
        />
      </div>

      <paragraph-input label="Description" name="description" v-bind:error="errors.description"
                       v-bind:value="form.description" v-on:input="form.description = $event"/>

      <form-actions v-bind:to="`/cms/${namespace}/${$route.params.id}`">Update</form-actions>
    </form>
  </edit-category>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import PageDetails from "../../../../components/PageDetails";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import EditCategory from "../../../../components/EditCategory";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {EditCategory, ParagraphInput, PageDetails, TextInput, FormActions, EditingStage},
  mixins: [edit_resource],
  data() {
    return {
      data: {},
      form: {
        name: '',
        description: '',
        rank: '',
      },
      errors: [],
      namespace: 'departments'
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
