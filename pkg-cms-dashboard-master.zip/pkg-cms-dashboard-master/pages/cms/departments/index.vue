<template>
  <div>
    <contextual-menu :menu="menu" :namespace="namespace">
      <link-button :to="`/cms/${category}/create`" accent="primary" icon="add">New Department</link-button>
    </contextual-menu>
    <index-stage @cancel="$router.go()" @loadeddata="data = $event" fields="name,description" table="departments">
      <div class="w-full">
        <nuxt-link :key="item.id" :to="`/cms/${category}/${item.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block" v-for="item in data.data">
          <div class="leading-loose">
            {{ item[headingColumn] }}
          </div>
          <div class="text-sm flex">
            <div class="flex-grow flex text-gray-600">
              <div class="mr-4">
                <fa-icon class="mr-2 hidden" icon="question-circle"/>
                <span class="bg-gray-300 text-xs px-2 py-1 rounded-full font-bold">{{ item[counterColumn]}}</span>
                <span class="">{{ itemsLabel }}</span>
              </div>
              <div class="mr-4">

              </div>
            </div>
          </div>
        </nuxt-link>
      </div>
      <pagination @loadeddata="data = $event" v-bind:paginator="data" v-if="data.from"/>
    </index-stage>
  </div>
</template>

<script>
import FaIcon from "~/components/FaIcon";
import Pagination from "~/components/Pagination";
import IndexStage from "../../../components/IndexStage";
import NavigateLink from "../../../components/NavigateLink";
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";

export default {
  name: "index",
  components: {LinkButton, ContextualMenu, NavigateLink, IndexStage, Pagination, FaIcon},
  created() {
    if (!process.browser) return
    this.$axios.get('departments').then(res => this.data = res.data.data)
  },
  data() {
    return {
      data: {},
      headingColumn: 'name',
        counterColumn: 'staff_count',
        namespace: 'people',
        category: 'departments',
        itemsLabel: 'People',
        menu: 'CMS'
      }
    }
  }
</script>
