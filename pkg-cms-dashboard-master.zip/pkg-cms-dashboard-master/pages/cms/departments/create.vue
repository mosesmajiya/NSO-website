<template>
  <div>
    <create-category sub-title="Create a department" title="Departments" v-bind:category="category">
      <form @submit.prevent="onSubmit">
        <text-input label="Department Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name" v-on:input="form.name = $event"/>

        <div class="md:flex">
          <text-input
            @input="form.icon = $event"
            label="Icon "
            name="icon"
            v-bind:error="errors.icon"
            v-bind:value="form.icon"
            class="md:mr-4 w-full"
          >
            <a href="https://material.io/resources/icons/?style=outline" target="_blank"
               class="text-gray-600 text-sm mt-3 py-2 px-4 border rounded inline-block">Available Icons</a>
          </text-input>

          <text-input
            @input="form.rank = $event"
            label="Rank"
            name="rank"
            v-bind:error="errors.rank"
            v-bind:value="form.rank"
            class="w-full"
          />
        </div>

        <paragraph-input label="Description" name="description" v-bind:error="errors.description"
                         v-bind:value="form.description" v-on:input="form.description = $event"/>

        <form-actions :to="`/cms/${namespace}`"/>
      </form>
    </create-category>
  </div>
</template>

<script>
  import TextInput from "../../../components/forms/TextInput";
  import FormActions from "../../../components/forms/FormActions";
  import CreateCategory from "../../../components/CreateCategory";
  import ParagraphInput from "../../../components/forms/ParagraphInput";

  export default {
    name: "create",
    components: {ParagraphInput, CreateCategory, FormActions, TextInput},
    data() {
      return {
        form: {
          name: '',
          description: '',
          rank: '',
        },
        errors: [],
        namespace: 'departments',
        category: 'departments',
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(this.category, this.form)
          .then(() => this.$router.push(`/cms/${this.category}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }

  }
</script>
