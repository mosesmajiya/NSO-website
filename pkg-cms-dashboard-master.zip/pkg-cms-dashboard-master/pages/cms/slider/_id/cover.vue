<template>
  <editing-stage subtitle="Upload slide cover" title="Slide Cover" v-bind:data="data">
    <form class="p-8 border border-gray-300 rounded bg-gray-100" method="post" @submit.prevent="onSubmit">

      <file-input id="file" v-model="form.file" class="pb-5" label="File" v-bind:error="errors.file"/>

      <form-submit accent="primary">Upload File</form-submit>
    </form>
    <nuxt/>
    <media-list v-bind:attachments="attachments" v-bind:banners="banners" v-bind:data="data"
                v-bind:namespace="namespace"/>
  </editing-stage>
</template>

<script>
import MediaUpload from "../../../../components/forms/MediaUpload";
import MediaList from "../../../../components/MediaList";
import EditingStage from "../../../../components/EditingStage";
import TextInput from "@/components/forms/TextInput";
import DropdownInput from "@/components/forms/DropdownInput";
import FileInput from "@/components/forms/FileInput";
import FormSubmit from "@/components/forms/FormSubmit";

export default {
  name: "index",
  components: {
    FormSubmit,
    FileInput,
    DropdownInput,
    TextInput,
    EditingStage,
    MediaList,
    MediaUpload,
  },
  async mounted() {
    this.banners = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}/media/cover`)).data.data
    this.data = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      namespace: "slider",
      data: {},
      banners: [],
      attachments: [],
      form: {
        file: '',
        caption: '',
        type: ''
      },
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)
      formData.append('type', 'cover')
      formData.append('caption', 'Album cover')

      this.$axios.post(`/${this.namespace}/${this.$route.params.id}/attach/cover`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go())
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
