<template>
  <metadata-edit :namespace="namespace" namespace-id="id" v-bind:data="data" v-bind:form="form"/>
</template>

<script>

import MetadataEdit from "../../../../components/forms/MetadataEdit";

export default {
  name: "metadata",
  components: {MetadataEdit},
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data
    this.form = response.metadata ? response.metadata : {description: '', keywords: ''}
    this.data = response
  },
  data() {
    return {
      form: {
        description: '',
        keywords: '',
      },
      data: {},
      namespace: 'slider'
    }
  }
}
</script>
