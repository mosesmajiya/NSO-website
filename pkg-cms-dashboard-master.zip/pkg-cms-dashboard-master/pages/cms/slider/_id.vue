<template>
  <div>
    <contextual-menu v-bind:menu="menu" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-arrow-left/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex items-center" exact>
        <svg-document-text class="mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex items-center">
        <svg-pencil-alt class="mr-2 h-6 w-6"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/metadata`" class="flex items-center">
        <svg-code class="h-6 w-6 mr-2"/>
        Metadata
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/cover`" class="flex items-center">
        <svg-image class="h-6 w-6 mr-2"/>
        Cover
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>

import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import ContextualMenu from "@/components/ContextualMenu";
import TabItem from "@/components/tabItem";
import FaIcon from "@/components/FaIcon";
import SvgChevronLeft from "@/components/icons/svg-chevron-left";
import SvgArrowLeft from "@/components/icons/svg-arrow-left";
import SvgDocumentText from "@/components/icons/svg-document-text";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";
import SvgCode from "@/components/icons/svg-code";
import SvgCamera from "@/components/icons/svg-camera";
import SvgImage from "@/components/icons/svg-image";

export default {
  name: "_id",
  components: {
    SvgImage,
    SvgCamera,
    SvgCode,
    SvgPencilAlt,
    SvgDocumentText, SvgArrowLeft, SvgChevronLeft, FaIcon, TabItem, ContextualMenu, ItemTabbedDetails
  },
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {},
      namespace: "slider",
      menu: "CMS"
    }
  }
}
</script>

