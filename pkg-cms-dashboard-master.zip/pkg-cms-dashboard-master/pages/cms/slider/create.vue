<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a photo slider" title="New Slider"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                    v-on:input="form.name = $event"/>

        <text-input label="Content" name="content"
                    v-bind:error="errors.content" v-bind:value="form.content" v-on:input="form.content = $event"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "@/components/forms/DropdownInput";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  created() {
  },
  data() {
    return {
      form: {
        name: '',
        content: '',
      },
      namespace: "slider",
      recent: [],
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(this.namespace, this.$stripFields(this.form))
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
