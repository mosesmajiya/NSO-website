<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "about"
  }
</script>
