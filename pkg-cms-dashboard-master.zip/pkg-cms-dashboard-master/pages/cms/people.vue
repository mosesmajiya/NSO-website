<template>

</template>

<script>
  export default {
    name: "people"
  }
</script>

<style scoped>

</style>
