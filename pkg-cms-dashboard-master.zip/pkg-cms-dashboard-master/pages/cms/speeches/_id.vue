<template>
  <div>
    <contextual-menu menu="CMS" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-chevron-left class="w-6 h-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex" exact>
        <svg-file class="w-6 h-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex">
        <svg-pencil-alt class="w-6 h-6 mr-2"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${data.id}/media`" class="flex">
        <svg-camera class="w-6 h-6 mr-2"/>
        Media
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>

</template>

<script>
import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import index_resources from "@/mixins/resource/index_resources";
import ContextualMenu from "@/components/ContextualMenu";
import TabItem from "@/components/tabItem";
import FaIcon from "@/components/FaIcon";
import SvgChevronLeft from "../../../components/icons/svg-chevron-left";
import SvgFile from "../../../components/icons/svg-file";
import SvgPencilAlt from "../../../components/icons/svg-pencil-alt";
import SvgCamera from "../../../components/icons/svg-camera";

export default {
  name: "_id",
  components: {SvgCamera, SvgPencilAlt, SvgFile, SvgChevronLeft, FaIcon, TabItem, ContextualMenu, ItemTabbedDetails},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'speeches'
    }
  }
}
</script>
