<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage title="New Speech">
      <template v-slot:subtitle>
        Create a speech
      </template>
      <form @submit.prevent="onSubmit">
        <text-input
          label="Name"
          name="name"
          v-bind:error="errors.name"
          v-bind:value="form.name"
          v-on:input="form.name = $event"
        />

        <paragraph-input
          label="Description"
          name="description"
          v-bind:error="errors.description"
          v-bind:value="form.description"
          v-on:input="form.description = $event"
        />

        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-if="recent.length" v-slot:recent>
        <div v-for="item in recent" v-if="recent" class="text-sm pt-4">
          <p class="text-gray-500">{{ $moment(item.created_at).fromNow() }}</p>
          <nuxt-link :to="`/cms/${namespace}/${item.id}`" class="hover:text-gray-600">{{ item.category }}</nuxt-link>
        </div>
      </template>

    </creation-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Alert from "../../../components/Alert";
import FormButton from "../../../components/FormButton";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormGroup from "../../../components/forms/FormGroup";
import NavigateBack from "../../../components/NavigateBack";
import ParagraphInput from "@/components/forms/ParagraphInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    ParagraphInput,
    NavigateBack,
    FormGroup,
    TextInput, CreationStage, FormButton, Alert, LinkButton, ContextualMenu
  },
  mixins: [create_resource],
  data() {
    return {
      form: {
        name: '',
        description: '',
      },
      namespace: 'speeches',
      recent: [],
      errors: {},
      editorOption: {
        theme: 'snow',
        modules: {}
      }
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(this.namespace, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
