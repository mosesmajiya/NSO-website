<template>
  <div>
    <editing-stage v-if="about" :title="about.name">
      <template v-slot:subtitle>Upload page media</template>
      <form class="p-8 border border-gray-300 rounded bg-gray-100" method="post" @submit.prevent="onSubmit">
        <text-input
          label="Caption"
          name="caption"
          v-bind:error="errors.caption"
          v-bind:value="form.caption"
          v-on:input="form.caption = $event"
        />

        <div class="mb-5">
          <file-input id="file" v-model="form.file" label="File" v-bind:error="errors.file"/>
        </div>

        <form-button type="submit">Upload File</form-button>
      </form>

      <nuxt/>
      <div v-if="banners.length && about" class="mt-8 flex flex-wrap items-stretch">
        <image-card
          v-for="i in banners"
          v-if="banners"
          v-bind:id="i.id"
          v-bind:key="i.id"
          :caption="i.caption"
          :remark="$moment(i.created_at).fromNow()"
          :source="i.url"
          :to="`/cms/about/${about.id}/media/${i.id}`"
          custom-class="w-1/3"
          v-on:deleted="$router.go()"
        />
      </div>

      <div v-if="attachments.length" class="mt-8 flex flex-wrap items-stretch border-t pt-8">
        <attachment-card
          v-for="i in attachments"
          v-bind:id="i.id"
          v-bind:key="i.id"
          :filename="i.caption"
          :remark="$moment(i.created_at).fromNow()"
          :to="i.download"
          custom-class="w-1/3"
          link-icon="download"
          v-on:deleted="$router.go()"
        />
      </div>
      <template v-if="about" v-slot:details>
        <page-details v-bind:page="about"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import EditingStage from "../../../../../components/EditingStage";
import PageDetails from "../../../../../components/PageDetails";
import ImageCard from "../../../../../components/ImageCard";
import AttachmentCard from "../../../../../components/AttachmentCard";
import TextInput from "../../../../../components/forms/TextInput";
import FormButton from "../../../../../components/FormButton";
import DropdownInput from "../../../../../components/forms/DropdownInput";
import FileInput from "../../../../../components/forms/FileInput";
import media_index from "@/mixins/media/media_index";

export default {
  name: "index",
  components: {
    FileInput,
    DropdownInput,
    FormButton,
    TextInput,
    AttachmentCard,
    ImageCard,
    PageDetails,
    EditingStage,
  },
  mixins: [media_index],
  data() {
    return {
      form: {
        file: '',
        caption: '',
        type: 'attachment'
      },
      namespace: 'reports',
      about: null,
      errors: [],
      banners: [],
      attachments: [],
    }
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      let type = this.form.type ? this.form.type : 'banner'
      formData.append('file', this.form.file)
      formData.append('type', this.form.type)
      formData.append('caption', this.form.caption)

      this.$axios.post(`/${this.namespace}/${this.$route.params.id}/attach/${type}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
