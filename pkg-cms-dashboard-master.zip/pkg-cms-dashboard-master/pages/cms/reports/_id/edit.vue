<template>
  <div>
    <editing-stage :title="data.name">
      <template v-slot:subtitle>
        Edit a report
      </template>

      <form @submit.prevent="onSubmit">
        <text-input
          label="Name"
          name="name"
          v-bind:error="errors.name"
          v-bind:value="form.name"
          v-on:input="form.name = $event"
        />

        <paragraph-input
          label="Description"
          name="description"
          v-bind:error="errors.description"
          v-bind:value="form.description"
          v-on:input="form.description = $event"
        />

        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>

      <template v-slot:details>
        <page-details :page="data"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import FormButton from "../../../../components/FormButton";
import EditingStage from "../../../../components/EditingStage";
import SideInfoItem from "../../../../components/SideInfoItem";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import ParagraphInput from "@/components/forms/ParagraphInput";
import edit_resource from "@/mixins/resource/edit_resource";

export default {
  name: "edit",
  components: {ParagraphInput, FormGroup, TextInput, PageDetails, SideInfoItem, EditingStage, FormButton},
  mixins: [edit_resource],
  data() {
    return {
      form: {
        name: '',
        description: '',
      },
      data: {},
      namespace: 'report',
      recent: [],
      errors: {},
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
