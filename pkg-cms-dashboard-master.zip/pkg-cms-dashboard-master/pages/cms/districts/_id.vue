<template>
  <item-tabbed-details :namespace="namespace" v-bind:data="data"/>
</template>

<script>

import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import index_resources from "~/mixins/resource/index_resources";

export default {
  name: "_id",
  mixins: [index_resources],

  components: {ItemTabbedDetails},
  data() {
    return {
      data: {},
      namespace: "districts",
      menu: "CMS"
    }
  }
}
</script>
