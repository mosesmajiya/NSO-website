<template>
  <div>
    <contextual-menu :menu="menu" :namespace="namespace">
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New District</link-button>
    </contextual-menu>
    <index-stage :table="namespace" fields="name" @cancel="$router.go(1)" @loadeddata="data = $event">
      <div class="w-full">
        <nuxt-link v-for="item in data" :key="item.id"
                   :to="`/cms/${namespace}/${item.id}`"
                   class="py-3 px-8 border-b last:border-b-0 hover:bg-gray-100 block">
          <div class="leading-loose">{{ item[headingField] }}</div>
        </nuxt-link>
      </div>
      <pagination v-if="data.from" v-bind:paginator="data" @loadeddata="data = $event"/>
    </index-stage>
  </div>
</template>

<script>
import global_index from "~/mixins/resource/global_index";
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import IndexStage from "../../../components/IndexStage";
import Pagination from "../../../components/Pagination";

export default {
  name: "index",
  components: {Pagination, IndexStage, LinkButton, ContextualMenu},
  mixins: [global_index],
  data() {
    return {
      data: [],
      namespace: 'districts',
      menu: 'CMS',
      headingField: 'name',
    }
  }
}
</script>

<style scoped>

</style>
