<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">
        District Media
      </h1>
      <h2 class="text-sm pt-4">
        View and Edit District Media
      </h2>
    </div>

    <div class="p-8">
      <div v-if="district.image" class="max-w-3xl pb-10">
        <div>
          <img :alt="district.name" :src="district.image"/>
          <button class="text-white rounded px-4 py-2 focus:outline-none mt-5 bg-red-500 hover:bg-red-600"
                  type="button" @click="deleteImage">Delete Image
          </button>
        </div>
      </div>
      <form class="max-w-3xl" @submit.prevent="onSubmit">
        <file-input id="file" v-model="form.file" class="" label="File" v-bind:error="errors.file"/>
        <div class="py-5">
          <form-submit>Save</form-submit>
        </div>
      </form>

    </div>
  </div>
</template>

<script>
import FileInput from "../../../../components/forms/FileInput";
import FormActions from "../../../../components/forms/FormActions";
import FormSubmit from "../../../../components/forms/FormSubmit";
import LinkButton from "../../../../components/LinkButton";
import FormButton from "../../../../components/FormButton";

export default {
  name: "media",
  components: {FormButton, LinkButton, FormSubmit, FormActions, FileInput},
  async created() {
    if (!process.browser) return
    if (this.namespace) {
      this.district = (await this.$axios.get(`${this.namespace}/${this.$route.params.id}`)).data.data
    }
  },
  data() {
    return {
      namespace: 'districts',
      form: {
        file: ''
      },
      district: {},
      errors: []
    }
  },
  methods: {
    deleteImage() {
      this.$axios.delete(`/${this.namespace}/${this.$route.params.id}/media/${this.district.image_id}`)
        .then(() => {
            this.$axios.get(`${this.namespace}/${this.$route.params.id}`)
              .then(response => this.district = response.data.data)
          }
        )
    },
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)

      this.$axios.post(`/${this.namespace}/${this.$route.params.id}/media`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>

<style scoped>

</style>
