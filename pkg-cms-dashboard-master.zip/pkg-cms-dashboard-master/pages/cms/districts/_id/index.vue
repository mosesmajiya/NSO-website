<template>
  <view-stage :title="data.name" heading-column="name" v-bind:data="data" @onDelete="onDelete"
              @onTogglePublish="togglePublish">
    <p class="mb-4 text-sm"><span class="text-gray-600">District Code:</span> {{ data.code }}</p>
    <div v-html="data.description"></div>
  </view-stage>
</template>

<script>
import ViewStage from "../../../../components/ViewStage";
import index_resources from "~/mixins/resource/index_resources";


export default {
  name: "index",
  components: {ViewStage},
  mixins: [index_resources],
  data() {
    return {
      data: {},
      namespace: 'districts'
    }
  },
}
</script>

<style scoped>

</style>
