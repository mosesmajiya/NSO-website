<template>

</template>

<script>
export default {
  name: "metadata"
}
</script>

<style scoped>

</style>
