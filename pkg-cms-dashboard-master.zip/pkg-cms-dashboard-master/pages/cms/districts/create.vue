<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a district" title="New District"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                    v-on:input="form.name = $event"/>

        <text-input label="Code" name="code" type="text" v-bind:error="errors.code" v-bind:value="form.code"
                    v-on:input="form.code = $event"/>

        <paragraph-input label="Description" v-bind:error="errors.description" v-bind:value="form.description"
                         @input="form.description = $event"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import create_resource from "~/mixins/resource/create_resource";
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import FormActions from "../../../components/forms/FormActions";

export default {
  name: "create",
  components: {FormActions, ParagraphInput, TextInput, CreationStage, NavigateBack},
  mixins: [create_resource],
  data() {
    return {
      form: {
        name: '',
        description: '',
        code: '',
      },
      namespace: 'districts',
      recent: [],
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`/${this.namespace}`, this.getFormData())
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    getFormData() {
      let form = new FormData();
      for (let field in this.form) {
        if (this.form[field]) form.append(field, this.form[field])
      }

      let object = {};
      form.forEach((value, key) => {
        object[key] = value
      });
      return object
    }
  }
}
</script>

<style scoped>

</style>
