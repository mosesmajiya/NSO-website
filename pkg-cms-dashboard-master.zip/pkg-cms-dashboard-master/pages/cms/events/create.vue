<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a event" title="New Event"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" type="text" v-bind:error="errors.name" v-bind:value="form.name"
                    v-on:input="form.name = $event"/>

        <div class="md:flex md:mr-4">
          <text-input class="md:flex-1 mr-4" label="Link URL" name="name" v-bind:error="errors.link"
                      v-bind:value="form.link"
                      v-on:input="form.link = $event"/>

          <dropdown-input @change="form.event_type_id = $event" class="md:flex-1" label="Event Type"
                          v-bind:error="errors.event_type_id"
                          v-bind:options="options" v-bind:value="form.event_type_id"/>
        </div>

        <div class="md:flex">
          <text-input @input="form.start_date = $event" class="md:flex-1 md:mr-4" label="Start Date" name="start_date"
                      type="datetime-local"
                      v-bind:error="errors.start_date" v-bind:value="form.start_date"/>

          <text-input @input="form.end_date = $event" class="md:flex-1" label="End Date" name="end_date"
                      type="datetime-local"
                      v-bind:error="errors.end_date" v-bind:value="form.end_date"/>
        </div>

        <text-input label="Venue" name="venue" v-bind:error="errors.venue" v-bind:value="form.venue"
                    v-on:input="form.venue = $event"/>

        <paragraph-input @input="form.content = $event" label="Content" v-bind:error="errors.content"
                         v-bind:value="form.content"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "../../../components/forms/DropdownInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  mixins: [create_resource],
  created() {
    if (!process.browser) return
    this.$axios.get('/eventTypes')
      .then(res => this.options = res.data.data.map(function (type) {
        return {
          value: type.id,
          label: type.name
        }
      }))
  },
    data() {
      return {
        form: {
          name: '',
          content: '',
          link: '',
          start_date: '',
          end_date: '',
          event_type_id: '',
          venue: '',
        },
        options: [],
        namespace: 'events',
        recent: [],
        errors: [],
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`/${this.namespace}`, this.getFormData())
          .then(() => this.$router.push(`/cms/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      getFormData() {
        let form = new FormData();
        for (let field in this.form) {
          if (this.form[field]) form.append(field, this.form[field])
        }

        let object = {};
        form.forEach((value, key) => {
          object[key] = value
        });
        return object
      }
    }
  }
</script>
