<template>
  <div>
    <editing-stage title="Edit Report Super Category">
      <template v-slot:subtitle>
        Edit a report super category
      </template>

      <form @submit.prevent="onSubmit">

        <text-input label="Name" name="name" v-bind:error="errors.name" v-bind:value="form.name"
                    v-on:input="form.name = $event"
        />

        <long-text-input :error="errors.description" :value="form.description" label="Description" name="description"
                         v-on:input="form.description = $event"
        />

        <div class="pb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-slot:details>
        <page-details :page="data"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import FormButton from "../../../../components/FormButton";
import EditingStage from "../../../../components/EditingStage";
import SideInfoItem from "../../../../components/SideInfoItem";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import LongTextInput from "../../../../components/forms/LongTextInput";

export default {
  name: "edit",
  components: {
    LongTextInput,
    FormGroup,
    TextInput,
    PageDetails,
    SideInfoItem,
    EditingStage,
    FormButton
  },
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`census/report-super-categories/${this.$route.params.id}`)).data.data;
    this.form = response
    this.data = response
  },
  data() {
    return {
      form: {
        name: '',
        description: '',
      },
      data: {},
      namespace: 'stat-report-super-categories',
      recent: [],
      errors: {},
    }
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`census/report-super-categories/${this.$route.params.id}`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
