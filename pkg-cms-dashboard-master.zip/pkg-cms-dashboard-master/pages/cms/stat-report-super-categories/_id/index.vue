<template>
  <view-stage :title="category.name" heading-column="name" v-bind:data="category" @onDelete="onDelete"
              @onTogglePublish="togglePublish">
    <div v-html="category.description"></div>
  </view-stage>
</template>

<script>
import ViewStage from "../../../../components/ViewStage";

export default {
  name: "index",
  async created() {
    if (!process.browser) return
    this.loaded = false
    this.$axios.get(`census/report-super-categories/${this.$route.params.id}`)
      .then(res => {
        this.category = res.data.data
        this.loaded = true
      })
  },
  components: {ViewStage},
  data() {
    return {
      category: {},
      loaded: false,
      namespace: 'stat-report-super-categories',
      api: 'census/report-super-categories',
      menu: 'CMS',
    }
  },
  methods: {
    onDelete() {
      this.$axios.delete(`${this.api}/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
    },
    togglePublish() {
      if (!this.category.published_at) {
        this.$axios.patch(`${this.api}/${this.$route.params.id}/publish`)
          .then(response => this.category = response.data.data)
      } else {
        this.$axios.delete(`${this.api}/${this.$route.params.id}/unpublish`)
          .then(response => this.category = response.data.data)
      }
    }
  }
}
</script>
