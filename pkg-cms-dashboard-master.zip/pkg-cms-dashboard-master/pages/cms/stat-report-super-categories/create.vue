<template>
  <div>
    <navigate-back :to="`/cms/${namespace}`"/>
    <creation-stage title="New Super category">
      <template v-slot:subtitle>
        Create a super category
      </template>
      <form @submit.prevent="onSubmit">
        <text-input
          label="Name"
          name="name"
          v-bind:error="errors.name"
          v-bind:value="form.name"
          v-on:input="form.name = $event"
        />

        <long-text-input :error="errors.description" :value="form.description" label="Description"
                         name="description" v-on:input="form.description = $event"/>
        <div class="mb-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Alert from "../../../components/Alert";
import FormButton from "../../../components/FormButton";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormGroup from "../../../components/forms/FormGroup";
import NavigateBack from "../../../components/NavigateBack";
import LongTextInput from "../../../components/forms/LongTextInput";

export default {
  name: "create",
  components: {
    LongTextInput,
    NavigateBack,
    FormGroup,
    TextInput, CreationStage, FormButton, Alert, LinkButton, ContextualMenu
  },
  data() {
    return {
      form: {
        name: '',
        description: ''
      },
      namespace: 'stat-report-super-categories',
      errors: {},
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post('census/report-super-categories', this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
