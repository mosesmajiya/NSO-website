<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "services"
  }
</script>
