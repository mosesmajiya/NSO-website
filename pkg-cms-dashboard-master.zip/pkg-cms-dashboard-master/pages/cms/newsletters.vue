<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "newsletters"
  }
</script>

<style scoped>

</style>
