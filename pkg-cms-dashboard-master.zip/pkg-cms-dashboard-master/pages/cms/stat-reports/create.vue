<template>
  <div>
    <navigate-back :namespace="namespace" :to="`/cms/${namespace}`"/>
    <creation-stage title="New Statistical Report">
      <template v-slot:subtitle>
        Create a statistical report
      </template>
      <form @submit.prevent="onSubmit">
        <text-input label="Title" name="title" v-bind:error="errors.title" v-bind:value="form.title"
                    v-on:input="form.title = $event"/>

        <text-input :error="errors.source" :value="form.source" label="Source" name="source"
                    @input="form.source = $event"/>

        <long-text-input :error="errors.abstract" :rows="3" :value="form.abstract" label="Abstract" name="abstract"
                         v-on:input="form.abstract = $event"/>

        <label>
          Report Category
          <vue-select :options="categories" v-model="form.report_category_id"></vue-select>
        </label>
        <div class="text-sm text-red-500" v-if="errors.report_category_id">{{ errors.report_category_id }}</div>

        <div class="py-5">
          <div v-if="remainingSuperCategories.length">
            <p class="py-1">Super Categories</p>
            <p class="text-red-500 text-sm">{{ errors.report_super_categories }}</p>
            <div class="flex flex-wrap -mx-2">
              <div v-for="(category, i) in remainingSuperCategories"
                   :key="i" class="px-2 py-1 bg-gray-200 mx-2 my-1 flex items-center rounded text-sm">
                {{ category.label }}
                <svg class="w-4 h-4 ml-1 bg-gray-300 hover:bg-gray-400 cursor-pointer rounded"
                     fill="none"
                     stroke="currentColor"
                     viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                     @click="addSuperCategory(category.value)">
                  <path d="M12 6v6m0 0v6m0-6h6m-6 0H6" stroke-linecap="round" stroke-linejoin="round"
                        stroke-width="2"></path>
                </svg>
              </div>
            </div>
          </div>
          <div v-if="addedReportSuperCategories.length" class="my-4 py-2">
            <p class="py-1">Added Super Categories</p>
            <div class="flex flex-wrap -mx-2 bg-primary-100 rounded">
              <div v-for="(category, i) in addedReportSuperCategories"
                   :key="i"
                   class="px-2 py-1 bg-primary-200 mx-2 my-2 flex items-center rounded text-sm text-primary-800">
                {{ category.label }}
                <svg class="w-4 h-4 ml-1 bg-primary-300 hover:bg-primary-400 cursor-pointer rounded" fill="none"
                     stroke="currentColor" viewBox="0 0 24 24"
                     xmlns="http://www.w3.org/2000/svg"
                     @click="removeSuperCategory(category.value)">
                  <path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <div class="my-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import Alert from "../../../components/Alert";
import FormButton from "../../../components/FormButton";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormGroup from "../../../components/forms/FormGroup";
import NavigateBack from "../../../components/NavigateBack";
import LongTextInput from "../../../components/forms/LongTextInput";
import FileInput from "../../../components/forms/FileInput";
import DropdownInput from "../../../components/forms/DropdownInput";
import VueSelect from "vue-select"

export default {
  name: "create",
  components: {
    VueSelect,
    DropdownInput,
    FileInput,
    LongTextInput,
    NavigateBack,
    FormGroup,
    TextInput, CreationStage, FormButton, Alert, LinkButton, ContextualMenu
  },
  created() {
    this.$axios.get('census/report-categories/options')
      .then(res => {
        this.categories = res.data.data.map(i => {
          return {label: i.name, code: i.id}
        })
      })
    this.$axios.get('census/report-super-categories/options')
      .then(res => {
        this.superCategories = res.data.data.map(i => {
          return {label: i.name, value: i.id}
        })
      })
  },
  data() {
    return {
      categories: [],
      superCategories: [],
      form: {
        title: '',
        abstract: '',
        source: '',
        document: '',
        report_category_id: '',
        report_super_categories: []
      },
      namespace: 'stat-reports',
      api: 'census',
      errors: {},
    }
  },
  computed: {
    remainingSuperCategories() {
      return this.superCategories.filter(i => !this.form.report_super_categories.includes(i.value))
    },
    addedReportSuperCategories() {
      return this.superCategories.filter(i => this.form.report_super_categories.includes(i.value))
    }
  },
  methods: {
    addSuperCategory(value) {
      this.form.report_super_categories.push(value)
    },
    removeSuperCategory(value) {
      this.form.report_super_categories.splice(this.form.report_super_categories.indexOf(value), 1)
    },
    onSubmit() {
      let formData = new FormData()
      formData.append('title', this.form.title)
      formData.append('abstract', this.form.abstract)
      formData.append('source', this.form.source)
      formData.append('document', this.form.document)
      formData.append('report_category_id', this.form.report_category_id.code)
      formData.append('report_super_categories', JSON.stringify(this.form.report_super_categories))

      this.$axios.post(this.api, formData, {
        headers: {'Content-Type': 'multipart/form-data'}
      })
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
<style>
  .style-chooser .vs__search::placeholder,
  .style-chooser .vs__dropdown-toggle,
  .style-chooser .vs__dropdown-menu {
    background: #dfe5fb;
    border: none;
    color: #394066;
    text-transform: lowercase;
    font-variant: small-caps;
  }

  .vs__search{
    @apply px-4 py-2 mt-2 mr-12 border border-gray-300 w-full block rounded bg-white
  }
  .vs__search:focus{
    @apply border-gray-400 outline-none
  }
  .vs__open-indicator{
    @apply absolute mt-4 mr-2 top-0 right-0;
  }
  .vs--open .vs__selected {
    @apply text-gray-400
  }
  .vs--searching.vs--open .vs__selected {
    @apply hidden
  }
  .vs__dropdown-toggle{
    @apply relative
  }
  .vs__selected{
    @apply absolute ml-4 mt-2
  }
  .vs__dropdown-menu{
    @apply border rounded border-gray-400 border-t-0 overflow-y-auto shadow-lg;
    max-height: 224px;
  }

  .vs__clear{
    @apply mr-2 absolute top-0 right-0 mr-8 mt-4;
  }
  .vs__dropdown-option{
    @apply px-3 cursor-pointer py-2 text-gray-600 text-sm
  }
  .vs__dropdown-option:hover{
    @apply bg-primary-500 text-primary-50
  }
  .vs__no-options{
    @apply p-3 text-red-600 text-sm
  }
  .style-chooser .vs__clear,
  .style-chooser .vs__open-indicator {
    fill: #394066;
  }
</style>
