<template>
  <div>
    <contextual-menu :namespace="namespace">
      <link-button :to="`/cms/${namespace}/create`" accent="primary" icon="playlist_add">New Report
      </link-button>
    </contextual-menu>
    <index-stage fields="title,abstract" table="reports" @cancel="$router.go(0)" @loadeddata="reports = $event">
      <div class="w-full">
        <nuxt-link v-for="report in reports.data" :key="report.id"
                   :to="`/cms/${namespace}/${report.id}`"
                   class="py-6 px-8 border-b last:border-b-0 hover:bg-gray-100 block">
          <div class="leading-loose">{{ report.title }}</div>
          <div class="text-sm flex">
            <div class="flex text-gray-600">
              <div class="mr-4 flex items-center">
                <svg-clock-solid/>
                {{ $moment(report.created_at).fromNow() }}
              </div>
              <div class="mr-4 flex items-center">
                <svg-eye/>
                {{ report.views }} views
              </div>
            </div>
            <div class="flex-grow flex items-center">
              <svg v-if="report.featured_on" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
              </svg>
              <span v-for="category in report.super_categories"
                    class="px-1 mx-1 py-px bg-primary-100 text-xs rounded text-primary-700">{{ category.name }}</span>
            </div>
            <svg-published :on="report.published_at"/>
          </div>
        </nuxt-link>
      </div>
      <pagination v-if="reports.from" v-bind:paginator="reports" @loadeddata="reports = $event"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "~/components/ContextualMenu";
import LinkButton from "~/components/LinkButton";
import IndexStage from "~/components/IndexStage";
import SvgClockSolid from "~/components/icons/svg-clock-solid";
import FaIcon from "~/components/FaIcon";
import Pagination from "~/components/Pagination";
import SvgEye from "../../../components/icons/svg-eye";
import SvgPublished from "../../../components/icons/svg-published";

export default {
  name: "index.vue",
  components: {SvgPublished, SvgEye, Pagination, FaIcon, SvgClockSolid, IndexStage, LinkButton, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get('census').then(res => this.reports = res.data.data)
  },
  data() {
    return {
      reports: {},
      menu: "CMS",
      api: 'census',
      namespace: 'stat-reports',
    }
  }
}
</script>

<style scoped>

</style>
