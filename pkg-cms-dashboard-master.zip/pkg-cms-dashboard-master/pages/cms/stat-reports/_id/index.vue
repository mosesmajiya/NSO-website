<template>
  <view-stage :title="report.title" heading-column="title" v-bind:data="report" @onDelete="onDelete"
              @onTogglePublish="togglePublish">
    <div v-html="report.abstract"></div>
  </view-stage>
</template>

<script>
import ViewStage from "../../../../components/ViewStage";

export default {
  name: "index",
  async created() {
    if (!process.browser) return
    this.loaded = false
    this.$axios.get(`${this.api}/${this.$route.params.id}`)
      .then(res => {
        this.report = res.data.data
        this.loaded = true
      })
  },
  components: {ViewStage},
  data() {
    return {
      report: {},
      loaded: false,
      namespace: 'stat-reports',
      api: 'census',
      menu: 'CMS',
    }
  },
  methods: {
    onDelete() {
      this.$axios.delete(`${this.api}/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
    },
    togglePublish() {
      if (!this.report.published_at) {
        this.$axios.patch(`${this.api}/${this.$route.params.id}/publish`)
          .then(response => this.report = response.data.data)
      } else {
        this.$axios.delete(`${this.api}/${this.$route.params.id}/unpublish`)
          .then(response => this.report = response.data.data)
      }
    }
  }
}
</script>
