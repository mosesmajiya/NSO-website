<template>
  <div>
    <editing-stage title="Edit Report">
      <template v-slot:subtitle>
        Edit a report
      </template>

      <form @submit.prevent="onSubmit">

        <text-input label="Title" name="title" v-bind:error="errors.title" v-bind:value="form.title"
                    v-on:input="form.title = $event"/>

        <text-input :error="errors.source" :value="form.source" label="Source" name="source"
                    @input="form.source = $event"/>

        <long-text-input :error="errors.abstract" :rows="3" :value="form.abstract" label="Abstract" name="abstract"
                         v-on:input="form.abstract = $event"/>

        <label>
          Report Category
          <vue-select :options="categories" v-model="form.report_category_id"></vue-select>
        </label>
        <div class="text-sm text-red-500" v-if="errors.report_category_id">{{ errors.report_category_id }}</div>

        <div class="py-5">
          <form-button type="submit">Submit</form-button>
        </div>
      </form>
      <template v-slot:details>
        <page-details :page="data"/>
      </template>
    </editing-stage>
  </div>
</template>

<script>
import FormButton from "../../../../components/FormButton";
import EditingStage from "../../../../components/EditingStage";
import SideInfoItem from "../../../../components/SideInfoItem";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormGroup from "../../../../components/forms/FormGroup";
import LongTextInput from "../../../../components/forms/LongTextInput";
import DropdownInput from "../../../../components/forms/DropdownInput";
import FileInput from "../../../../components/forms/FileInput";
import VueSelect from "vue-select"

export default {
  name: "edit",
  components: {
    VueSelect,
    FileInput,
    DropdownInput,
    LongTextInput,
    FormGroup,
    TextInput,
    PageDetails,
    SideInfoItem,
    EditingStage,
    FormButton
  },
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`${this.api}/${this.$route.params.id}`)).data.data;
    this.form = response
    this.data = response
    this.form.report_super_categories = response.super_categories.map(i => i.id)
    this.form.report_category_id = {
      label: response.category.name,
      code: response.category.id
    }
    this.$axios.get('census/report-categories/options')
      .then(res => {
        this.categories = res.data.data.map(i => {
          return {label: i.name, code: i.id}
        })
      })
    this.$axios.get('census/report-super-categories/options')
      .then(res => {
        this.superCategories = res.data.data.map(i => {
          return {label: i.name, value: i.id}
        })
      })
  },
  data() {
    return {
      categories: [],
      superCategories: [],
      form: {
        title: '',
        abstract: '',
        source: '',
        document: '',
        report_category_id: '',
        report_super_categories: []
      },
      data: {},
      namespace: 'stat-reports',
      api: 'census',
      recent: [],
      errors: {},
    }
  },
  computed: {
    remainingSuperCategories() {
      return this.superCategories.filter(i => !this.form.report_super_categories.includes(i.value))
    },
    addedReportSuperCategories() {
      return this.superCategories.filter(i => this.form.report_super_categories.includes(i.value))
    }
  },
  methods: {
    addSuperCategory(value) {
      this.form.report_super_categories.push(value)
      console.log(this.form.report_super_categories)
    },
    removeSuperCategory(value) {
      this.form.report_super_categories.splice(this.form.report_super_categories.indexOf(value), 1)
    },
    onSubmit() {
      let form = this.form
      form.report_category_id = this.form.report_category_id.code
      this.$axios.patch(`${this.api}/${this.$route.params.id}`, form)
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
<style>
.style-chooser .vs__search::placeholder,
.style-chooser .vs__dropdown-toggle,
.style-chooser .vs__dropdown-menu {
  background: #dfe5fb;
  border: none;
  color: #394066;
  text-transform: lowercase;
  font-variant: small-caps;
}

.vs__search{
  @apply px-4 py-2 mt-2 mr-12 border border-gray-300 w-full block rounded bg-white
}
.vs__search:focus{
  @apply border-gray-400 outline-none
}
.vs__open-indicator{
  @apply absolute mt-4 mr-2 top-0 right-0;
}
.vs--open .vs__selected {
  @apply text-gray-400
}
.vs--searching.vs--open .vs__selected {
  @apply hidden
}
.vs__dropdown-toggle{
  @apply relative
}
.vs__selected{
  @apply absolute ml-4 mt-2
}
.vs__dropdown-menu{
  @apply border rounded border-gray-400 border-t-0 overflow-y-auto shadow-lg;
  max-height: 224px;
}

.vs__clear{
  @apply mr-2 absolute top-0 right-0 mr-8 mt-4;
}
.vs__dropdown-option{
  @apply px-3 cursor-pointer py-2 text-gray-600 text-sm
}
.vs__dropdown-option:hover{
  @apply bg-primary-500 text-primary-50
}
.vs__no-options{
  @apply p-3 text-red-600 text-sm
}
.style-chooser .vs__clear,
.style-chooser .vs__open-indicator {
  fill: #394066;
}
</style>
