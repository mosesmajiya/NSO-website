<template>
  <editing-stage title="Report Indicators">
    <template v-slot:subtitle>
      Edit indicators for {{ report.title }}
    </template>
    <template v-slot:details>
      <page-details :page="report"/>
    </template>
    <form class="flex mb-5" @submit.prevent="onSubmit">
      <label class="flex-1">
        <input autocomplete="off"
               class="block w-full border border-gray-300 rounded-l px-4 py-2 focus:outline-none focus:border-gray-500"
               name="indicator" placeholder="Add new indicator"
               type="text"
               v-bind:value="form.indicator" v-on:input="form.indicator = $event.target.value"
        />
      </label>
      <button :class="{'cursor-wait': busy}" class="text-white bg-primary-500 rounded-r px-4 py-2 focus:outline-none"
              type="submit">
        Add Indicator
      </button>
    </form>
    <div>
      <div v-for="indicator in indicators" v-if="indicators.length"
           :key="indicator.id" class="flex items-center bg-gray-100 p-2 mb-3 border border-gray-200 rounded">
        <div class="flex-1">{{ indicator.indicator }}</div>
        <button class="hover:bg-red-500 text-gray-500 hover:text-white p-1 rounded" @click="destroy(indicator)">
          <svg class="w-4 h-4 p-px" fill="none" stroke="currentColor" viewBox="0 0 24 24"
               xmlns="http://www.w3.org/2000/svg">
            <path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
          </svg>
        </button>
      </div>
    </div>
  </editing-stage>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import PageDetails from "../../../../components/PageDetails";
import TextInput from "../../../../components/forms/TextInput";
import FormSubmit from "../../../../components/forms/FormSubmit";

export default {
  name: "indicators",
  components: {FormSubmit, TextInput, PageDetails, EditingStage},
  created() {
    if (!process.browser) return;
    this.$axios.get(`census/${this.$route.params.id}/indicators`)
      .then(res => this.report = res.data.report)
  },
  methods: {
    destroy(indicator) {
      this.$axios.$delete('census/indicators/' + indicator.id)
        .then(() => {
          this.report.indicators.splice(this.report.indicators.findIndex(i => i.id === indicator.id), 1)
        })
    },
    onSubmit() {
      this.busy = true
      this.$axios.post(`census/${this.$route.params.id}/indicators`, this.form)
        .then(res => {
          this.form.indicator = ''
          this.report.indicators.push(res.data.indicator)
          this.busy = false
        })
        .catch(err => {
          this.busy = false
          this.form.indicator = ''
        })

    }
  },
  data() {
    return {
      report: {},
      busy: false,
      form: {
        indicator: ''
      }
    }
  },
  computed: {
    indicators() {
      if (this.report.indicators) return this.report.indicators

      return []
    }
  }
}
</script>

<style scoped>

</style>
