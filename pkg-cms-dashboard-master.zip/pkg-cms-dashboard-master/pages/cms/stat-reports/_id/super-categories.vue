<template>
  <editing-stage v-if="report.title" title="Report Super Categories">
    <template v-slot:subtitle>Manage super categories {{ report.title }} belongs to</template>
    <template v-slot:details>
      <page-details :page="report"/>
    </template>
    <div>
      <p>Belongs to</p>
      <div class="flex flex-wrap -mx-2">
        <div v-for="category in categories" v-if="categories.length" :key="category.id"
             class="flex items-center text-sm bg-primary-100 py-1 my-2 mx-2 border border-primary-200 rounded px-2">
          {{ category.name }}
          <button class="p-1 hover:bg-red-400 hover:text-white rounded mx-1" @click="removeFromCategory(category.id)">
            <svg class="w-4 h-4 p-px" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
    <div class="mt-8">
      <p>Can be added to</p>
      <div class="flex flex-wrap -mx-2">
        <div v-for="category in remainingSuperCategories" v-if="remainingSuperCategories.length" :key="category.id"
             class="flex items-center text-sm text-green-800 bg-green-100 py-1 my-2 mx-2 border border-green-200 rounded px-2">
          {{ category.label }}
          <button class="p-1 hover:bg-green-400 hover:text-white rounded mx-1" @click="addToCategory(category.value)">
            <svg class="w-4 h-4 p-px" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path d="M12 6v6m0 0v6m0-6h6m-6 0H6" stroke-linecap="round" stroke-linejoin="round"
                    stroke-width="2"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
  </editing-stage>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import PageDetails from "../../../../components/PageDetails";

export default {
  name: "super-categories",
  components: {PageDetails, EditingStage},
  created() {
    if (!process.browser) return;
    this.$axios.get(`census/${this.$route.params.id}/super-categories`)
      .then(res => this.report = res.data.report)
    this.$axios.get('census/report-super-categories/options')
      .then(res => {
        this.superCategories = res.data.data.map(i => {
          return {label: i.name, value: i.id}
        })
      })
  },
  methods: {
    addToCategory(categoryId) {
      this.$axios.post(`census/${this.$route.params.id}/super-categories`, {category: categoryId})
        .then(res => this.report = res.data.report)
    },
    removeFromCategory(categoryId) {
      this.$axios.delete(`census/${this.$route.params.id}/super-categories/${categoryId}`)
        .then(res => this.report = res.data.report)
    }
  },
  data() {
    return {
      report: {},
      superCategories: [],
    }
  },
  computed: {
    categories() {
      if (this.report && this.report.super_categories)
        return this.report.super_categories

      return []
    },
    remainingSuperCategories() {
      let selectedCategories = this.categories.map(i => i.id)
      let allCategories = this.superCategories.map(i => i.value)
      let remainingCategories = allCategories.filter(i => !selectedCategories.includes(i))
      return remainingCategories.map(i => this.superCategories.find(j => i === j.value))
    }
  }
}
</script>

<style scoped>

</style>
