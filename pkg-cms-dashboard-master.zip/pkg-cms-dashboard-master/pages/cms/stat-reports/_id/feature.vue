<template>
  <div>
    <div class="m-8 rounded border">
      <div class="bg-gray-200 py-5 px-8">
        <h1 class="text-2xl">Census Media</h1>
        <h2 class="text-sm pt-4">
          <slot name="subtitle">
            Manage Census Media
          </slot>
        </h2>
      </div>

      <div class="p-8 flex flex-row" v-if="!featured">
        <div class="flex-1">
          <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">
            <div class="mb-5">
              <file-input id="image" label="Cover Image" v-bind:error="errors.image" v-model="form.image"/>
            </div>
            <form-button type="submit">Upload Cover Image</form-button>
          </form>
        </div>
      </div>

      <div class="p-8 pt-5 flex flex-wrap" v-else>
        <div class="rounded w-1/5">
          <div class="mr-4 mb-8 shadow hover:shadow-lg overflow-hidden">
            <img :src="feature.image" class="object-cover w-full rounded-t" alt=""/>
            <form-button class="m-2 w-full" @click="destroy()">Unfeature Report</form-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import TextInput from "../../../../components/forms/TextInput";
import FileInput from "../../../../components/forms/FileInput";
import FormButton from "../../../../components/FormButton";
import ConfirmIcon from "../../../../components/ConfirmIcon";

export default {
  name: "media",
  components: {ConfirmIcon, FormButton, FileInput, TextInput},
  created() {
    this.$axios.get(`census/${this.$route.params.id}/feature`)
      .then(res => this.feature = res.data.feature)
  },
  data() {
    return {
      form: {
        image: '',
      },
      namespace: 'census',
      feature: {},
      errors: [],
    }
  },
  methods: {
    destroy() {
      this.$axios.delete(`census/${this.feature.id}/feature`)
        .then(() => this.feature = {})
    },
    onSubmit() {
      let formData = new FormData()
      formData.append('image', this.form.image)

      this.$axios.post(`census/${this.$route.params.id}/feature`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  computed:{
    featured(){
      return this.feature && this.feature.featured
    }
  }
}
</script>
