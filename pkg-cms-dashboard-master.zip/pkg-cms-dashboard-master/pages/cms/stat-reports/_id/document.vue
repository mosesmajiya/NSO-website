<template>
  <editing-stage v-if="report.title" title="Report Document">
    <template v-slot:subtitle>Manage the report file for {{ report.title }}</template>
    <template v-slot:details>
      <page-details :page="report"/>
    </template>
    <div>
      <div v-if="hasMedia" v-for="document in report.documents"
           class="flex items-center border border-primary-100 rounded bg-primary-50 text-primary-700 mb-6">
        <div class="flex-0 p-2 bg-primary-100 h-20 w-20 flex items-center justify-center">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
              stroke-linecap="round" stroke-linejoin="round"
              stroke-width="2"></path>
          </svg>
        </div>
        <div class="px-4 flex w-full">
          <div class="flex-grow">
            <a :href="document.url" class="hover:underline" target="_blank">{{ document.name }}</a>
            <p class="text-xs">{{ document.filesize }}</p>
          </div>
          <button class="text-red-500 hover:text-red-700 px-3 py-1 hover:bg-primary-100 rounded"
                  @click="destroy(document.id)">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                 xmlns="http://www.w3.org/2000/svg">
              <path
                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
            </svg>
          </button>
        </div>

      </div>
      <div>
        <form class="" @submit.prevent="onSubmit">
          <text-input label="Name" name="name" :error="errors.name" id="name" :value="form.name"
                      @input="form.name = $event"/>
          <file-input id="document" v-model="form.file" :error="errors.file" label="Report file"/>
          <form-submit class="py-5">Upload</form-submit>
        </form>
      </div>
    </div>
  </editing-stage>
</template>

<script>
import EditingStage from "../../../../components/EditingStage";
import PageDetails from "../../../../components/PageDetails";
import FileInput from "../../../../components/forms/FileInput";
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";

export default {
  name: "document",
  components: {TextInput, FormSubmit, FileInput, PageDetails, EditingStage},
  data() {
    return {
      report: {},
      form: {
        file: '',
        name: ''
      },
      errors: {}
    }
  },
  methods: {
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)
      formData.append('name', this.form.name)
      this.$axios.post(`census/${this.$route.params.id}/document`, formData, {
        headers: {'Content-Type': 'multipart/form-data'}
      })
        .then(res => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    destroy(id) {
      this.$axios.delete(`census/${this.$route.params.id}/document/${id}`)
        .then(() => {
          let documents = this.report.documents
          documents.splice(documents.findIndex(i => i.id === id), 1)
        })
    }
  },
  computed: {
    hasMedia() {
      return this.report.media && this.report.media.length
    },
    media() {
      return this.report.media[0]
    }
  },
  created() {
    if (!process.browser) return;
    this.$axios.get(`census/${this.$route.params.id}`)
      .then(res => this.report = res.data.data)
  },
}
</script>

<style scoped>

</style>
