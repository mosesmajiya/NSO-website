<template>
  <div>
    <contextual-menu menu="CMS" v-bind:namespace="namespace">
      <tab-item :to="`/cms/${namespace}/`">
        <svg-chevron-left class="w-6 h-6"/>
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}`" class="flex" exact>
        <svg-file class="w-6 h-6 mr-2"/>
        View
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/edit`" class="flex">
        <svg-pencil-alt class="w-6 h-6 mr-2"/>
        Edit
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/indicators`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Indicators
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/super-categories`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14" stroke-linecap="round" stroke-linejoin="round"
                stroke-width="2"></path>
        </svg>
        Super Categories
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/document`" class="flex">
        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
             xmlns="http://www.w3.org/2000/svg">
          <path
            d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"></path>
        </svg>
        Document
      </tab-item>
      <tab-item :to="`/cms/${namespace}/${category.id}/feature`" class="flex">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/>
        </svg>
        Feature
      </tab-item>
    </contextual-menu>
    <nuxt-child/>
  </div>
</template>

<script>
import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import ContextualMenu from "../../../components/ContextualMenu";
import TabItem from "../../../components/tabItem";
import SvgChevronLeft from "../../../components/icons/svg-chevron-left";
import SvgFile from "../../../components/icons/svg-file";
import SvgPencilAlt from "../../../components/icons/svg-pencil-alt";
import SvgList from "../../../components/icons/svg-list";

export default {
  name: "_id",
  components: {SvgList, SvgPencilAlt, SvgFile, SvgChevronLeft, TabItem, ContextualMenu, ItemTabbedDetails},
  async created() {
    if (!process.browser) return
    this.loaded = false
    this.$axios.get(`${this.api}/${this.$route.params.id}`)
      .then(res => {
        this.category = res.data.data
        this.loaded = true
      })
  },
  data() {
    return {
      category: {},
      loaded: false,
      namespace: 'stat-reports',
      api: 'census'
    }
  }
}
</script>
