<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "faqs"
  }
</script>
