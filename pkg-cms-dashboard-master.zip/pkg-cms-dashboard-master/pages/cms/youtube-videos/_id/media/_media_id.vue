<template>
  <div class="m-8 rounded border">
    <div class="bg-gray-200 py-5 px-8">
      <h1 class="text-2xl">Album Cover</h1>
      <h2 class="text-sm pt-4">
        <slot name="subtitle">
          Change album cover
        </slot>
      </h2>
    </div>
  </div>
</template>

<script>

import media_id from "@/mixins/media/media_id";

export default {
  name: "_media_id",
  mixins: [media_id],
  data() {
    return {
      form: {
        caption: ''
      },
      url: '',
      namespace: 'youtube-videos',
      media: {}
    }
  },
}
</script>
