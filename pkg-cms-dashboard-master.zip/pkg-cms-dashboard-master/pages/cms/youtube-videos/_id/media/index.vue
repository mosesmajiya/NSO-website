<template>
  <editing-stage subtitle="Upload album cover image" title="Album Cover Image" v-bind:data="data">
    <form @submit.prevent="onSubmit" class="p-8 border border-gray-300 rounded bg-gray-100" method="post">
      <div>
      </div>
      <file-input class="pb-5" id="file" label="File" v-bind:error="errors.file" v-model="form.file"/>
      <form-submit accent="primary">Upload File</form-submit>
    </form>
    <nuxt/>
    <div class="mt-8 flex flex-wrap items-stretch" v-if="banners && banners.length">
      <image-card
        :caption="i.caption"
        :remark="$moment(i.created_at).fromNow()"
        :source="i.url"
        :to="getTarget(i)"
        custom-class="w-1/3"
        v-bind:id="i.id"
        v-bind:key="i.id"
        v-for="i in banners"
        v-if="banners"
        v-on:deleted="$router.go()"
      />
    </div>
  </editing-stage>
</template>

<script>
import MediaUpload from "../../../../../components/forms/MediaUpload";
import MediaList from "../../../../../components/MediaList";
import EditingStage from "../../../../../components/EditingStage";
import ImageCard from "@/components/ImageCard";
import TextInput from "@/components/forms/TextInput";
import FileInput from "@/components/forms/FileInput";
import FormSubmit from "@/components/forms/FormSubmit";

export default {
  name: "index",
  components: {
    FormSubmit,
    FileInput,
    TextInput,
    ImageCard,
    EditingStage,
    MediaList,
    MediaUpload,
  },
  async created() {
    if (!process.browser) return
    this.banners = (await this.$axios.get(`youtubeAlbums/${this.$route.params.id}/media/banner`)).data.data
    this.data = (await this.$axios.get(`youtubeAlbums/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      namespace: 'youtube-videos',
      data: {},
      banners: [],
      form: {
        file: '',
        caption: '',
      },
      errors: [],
    }
  },
  methods: {
    getTarget(item) {
      return `/cms/${this.namespace}/${this.data.id}/media/${item.id}`
    },
    onSubmit() {
      let formData = new FormData();
      formData.append('file', this.form.file)
      formData.append('caption', this.form.caption)

      this.$axios.post(`/youtubeAlbums/${this.$route.params.id}/attach/banner`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    }

  }
}
</script>
