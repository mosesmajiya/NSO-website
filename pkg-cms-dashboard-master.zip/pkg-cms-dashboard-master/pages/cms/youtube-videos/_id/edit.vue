<template>
  <editing-stage subtitle="Edit gallery" title="Edit Youtube Gallery" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input label="Name" name="name" type="text" v-bind:error="errors.name"
                  v-bind:value="form.name"
                  v-on:input="form.name = $event"/>
      <text-input label="Description" name="description" v-bind:error="errors.description"
                  v-bind:value="form.description" v-on:input="form.description = $event"/>

      <form-actions v-bind:to="`/cms/${namespace}`"/>
    </form>
  </editing-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import FormActions from "../../../../components/forms/FormActions";
import EditingStage from "../../../../components/EditingStage";

export default {
  name: "edit",
  components: {
    EditingStage, FormActions, ParagraphInput, TextInput, FormSubmit
  },
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`youtubeAlbums/${this.$route.params.id}`)).data.data

    this.form = response
    this.data = response
  },
  methods: {
    onSubmit() {
      this.$axios.patch(`/youtubeAlbums/${this.$route.params.id}`, this.$stripFields(this.form))
        .then(() => this.$router.push(`/cms/${this.namespace}/${this.$route.params.id}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        content: '',
      },
      namespace: 'youtube-videos',
      errors: [],
    }
  }
}
</script>

