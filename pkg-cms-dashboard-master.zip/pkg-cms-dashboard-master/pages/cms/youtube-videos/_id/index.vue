<template>
  <div>
    <div class="m-8 rounded border">
      <div class="bg-gray-200 py-5 px-8">
        <h1 class="text-2xl">{{ data.name }}</h1>
        <h2 class="text-sm pt-4">
          Manage videos in this album
        </h2>
      </div>
      <div class="p-8 flex justify-between items-center">
        <div class="flex">
          <form-button
            :fa-icon="data.published_at ? 'unlink' : 'link'"
            @click="togglePublish"
            accent="primary"
            custom-class="mr-4">
            {{ data.published_at ? 'Unpublish' : 'Publish' }}
          </form-button>
          <confirm-button @confirmed="destroyAlbum" accent="gray" fa-icon="trash" label="Delete Album"
                          message="This album including all its videos will be deleted permanently"
                          title="Confirm Deletion"/>
        </div>
        <svg-published :on="data.published_at"/>
      </div>
    </div>
    <div class="border mx-8 mb-8 rounded overflow-hidden">
      <form @submit.prevent="onSubmit" class="border-b p-8 pb-4 mb-0 flex items-end bg-gray-100">
        <text-input @input="form.name = $event" class="flex-1 mr-4" label="Caption" name="name"
                    v-bind:error="errors.name"
                    v-bind:value="form.name"/>
        <text-input @input="form.video_id = $event" class="flex-2 mr-4" label="Video ID" name="video_id"
                    v-bind:error="errors.video_id" v-bind:value="form.video_id"/>
        <form-submit accent="primary">Add Video</form-submit>
      </form>
      <div class="p-8 pb-0 flex flex-wrap" v-if="data.videos && data.videos.length">
        <div class="w-1/2 odd:pr-8 pb-8" v-bind:key="video.id" v-for="video in data.videos">
          <div class="shadow hover:shadow-md">
            <iframe :src="`https://www.youtube.com/embed/${video.video_id}`"
                    allow="encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen class="w-full"
                    frameborder="0" height="350"></iframe>
            <div class="flex justify-between p-4">
              <p>{{ video.name }}</p>
              <confirm-icon
                icon="trash"
                message="This embedded video will be deleted permanently"
                title="Delete Confirmation"
                v-on:confirmed="destroy(video.id)"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ConfirmIcon from "../../../../components/ConfirmIcon";
import EditingStage from "../../../../components/EditingStage";
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import FormButton from "@/components/FormButton";
import ConfirmButton from "@/components/ConfirmButton";
import FaIcon from "@/components/FaIcon";
import SvgPublished from "../../../../components/icons/svg-published";

export default {
  name: "index",
  components: {SvgPublished, FaIcon, ConfirmButton, FormButton, TextInput, FormSubmit, EditingStage, ConfirmIcon},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`youtubeAlbums/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: [],
      form: {
        name: '',
        video_id: '',
        youtube_album_id: this.$route.params.id
      },
      errors: [],
      namespace: 'youtubeAlbums'
    }
  },
  methods: {
    destroy(videoId) {
      this.$axios.delete(`youtubeVideos/${videoId}`)
        .then(() => this.$router.go(0))
    },
    destroyAlbum() {
      this.$axios.delete(`youtubeAlbums/${this.$route.params.id}`)
        .then(() => this.$router.push(`/cms/youtube-videos`))
    },
    onSubmit() {
      this.$axios.post(`youtubeVideos`, this.form)
        .then(() => this.$router.go(0))
        .catch(err => this.errors = err.response.data.status.errors)
    },
    togglePublish() {
      if (this.data.published_at) {
        return this.unpublish();
      } else {
        return this.publish()
      }
    },
    publish() {
      this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
        .then(() => this.$router.go(0))
    },
    unpublish() {
      this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
        .then(() => this.$router.go(0))
    }
  }
}
</script>

