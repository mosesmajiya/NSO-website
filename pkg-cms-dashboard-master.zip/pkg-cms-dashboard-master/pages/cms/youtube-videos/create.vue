<template>
  <div>
    <navigate-back :namespace="namespace" :to="`/cms/${namespace}`"/>
    <creation-stage :namespace="namespace" heading-field="name" subtitle="Create a new YouTube video album"
                    title="Create YouTube Album"
                    v-bind:recent="recent">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" type="text" v-bind:error="errors.name"
                    v-bind:value="form.name"
                    v-on:input="form.name = $event"/>

        <text-input label="Description" name="description" v-bind:error="errors.description"
                    v-bind:value="form.description" v-on:input="form.description = $event"/>

        <form-actions v-bind:to="`/cms/${namespace}`"/>
      </form>
    </creation-stage>
  </div>

</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import FormSubmit from "../../../components/forms/FormSubmit";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import CreationStage from "../../../components/CreationStage";
import TextInput from "../../../components/forms/TextInput";
import FormLink from "../../../components/forms/FormLink";
import FormActions from "../../../components/forms/FormActions";
import DropdownInput from "../../../components/forms/DropdownInput";
import create_resource from "@/mixins/resource/create_resource";

export default {
  name: "create",
  components: {
    DropdownInput,
    FormActions, FormLink, ParagraphInput, TextInput, FormSubmit, NavigateBack, CreationStage
  },
  mixins: [create_resource],
  data() {
    return {
      form: {
        position: '',
        description: '',
      },
      namespace: 'youtube-videos',
      recent: [],
      errors: [],
    }
  },
  methods: {
    onSubmit() {
      this.$axios.post(`/youtubeAlbums`, this.form)
        .then(() => this.$router.push(`/cms/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }
}
</script>
