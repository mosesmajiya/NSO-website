<template>
  <settings-tabbed-details v-bind:data="data" v-bind:menu="menu" v-bind:namespace="namespace">
    <tab-item :to="`/cms/${namespace}/${data.id}`" class="flex items-center">
      <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
           xmlns="http://www.w3.org/2000/svg">
        <path
          d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
          stroke-linecap="round" stroke-linejoin="round"
          stroke-width="2"></path>
      </svg>
      Videos
    </tab-item>
    <tab-item :to="`/cms/${namespace}/${data.id}/edit`" class="flex items-center">
      <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
           xmlns="http://www.w3.org/2000/svg">
        <path
          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
          stroke-linecap="round" stroke-linejoin="round"
          stroke-width="2"></path>
      </svg>
      Edit
    </tab-item>
    <tab-item :to="`/cms/${namespace}/${data.id}/media`" class="flex items-center">
      <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
           xmlns="http://www.w3.org/2000/svg">
        <path
          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
          stroke-linecap="round" stroke-linejoin="round"
          stroke-width="2"></path>
      </svg>
      Cover
    </tab-item>
  </settings-tabbed-details>
</template>

<script>

import ItemTabbedDetails from "../../../components/ItemTabbedDetails";
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";
import TabItem from "../../../components/tabItem";
import FaIcon from "../../../components/FaIcon";

export default {
  name: "_id",
  components: {FaIcon, TabItem, SettingsTabbedDetails, ItemTabbedDetails},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`youtubeAlbums/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {},
      namespace: "youtube-videos",
      menu: "cms",
    }
  }
}
</script>

