<template>
  <div>
    <navigate-back :to="`/${menu}/${namespace}`" v-bind:menu="menu" v-bind:namespace="namespace"/>
    <creation-stage heading-field="name" subtitle="Create a user" title="Create User"
                    v-bind:namespace="namespace">
      <form @submit.prevent="onSubmit">
        <text-input label="Name" name="name" v-bind:error="errors.name" v-bind:value="form.name"
                    @input="form.name = $event"/>
        <text-input label="Email" name="email" type="email" v-bind:error="errors.email"
                    v-bind:value="form.email" @input="form.email = $event"/>

        <div class="pb-4">
          <p class="pb-2">
            Roles
            <span class="block text-sm text-red-500">{{ errors.roles }}</span>
          </p>
          <label v-for="(option, index) in roleOptions" :key="index" class="flex items-center">
            <input :checked="hasRole(option.id)" :name="option.id" type="checkbox"
                   @change="syncRoles($event.target.name)">
            <span class="pl-2">{{ option.name }}</span>
          </label>
        </div>
        <form-actions v-bind:to="`/${menu}/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import FormActions from "../../../components/forms/FormActions";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import DropdownInput from "../../../components/forms/DropdownInput";

export default {
  name: "create",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  async created() {
    if (process.browser) this.roles = (await this.$axios.get('roles/portal')).data.data
  },
  data() {
    return {
      menu: 'cms',
      namespace: 'downloads-users',
      form: {
        name: '',
        email: '',
        roles: []
      },
      roles: [],
      errors: []
    }
  },
  computed: {
    roleOptions() {
      return this.roles.map(function (role) {
        return {
          id: role.id,
          name: role.name
        }
      })
    }
  },
  methods: {
    hasRole(role) {
      return this.form.roles.includes(role)
    },
    syncRoles(role) {
      if (this.hasRole(role)) {
        this.form.roles.splice(this.form.roles.indexOf(role), 1)
      } else {
        this.form.roles.push(role)
      }
    },
    onSubmit() {
      this.$axios.post(`${this.namespace}`, this.form)
        .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }

}
</script>

