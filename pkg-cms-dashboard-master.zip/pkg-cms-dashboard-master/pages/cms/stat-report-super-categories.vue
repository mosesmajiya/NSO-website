<template>
  <nuxt-child />
</template>

<script>
export default {
name: "stat-report-super-categories.vue"
}
</script>

<style scoped>

</style>
