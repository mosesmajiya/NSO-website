<template>
  <nuxt/>
</template>

<script>
export default {
  name: "speeches"
}
</script>
