<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "posts"
  }
</script>

<style scoped>

</style>
