<template>
  <landing/>
</template>

<script>
  import Landing from "../components/landing";

  export default {
    name: "extras",
    components: {Landing}
  }
</script>

<style scoped>

</style>
