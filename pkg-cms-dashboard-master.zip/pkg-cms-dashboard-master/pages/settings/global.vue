<template>
  <div>
    <contextual-menu :menu="menu" :namespace="namespace"/>
    <editing-stage subtitle="Manage site-wide settings" title="Edit Global Settings" v-bind:data="data">
      <form @submit.prevent="onSubmit">
        <text-input @input="form.organization_name = $event" label="Organization Name"
                    name="organization_name"
                    v-bind:error="errors.organization_name" v-bind:value="form.organization_name"/>

        <text-input @input="form.email = $event" label="Email"
                    name="email"
                    v-bind:error="errors.email" v-bind:value="form.email"/>

        <text-input @input="form.web_address = $event" label="Web Address"
                    name="web_address"
                    v-bind:error="errors.web_address" v-bind:value="form.web_address"/>

        <text-input @input="form.postal_address = $event" label="Postal Address"
                    name="postal_address"
                    v-bind:error="errors.postal_address" v-bind:value="form.postal_address"/>

        <text-input @input="form.physical_address = $event" label="Physical Address"
                    name="physical_address"
                    v-bind:error="errors.physical_address" v-bind:value="form.physical_address"/>

        <text-input @input="form.phone = $event" label="Phone Number"
                    name="phone"
                    v-bind:error="errors.phone" v-bind:value="form.phone"/>

        <text-input @input="form.google_map = $event" label="Google Map"
                    name="google_map"
                    v-bind:error="errors.google_map" v-bind:value="form.google_map"/>

        <text-input @input="form.facebook = $event" label="Facebook"
                    name="facebook"
                    v-bind:error="errors.facebook" v-bind:value="form.facebook"/>

        <text-input @input="form.linkedin = $event" label="LinkedIn"
                    name="linkedin"
                    v-bind:error="errors.linkedin" v-bind:value="form.linkedin"/>

        <text-input @input="form.twitter = $event" label="Twitter"
                    name="twitter"
                    v-bind:error="errors.twitter" v-bind:value="form.twitter"/>

        <text-input @input="form.instagram = $event" label="Instagram"
                    name="instagram"
                    v-bind:error="errors.instagram" v-bind:value="form.instagram"/>

        <text-input @input="form.youtube = $event" label="Youtube"
                    name="youtube"
                    v-bind:error="errors.youtube" v-bind:value="form.youtube"/>

        <text-input @input="form.skype = $event" label="Skype"
                    name="skype"
                    v-bind:error="errors.skype" v-bind:value="form.skype"/>

        <text-input @input="form.meta_description = $event" label="Site Description"
                    name="meta_description"
                    v-bind:error="errors.meta_description" v-bind:value="form.meta_description"/>

        <form-submit accent="primary">Update</form-submit>
      </form>
    </editing-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../components/ContextualMenu";
import EditingStage from "../../components/EditingStage";
import FormActions from "../../components/forms/FormActions";
import FormSubmit from "../../components/forms/FormSubmit";
import TextInput from "../../components/forms/TextInput";

export default {
  name: "global",
  components: {TextInput, FormSubmit, FormActions, EditingStage, ContextualMenu},
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`settings`)).data.data;
    this.data = response
    this.form = response
  },
  data() {
    return {
      namespace: 'global',
      menu: 'settings',
      data: {},
      form: {
        organization_name: '',
        email: '',
        web_address: '',
          postal_address: '',
          physical_address: '',
          phone: '',
          google_map: '',
          facebook: '',
          linkedin: '',
          twitter: '',
          instagram: '',
          youtube: '',
          skype: '',
          meta_description: '',
        },
        errors: []
      }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`settings/1`, this.getFormData())
          .then(() => this.$router.go())
          .catch(err => this.errors = err.response.data.status.errors)
      },
      getFormData() {
        let form = new FormData();
        for (let field in this.form) {
          if (this.form[field]) form.append(field, this.form[field])
        }

        let object = {};
        form.forEach((value, key) => {
          object[key] = value
        });
        return object
      }
    }
  }
</script>
