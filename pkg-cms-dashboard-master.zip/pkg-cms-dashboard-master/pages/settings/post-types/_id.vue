<template>
  <settings-tabbed-details menu="settings" namespace="post-types" v-bind:data="data"/>
</template>

<script>
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";

export default {
  name: "_id",
  components: {SettingsTabbedDetails},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`post-types/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {}
    }
  }
}
</script>
