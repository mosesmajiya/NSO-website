<template>
  <div>
    <navigate-back :to="`/${menu}/${namespace}`" v-bind:menu="menu" v-bind:namespace="namespace"/>
    <creation-stage heading-field="name" subtitle="Create new post type" title="Create Post Type"
                    v-bind:namespace="namespace">
      <form @submit.prevent="onSubmit">
        <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name"/>
        <form-actions v-bind:to="`/${menu}/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
  import NavigateBack from "../../../components/NavigateBack";
  import CreationStage from "../../../components/CreationStage";
  import FormActions from "../../../components/forms/FormActions";
  import TextInput from "../../../components/forms/TextInput";

  export default {
    name: "create",
    components: {TextInput, FormActions, CreationStage, NavigateBack},
    data() {
      return {
        menu: 'settings',
        namespace: 'post-types',
        form: {
          name: '',
        },
        errors: []
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`${this.namespace}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>

