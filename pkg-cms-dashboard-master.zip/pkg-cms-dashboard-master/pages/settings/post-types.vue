<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "post-types"
  }
</script>
