<template>
  <editing-stage subtitle="Edit footer link" title="Edit Link" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>
      <text-input @input="form.url = $event" label="URL" name="url" v-bind:error="errors.url"
                  v-bind:value="form.url"/>
      <dropdown-input @change="form.type = $event" label="Type" name="type" v-bind:error="errors.type"
                      v-bind:options="options" v-bind:value="form.type"/>
      <div class="flex">
        <form-actions v-bind:to="`/${menu}/${namespace}`">Update</form-actions>
        <confirm-button
          @confirmed="onDelete"
          class="ml-4"
          label="Delete"
          message="Proceed to delete this link?"
          title="Confirm Deletion"/>
      </div>
    </form>
  </editing-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import ConfirmButton from "../../../../components/ConfirmButton";
import get_one_resource from "@/mixins/settings/get_one_resource";
import DropdownInput from "../../../../components/forms/DropdownInput";

export default {
  name: "index",
  components: {DropdownInput, ConfirmButton, TextInput, FormActions, EditingStage, ViewStage},
  mixins: [get_one_resource],
  data() {
    return {
      data: {},
      form: {
        name: '',
        url: '',
        type: '',
      },
      errors: [],
      options:  [{label: 'Local', value: 'local'}, {label: 'Foreign', value: 'foreign'}],
      namespace: 'footer-links',
      menu: 'settings'
    }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      onDelete() {
        this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
