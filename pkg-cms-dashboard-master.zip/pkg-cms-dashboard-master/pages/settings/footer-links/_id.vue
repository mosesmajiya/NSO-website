<template>
  <settings-tabbed-details menu="settings" namespace="footer-links" v-bind:data="data"/>
</template>

<script>
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";

export default {
  name: "_id",
  components: {SettingsTabbedDetails},
  async created() {
    if (!process.browser) return
    this.data = (await this.$axios.get(`footer-links/${this.$route.params.id}`)).data.data
  },
  data() {
    return {
      data: {}
    }
  }
}
</script>
