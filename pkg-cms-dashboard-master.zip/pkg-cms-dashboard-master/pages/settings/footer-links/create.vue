<template>
  <div>
    <navigate-back :to="`/${menu}/${namespace}`" v-bind:menu="menu" v-bind:namespace="namespace"/>
    <creation-stage heading-field="name" subtitle="Create new footer link" title="Create Link"
                    v-bind:namespace="namespace">
      <form @submit.prevent="onSubmit">
        <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name"/>
        <text-input @input="form.url = $event" label="URL" name="url" v-bind:error="errors.url"
                    v-bind:value="form.url"/>
        <dropdown-input @change="form.type = $event" label="Type" name="type" v-bind:error="errors.type"
                        v-bind:options="options" v-bind:value="form.type"/>
        <form-actions v-bind:to="`/${menu}/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
  import NavigateBack from "../../../components/NavigateBack";
  import CreationStage from "../../../components/CreationStage";
  import FormActions from "../../../components/forms/FormActions";
  import TextInput from "../../../components/forms/TextInput";
  import DropdownInput from "../../../components/forms/DropdownInput";

  export default {
    name: "create",
    components: {DropdownInput, TextInput, FormActions, CreationStage, NavigateBack},
    data() {
      return {
        menu: 'settings',
        namespace: 'footer-links',
        form: {
          name: '',
          url: '',
          type: '',
        },
        errors: [],
        options:  [{label: 'Local', value: 'local'}, {label: 'Foreign', value: 'foreign'}]
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`${this.namespace}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>

