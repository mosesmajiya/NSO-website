<template>
  <div>
    <contextual-menu :menu="menu" namespace="Footer Links">
      <link-button accent="primary" icon="playlist_add" to="/settings/footer-links/create">New Link</link-button>
    </contextual-menu>
    <index-stage :table="namespace" @cancel="$router.go()" @loadeddata="data = $event" fields="name">
      <div class="w-full">
        <nuxt-link :key="item.id" :to="`/settings/${namespace}/${item.id}`"
                   v-for="item in data.data"
                   class="py-3 px-8 border-b last:border-b-0 hover:bg-gray-100 flex items-center justify-between">
          <div class="leading-loose">{{ item[headingColumn] }}</div>
          <div class="text-sm">
            {{ $moment(item.created_at).fromNow() }}
          </div>
        </nuxt-link>
      </div>
      <pagination @loadeddata="data = $event" v-bind:paginator="data" v-if="data.from"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../../components/ContextualMenu";
import LinkButton from "../../../components/LinkButton";
import IndexStage from "../../../components/IndexStage";
import FaIcon from "../../../components/FaIcon";
import Pagination from "../../../components/Pagination";

export default {
  name: "index",
  components: {Pagination, FaIcon, IndexStage, LinkButton, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get('footer-links')
      .then(res => this.data = res.data.data)
  },
  data() {
    return {
      data: {},
      menu: "settings",
      namespace: 'footer-links',
      headingColumn: 'name',
    }
  }
}
</script>
