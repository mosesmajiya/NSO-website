<template>
  <creation-stage subtitle="Upload new profile avatar" title="Account Avatar">
    <form @submit.prevent="onSubmit">
      <p class="text-red-500 pb-5">{{ status }}</p>

      <file-input label="File" name="file" v-bind:error="errors.file" v-model="form.file"/>

      <form-submit accent="primary" class="mt-5">Upload File</form-submit>
    </form>
    <template slot="actions">
      <div class="rounded overflow-hidden">
        <img :src="avatar" class="rounded" v-if="avatar"/>
        <img v-else class="rounded" src="~assets/images/no-image.png"/>
      </div>
    </template>
  </creation-stage>
</template>

<script>
import CreationStage from "../../../../components/CreationStage";
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import FileInput from "../../../../components/forms/FileInput";

export default {
  name: "avatar",
  components: {FileInput, TextInput, FormSubmit, CreationStage},
  data() {
    return {
      errors: [],
      form: {
        file: ''
      }
    }
  },
    computed: {
      avatar() {
        return this.$store.getters['user/GET_AVATAR']
      }
    },
    methods: {
      onSubmit() {
        let formData = new FormData
        formData.append('file', this.form.file)
        this.$axios.post(`/user/avatar`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
          .then(() => this.$router.push('/settings/account'))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>

<style scoped>

</style>
