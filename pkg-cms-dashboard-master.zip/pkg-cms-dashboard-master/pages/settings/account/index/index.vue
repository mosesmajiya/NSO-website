<template>
  <creation-stage subtitle="Manage your personal details" title="Personal Details">
    <div>
      <div v-if="data">
        <div>
          <p class="text-gray-500 text-sm">Name</p>
          <p>{{ data.name }}</p>
        </div>
        <div class="mt-5">
          <p class="text-gray-500 text-sm">Email</p>
          <p>{{ data.email }}</p>
        </div>
        <div class="mt-5">
          <p class="text-gray-500 text-sm">Created at</p>
          <p>{{ $moment(data.created_at).format('D MMM YYYY, h:mm a') }}</p>
        </div>
      </div>
    </div>
    <template slot="actions">
      <div class="rounded overflow-hidden">
        <img :src="avatar" class="rounded" v-if="avatar"/>
        <img v-else class="rounded" src="~assets/images/no-image.png"/>
      </div>
    </template>
  </creation-stage>
</template>

<script>
import CreationStage from "../../../../components/CreationStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import FormSubmit from "../../../../components/forms/FormSubmit";
import IndexStage from "../../../../components/IndexStage";

export default {
  name: "index",
  components: {IndexStage, FormSubmit, TextInput, FormActions, CreationStage},
  created() {
    if (!process.browser) return
    this.$axios.get('user').then(res => this.data = res.data.data)
  },
  computed: {
    avatar() {
      return this.$store.getters['user/GET_AVATAR']
    }
    }
  }
</script>

