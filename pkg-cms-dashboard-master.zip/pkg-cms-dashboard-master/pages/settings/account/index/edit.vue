<template>
  <creation-stage subtitle="Manage your personal details" title="Edit Personal Details">
    <form @submit.prevent="onSubmit">
      <p class="text-red-500 pb-5">{{ status }}</p>
      <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>
      <text-input @input="form.email = $event" label="Email" name="email" type="email" v-bind:error="errors.email"
                  v-bind:value="form.email"/>

      <hr class="my-10"/>
      <text-input @input="form.password = $event" label="Confirm action with password" name="password" type="password"
                  v-bind:error="errors.password"
                  v-bind:value="form.password"/>

      <form-submit accent="primary">Update</form-submit>
    </form>
    <template slot="actions">
      <div class="rounded overflow-hidden">
        <img :src="avatar" class="rounded" v-if="avatar"/>
        <img v-else class="rounded" src="~assets/images/no-image.png"/>
      </div>
    </template>
  </creation-stage>
</template>

<script>
import FormSubmit from "../../../../components/forms/FormSubmit";
import TextInput from "../../../../components/forms/TextInput";
import FormActions from "../../../../components/forms/FormActions";
import CreationStage from "../../../../components/CreationStage";

export default {
  name: "edit",
  components: {FormSubmit, TextInput, FormActions, CreationStage},
  created() {
    if (!process.browser) return
    this.$axios.get('user').then(res => this.form = res.data.data)
  },
  data() {
    return {
      namespace: 'account',
      menu: 'settings',
        status: '',
        errors: [],
        form: {
          email: '',
          name: ''
        }
      }
    },
    computed: {
      avatar() {
        return this.$store.getters['user/GET_AVATAR']
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`/user`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => {
            let status = err.response.data.status.code
            if (status === 412) this.status = err.response.data.status.message
            this.errors = err.response.data.status.errors
          })
      }
    }
  }
</script>

<style scoped>

</style>
