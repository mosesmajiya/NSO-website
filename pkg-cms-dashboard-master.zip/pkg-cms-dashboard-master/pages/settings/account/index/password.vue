<template>
  <creation-stage subtitle="Change credentials for your account" title="Change Password">
    <form @submit.prevent="onSubmit">
      <p class="text-red-500 pb-5">{{ status }}</p>
      <text-input @input="form.password = $event" label="Current password" name="password"
                  type="password" v-bind:error="errors.password"
                  v-bind:value="form.password"/>

      <text-input @input="form.new_password = $event" label="New password" name="new_password" type="password"
                  v-bind:error="errors.new_password"
                  v-bind:value="form.new_password"/>

      <text-input @input="form.new_password_confirmation = $event" label="Password Confirmation"
                  name="new_password_confirmation" type="password"
                  v-bind:error="errors.new_password_confirmation"
                  v-bind:value="form.new_password_confirmation"/>

      <form-submit accent="primary">Update</form-submit>
    </form>
    <template slot="actions">
      <div class="rounded overflow-hidden">
        <img :src="avatar" class="rounded" v-if="avatar"/>
        <img v-else class="rounded" src="~assets/images/no-image.png"/>
      </div>
    </template>
  </creation-stage>
</template>

<script>
import CreationStage from "../../../../components/CreationStage";
import TextInput from "../../../../components/forms/TextInput";
import FormSubmit from "../../../../components/forms/FormSubmit";

export default {
  name: "password",
  components: {FormSubmit, TextInput, CreationStage},
  data() {
    return {
      form: {
        password: '',
        new_password: '',
        new_password_confirmation: '',
      },
      errors: [],
        status: ''
      }
    },
    computed: {
      avatar() {
        return this.$store.getters['user/GET_AVATAR']
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`/user/password`, this.form)
          .then(() => this.$router.push(`/settings/account`))
          .catch(err => {
            this.errors = err.response.data.status.errors
            this.status = err.response.data.status.message
          })
      }
    }
  }
</script>

<style scoped>

</style>
