<template>
  <div>
    <div
      class="h-16 bg-gray-100 border-b border-gray-200 justify-between flex flex-row px-8 items-center text-gray-500 tertiary-nav">
      <div class="flex">
        <tab-item :to="`/${menu}/${namespace}`" class="flex items-center">
          <svg-user class="mr-2 h-6 w-6"/>
          Personal Details
        </tab-item>
        <tab-item :to="`/${menu}/${namespace}/edit`" class="flex items-center">
          <svg-pencil-alt class="h-6 w-6 mr-2"/>
          Edit
        </tab-item>
        <tab-item :to="`/${menu}/${namespace}/password`" class="flex items-center">
          <svg-lock-closed class="mr-2 h-6 w-6"/>
          Password
        </tab-item>
        <tab-item :to="`/${menu}/${namespace}/avatar`" class="flex items-center">
          <svg-avatar class="mr-2 w-6 h-6"/>
          Avatar
        </tab-item>
      </div>
    </div>
    <nuxt/>
  </div>
</template>

<script>
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";
import TabItem from "../../../components/tabItem";
import FaIcon from "../../../components/FaIcon";
import SvgUser from "@/components/icons/svg-user";
import SvgPencilAlt from "@/components/icons/svg-pencil-alt";
import SvgLockClosed from "@/components/icons/svg-lock-closed";
import SvgAvatar from "@/components/icons/svg-avatar";

export default {
  name: "index",
  components: {SvgAvatar, SvgLockClosed, SvgPencilAlt, SvgUser, FaIcon, TabItem, SettingsTabbedDetails},
  created() {
    this.$store.dispatch('user/FETCH_USER')
  },
  data() {
    return {
      namespace: 'account',
      menu: 'settings',
    }
  }
}
</script>
