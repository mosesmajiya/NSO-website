<template>
  <div>
    <contextual-menu menu="settings" namespace="branding"/>
    <base-stage subtitle="Manage site-wide branding" title="Site Branding">
      <form @submit.prevent="onSubmit" class="border p-8 pb-3 rounded bg-gray-100">
        <file-input class="mb-5" id="file" label="Logo" v-bind:error="errors.file" v-model="form.file"/>
        <form-submit accent="primary">Upload Logo</form-submit>
      </form>
      <div class="mt-8">
        <img :src="image" v-if="image">
      </div>
    </base-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../components/ContextualMenu";
import BaseStage from "../../components/BaseStage";
import FormSubmit from "../../components/forms/FormSubmit";
import MediaUpload from "../../components/forms/MediaUpload";
import FileInput from "../../components/forms/FileInput";

export default {
  name: "branding",
  components: {FileInput, MediaUpload, FormSubmit, BaseStage, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get('branding')
      .then(res => this.image = res.data.data)
  },
  data() {
    return {
      image: '',
      form: {
        file: ''
      },
      errors: [],
    }
    },
    methods: {
      onSubmit() {
        let formData = new FormData();
        formData.append('file', this.form.file)

        this.$axios.post(`branding`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
          .then(() => this.$router.go())
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>
