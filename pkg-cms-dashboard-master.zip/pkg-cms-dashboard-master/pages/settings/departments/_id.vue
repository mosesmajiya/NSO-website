<template>
  <settings-tabbed-details :menu="menu" :namespace="namespace" v-bind:data="data"/>
</template>

<script>
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";
import get_one_resource from "@/mixins/settings/get_one_resource";

export default {
  name: "_id",
  components: {SettingsTabbedDetails},
  mixins: [get_one_resource],
  data() {
    return {
      namespace: 'departments',
      menu: 'settings'
    }
  }
}
</script>
