<template>
  <editing-stage subtitle="Edit post type" title="Edit Post Type" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input @input="form.name = $event" label="Type Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>
      <text-input @input="form.rank = $event" label="Rank" name="rank" type="number"
                  v-bind:error="errors.rank" v-bind:value="form.rank"/>
      <paragraph-input @input="form.description = $event" label="Description" name="description"
                       v-bind:error="errors.description" v-bind:value="form.description"/>
      <div class="flex">
        <form-actions v-bind:to="`/${menu}/${namespace}`">Update</form-actions>
        <confirm-button
          @confirmed="onDelete"
          class="ml-4"
          label="Delete"
          message="This department together wil its posts will be deleted completely"
          title="Confirm Deletion"/>
      </div>
    </form>
  </editing-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import ConfirmButton from "../../../../components/ConfirmButton";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import get_one_resource from "@/mixins/settings/get_one_resource";

export default {
  name: "index",
  components: {ParagraphInput, ConfirmButton, TextInput, FormActions, EditingStage, ViewStage},
  mixins: [get_one_resource],
  data() {
    return {
      data: {},
      form: {
        name: '',
        description: '',
        rank: '',
      },
      errors: [],
      namespace: 'departments',
        menu: 'settings'
      }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      onDelete() {
        this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
