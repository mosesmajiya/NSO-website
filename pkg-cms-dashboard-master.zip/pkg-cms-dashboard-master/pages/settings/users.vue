<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "users"
  }
</script>

<style scoped>

</style>
