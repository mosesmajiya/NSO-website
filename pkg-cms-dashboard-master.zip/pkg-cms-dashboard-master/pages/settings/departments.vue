<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "departments"
  }
</script>

<style scoped>

</style>
