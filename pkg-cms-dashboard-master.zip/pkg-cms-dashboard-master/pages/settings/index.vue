<template>
  <div class="flex items-center justify-center text-gray-200 watermark">SETTINGS</div>
</template>

<script>
  import Landing from "../../components/landing";

  export default {
    name: "index",
    components: {Landing}
  }
</script>

<style scoped>
.watermark {
  font-size: 16rem;
}
</style>
