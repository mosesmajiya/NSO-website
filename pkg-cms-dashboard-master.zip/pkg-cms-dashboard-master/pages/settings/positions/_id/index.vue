<template>
  <editing-stage subtitle="Edit position" title="Edit Position" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input @input="form.name = $event" label="Type Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>
      <text-input @input="form.rank = $event" label="Rank" name="rank" type="number"
                  v-bind:error="errors.rank" v-bind:value="form.rank"/>
      <dropdown-input @change="form.department_id = $event" label="Department" name="department_id"
                      v-bind:error="errors.department_id" v-bind:options="departments"
                      v-bind:value="form.department_id"/>
      <div class="flex">
        <form-actions v-bind:to="`/${menu}/${namespace}`">Update</form-actions>
        <confirm-button
          @confirmed="onDelete"
          class="ml-4"
          label="Delete"
          message="This position will be deleted completely"
          title="Confirm Deletion"/>
      </div>
    </form>
  </editing-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import ConfirmButton from "../../../../components/ConfirmButton";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import DropdownInput from "../../../../components/forms/DropdownInput";

export default {
  name: "index",
  components: {DropdownInput, ParagraphInput, ConfirmButton, TextInput, FormActions, EditingStage, ViewStage},
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`positions/${this.$route.params.id}`)).data;
    await this.$store.dispatch('departments/FETCH_ITEMS')
    return {
      data: response.data,
      form: response.data
    }
  },
  data() {
    return {
      data: {},
      form: {
          name: '',
          department_id: '',
          rank: '',
        },
        errors: [],
        namespace: 'positions',
        menu: 'settings'
      }
    },
    computed: {
      departments() {
        return this.$store.getters['departments/GET_ITEMS'].map(department => {
          return {
            label: department.name,
            value: department.id
          }
        })
      }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      onDelete() {
        this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
