<template>
  <div>
    <navigate-back :to="`/${menu}/${namespace}`" v-bind:menu="menu" v-bind:namespace="namespace"/>
    <creation-stage heading-field="name" subtitle="Create a position" title="Create Position"
                    v-bind:namespace="namespace">
      <form @submit.prevent="onSubmit">
        <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name"/>
        <text-input @input="form.rank = $event" label="Rank" name="rank" type="number"
                    v-bind:error="errors.rank" v-bind:value="form.rank"/>

        <dropdown-input @change="form.department_id = $event" label="Department" name="department_id"
                        v-bind:error="errors.department_id" v-bind:options="departments"
                        v-bind:value="form.department_id"/>

        <form-actions v-bind:to="`/${menu}/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import FormActions from "../../../components/forms/FormActions";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import DropdownInput from "../../../components/forms/DropdownInput";

export default {
  name: "create",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  async created() {
    if (!process.browser) return
    await this.$store.dispatch('departments/FETCH_ITEMS')
  },
  data() {
    return {
      menu: 'settings',
      namespace: 'positions',
      form: {
        name: '',
        department_id: '',
        rank: '',
      },
        errors: []
      }
    },
    computed: {
      departments() {
        return this.$store.getters['departments/GET_ITEMS'].map(department => {
          return {
            label: department.name,
            value: department.id
          }
        })
      }
    },
    methods: {
      onSubmit() {
        this.$axios.post(`${this.namespace}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      }
    }
  }
</script>

