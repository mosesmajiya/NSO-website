<template>
  <settings-tabbed-details :menu="menu" :namespace="namespace" v-bind:data="data"/>
</template>

<script>
import SettingsTabbedDetails from "../../../components/SettingsTabbedDetails";

export default {
  name: "_id",
  components: {SettingsTabbedDetails},
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`positions/${this.$route.params.id}`)).data;
    this.data = response.data
  },
  data() {
    return {
      namespace: 'positions',
      menu: 'settings',
      data: {}
    }
  }
}
</script>
