<template>
  <div>
    <navigate-back :to="`/${menu}/${namespace}`" v-bind:menu="menu" v-bind:namespace="namespace"/>
    <creation-stage heading-field="name" subtitle="Create a user" title="Create User"
                    v-bind:namespace="namespace">
      <form @submit.prevent="onSubmit">
        <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                    v-bind:value="form.name"/>
        <text-input @input="form.email = $event" label="Email" name="email" type="email"
                    v-bind:error="errors.email" v-bind:value="form.email"/>

        <text-input @input="form.password = $event" label="Password" name="password" type="password"
                    v-bind:error="errors.password" v-bind:value="form.password"/>

        <form-actions v-bind:to="`/${menu}/${namespace}`"/>
      </form>
    </creation-stage>
  </div>
</template>

<script>
import NavigateBack from "../../../components/NavigateBack";
import CreationStage from "../../../components/CreationStage";
import FormActions from "../../../components/forms/FormActions";
import TextInput from "../../../components/forms/TextInput";
import ParagraphInput from "../../../components/forms/ParagraphInput";
import DropdownInput from "../../../components/forms/DropdownInput";

export default {
  name: "create",
  components: {DropdownInput, ParagraphInput, TextInput, FormActions, CreationStage, NavigateBack},
  created() {
    this.populateRoles()
  },
  data() {
    return {
      menu: 'settings',
      namespace: 'users',
      form: {
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
        roles: []
      },
      errors: []
    }
  },
  methods: {
    async populateRoles() {
      let roles = (await this.$axios.get('roles/admin')).data.data
      if (!roles.length) return
      this.form.roles.push(roles[0].id)
    },
    onSubmit() {
      this.$axios.post(`${this.namespace}`, this.form)
        .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
        .catch(err => this.errors = err.response.data.status.errors)
    }
  }

}
</script>

