<template>
  <editing-stage subtitle="Edit position" title="Edit Position" v-bind:data="data">
    <form @submit.prevent="onSubmit">
      <text-input @input="form.name = $event" label="Name" name="name" v-bind:error="errors.name"
                  v-bind:value="form.name"/>
      <text-input @input="form.email = $event" label="Email" name="email" type="email"
                  v-bind:error="errors.email" v-bind:value="form.email"/>
      <div class="flex">
        <form-actions v-bind:to="`/${menu}/${namespace}`">Update</form-actions>
        <confirm-button
          @confirmed="onDelete"
          class="ml-4"
          label="Delete"
          message="This user will be deleted completely"
          title="Confirm Deletion"/>
      </div>
    </form>
  </editing-stage>
</template>

<script>

import ViewStage from "../../../../components/ViewStage";
import EditingStage from "../../../../components/EditingStage";
import FormActions from "../../../../components/forms/FormActions";
import TextInput from "../../../../components/forms/TextInput";
import ConfirmButton from "../../../../components/ConfirmButton";
import ParagraphInput from "../../../../components/forms/ParagraphInput";
import DropdownInput from "../../../../components/forms/DropdownInput";

export default {
  name: "index",
  components: {DropdownInput, ParagraphInput, ConfirmButton, TextInput, FormActions, EditingStage, ViewStage},
  async created() {
    if (!process.browser) return
    let response = (await this.$axios.get(`users/${this.$route.params.id}`)).data.data;
    this.data = response
    this.form = response
  },
  data() {
    return {
      data: {},
      form: {
        name: '',
        email: '',
      },
      errors: [],
      namespace: 'users',
        menu: 'settings'
      }
    },
    methods: {
      onSubmit() {
        this.$axios.patch(`${this.namespace}/${this.$route.params.id}`, this.form)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
          .catch(err => this.errors = err.response.data.status.errors)
      },
      onDelete() {
        this.$axios.delete(`${this.namespace}/${this.$route.params.id}`)
          .then(() => this.$router.push(`/${this.menu}/${this.namespace}`))
      },
      togglePublish() {
        if (!this.data.published_at) {
          this.$axios.post(`${this.namespace}/${this.$route.params.id}/publish`)
            .then(response => this.data = response.data.data)
        } else {
          this.$axios.delete(`${this.namespace}/${this.$route.params.id}/unpublish`)
            .then(response => this.data = response.data.data)
        }
      }
    }
  }
</script>
