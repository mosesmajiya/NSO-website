<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "positions"
  }
</script>
