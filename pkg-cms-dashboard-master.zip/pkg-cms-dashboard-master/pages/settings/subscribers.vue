<template>
  <div>
    <contextual-menu :menu="menu" namespace="Subscribers"/>
    <index-stage :table="namespace" fields="email" @cancel="$router.go()" @loadeddata="data = $event">
      <div class="w-full p-5 bg-gray-100 text-gray-700">
        <div
          v-for="item in data.data"
          v-if="data.data && data.data.length"
          v-bind:id="item.id"
          v-bind:key="item.id"
          class="px-4 pb-2 flex items-center justify-between text-xs">
          <div class="leading-loose flex items-center">
            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path clip-rule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z"
                    fill-rule="evenodd"/>
            </svg>
            <span class="font-bold mr-2">{{ item.email }}</span>
            <span v-for="subscription in item.subscriptions" :key="subscription.id" class="italic mr-1">
              {{ subscription.name }},
            </span>
          </div>
          <div class="flex items-center">
            <span class="mr-2">{{ $moment(item.created_at).fromNow() }}</span>
            <confirm-icon
              :icon="actionIcon"
              custom-class="relative"
              title="Delete Confirmation"
              v-bind:message="`${item.email} will be permanently deleted.`"
              v-on:confirmed="destroy(item.id)"
            />
          </div>
        </div>
      </div>
      <pagination v-if="data.from" v-bind:paginator="data" @loadeddata="data = $event"/>
    </index-stage>
  </div>
</template>

<script>
import ContextualMenu from "../../components/ContextualMenu";
import IndexStage from "../../components/IndexStage";
import FaIcon from "../../components/FaIcon";
import Pagination from "../../components/Pagination";
import ConfirmButton from "../../components/ConfirmButton";
import ConfirmIcon from "../../components/ConfirmIcon";

export default {
  name: "subscribers",
  components: {ConfirmIcon, ConfirmButton, Pagination, FaIcon, IndexStage, ContextualMenu},
  created() {
    if (!process.browser) return
    this.$axios.get('subscribers').then(res => this.data = res.data.data)
  },
  data() {
    return {
      data: {},
      pageLinks: {},
      namespace: 'subscribers',
      menu: 'settings',
    }
  },
  props: {
    customClass: {
      type: String,
      required: true
    },
    filename: {
      type: String,
      required: true,
    },
    remark: {
      type: String,
      required: true
    },
    actionIcon: {
      type: String,
      default: 'trash'
    },
    linkIcon: {
      type: String,
      default: 'edit'
    },
    to: {
      required: true
    },
    id: {required: true}
  },
  methods: {
    destroy(id) {
      this.$axios.delete(`subscribers/${id}`)
        .then(() => {
          let subscribers = this.data.data
          subscribers.splice(subscribers.findIndex(i => i.id === id), 1)
        })
    }
  },
  computed: {
    navigateTo() {
      if (this.to) return this.to
      return `/cms/${this.namespace}/${this.$route.params.id}/`;
    }
  }
}
</script>
