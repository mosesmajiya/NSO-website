<template>
  <nuxt/>
</template>

<script>
  export default {
    name: "account"
  }
</script>

<style scoped>

</style>
