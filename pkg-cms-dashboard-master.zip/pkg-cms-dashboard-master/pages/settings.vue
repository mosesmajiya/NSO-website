<template>
  <div class="flex">
    <sidenav>
      <sidenav-section icon="settings" label="Content Settings">
        <sidenav-item to="/settings/post-types">Post Types</sidenav-item>
        <sidenav-item to="/settings/departments">Staff Departments</sidenav-item>
        <sidenav-item to="/settings/positions">Staff Positions</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="settings" label="Site Settings">
        <sidenav-item to="/settings/global">Global Settings</sidenav-item>
        <sidenav-item to="/settings/branding">Branding</sidenav-item>
        <sidenav-item to="/settings/footer-links">Footer Links</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="people" label="User Management">
        <sidenav-item to="/settings/users">Users</sidenav-item>
        <sidenav-item to="/settings/logs">User Activity</sidenav-item>
        <sidenav-item to="/settings/subscribers">Email Subscribers</sidenav-item>
        <sidenav-item to="/settings/account">My Account</sidenav-item>
      </sidenav-section>
    </sidenav>
    <nuxt class="flex-1"/>
  </div>
</template>

<script>
import Sidenav from "../components/Sidenav";
import SidenavSection from "../components/SidenavSection";
import SidenavItem from "../components/SidenavItem";

export default {
  name: "settings",
  components: {SidenavItem, SidenavSection, Sidenav}
}
</script>
