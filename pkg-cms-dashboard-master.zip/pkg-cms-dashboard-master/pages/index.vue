<template>
  <div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue'

  export default Vue.extend({
    created() {
      this.$router.push(`dashboard`)
    }
  })
</script>

