<template>
  <div class="flex">
    <sidenav>
      <sidenav-section v-if="hasCensus" action="Home Page" action-to="/cms/census/home" icon="trending_up" label="Quick Statistics">
      </sidenav-section>

      <sidenav-section v-if="hasCensus" action="new" action-to="/cms/census/create" icon="bubble_chart" label="Census">
        <sidenav-item v-for="(census, i) in censuses" :key="i" :to="`/cms/census/${census.year}/summary`">
          Year {{ census.year }}
        </sidenav-item>
      </sidenav-section>

      <sidenav-section v-if="hasReports" icon="pie_chart" label="Statistical Reports">
        <sidenav-item to="/cms/stat-report-super-categories">Report Super Categories</sidenav-item>
        <sidenav-item to="/cms/stat-report-categories">Report Categories</sidenav-item>
        <sidenav-item to="/cms/stat-reports">Statistical Reports</sidenav-item>
        <sidenav-item to="/cms/cpi-annual">CPI - Annual</sidenav-item>
        <sidenav-item to="/cms/cpi-monthly">CPI - Monthly</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="web" label="Pages">
        <sidenav-item to="/cms/about">About</sidenav-item>
        <sidenav-item v-if="hasCensus" to="/cms/districts">Districts</sidenav-item>
        <sidenav-item to="/cms/pages">Pages</sidenav-item>
        <sidenav-item to="/cms/faqCategories">FAQs</sidenav-item>
        <sidenav-item to="/cms/projects">Projects</sidenav-item>
        <sidenav-item v-if="hasServices" to="/cms/services">Services</sidenav-item>
        <sidenav-item to="/cms/departments">People</sidenav-item>
      </sidenav-section>


      <sidenav-section icon="rss_feed" label="Posts">
        <sidenav-item to="/cms/events">Events</sidenav-item>
        <sidenav-item to="/cms/posts">Posts</sidenav-item>
        <sidenav-item to="/cms/speeches">Speeches</sidenav-item>
        <sidenav-item to="/cms/reports">Reports</sidenav-item>
        <sidenav-item to="/cms/vacancies">Vacancies</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="collections" label="Collections">
        <sidenav-item to="/cms/youtube-videos">Youtube Videos</sidenav-item>
        <sidenav-item to="/cms/photoGalleries">Photo Galleries</sidenav-item>
        <sidenav-item to="/cms/portfolios">Portfolios</sidenav-item>
        <sidenav-item to="/cms/slider">Slider</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="subscriptions" label="Subscriptions">
        <sidenav-item to="/cms/newsletters">Newsletters</sidenav-item>
      </sidenav-section>

      <sidenav-section icon="cloud_download" label="Downloads">
        <sidenav-item to="/cms/public-downloads">Public Downloads</sidenav-item>
        <sidenav-item v-if="hasPrivateDownloads" to="/cms/private-downloads">Private Downloads</sidenav-item>
        <sidenav-item v-if="hasPrivateDownloads" to="/cms/downloads-users">Downloads Users</sidenav-item>
      </sidenav-section>
    </sidenav>
    <nuxt class="flex-1"/>
  </div>
</template>

<script>
import SidenavDivider from "../components/SidenavDivider";
import SidenavItem from "../components/SidenavItem";
import Sidenav from "../components/Sidenav";
import SidenavSection from "../components/SidenavSection";

export default {
  name: "cms",
  components: {SidenavSection, Sidenav, SidenavItem, SidenavDivider},
  async created() {
    if (this.hasCensus) {
      this.censuses = (await this.$axios.get('web/census')).data.data
    }
  },
  data() {
    return {
      censuses: [],
    }
  },
  computed: {
    hasCensus() {
      return this.getModules().includes('census')
    },
    hasReports() {
      return this.getModules().includes('reports')
    },
    hasServices() {
      return this.getModules().includes('services')
    },
    hasPrivateDownloads() {
      return this.getModules().includes('private-downloads')
    }
  },
  methods: {
    getModules() {
      let moduleString = localStorage.getItem('modules')
      return moduleString.split(',')
    }
  }
}
</script>
