<template>
  <div class="bg-gray-200">
    <div class="flex mb-8">
      <div class="w-1/5 mr-8">
        <div class="bg-primary-500 capitalize font-bold rounded-2xl px-8 py-4 text-primary-100 h-full">
          <p class="text-primary-200">Visitors Today</p>
          <p class="text-5xl">{{ visitsToday }}</p>
        </div>
      </div>
      <div class="w-1/5 mr-8">
        <div class="bg-primary-500 capitalize font-bold rounded-2xl px-8 py-4 text-primary-100 h-full">
          <p class="text-primary-200">{{ new Date | moment('MMMM') }} visitors</p>
          <p class="text-5xl">{{ visitsThisMonth }}</p>
        </div>
      </div>
      <div class="w-1/5 mr-8">
        <div class="bg-primary-500 capitalize font-bold rounded-2xl px-8 py-4 text-primary-100 h-full">
          <p class="text-primary-200">Total Email Subscribers</p>
          <p class="text-5xl">
            <nuxt-link to="/settings/subscribers">{{ subscribers }}</nuxt-link>
          </p>
        </div>
      </div>
      <div class="flex-grow">
        <div class="bg-white font-bold rounded-2xl px-8 py-4 text-gray-700 h-full">
          <p class="text-gray-600">Top Country Visits <span class="text-sm font-light">- past 6 months</span></p>
          <div class="flex justify-between">
            <div v-for="visit in countryVisits" :key="visit.country">
              <p class="text-3xl">{{ visit.value }}</p>
              <p class="text-sm font-normal text-gray-500">{{ visit.country }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="flex items-center">
      <div class="w-1/5 bg-white rounded-2xl mr-8">
        <div class="m-8">
          <user-agents class=""/>
        </div>
      </div>
      <div class="w-4/5 bg-white rounded-2xl">
        <div class="m-8">
          <daily-hits/>
        </div>
      </div>
    </div>
    <div class="flex mt-8 h-kfull">
      <div class="w-1/5 mr-8 flex items-center text-gray-600">
        <div class="bg-white rounded-2xl px-8 py-4 h-full w-full flex justify-between">
          <nuxt-link class="flex flex-col justify-center items-center hover:text-primary-500" to="/cms/posts/create">
            <svg-file class="w-12 h-12"/>
            <p class="text-xs">New Post</p>
          </nuxt-link>
          <nuxt-link to="/settings/users" class="flex flex-col justify-center items-center hover:text-primary-500">
            <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
            </svg>
            <p class="text-xs">Users</p>
          </nuxt-link>
          <nuxt-link to="/settings/logs" class="flex flex-col justify-center items-center hover:text-primary-500">
            <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path clip-rule="evenodd"
                    d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                    fill-rule="evenodd"></path>
            </svg>
            <p class="text-xs">Logs</p>
          </nuxt-link>
        </div>
      </div>
      <div class="flex-grow">
        <div class="bg-white rounded-2xl px-8 py-4 text-gray-700 h-full" v-if="popularReports.length">
          <p class="text-gray-600 pb-2">Popular Reports</p>
          <div class="flex justify-between">
            <div class="flex-1" v-for="report in popularReports">
              <p class="font-bold">{{ report.title  | str_limit(50) }}</p>
              <p class="text-xs"><span class="text-primary-500">{{ report.views }} views</span>
                <span>since {{ report.published_at | moment('Do MMMM') }}</span></p>
            </div>
          </div>
        </div>
        <div class="bg-white rounded-2xl px-8 py-4 text-gray-700 h-full" v-else>
          <p class="text-gray-600 pb-2">Popular Posts</p>
          <div class="flex justify-between">
            <div class="flex-1" v-for="article in popularArticles">
              <p class="font-bold">{{ article.title  | str_limit(50) }}</p>
              <p class="text-xs"><span class="text-primary-500">{{ article.views }} views</span>
                <span>since {{ article.published_at | moment('Do MMMM') }}</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Landing from "../components/landing";
import DailyHits from "@/components/dashboard/DailyHits";
import UserAgents from "@/components/dashboard/UserAgents";
import FaIcon from "@/components/FaIcon";
import SvgFile from "@/components/icons/svg-file";

export default {
  name: "dashboard",
  layout: "dashboard",
  components: {SvgFile, FaIcon, UserAgents, DailyHits, Landing},
  async created() {
    if (!process.browser) return
    await this.getSubscribers()
    await this.visitsByCountry()
    await this.getVisitsToday()
    await this.getVisitsThisMonth()
    await this.getPopularArticles()
    await this.getPopularReports()
  },
  data() {
    return {
      subscribers: 0,
      visitsToday: 0,
      visitsThisMonth: 0,
      countryVisits: [],
      popularArticles: [],
      popularReports: []
    }
  },
  methods: {
    async getSubscribers() {
      let subscribers = await this.$axios.get('dashboard/total-subscribers')
      this.subscribers = subscribers.data.data.total_subscribers
    },
    async visitsByCountry() {
      let countryVisits = await this.$axios.get('dashboard/visits-by-country')
      this.countryVisits = countryVisits.data.data
    },
    async getVisitsToday() {
      let visitsToday = await this.$axios.get('dashboard/visits-today')
      this.visitsToday = visitsToday.data.data.visitors_today
    },
    async getVisitsThisMonth() {
      let visitsThisMonth = await this.$axios.get('dashboard/visits-this-month')
      this.visitsThisMonth = visitsThisMonth.data.data.visitors_this_month
    },
    async getPopularArticles() {
      let popularArticles = await this.$axios.get('dashboard/popular-articles')
      this.popularArticles = popularArticles.data.data
    },
    async getPopularReports() {
      let popularReports = await this.$axios.get('dashboard/popular-reports')
      this.popularReports = popularReports.data.data
    }
  }
}
</script>
