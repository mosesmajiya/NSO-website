<template>
  <div :style="{ backgroundImage: 'url(https://source.unsplash.com/vOFp-XtwHDE/1600x900/)' }"
       class="flex flex-row items-center justify-center h-screen bg-cover">
    <div class="rounded w-120 bg-white">

      <div class="flex justify-center border-primary-200 border-b-0 rounded-t py-5 mx-8">
        <img v-bind:alt="settings.organization_name" v-bind:src="settings.logo"/>
      </div>

      <form @submit.prevent="onSubmit" class="px-8 border-primary-200 text-primary-500">

        <div class="text-red-500 pb-5" v-if="errorMessages.length">
          <p v-for="message in errorMessages">{{ message }}</p>
        </div>
        <div class="text-red-500 pb-5" v-else>
          {{ message }}
        </div>

        <div class="pb-5">
          <label> <span>Email</span>
            <input
              class="block w-full border border-primary-200 rounded mt-2 px-4 py-2 focus:outline-none focus:border-gray-500"
              name="email"
              v-model="form.email">
          </label>
        </div>

        <div class="pb-5">
          <label> <span>Password</span>
            <input
              class="block w-full border border-primary-200 rounded mt-2 px-4 py-2 focus:outline-none focus:border-gray-500"
              name="password" type="password"
              v-model="form.password">
          </label>
        </div>

        <button
          class="bg-white text-primary-500 border-primary-200 border rounded px-4 py-2 focus:outline-none -mb-5"
          type="submit">
          Sign in
        </button>
      </form>
      <div class="px-8 bg-primary-500 rounded-b py-8">
        <nuxt-link class="text-primary-100 text-xs hover:underline" to="/forgot-password">Forgot password?
        </nuxt-link>
      </div>
    </div>


  </div>
</template>

<script>
import TextInput from "../components/forms/TextInput";
import FormSubmit from "../components/forms/FormSubmit";
import Landing from "../components/landing";

export default {
  name: "login",
  components: {Landing, FormSubmit, TextInput},
  layout: 'login',
  head() {
    return {
      title: 'Login | ' + this.organizationName,
      meta: [
        // hid is used as unique identifier. Do not use `vmid` for it as it will not work
        {hid: 'description', name: 'description', content: this.settings.meta_description}
      ]
    }
  },
  data() {
    return {
      form: {
        email: '',
        password: ''
      },
      errors: {},
      message: '',
    }
  },
  created() {
    if (process.browser) {
      if (localStorage.getItem('token')) this.$router.push('/')
    }
    console.log(process.env.NUXT_ENV_API_URL)
  },
  methods: {
    onSubmit() {
      this.errors = []
      this.message = ''
      this.$axios.post('login', this.form)
        .then(response => {
          localStorage.setItem('user', response.data.data.name)
          localStorage.setItem('token', response.data.data.accessToken)
          localStorage.setItem('email', response.data.data.email)
          localStorage.setItem('modules', response.data.data.modules)
          this.$router.push('/')
          // window.location.href = '/'
          // this.$store.dispatch('auth/LOGIN', response.data.data)
        })
        .catch(err => {
          this.errors = err.response.data.status.errors
          this.message = err.response.data.status.message
        })
    }
  },
  computed: {
    organizationName() {
      return this.settings.organization_name ? this.settings.organization_name : 'Loading'
    },
    errorMessages() {
      return Object.values(this.errors);
    },
    settings() {
      return this.$store.state.settings
    }
  }
}
</script>
