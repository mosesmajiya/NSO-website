export default (context, inject) => {

  const stripFields = data => {
    let strippedData = {};
    Object.entries(data).forEach(([field, value]) => {
      if (value && value !== '') strippedData[field] = value
    })

    return strippedData;
  }

  inject('stripFields', stripFields)
  context.$stripFields = stripFields
}
