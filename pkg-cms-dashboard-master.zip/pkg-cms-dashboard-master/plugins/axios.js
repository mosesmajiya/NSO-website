export default function ({$axios, redirect, route}) {

  $axios.onRequest(config => {
    console.log('Making request to ' + config.url)
    if (process.browser) {
      config.headers['Authorization'] = 'Bearer ' + localStorage.getItem('token')
      config.headers['Accept'] = 'application/json'
    }
  })

  $axios.onError(error => {
    if (error.response && error.response.status === 401 && route.path !== '/login') {
      localStorage.clear();
      redirect('/login');
    }
  })

  $axios.onResponse(res => {
    let token = res.headers['x-refresh-token']
    if (token && process.browser) localStorage.setItem('token', token)
  })
}
