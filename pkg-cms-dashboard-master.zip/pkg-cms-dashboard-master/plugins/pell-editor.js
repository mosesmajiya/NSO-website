import Vue from 'vue'
import VuePellEditor from 'vue-pell-editor'

Vue.use(VuePellEditor)
