import Vue from 'vue';
import moment from "moment";

Vue.filter('str_limit', function (value, limit, delimiter = '...') {

  if (!value) return '';

  value = value.toString();

  if (value.length <= limit) return value;

  return value.substr(0, limit) + delimiter;

})

Vue.filter('from_now', function (value) {
  return moment(value).fromNow()
})

Vue.filter('moment', function (value, format) {
  return moment(value).format(format)
})


